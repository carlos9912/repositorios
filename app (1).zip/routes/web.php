<?php
use Carbon\Carbon;
use App\Enums\ESiNo;
use App\Models\Soat;
use App\Models\Pagos;
use App\Models\Venta;
use App\Models\Perfil;
use App\Models\Cliente;
use App\Models\Permiso;
use App\Models\Recarga;
use App\Models\Usuario;
use App\Models\Convenio;
use App\Models\Empleado;
use App\Models\Producto;
use App\Models\Sucursal;
use App\Models\Inventario;
use App\Models\Movimiento;
use Illuminate\Support\Str;
use App\Models\Consignaciones;
use App\Models\RecargaPaquete;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Arr;
$usuario = \Auth::user();
/*
 * |--------------------------------------------------------------------------
 * | Web routes
 * |--------------------------------------------------------------------------
 * |
 * | Here is where you can register web routes for your application. These
 * | routes are loaded by the RouteServiceProvider within a group which
 * | contains the "web" middleware group. Now create something great!
 * |
 */

Route::get('/empleado-error', function () {
    return view('errors.empleado-sucursal');
})->name(404);
Route::get('/empleado-bloqueo', function () {
    return view('errors.empleado-bloqueo');
})->name(404);
Route::get('/sucursal-bloqueo', function () {
    return view('errors.sucursal-bloqueo');
})->name(404);

Route::get('/', 'DashboardController@index');


Route::get('caja/limpiar', function () {
    DB::table('rel_sucursal_caja')->delete();
    return redirect()->route('transacciones');
});
Route::get('factura-consignacion', function () {
    $consignacion = Consignaciones::find(request('codconsignacion'));
    $convenio = Convenio::find($consignacion->codconvenio);
    $empleado = Empleado::find($consignacion->codempleado);
    //dd(\Auth::user());
    $sucursal = Sucursal::find($consignacion->codsucursal);    
    $pdf = new Fpdf();
    $pdf::AddPage('P',array(100,240));
    $pdf::Image('img/logo-factura.jpg',40,9,18);
    $pdf::SetMargins(5,1);
    $pdf::Ln();
    $pdf::SetFont('Helvetica','B',8);
    $pdf::Cell(55,5,'AFAINVERSIONES S.A.S',0,0,"L");
    $pdf::SetFont('Helvetica','B',4);
    $pdf::SetFont('Arial','B',5);
    $pdf::Ln();
    $pdf::Cell(55,2,'Nit. 901.192.632-6',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Carrera 13 No. 23 - 77 Oficina 102',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Bucaramanga - Santander',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('(7) 6960663 - 3205624402'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('Actividad ICA 306999'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(40,2,utf8_decode('Tarifa 7.2 x 1000'),0,0,"L");
    $pdf::Ln();
    
    $pdf::Ln(5);
    $pdf::Ln();
    $pdf::SetFont('Arial','B',6);
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FACTURA No. '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode('V-'.str_pad($consignacion->codconsignacion, 4, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FECHA'),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse(date('Y-m-d'))->format(trans('general.format_datetime'))),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CAJERO '),0,0,"L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,"R");
    //$pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CÓDIGO '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(str_pad($empleado->codempleado, 6, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln(7);
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('DETALLE CONSIGNACION'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',7);
    $pdf::Ln(7);
    
    $pdf::cell(15,3,utf8_decode('VIGENCIA HASTA'),0,"","L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse(date('Y-m-d'))->addDays(30)->format(trans('general.format_date'))),0,0,"R");
    $pdf::Ln(5);
    
    if($convenio->tiene_campos==2){
        $pdf::cell(15,3,utf8_decode('ENVÍA:'),0,"","L");
        $pdf::MultiCell(40,3,utf8_decode(strtoupper($consignacion->nombre_envia)),0,"R");
        //$pdf::Ln();
        $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
        $pdf::cell(40,3,utf8_decode(''.$consignacion->identificacion_envia),0,"","R");
        $pdf::Ln();
        $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
        $pdf::cell(40,3,utf8_decode(''.$consignacion->telefono_envia),0,"","R");
        $pdf::Ln();
        $pdf::cell(15,3,utf8_decode('ORIGEN'),0,"","L");
        $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->nombres)),0,"R");
        //$pdf::Ln();
        $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
        $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
        //$pdf::Ln();
        $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
        $pdf::cell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"","R");
        $pdf::Ln(6);
        $pdf::cell(15,3,utf8_decode('CUENTA No.'),0,"","L");
        $pdf::cell(40,3,utf8_decode($consignacion->numero_cuenta),0,"","R");
        $pdf::Ln();
        $pdf::cell(22,3,utf8_decode('TIPO CUENTA'),0,"","L");
        $pdf::cell(6,3,utf8_decode($consignacion->tipo_cuenta==2 ? 'X' : ''),'B',"","C");
        $pdf::cell(14,3,utf8_decode('AHORRO'),0,"","R");
        $pdf::cell(6,3,utf8_decode($consignacion->tipo_cuenta==3 ? 'X' : ''),'B',"","C");
        $pdf::cell(6,3,utf8_decode('CTE'),0,"","R");
        $pdf::Ln(4);
        $pdf::cell(15,3,utf8_decode('ENTIDAD'),0,"","L");
        $pdf::cell(40,3,utf8_decode($convenio->nombre),0,"","R");
        $pdf::Ln();
        $pdf::cell(15,3,utf8_decode('RECIBE'),0,"","L");
        $pdf::MultiCell(40,3,utf8_decode($consignacion->nombre_recibe),0,"R");
    
        $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
        $pdf::cell(40,3,utf8_decode($consignacion->identificacion_recibe),0,"","R");
        $pdf::Ln();
        $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
        $pdf::cell(40,3,utf8_decode($consignacion->telefono_recibe),0,"","R");
        $pdf::Ln();
    }else{
        $pdf::cell(15,3,utf8_decode('ENVÍA:'),0,"","L");
        $pdf::MultiCell(40,3,utf8_decode(strtoupper($consignacion->nombre_envia)),0,"R");
        //$pdf::Ln();
        $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
        $pdf::cell(40,3,utf8_decode(''.$consignacion->identificacion_envia),0,"","R");
        $pdf::Ln();
        $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
        $pdf::cell(40,3,utf8_decode(''.$consignacion->telefono_envia),0,"","R");
        $pdf::Ln();
        $pdf::cell(15,3,utf8_decode('ORIGEN'),0,"","L");
        $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->nombres)),0,"R");
        //$pdf::Ln();
        $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
        $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
        //$pdf::Ln();
        $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
        $pdf::cell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"","R");
        $pdf::Ln(6);
        $pdf::cell(15,3,utf8_decode('ENTIDAD'),0,"","L");
        $pdf::cell(40,3,utf8_decode($convenio->nombre),0,"","R");
        $pdf::Ln();
        $pdf::cell(15,3,utf8_decode('CONVENIO No.'),0,"","L");
        $pdf::cell(40,3,utf8_decode($consignacion->numero_cuenta),0,"","R");
        $pdf::Ln();
        $pdf::cell(15,3,utf8_decode('REFERENCIA'),0,"","L");
        $pdf::cell(40,3,utf8_decode($consignacion->identificacion_recibe),0,"","R");
        $pdf::Ln();
    }
    
    $pdf::cell(55,3,utf8_decode(''),'B',"","L");
    $pdf::Ln(8);
    $pdf::cell(15,3,utf8_decode('VALOR ENVIADO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($consignacion->valor)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('VALOR GIRO'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($consignacion->valor_tarifa)),0,"","R");
    
    $pdf::Ln();
    $pdf::cell(25,4,utf8_decode('VALOR TOTAL'),0,"","L", true);
    $pdf::cell(30,4,utf8_decode('$ '.number_format($consignacion->valor+$consignacion->valor_tarifa)),0,"","R", true);

    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('VALOR RECIBIDO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($consignacion->valor_recibido)),0,"","R");
    
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('CAMBIO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($consignacion->valor_recibido-($consignacion->valor+$consignacion->valor_tarifa))),0,"","R");
    
    $pdf::Ln(10);
    
    $pdf::cell(55,3,utf8_decode('Recibí Conforme'),'T',"","L");
    $pdf::Ln(6);
    $pdf::cell(55,3,utf8_decode('C.C.'),'T',"","L");
    $pdf::Ln(6);
    $pdf::SetFont('Arial','B',4.5);
    $pdf::MultiCell(55,2,utf8_decode('Este documento se asimila a la letra de cambio y le son aplicables los artículos 772 y siguientes del código de comercio La entrega se considera cumplida si al momento del recibo del giro por el destinatario no hay reclamación alguna aplican condiciones del contrato publicado en la página web con la solicitud y aceptación de este servicio entiéndase que manifiesto verbalmente mi autorización para el tratamiento de los datos personales que voluntariamente he entregado a AFA INVERSIONES S.A.S Estos datos pueden ser utilizados única y exclusivamente para la presentación del servicio convenido'),0,'J');
    $pdf::MultiCell(55,3,utf8_decode('Linea de servicio al cliente: (7) 6960663 info@afainversiones.com www.afainversiones.com'),0,'C');


    $pdf::Output();
    exit;
});

Route::get('factura-soat', function () {
    $soat = Soat::find(request('codsoat'));
    $empleado = Empleado::find($soat->codempleado);
    //dd(\Auth::user());
    $sucursal = Sucursal::find($soat->codsucursal);    
    $pdf = new Fpdf();
    
    
    $pdf::AddPage('P',array(100,200));
    
    $response = json_decode($soat->response, true);
    $data = $response["data"];
    //$pdf::Image('img/logo-factura.jpg',40,9,18);
    $pdf::SetMargins(5,1);
    $pdf::Ln();
    $pdf::SetFont('Helvetica','B',8);
    $pdf::Cell(55,5,'AXA COLPATRIA SEGUROS S.A',0,0,"C");
    $pdf::SetFont('Helvetica','B',4);
    $pdf::SetFont('Arial','B',5);
    $pdf::Ln();
    $pdf::Cell(55,2,'Nit. 860.002.184-6',0,0,"C");
    $pdf::Ln();
    
    $pdf::SetFont('Arial','B',6);
    
    $pdf::Ln(3);
    
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('INFORMACION DE LA POLIZA'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',7);
    $pdf::Ln(7);
    $pdf::cell(15,3,utf8_decode('FECHA EXPEDICIÓN'),0,"","L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($soat->fecha)->format(trans('general.format_datetime'))),0,0,"R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('INICIO VIGENCIA'),0,"","L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($data["start_date"])->format(trans('general.format_datetime'))),0,0,"R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('FIN VIGENCIA'),0,"","L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($data["end_date"])->format(trans('general.format_datetime'))),0,0,"R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('No. POLIZA'),0,"","L");
    $pdf::Cell(40,3,utf8_decode($data["insurance_id"]),0,0,"R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('PRIMA SOAT'),0,"","L");
    $pdf::Cell(40,3,utf8_decode($data["insurance_amount"]),0,0,"R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('CONTRIBUCIÓN'),0,"","L");
    $pdf::Cell(40,3,utf8_decode($data["tax1_amount"]),0,0,"R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('RUNT'),0,"","L");
    $pdf::Cell(40,3,utf8_decode($data["runt_amount"]),0,0,"R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TOTAL A PAGAR'),0,"","L");
    $pdf::Cell(40,3,utf8_decode($data["total_amount"]),0,0,"R");
    $pdf::Ln(7);
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('INFORMACION DEL CORRESPONSAL'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',7);

    $pdf::Ln(7);
    
    $pdf::Cell(55,3,'AFAINVERSIONES S.A.S',0,0,"C");
    
    $pdf::Ln(4);
    $pdf::Cell(55,3,'Nit. 901.192.632-6',0,0,"C");

    $pdf::Ln(4);
    $pdf::Cell(15,3,utf8_decode('FACTURA No. '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode('R-'.str_pad($soat->codsoat, 4, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FECHA'),0,0,"L");
    $pdf::Cell(40,3,utf8_decode($soat->fecha),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CAJERO '),0,0,"L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,"R");
    //$pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CÓDIGO '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(str_pad($empleado->codempleado, 6, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln(7);
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('INFORMACION DEL TOMADOR'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',5);

    $pdf::Ln(7);
    $pdf::cell(15,3,utf8_decode('TOMADOR'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode($data["client_name"]),0,"R");
    //$pdf::Ln();
    $documentos = ["C" => "CC","N"=>"NIT", "T" => "TI", "E" => "CE"];

    $pdf::cell(15,3,utf8_decode('DOCUMENTO'),0,"","L");
    $pdf::Cell(40,3,utf8_decode($documentos[$soat->tipo_identificacion].' '.$data["client_id"]),0,0,"R");
    $pdf::Ln(5);
    $pdf::MultiCell(55,2,utf8_decode('Se solicita información al tomador para tratamiento de sus datos y se le informa que las políticas tratamiento de datos y la posibilidad de modificarlos o eliminarlos están en la pagina www.axacolpatria.co'),0,'C');
    //$pdf::Cell(40,3,utf8_decode(''),0,0,"R");
    //$pdf::Cell(40,3,utf8_decode($data["client_name"]),0,0,"R");
    $pdf::Ln();
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('INFORMACION DEL VEHICULO'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',5);

    $pdf::Ln(7);
    $pdf::cell(15,2.5,utf8_decode('SERVICIO'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["service_type"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('CILINDRAJE'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["engine"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('MODELO'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["model"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('PLACA'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["vehicle_id"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('MARCA'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["trademark"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('LINEA'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["type"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('PASAJEROS'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["passengers"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('CAPACIDAD'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["capacity"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('CLASE'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["class"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('No. MOTOR'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["motor_id"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('No. CHASIS'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["chassis_id"]),0,"R");
    $pdf::cell(15,2.5,utf8_decode('No. VIN'),0,"","L");
    $pdf::MultiCell(40,2.5,utf8_decode($data["vin_id"]),0,"R");
    $pdf::Ln(4);
    $pdf::SetFont('Arial','B',4.5);
    $pdf::MultiCell(55,2,utf8_decode('Conserva tu recibo y descarga tu póliza en https://clientes.axacolpatria.co/descargar y consulta la póliza en la página web del registro único de transito www.runt.co opción ciudadanos 24 horas después de la expedición de la póliza.'),0,'J');
    $pdf::MultiCell(55,3,utf8_decode('Linea de servicio al cliente: (7) 6960663 info@afainversiones.com www.afainversiones.com'),0,'C');



    $pdf::Output();
    exit();
    $pdf::cell(15,3,utf8_decode('VIGENCIA HASTA'),0,"","L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse(date('Y-m-d'))->addDays(30)->format(trans('general.format_date'))),0,0,"R");
    $pdf::Ln(5);
    $pdf::cell(15,3,utf8_decode('ENVÍA:'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($consignacion->nombre_envia)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$consignacion->identificacion_envia),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$consignacion->telefono_envia),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('ORIGEN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::cell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('CUENTA No.'),0,"","L");
    $pdf::cell(40,3,utf8_decode($consignacion->numero_cuenta),0,"","R");
    $pdf::Ln();
    $pdf::cell(22,3,utf8_decode('TIPO CUENTA'),0,"","L");
    $pdf::cell(6,3,utf8_decode($consignacion->tipo_cuenta==2 ? 'X' : ''),'B',"","C");
    $pdf::cell(14,3,utf8_decode('AHORRO'),0,"","R");
    $pdf::cell(6,3,utf8_decode($consignacion->tipo_cuenta==3 ? 'X' : ''),'B',"","C");
    $pdf::cell(6,3,utf8_decode('CTE'),0,"","R");
    $pdf::Ln(4);
    $pdf::cell(15,3,utf8_decode('ENTIDAD'),0,"","L");
    $pdf::cell(40,3,utf8_decode($convenio->nombre),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('RECIBE'),0,"","L");
    $pdf::cell(40,3,utf8_decode($consignacion->nombre_recibe),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
    $pdf::cell(40,3,utf8_decode($consignacion->identificacion_recibe),0,"","R");
    $pdf::Ln();
    $pdf::cell(55,3,utf8_decode(''),'B',"","L");
    $pdf::Ln(8);
    $pdf::cell(15,3,utf8_decode('VALOR ENVIADO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($consignacion->valor)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('VALOR GIRO'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($consignacion->valor_tarifa)),0,"","R");
    
    $pdf::Ln();
    $pdf::cell(25,4,utf8_decode('VALOR TOTAL'),0,"","L", true);
    $pdf::cell(30,4,utf8_decode('$ '.number_format($consignacion->valor+$consignacion->valor_tarifa)),0,"","R", true);

    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('VALOR RECIBIDO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($consignacion->valor_recibido)),0,"","R");
    
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('CAMBIO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($consignacion->valor_recibido-($consignacion->valor+$consignacion->valor_tarifa))),0,"","R");
    
    $pdf::Ln(10);
    
    $pdf::cell(55,3,utf8_decode('Recibí Conforme'),'T',"","L");
    $pdf::Ln(6);
    $pdf::cell(55,3,utf8_decode('C.C.'),'T',"","L");
    $pdf::Ln(6);
    $pdf::SetFont('Arial','B',4.5);
    $pdf::MultiCell(55,2,utf8_decode('Este documento se asimila a la letra de cambio y le son aplicables los artículos 772 y siguientes del código de comercio La entrega se considera cumplida si al momento del recibo del giro por el destinatario no hay reclamación alguna aplican condiciones del contrato publicado en la página web con la solicitud y aceptación de este servicio entiéndase que manifiesto verbalmente mi autorización para el tratamiento de los datos personales que voluntariamente he entregado a AFA INVERSIONES S.A.S Estos datos pueden ser utilizados única y exclusivamente para la presentación del servicio convenido'),0,'J');
    $pdf::MultiCell(55,3,utf8_decode('Linea de servicio al cliente: (7) 6960663 info@afainversiones.com www.afainversiones.com'),0,'C');


    $pdf::Output();
    exit;
});

Route::get('factura-recarga', function () {
    $recarga = Recarga::find(request('codrecarga'));
    $recargaPaquete = DB::table('recargas_paquetes')->where('codigo','=',$recarga->codrecpaq)->first();
    $empleado = Empleado::find($recarga->codempleado);
    //dd(\Auth::user());
    $sucursal = Sucursal::find($recarga->codsucursal);    
    $pdf = new Fpdf();
    if($recarga->tipo==3){
        $recargaPaquete = DB::table('recargas_paquetes')->where('codigo','=',21)->first();
        $recarga->numero = $recarga->codrecpaq.' - '.$recarga->numero;
    }
    if($recargaPaquete->tiene_retorno==2){
        $pdf::AddPage('P',array(100,180));
    }else{
        $pdf::AddPage('P',array(100,200));
    }
    $response = json_decode($recarga->response, true);
    $data = $response["data"];
    $pdf::Image('img/logo-factura.jpg',40,9,18);
    $pdf::SetMargins(5,1);
    $pdf::Ln();
    $pdf::SetFont('Helvetica','B',8);
    $pdf::Cell(55,5,'AFAINVERSIONES S.A.S',0,0,"L");
    $pdf::SetFont('Helvetica','B',4);
    $pdf::SetFont('Arial','B',5);
    $pdf::Ln();
    $pdf::Cell(55,2,'Nit. 901.192.632-6',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Carrera 13 No. 23 - 77 Oficina 102',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Bucaramanga - Santander',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('(7) 6960663 - 3205624402'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('Actividad ICA 306999'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(40,2,utf8_decode('Tarifa 7.2 x 1000'),0,0,"L");
    $pdf::Ln();
    
    $pdf::Ln(5);
    $pdf::Ln();
    $pdf::SetFont('Arial','B',6);
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FACTURA No. '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode('R-'.str_pad($recarga->codrecarga, 4, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FECHA'),0,0,"L");
    $pdf::Cell(40,3,utf8_decode($recarga->fecha),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CAJERO '),0,0,"L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,"R");
    //$pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CÓDIGO '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(str_pad($empleado->codempleado, 6, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln(7);
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('DETALLE RECARGA'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',7);
    $pdf::Ln(7);
    $pdf::cell(15,3,utf8_decode('NUMERO'),0,"","L");
    $pdf::Cell(40,3,utf8_decode($recarga->numero),0,0,"R");
    $pdf::Ln(5);
    
    $pdf::cell(15,3,utf8_decode('OPERADOR'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strip_tags($recargaPaquete->nombre)),0,"R", true);
    $pdf::Ln(2);
    if($recargaPaquete->tiene_retorno==1){
        $pdf::Ln(2);
        if(Arr::exists($data, "count") && $data["count"]>0){
            for($i=0; $i<$data["count"]; $i++){
                $pdf::cell(15,3,utf8_decode('PIN'.($i+1)),0,"","L");
                $pdf::Cell(40,3,utf8_decode(Arr::exists($data, "pin".($i+1)) && !blank($data["pin".($i+1)]) ? $data["pin".($i+1)] : 'ERROR'),0,0,"R");
                $pdf::Ln(3);
            }
        }
    } else if($recarga->tipo==3){
        $pdf::Ln(2);
        foreach (json_decode($recarga->datos) as $nombre => $valor) {
            $pdf::Cell(15,3,utf8_decode(strtoupper($nombre)),0,"","L");
            $pdf::MultiCell(40,3,utf8_decode(strtoupper($valor)),0,"R");
            
        }
    }
    $pdf::Ln(2);
    $pdf::cell(15,3,utf8_decode('VALOR'),0,"","L");
    $pdf::Cell(40,3,utf8_decode('$ '.number_format($recarga->valor)),0,0,"R");
    $pdf::Ln(5);
    
    $pdf::cell(15,3,utf8_decode('SUCURSAL'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::cell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"","R");
    
    $pdf::Ln(6);
    $pdf::SetFont('Arial','B',4.5);
    $pdf::MultiCell(55,2,utf8_decode('Este documento se asimila a la letra de cambio y le son aplicables los artículos 772 y siguientes del código de comercio La entrega se considera cumplida si al momento del recibo del giro por el destinatario no hay reclamación alguna aplican condiciones del contrato publicado en la página web con la solicitud y aceptación de este servicio entiéndase que manifiesto verbalmente mi autorización para el tratamiento de los datos personales que voluntariamente he entregado a AFA INVERSIONES S.A.S Estos datos pueden ser utilizados única y exclusivamente para la presentación del servicio convenido'),0,'J');
    $pdf::MultiCell(55,3,utf8_decode('Linea de servicio al cliente: (7) 6960663 info@afainversiones.com www.afainversiones.com'),0,'C');



    $pdf::Output();
    exit;
    $pdf::cell(15,3,utf8_decode('VIGENCIA HASTA'),0,"","L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse(date('Y-m-d'))->addDays(30)->format(trans('general.format_date'))),0,0,"R");
    $pdf::Ln(5);
    $pdf::cell(15,3,utf8_decode('ENVÍA:'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($consignacion->nombre_envia)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$consignacion->identificacion_envia),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$consignacion->telefono_envia),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('ORIGEN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::cell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('CUENTA No.'),0,"","L");
    $pdf::cell(40,3,utf8_decode($consignacion->numero_cuenta),0,"","R");
    $pdf::Ln();
    $pdf::cell(22,3,utf8_decode('TIPO CUENTA'),0,"","L");
    $pdf::cell(6,3,utf8_decode($consignacion->tipo_cuenta==2 ? 'X' : ''),'B',"","C");
    $pdf::cell(14,3,utf8_decode('AHORRO'),0,"","R");
    $pdf::cell(6,3,utf8_decode($consignacion->tipo_cuenta==3 ? 'X' : ''),'B',"","C");
    $pdf::cell(6,3,utf8_decode('CTE'),0,"","R");
    $pdf::Ln(4);
    $pdf::cell(15,3,utf8_decode('ENTIDAD'),0,"","L");
    $pdf::cell(40,3,utf8_decode($convenio->nombre),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('RECIBE'),0,"","L");
    $pdf::cell(40,3,utf8_decode($consignacion->nombre_recibe),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
    $pdf::cell(40,3,utf8_decode($consignacion->identificacion_recibe),0,"","R");
    $pdf::Ln();
    $pdf::cell(55,3,utf8_decode(''),'B',"","L");
    $pdf::Ln(8);
    $pdf::cell(15,3,utf8_decode('VALOR ENVIADO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($consignacion->valor)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('VALOR GIRO'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($consignacion->valor_tarifa)),0,"","R");
    
    $pdf::Ln();
    $pdf::cell(25,4,utf8_decode('VALOR TOTAL'),0,"","L", true);
    $pdf::cell(30,4,utf8_decode('$ '.number_format($consignacion->valor+$consignacion->valor_tarifa)),0,"","R", true);

    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('VALOR RECIBIDO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($consignacion->valor_recibido)),0,"","R");
    
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('CAMBIO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($consignacion->valor_recibido-($consignacion->valor+$consignacion->valor_tarifa))),0,"","R");
    
    $pdf::Ln(10);
    
    $pdf::cell(55,3,utf8_decode('Recibí Conforme'),'T',"","L");
    $pdf::Ln(6);
    $pdf::cell(55,3,utf8_decode('C.C.'),'T',"","L");
    $pdf::Ln(6);
    $pdf::SetFont('Arial','B',4.5);
    $pdf::MultiCell(55,2,utf8_decode('Este documento se asimila a la letra de cambio y le son aplicables los artículos 772 y siguientes del código de comercio La entrega se considera cumplida si al momento del recibo del giro por el destinatario no hay reclamación alguna aplican condiciones del contrato publicado en la página web con la solicitud y aceptación de este servicio entiéndase que manifiesto verbalmente mi autorización para el tratamiento de los datos personales que voluntariamente he entregado a AFA INVERSIONES S.A.S Estos datos pueden ser utilizados única y exclusivamente para la presentación del servicio convenido'),0,'J');
    $pdf::MultiCell(55,3,utf8_decode('Linea de servicio al cliente: (7) 6960663 info@afainversiones.com www.afainversiones.com'),0,'C');


    $pdf::Output();
    exit;
});

Route::get('factura-pago', function () {
    $pago = Pagos::find(request('codpago'));
    
    $convenio = Convenio::find($pago->codconvenio);
    $empleado = Empleado::find($pago->codempleado);
    //dd(\Auth::user());
    $sucursal = Sucursal::find($pago->codsucursal);    
    $pdf = new Fpdf();

    $pdf::AddPage('P',array(100,160));
    $pdf::Image('img/logo-factura.jpg',40,9,18);
    $pdf::SetMargins(5,1);
    $pdf::Ln();
    $pdf::SetFont('Helvetica','B',8);
    $pdf::Cell(55,5,'AFAINVERSIONES S.A.S',0,0,"L");
    $pdf::SetFont('Helvetica','B',4);
    $pdf::SetFont('Arial','B',5);
    $pdf::Ln();
    $pdf::Cell(55,2,'Nit. 901.192.632-6',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Carrera 13 No. 23 - 77 Oficina 102',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Bucaramanga - Santander',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('(7) 6960663 - 3205624402'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('Actividad ICA 306999'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(40,2,utf8_decode('Tarifa 7.2 x 1000'),0,0,"L");
    $pdf::Ln();
    
    $pdf::Ln(1);
    $pdf::Ln();
    $pdf::SetFont('Arial','B',6);
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FACTURA No. '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode('P-'.str_pad($pago->codpago, 4, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FECHA'),0,0,"L");
    $pdf::Cell(40,3,utf8_decode($pago->fecha),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CAJERO '),0,0,"L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,"R");
    //$pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CÓDIGO '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(str_pad($empleado->codempleado, 6, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln(7);
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('DETALLE PAGO'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',7);
    $pdf::Ln(7);
    $pdf::Cell(15,3,utf8_decode('CONVENIO:'),0,"","L");
    $pdf::Ln();
    $pdf::MultiCell(55,5,utf8_decode($convenio->nombre),0,"L", true);
    $pdf::Ln(2);
    foreach (json_decode($pago->campos_js) as $nombre => $valor) {
        $pdf::SetFont('Arial','',5);
        $alturaT = $pdf::GetStringWidth($nombre);
        if($alturaT>25){
            $pdf::Cell(20,3,utf8_decode($nombre),0,"","L");
            $pdf::Ln();
            $pdf::Cell(20,3,'',0,"","L");
            $pdf::SetFont('Arial','B',5);
            $pdf::MultiCell(35,3,utf8_decode(strtoupper($valor)),0,"R");
        }else{
            $pdf::Cell(20,3,utf8_decode($nombre),0,"","L");
            $pdf::SetFont('Arial','B',5);
            $pdf::MultiCell(35,3,utf8_decode(strtoupper($valor)),0,"R");
        }
        
    }
    
    if($convenio->codcategoria==4){

        //$pdf::Ln(8);
        $pdf::cell(15,3,utf8_decode('VALOR ENVIADO'),0,"","L");
        $pdf::cell(40,3,utf8_decode('$ '.number_format($pago->valor)),0,"","R");
        $pdf::Ln();
        $pdf::cell(15,4,utf8_decode('VALOR GIRO'),0,"","L");
        $pdf::cell(40,4,utf8_decode('$ '.number_format($pago->valor_tarifa)),0,"","R");
        
        $pdf::Ln();
        $pdf::cell(25,4,utf8_decode('VALOR TOTAL'),0,"","L", true);
        $pdf::cell(30,4,utf8_decode('$ '.number_format($pago->valor+$pago->valor_tarifa)),0,"","R", true);
    
        $pdf::Ln();
        $pdf::cell(15,4,utf8_decode('VALOR RECIBIDO'),0,"","L");
        $pdf::cell(40,3,utf8_decode('$ '.number_format($pago->valor_recibido)),0,"","R");
        
        $pdf::Ln();
        $pdf::cell(15,4,utf8_decode('CAMBIO'),0,"","L");
        $pdf::cell(40,3,utf8_decode('$ '.number_format($pago->valor_recibido-($pago->valor+$pago->valor_tarifa))),0,"","R");
        $pdf::Ln(5);
        
    }else{
        $pdf::cell(15,3,utf8_decode('VALOR'),0,"","L");
        $pdf::Cell(40,3,utf8_decode('$ '.number_format($pago->valor)),0,0,"R");
        $pdf::Ln(5);
    }
    $pdf::cell(15,3,utf8_decode('SUCURSAL'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::cell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"","R");
    
    $pdf::Ln(5);
    $pdf::MultiCell(55,3,utf8_decode('ESTE PAGO SE REGISTRARÁ DURANTE UN PLAZO MÁXIMO DE 24 HORAS'),0,"C", true);
    $pdf::Ln(2);
    $pdf::SetFont('Arial','B',4.5);
    $pdf::MultiCell(55,2,utf8_decode('Este documento se asimila a la letra de cambio y le son aplicables los artículos 772 y siguientes del código de comercio La entrega se considera cumplida si al momento del recibo del giro por el destinatario no hay reclamación alguna aplican condiciones del contrato publicado en la página web con la solicitud y aceptación de este servicio entiéndase que manifiesto verbalmente mi autorización para el tratamiento de los datos personales que voluntariamente he entregado a AFA INVERSIONES S.A.S Estos datos pueden ser utilizados única y exclusivamente para la presentación del servicio convenido'),0,'J');
    $pdf::MultiCell(55,3,utf8_decode('Linea de servicio al cliente: (7) 6960663 info@afainversiones.com www.afainversiones.com'),0,'C');



    $pdf::Output();
    exit;
    
});
Route::get('factura', function () {
    if(blank(request('m'))){
        $last_m = DB::table('movimientos')->orderBy('codmovimiento','DESC')->first();
        $movimiento = Movimiento::find($last_m->codmovimiento);
    }else{
        $movimiento = Movimiento::find((request('m')));
    }
    $empleado = Empleado::find($movimiento->cod_empleado_envia);
    $sucursal = Sucursal::find($movimiento->codsucursal);
    if(!blank($movimiento->cod_sucursal_retira)){
        $sucursal = Sucursal::find($movimiento->cod_sucursal_retira);
    }
    $sucursalEnvia = Sucursal::find($movimiento->cod_sucursal_envia);
    $cliente=Cliente::find($movimiento->codcliente_envia);
    $clienteRecibe = DB::table('clientes AS c')->where('identificacion','=',$movimiento->identificacion_recibe)->first();
    //dd($movimiento);
    $clienteRecibeDto=Cliente::find($movimiento->codcliente_recibe);
    //dd($clienteRecibeDto);
    //$cliente=Cliente::find($cliente->codcliente);
    $tarifa = DB::table('tarifas AS t')->where('codtarifa','=',$movimiento->codtarifa)->first();
    $venta = Venta::find(1);
    $usuario = Usuario::find($venta->cod_punto);
    $inventario = Inventario::find($venta->codinventario);
    $producto = Producto::find($inventario->codproducto);
    
    $pdf = new Fpdf();
    $pdf::AddPage('P',array(100,240));
    $pdf::Image('img/logo-factura.jpg',40,9,18);
    $pdf::SetMargins(5,1);
    $pdf::Ln();
    $pdf::SetFont('Helvetica','B',8);
    $pdf::Cell(55,5,'AFAINVERSIONES S.A.S',0,0,"L");
    $pdf::SetFont('Helvetica','B',4);
    $pdf::SetFont('Arial','B',5);
    $pdf::Ln();
    $pdf::Cell(55,2,'Nit. 901.192.632-6',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Carrera 13 No. 23 - 77 Oficina 102',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Bucaramanga - Santander',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('(7) 6960663 - 3205624402 '),0,0,"L");
    $pdf::Ln();
    
    $pdf::Cell(55,2,utf8_decode('Actividad ICA 306999'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(40,2,utf8_decode('Tarifa 7.2 x 1000'),0,0,"L");
    $pdf::Ln();
    
    $pdf::Ln(5);
    $pdf::Ln();
    $pdf::SetFont('Arial','B',6);
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FACTURA No. '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode('V-'.str_pad($movimiento->codmovimiento, 4, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FECHA '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($movimiento->fecha_transaccion)->format(trans('general.format_datetime'))),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CAJERO '),0,0,"L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,"R");
    //$pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CÓDIGO '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(str_pad($empleado->codempleado, 6, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln(7);
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('DETALLE GIRO'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',7);
    $pdf::Ln(7);
    
    $pdf::cell(15,3,utf8_decode('VIGENCIA HASTA'),0,"","L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($movimiento->fecha_transaccion)->addDays(30)->format(trans('general.format_date'))),0,0,"R");
    $pdf::Ln(5);
    $pdf::cell(15,3,utf8_decode('ENVÍA:'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($cliente->nombreCompleto())),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$cliente->identificacion),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$cliente->celular),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('ORIGEN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->barrio)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode(''),0,"","L");
    $pdf::cell(40,3,utf8_decode(''),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('PUNTO ENVÍO'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''),0,"","R");
    $pdf::Ln(7);
    $pdf::cell(15,3,utf8_decode('RECIBE'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper(blank($clienteRecibeDto) ? $movimiento->nombres_recibe.' '.$movimiento->apellidos_recibe : $clienteRecibeDto->nombreCompleto())),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('CC.'),0,"","L");
    $pdf::cell(40,3,utf8_decode((blank($clienteRecibeDto) ? $movimiento->identificacion_recibe : $clienteRecibeDto->identificacion)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
    $pdf::cell(40,3,utf8_decode(blank($clienteRecibeDto) ? $movimiento->celular_recibe : $clienteRecibeDto->celular ),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DESTINO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"R");
    //$pdf::Ln();
    $pdf::cell(55,3,utf8_decode(''),'B',"","L");
    $pdf::Ln(8);
    $pdf::cell(15,3,utf8_decode('VALOR ENVIADO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($movimiento->valor)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('VALOR GIRO'),0,"","L");
    $costo = $tarifa->costo==0 ? ($tarifa->porcentaje*$movimiento->valor/100) : ($tarifa->costo) + ($tarifa->porcentaje*$movimiento->valor/100);
    $pdf::cell(40,3,utf8_decode('$ '.number_format($costo)),0,"","R");
    $pdf::Ln(8);
    $pdf::cell(15,3,utf8_decode('VALOR RECIBIDO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($movimiento->valor_recibido)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('CAMBIO'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($movimiento->valor_recibido-($costo+$movimiento->valor))),0,"","R");
    $pdf::Ln(8);
    $pdf::cell(15,4,utf8_decode('VALOR TOTAL'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($costo+$movimiento->valor)),0,"","R");
    $pdf::Ln(10);
    $pdf::cell(55,3,utf8_decode('Recibí Conforme'),'T',"","L");
    $pdf::Ln(6);
    $pdf::cell(55,3,utf8_decode('C.C.'),'T',"","L");
    $pdf::Ln(6);
    $pdf::SetFont('Arial','B',4.5);
    $pdf::MultiCell(55,2,utf8_decode('Este documento se asimila a la letra de cambio y le son aplicables los artículos 772 y siguientes del código de comercio La entrega se considera cumplida si al momento del recibo del giro por el destinatario no hay reclamación alguna aplican condiciones del contrato publicado en la página web con la solicitud y aceptación de este servicio entiéndase que manifiesto verbalmente mi autorización para el tratamiento de los datos personales que voluntariamente he entregado a AFA INVERSIONES S.A.S Estos datos pueden ser utilizados única y exclusivamente para la presentación del servicio convenido'),0,'J');
    $pdf::MultiCell(55,3,utf8_decode('Linea de servicio al cliente: (7) 6960663 info@afainversiones.com www.afainversiones.com'),0,'C');
    //$pdf::Image('img/icon/whatsapp.png',5,171,3.5,3.5);
    //$pdf::SetXY(10,170);
    //$pdf::SetFont('Arial','B',7);
    //$pdf::cell(55,6,utf8_decode('3205624402'),'',"","L");
    
    $pdf::AddPage('P',array(100,220));
    $pdf::Image('img/logo-factura.jpg',40,9,18);
    $pdf::SetMargins(5,1);
    $pdf::Ln();
    $pdf::SetFont('Helvetica','B',8);
    $pdf::Cell(55,5,'AFAINVERSIONES S.A.S',0,0,"L");
    $pdf::SetFont('Helvetica','B',4);
    $pdf::SetFont('Arial','B',5);
    $pdf::Ln();
    $pdf::Cell(55,2,'Nit. 901.192.632-6',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Carrera 13 No. 23 - 77 Oficina 102',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Bucaramanga - Santander',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('(7) 6960663 - 3205624402'),0,0,"L");
    $pdf::Ln();
   
    $pdf::Cell(55,2,utf8_decode('Actividad ICA 306999'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(40,2,utf8_decode('Tarifa 7.2 x 1000'),0,0,"L");
    $pdf::Ln();
    
    $pdf::Ln(5);
    $pdf::Ln();
    $pdf::SetFont('Arial','B',6);
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FACTURA No. '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode('V-'.str_pad($movimiento->codmovimiento, 4, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FECHA '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($movimiento->fecha_transaccion)->format(trans('general.format_datetime'))),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CAJERO '),0,0,"L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,"R");
    //$pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CÓDIGO '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(str_pad($empleado->codempleado, 6, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln(7);
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('DETALLE GIRO'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',7);
    $pdf::Ln(7);
    
    $pdf::cell(15,3,utf8_decode('VIGENCIA HASTA'),0,"","L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($movimiento->fecha_transaccion)->addDays(30)->format(trans('general.format_date'))),0,0,"R");
    $pdf::Ln(5);
    $pdf::cell(15,3,utf8_decode('ENVÍA:'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($cliente->nombreCompleto())),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$cliente->identificacion),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$cliente->celular),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('ORIGEN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->barrio)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode(''),0,"","L");
    $pdf::cell(40,3,utf8_decode(''),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('PUNTO ENVÍO'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''),0,"","R");
    $pdf::Ln(7);
    $pdf::cell(15,3,utf8_decode('RECIBE'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper(blank($clienteRecibeDto) ? $movimiento->nombres_recibe.' '.$movimiento->apellidos_recibe : $clienteRecibeDto->nombreCompleto())),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('CC.'),0,"","L");
    $pdf::cell(40,3,utf8_decode((blank($clienteRecibeDto) ? $movimiento->identificacion_recibe : $clienteRecibeDto->identificacion)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
    $pdf::cell(40,3,utf8_decode(blank($clienteRecibeDto) ? $movimiento->celular_recibe : $clienteRecibeDto->celular ),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DESTINO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"R");
    //$pdf::Ln();
    $pdf::cell(55,3,utf8_decode(''),'B',"","L");
    $pdf::Ln(8);
    $pdf::cell(15,3,utf8_decode('VALOR ENVIADO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($movimiento->valor)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('VALOR GIRO'),0,"","L");
    $costo = $tarifa->costo==0 ? ($tarifa->porcentaje*$movimiento->valor/100) : ($tarifa->costo) + ($tarifa->porcentaje*$movimiento->valor/100);
    $pdf::cell(40,3,utf8_decode('$ '.number_format($costo)),0,"","R");
    $pdf::Ln(8);
    $pdf::cell(15,3,utf8_decode('VALOR RECIBIDO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($movimiento->valor_recibido)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('CAMBIO'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($movimiento->valor_recibido-($costo+$movimiento->valor))),0,"","R");
    $pdf::Ln(8);
    $pdf::cell(15,4,utf8_decode('VALOR TOTAL'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($costo+$movimiento->valor)),0,"","R");
    $pdf::Ln(10);
    $pdf::cell(55,3,utf8_decode('Recibí Conforme'),'T',"","L");
    $pdf::Ln(6);
    $pdf::cell(55,3,utf8_decode('C.C.'),'T',"","L");
    $pdf::Ln(6);
    $pdf::SetFont('Arial','B',4.5);
    $pdf::MultiCell(55,2,utf8_decode('Este documento se asimila a la letra de cambio y le son aplicables los artículos 772 y siguientes del código de comercio La entrega se considera cumplida si al momento del recibo del giro por el destinatario no hay reclamación alguna aplican condiciones del contrato publicado en la página web con la solicitud y aceptación de este servicio entiéndase que manifiesto verbalmente mi autorización para el tratamiento de los datos personales que voluntariamente he entregado a AFA INVERSIONES S.A.S Estos datos pueden ser utilizados única y exclusivamente para la presentación del servicio convenido'),0,'J');
    $pdf::MultiCell(55,3,utf8_decode('Linea de servicio al cliente: (7) 6960663 info@afainversiones.com www.afainversiones.com'),0,'C');
    //$pdf::Image('img/icon/whatsapp.png',5,171,3.5,3.5);
    //$pdf::SetXY(10,170);
    //$pdf::SetFont('Arial','B',7);
    //$pdf::cell(55,6,utf8_decode('3205624402'),'',"","L");
    $pdf::Output();
    exit;

});


Route::get('factura-retira', function () {
    if(blank(request('m'))){
        $last_m = DB::table('movimientos')->orderBy('codmovimiento','DESC')->first();
        $movimiento = Movimiento::find($last_m->codmovimiento);
    }else{
        $movimiento = Movimiento::find((request('m')));
    }
    $empleado = Empleado::find($movimiento->cod_empleado_retira);
    $sucursal = Sucursal::find($movimiento->codsucursal);
    if(!blank($movimiento->cod_sucursal_retira)){
        $sucursal = Sucursal::find($movimiento->cod_sucursal_retira);
    }
    $sucursalEnvia = Sucursal::find($movimiento->cod_sucursal_envia);
    $cliente=Cliente::find($movimiento->codcliente_envia);
    $clienteRecibe = DB::table('clientes AS c')->where('identificacion','=',$movimiento->identificacion_recibe)->first();
    //dd($movimiento);
    $clienteRecibeDto=Cliente::find($movimiento->codcliente_recibe);
    //dd($clienteRecibeDto);
    //$cliente=Cliente::find($cliente->codcliente);
    $tarifa = DB::table('tarifas AS t')->where('codtarifa','=',$movimiento->codtarifa)->first();
    $venta = Venta::find(1);
    $usuario = Usuario::find($venta->cod_punto);
    $inventario = Inventario::find($venta->codinventario);
    $producto = Producto::find($inventario->codproducto);
    
    $pdf = new Fpdf();
    $pdf::AddPage('P',array(100,240));
    $pdf::Image('img/logo-factura.jpg',40,9,18);
    $pdf::SetMargins(5,1);
    $pdf::Ln();
    $pdf::SetFont('Helvetica','B',8);
    $pdf::Cell(55,5,'AFAINVERSIONES S.A.S',0,0,"L");
    $pdf::SetFont('Helvetica','B',4);
    $pdf::SetFont('Arial','B',5);
    $pdf::Ln();
    $pdf::Cell(55,2,'Nit. 901.192.632-6',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Carrera 13 No. 23 - 77 Oficina 102',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Bucaramanga - Santander',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('(7) 6960663 - 3205624402'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('Actividad ICA 306999'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(40,2,utf8_decode('Tarifa 7.2 x 1000'),0,0,"L");
    $pdf::Ln();
    
    $pdf::Ln(5);
    $pdf::Ln();
    $pdf::SetFont('Arial','B',6);
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FACTURA No. '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode('V-'.str_pad($movimiento->codmovimiento, 4, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FECHA ENVIO'),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($movimiento->fecha_transaccion)->format(trans('general.format_datetime'))),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FECHA RETIRO'),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($movimiento->fecha_retiro)->format(trans('general.format_datetime'))),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CAJERO '),0,0,"L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,"R");
    //$pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CÓDIGO '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(str_pad($empleado->codempleado, 6, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln(7);
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('DETALLE GIRO'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',7);
    $pdf::Ln(7);
    
    $pdf::cell(15,3,utf8_decode('VIGENCIA HASTA'),0,"","L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($movimiento->fecha_transaccion)->addDays(30)->format(trans('general.format_date'))),0,0,"R");
    $pdf::Ln(5);
    $pdf::cell(15,3,utf8_decode('ENVÍA:'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($cliente->nombreCompleto())),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$cliente->identificacion),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$cliente->celular),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('ORIGEN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->barrio)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode(''),0,"","L");
    $pdf::cell(40,3,utf8_decode(''),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('PUNTO ENVÍO'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''),0,"","R");
    $pdf::Ln(7);
    $pdf::cell(15,3,utf8_decode('RECIBE'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper(blank($clienteRecibeDto) ? $movimiento->nombres_recibe.' '.$movimiento->apellidos_recibe : $clienteRecibeDto->nombreCompleto())),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('CC.'),0,"","L");
    $pdf::cell(40,3,utf8_decode((blank($clienteRecibeDto) ? $movimiento->identificacion_recibe : $clienteRecibeDto->identificacion)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
    $pdf::cell(40,3,utf8_decode(blank($clienteRecibeDto) ? $movimiento->celular_recibe : $clienteRecibeDto->celular ),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DESTINO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"R");
    //$pdf::Ln();
    $pdf::cell(55,3,utf8_decode(''),'B',"","L");
    $pdf::Ln(8);
    $pdf::cell(15,3,utf8_decode('VALOR ENVIADO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($movimiento->valor)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('VALOR GIRO'),0,"","L");
    $costo = $tarifa->costo==0 ? ($tarifa->porcentaje*$movimiento->valor/100) : ($tarifa->costo) + ($tarifa->porcentaje*$movimiento->valor/100);
    $pdf::cell(40,3,utf8_decode('$ '.number_format($costo)),0,"","R");
    $pdf::Ln(8);
    $pdf::cell(15,4,utf8_decode('VALOR TOTAL'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($costo+$movimiento->valor)),0,"","R");
    $pdf::Ln(8);
    $pdf::cell(15,4,utf8_decode('VALOR A CANCELAR'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($movimiento->valor)),0,"","R");
    $pdf::Ln(10);
    $pdf::cell(55,3,utf8_decode('Recibí Conforme'),'T',"","L");
    $pdf::Ln(6);
    $pdf::cell(55,3,utf8_decode('C.C.'),'T',"","L");
    $pdf::Ln(6);
    $pdf::SetFont('Arial','B',4.5);
    $pdf::MultiCell(55,2,utf8_decode('Este documento se asimila a la letra de cambio y le son aplicables los artículos 772 y siguientes del código de comercio La entrega se considera cumplida si al momento del recibo del giro por el destinatario no hay reclamación alguna aplican condiciones del contrato publicado en la página web con la solicitud y aceptación de este servicio entiéndase que manifiesto verbalmente mi autorización para el tratamiento de los datos personales que voluntariamente he entregado a AFA INVERSIONES S.A.S Estos datos pueden ser utilizados única y exclusivamente para la presentación del servicio convenido'),0,'J');
    $pdf::MultiCell(55,3,utf8_decode('Linea de servicio al cliente: (7) 6960663 info@afainversiones.com www.afainversiones.com'),0,'C');
    //$pdf::Image('img/icon/whatsapp.png',5,171,3.5,3.5);
    //$pdf::SetXY(10,170);
    //$pdf::SetFont('Arial','B',7);
    //$pdf::cell(55,6,utf8_decode('3205624402'),'',"","L");
    
    $pdf::AddPage('P',array(100,220));
    $pdf::Image('img/logo-factura.jpg',40,9,18);
    $pdf::SetMargins(5,1);
    $pdf::Ln();
    $pdf::SetFont('Helvetica','B',8);
    $pdf::Cell(55,5,'AFAINVERSIONES S.A.S',0,0,"L");
    $pdf::SetFont('Helvetica','B',4);
    $pdf::SetFont('Arial','B',5);
    $pdf::Ln();
    $pdf::Cell(55,2,'Nit. 901.192.632-6',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Carrera 13 No. 23 - 77 Oficina 102',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,'Bucaramanga - Santander',0,0,"L");
    $pdf::Ln();
    $pdf::Cell(55,2,utf8_decode('(7) 6960663 - 3205624402'),0,0,"L");
    $pdf::Ln();
    
    $pdf::Cell(55,2,utf8_decode('Actividad ICA 306999'),0,0,"L");
    $pdf::Ln();
    $pdf::Cell(40,2,utf8_decode('Tarifa 7.2 x 1000'),0,0,"L");
    $pdf::Ln();
    
    $pdf::Ln(5);
    $pdf::Ln();
    $pdf::SetFont('Arial','B',6);
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FACTURA No. '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode('V-'.str_pad($movimiento->codmovimiento, 4, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FECHA ENVIO'),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($movimiento->fecha_transaccion)->format(trans('general.format_datetime'))),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('FECHA RETIRO'),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($movimiento->fecha_retiro)->format(trans('general.format_datetime'))),0,0,"R");
    $pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CAJERO '),0,0,"L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,"R");
    //$pdf::Ln();
    $pdf::Cell(15,3,utf8_decode('CÓDIGO '),0,0,"L");
    $pdf::Cell(40,3,utf8_decode(str_pad($empleado->codempleado, 6, "0", STR_PAD_LEFT)),0,0,"R");
    $pdf::Ln(7);
    $pdf::SetFont('Arial','B',7);
    $pdf::SetFillColor(233);
    $pdf::Cell(55,5,utf8_decode('DETALLE GIRO'),'TB',0,'C',true);
    $pdf::SetFont('Arial','B',7);
    $pdf::Ln(7);
    
    $pdf::cell(15,3,utf8_decode('VIGENCIA HASTA'),0,"","L");
    $pdf::Cell(40,3,utf8_decode(Carbon::parse($movimiento->fecha_transaccion)->addDays(30)->format(trans('general.format_date'))),0,0,"R");
    $pdf::Ln(5);
    $pdf::cell(15,3,utf8_decode('ENVÍA:'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($cliente->nombreCompleto())),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('C.C'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$cliente->identificacion),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''.$cliente->celular),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('ORIGEN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursalEnvia->barrio)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode(''),0,"","L");
    $pdf::cell(40,3,utf8_decode(''),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('PUNTO ENVÍO'),0,"","L");
    $pdf::cell(40,3,utf8_decode(''),0,"","R");
    $pdf::Ln(7);
    $pdf::cell(15,3,utf8_decode('RECIBE'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper(blank($clienteRecibeDto) ? $movimiento->nombres_recibe.' '.$movimiento->apellidos_recibe : $clienteRecibeDto->nombreCompleto())),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('CC.'),0,"","L");
    $pdf::cell(40,3,utf8_decode((blank($clienteRecibeDto) ? $movimiento->identificacion_recibe : $clienteRecibeDto->identificacion)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('TEL'),0,"","L");
    $pdf::cell(40,3,utf8_decode(blank($clienteRecibeDto) ? $movimiento->celular_recibe : $clienteRecibeDto->celular ),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DESTINO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->nombres)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
    //$pdf::Ln();
    $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
    $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"R");
    //$pdf::Ln();
    $pdf::cell(55,3,utf8_decode(''),'B',"","L");
    $pdf::Ln(8);
    $pdf::cell(15,3,utf8_decode('VALOR ENVIADO'),0,"","L");
    $pdf::cell(40,3,utf8_decode('$ '.number_format($movimiento->valor)),0,"","R");
    $pdf::Ln();
    $pdf::cell(15,4,utf8_decode('VALOR GIRO'),0,"","L");
    $costo = $tarifa->costo==0 ? ($tarifa->porcentaje*$movimiento->valor/100) : ($tarifa->costo) + ($tarifa->porcentaje*$movimiento->valor/100);
    $pdf::cell(40,3,utf8_decode('$ '.number_format($costo)),0,"","R");
    $pdf::Ln(8);
    $pdf::cell(15,4,utf8_decode('VALOR TOTAL'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($costo+$movimiento->valor)),0,"","R");
    $pdf::Ln(8);
    $pdf::cell(15,4,utf8_decode('VALOR A CANCELAR'),0,"","L");
    $pdf::cell(40,4,utf8_decode('$ '.number_format($movimiento->valor)),0,"","R");
    $pdf::Ln(10);
    $pdf::cell(55,3,utf8_decode('Recibí Conforme'),'T',"","L");
    $pdf::Ln(6);
    $pdf::cell(55,3,utf8_decode('C.C.'),'T',"","L");
    $pdf::Ln(6);
    $pdf::SetFont('Arial','B',4.5);
    $pdf::MultiCell(55,2,utf8_decode('Este documento se asimila a la letra de cambio y le son aplicables los artículos 772 y siguientes del código de comercio La entrega se considera cumplida si al momento del recibo del giro por el destinatario no hay reclamación alguna aplican condiciones del contrato publicado en la página web con la solicitud y aceptación de este servicio entiéndase que manifiesto verbalmente mi autorización para el tratamiento de los datos personales que voluntariamente he entregado a AFA INVERSIONES S.A.S Estos datos pueden ser utilizados única y exclusivamente para la presentación del servicio convenido'),0,'J');
    $pdf::MultiCell(55,3,utf8_decode('Linea de servicio al cliente: (7) 6960663 info@afainversiones.com www.afainversiones.com'),0,'C');
    //$pdf::Image('img/icon/whatsapp.png',5,171,3.5,3.5);
    
    
    $pdf::Output();
    exit;

});

Route::get('reporte-ingresos', function () {
    if(blank(request('m'))){
        $last_m = DB::table('movimientos')->orderBy('codmovimiento','DESC')->first();
        $movimiento = Movimiento::find($last_m->codmovimiento);
    }else{
        $movimiento = Movimiento::find((request('m')));
    }
    $empleado = Empleado::find(32);
    $sucursal = Sucursal::find($movimiento->codsucursal);
    if(!blank($movimiento->cod_sucursal_retira)){
        $sucursal = Sucursal::find($movimiento->cod_sucursal_retira);
    }
    $sucursalEnvia = Sucursal::find($movimiento->cod_sucursal_envia);
    $cliente=Cliente::find($movimiento->codcliente_envia);
    $clienteRecibe = DB::table('clientes AS c')->where('identificacion','=',$movimiento->identificacion_recibe)->first();
    //dd($movimiento);
    $clienteRecibeDto=Cliente::find($movimiento->codcliente_recibe);
    //dd($clienteRecibeDto);
    //$cliente=Cliente::find($cliente->codcliente);
    $tarifa = DB::table('tarifas AS t')->where('codtarifa','=',$movimiento->codtarifa)->first();
    $venta = Venta::find(1);
    $usuario = Usuario::find($venta->cod_punto);
    $inventario = Inventario::find($venta->codinventario);
    $producto = Producto::find($inventario->codproducto);
    
    $pdf = new Fpdf();
    $pdf::AddPage('P',array(215,280));
    $pdf::SetMargins(15,1);
    $pdf::SetAutoPageBreak(false);
    $pdf::Image('img/logo-factura.jpg',15,9,18);
    $pdf::Image('img/marca de agua.png',0,30,215);
    $pdf::Image('img/logo-giros.jpg',165,9,30);
    $pdf::SetFont('Helvetica','B',12);
    
    $pdf::SetXY(35,14);
    $pdf::Cell(55,5,'AFAINVERSIONES S.A.S',0,0,"L");
    $pdf::SetXY(35,18);
    $pdf::Cell(55,5,'Nit. 901.192.632-6',0,0,"L");
    $pdf::SetXY(35,18);

    

    $pdf::SetXY(15,65);
    $pdf::Cell(185,5,'FORMATO REPORTE DE INGRESOS',0,0,"C");
    $pdf::Ln();
    $pdf::Ln();
    $pdf::Ln();
    $pdf::Ln();
    $pdf::Ln();
    $pdf::Cell(185,5,'SOLO PARA DESTINATARIOS',0,0,"L");
    $pdf::Ln();
    $pdf::Ln();
    $pdf::SetFont('Helvetica','',9);
    $pdf::Cell(75,7,utf8_decode('FECHA'),1,0,"C");
    $pdf::Cell(110,7,utf8_decode(Carbon::parse($movimiento->fecha_transaccion)->format(trans('general.format_datetime'))),1,0,"L");
    $pdf::Ln();
    $pdf::Cell(75,7,utf8_decode('NOMBRE'),1,0,"C");
    $pdf::Cell(110,7,utf8_decode(strtoupper($cliente->nombreCompleto())),1,0,"L");
    $pdf::Ln();
    $pdf::Cell(75,7,utf8_decode('CEDULA'),1,0,"C");
    $pdf::Cell(110,7,utf8_decode($cliente->identificacion),1,0,"L");
    $pdf::Ln();
    $pdf::Cell(75,7,utf8_decode('FECHA DE EXPEDICIÓN'),1,0,"C");
    $pdf::Cell(110,7,utf8_decode(Carbon::parse($cliente->fecha_expedicion)->format(trans('general.format_datetime'))),1,0,"L");
    $pdf::Ln();
    $pdf::Cell(75,7,utf8_decode('FECHA DE NACIMIENTO'),1,0,"C");
    $pdf::Cell(110,7,utf8_decode(Carbon::parse($cliente->fecha_nacimiento)->format(trans('general.format_datetime'))),1,0,"L");
    $pdf::Ln();
    $pdf::Cell(75,7,utf8_decode('OCUPACIÓN'),1,0,"C");
    $pdf::Cell(110,7,utf8_decode(strtoupper($movimiento->ocupacion)),1,0,"L");
    $pdf::Ln();
    $pdf::Cell(75,7,utf8_decode('¿DE DONDE PROVIENEN LOS INGRESOS?'),1,0,"C");
    $pdf::Cell(110,7,utf8_decode(strtoupper($movimiento->origen_ingresos)),1,0,"L");
    $pdf::Ln();
    $pdf::Cell(75,7,utf8_decode('RANGO DE INGRESOS'),1,0,"C");
    $pdf::Cell(110,7,utf8_decode(number_format(blank($cliente->ingresos) ? 0 : $cliente->ingresos)),1,0,"L");

    $pdf::SetXY(15,-15);
    $pdf::Cell(92.5/2,5,utf8_decode('6960663'),0,0,"C");
    $pdf::Cell(92.5/2,5,utf8_decode('3205624402'),0,0,"C");
    $pdf::Cell(92.5,5,utf8_decode('Cra. 13 No. 23 - 77 Of. 102 barrio. Girardot - Bucaramanga'),0,0,"C");
    $pdf::Ln();
    $pdf::Cell(92.5*2,5,utf8_decode('Info@afainversiones.co'),0,0,"C");
    
    $pdf::Output();
    exit;
    
});

Route::get('/home', 'DashboardController@index')->name('home');

// rutas de autenticacion
Route::get('logout', 'Auth\LoginController@logout')->name('logout');

Route::get('/menus/{menu}/{nombre}', 'HomeController@visualizarMenu')->name('paginas.navegar');
Route::get('/paginas/{pagina}/{nombre}', 'HomeController@navegarPagina')->name('paginas.navegar-pagina');
//Route::get('/contenido/{menu}/{nombre}', 'HomeController@visualizar')->name('paginas.navegar-contenido');
Auth::routes();

Route::get('download', function () {
    $filename = request('filename');
    $file_path = public_path() . "premium/files/". $filename;
    //dd($file_path);
    if (file_exists($file_path)) {
        return Response::download($file_path, $filename, [
            'Content-Length: ' . filesize($file_path)
        ]);
    } else {
        // Error
        exit('El archivo no se encuentra disponible para descargar');
    }
})->where('filename', '[A-Za-z0-9\-\_\.]+')->name('colegios.descargar_archivo');

Route::middleware([
    'auth'
])->group(function ($usuario) {
    //CONVENIOS
    
    Route::get('convenios', 'ConvenioController@index')->name('convenios.index');
    Route::post('convenios/buscar', 'ConvenioController@buscarConvenios')->name('convenios.buscar');
    Route::post('convenios/detalle', 'ConvenioController@detalleConvenios')->name('convenios.buscar');
    Route::post('convenios/crear', 'ConvenioController@crearConvenio')->name('convenios.crear-convenio');
    Route::post('convenios/consultar', 'ConvenioController@abrirFormulario')->name('convenios.formulario');
    Route::post('convenios/validar-snr', 'ConvenioController@validarSNR')->name('convenios.valirdar-snr');
    Route::post('convenios/validar-wplay', 'ConvenioController@validarWPLAY')->name('convenios.valirdar-wplay');
    
    Route::get('pagos', 'ConvenioController@pagos')->name('convenios.pagos');
    Route::post('pagos/registrar-pagos', 'ConvenioController@registrarPagos')->name('pagos.registrar_pagos');
    Route::post('consignacion/registrar-consignacion', 'ConvenioController@registrarConsignacion')->name('consignacion.registrar_consignacion');
    Route::post('pagos/consultar', 'ConvenioController@pagoConsultar')->name('pagos.consultar');
    Route::post('consignacion/consultar', 'ConvenioController@consignacionConsultar')->name('pagos.consultar');
    
    Route::get('otros', 'ConvenioController@otros')->name('convenios.otros');
    Route::post('otros/consultar-pagos', 'ConvenioController@otros')->name('otros.otros-consultar');

    Route::post('pagos/consultar-pagos', 'ConvenioController@pagos')->name('pagos.pagos-consultar');
    Route::post('consignaciones/consultar-pagos', 'ConvenioController@consignaciones')->name('consignaciones.consignaciones-consultar');
    
    Route::get('consignaciones-giros', 'ConvenioController@consignaciones')->name('pagos.consignaciones-giros');

    Route::post('recargas/registrar', 'ClienteController@registrarRecarga')->name('recargas.registrar');
    
    Route::post('soat/validar', 'ConvenioController@soatValidar')->name('soat.validar');
    Route::post('soat/registrar', 'ClienteController@soatRecarga')->name('soat.registrar');
    
    

    Route::post('recargas/buscar-paquete', 'ConvenioController@buscarPaquete')->name('recargas.buscar-paquete');
    //FIN CONVENIOS



    Route::post('clientes/buscar', 'ClienteController@buscarCliente')->name('clientes.buscar');
    Route::post('clientes/enviar-giro', 'ClienteController@enviarGiro')->name('clientes.enviar-giro');
    Route::post('clientes/enviar-giro-banco', 'ClienteController@enviarGiroBanco')->name('clientes.enviar-giro-banco');
    Route::post('clientes/pagar-convenio', 'ClienteController@pagarConvenio')->name('clientes.pagar-convenio');
    Route::post('clientes/retirar-giro', 'ClienteController@retirarGiro')->name('clientes.retirar-giro');
    Route::post('clientes/buscar-giro', 'ClienteController@buscarGiro')->name('clientes.buscar-giro');
    Route::post('clientes/revertir-giro', 'ClienteController@revertirGiro')->name('clientes.revertir-giro');
    Route::post('clientes/buscar-recibe', 'ClienteController@buscarClienteRecibe')->name('clientes.buscar-recibe');
    Route::post('tarifas/consultar', 'ClienteController@consultarTarifas')->name('tarifas.consultar');
    Route::post('clientes/historial', 'ClienteController@buscarHistorial')->name('clientes.historial');
    // permisos
    $menusBD = Permiso::permisosIndices();

    Route::get('transacciones', 'DashboardController@transacciones')->name('transacciones');
    Route::get('transacciones-new', 'DashboardController@transaccionesNew')->name('transacciones-new');
    Route::post('mensaje', 'ClienteController@enviarMensaje')->name('mensaje');

    Route::get('tarifas', 'ParametroController@tarifas')->name('tarifas.index');
    Route::post('tarifas/consultar-form', 'ParametroController@abrirFormulario')->name('tarifas.formulario');
    Route::post('tarifas/crear', 'ParametroController@crearTarifa')->name('tarifas.crear-tarifa');
    Route::post('tarifas/eliminar', 'ParametroController@eliminarTarifa')->name('tarifas.eliminar');


    Route::get('clientes', 'ClienteController@index')->name('clientes.index');
    Route::post('clientes/consultar', 'ClienteController@abrirFormulario')->name('clientes.formulario');
    Route::post('clientes/consultar-transacciones', 'ClienteController@abrirFormularioTransacciones')->name('clientes.consultar-transacciones');
    Route::post('clientes/eliminar', 'ClienteController@eliminar')->name('clientes.eliminar');

    Route::get('sucursal', 'SucursalController@index')->name('sucursal.index');
    Route::post('sucursal-buscar', 'SucursalController@index')->name('sucursal.buscar');
    Route::get('sucursal-consultar', 'SucursalController@indexConsultar')->name('sucursal.index-consultar');
    Route::get('sucursal-consultar-2', 'SucursalController@indexConsultar2')->name('sucursal.index-consultar2');
    Route::get('sucursal-cierre', 'SucursalController@reporteCierre')->name('sucursal.reporte-cierre');
    Route::get('sucursal-consolidado', 'SucursalController@consolidadoCierre')->name('sucursal.reporte-cierre-consolidado');
    Route::get('sucursal-extracto', 'SucursalController@extracto')->name('sucursal.reporte-cierre-consolidado');
    Route::get('{sucursal}/estado-cuenta/', 'AsignaturaController@reportesEstados')->name('sucursal.estado-cuenta');
    Route::post('sucursal/estado-cuenta/', 'AsignaturaController@reportesEstados')->name('sucursal.estado-cuenta-buscar');
    
    Route::post('sucursal/comisiones', 'SucursalController@comisiones')->name('sucursal.comisiones');
    Route::post('sucursal/consultar', 'SucursalController@abrirFormulario')->name('sucursal.formulario');
    Route::post('sucursal/consultar-empleados', 'SucursalController@abrirFormularioEmpleados')->name('sucursal.formulario-empleados');
    Route::post('sucursal/consultar-horarios', 'SucursalController@abrirFormularioHorarios')->name('sucursal.formulario-horarios');
    Route::post('sucursal/asignar-horario', 'SucursalController@asignarHorario')->name('sucursal.asignar-horario');
    Route::post('sucursal/abrir-caja', 'SucursalController@manejoCaja')->name('sucursal.abrir-caja');
    Route::post('sucursal/registrar-consignacion', 'SucursalController@registrarConsignacion')->name('sucursal.registrar_consignacion');
   
    Route::post('sucursal/eliminar', 'SucursalController@eliminar')->name('sucursal.eliminar');
    Route::post('sucursal/bloqueo', 'SucursalController@bloqueo')->name('sucursal.bloqueo');
    Route::post('sucursal/crear', 'SucursalController@crearSucursal')->name('sucursal.crear-sucursal');
    Route::post('sucursal/vincular-empleado', 'SucursalController@vincularEmpleado')->name('sucursal.vincular-empleado');
    

        
    Route::get('empleado', 'EmpleadoController@index')->name('empleado.index');
    Route::post('empleado/consultar', 'EmpleadoController@abrirFormulario')->name('empleado.formulario');
    Route::post('empleado/eliminar', 'EmpleadoController@eliminar')->name('empleado.eliminar');
    Route::post('empleado/bloqueo', 'EmpleadoController@bloqueo')->name('empleado.bloqueo');
    Route::post('empleado/resetear-password', 'EmpleadoController@resetearPassword')->name('empleado.resetear-password');
    Route::post('empleado/crear', 'EmpleadoController@crearEmpleado')->name('empleado.crear-empleado');







    Route::post('clientes/crear', 'ClienteController@crearCliente')->name('clientes.crear-clientes');
    Route::post('clientes/crear-transacciones', 'ClienteController@crearClienteTransacciones')->name('clientes.crear-clientes-transacciones');
    
    Route::post('clientes/registrar-consignacion', 'ClienteController@registrarConsignacion')->name('clientes.registrar_consignacion');
    Route::post('clientes/resetear-password', 'UsuarioController@passwordCliente')->name('clientes.resetear-password');
    Route::post('clientes/editar-informacion', 'UsuarioController@editarCliente')->name('clientes.editar_informacion');
    Route::post('usuarios/cambiar-password', 'UsuarioController@cambiarPassword')->name('usuarios.cambiar-password');



    Route::get('productos', 'ProductoController@index')->name('productos.index');
    Route::post('producto/crear', 'ProductoController@crearProducto')->name('productos.crear-producto');
    Route::post('producto/cargar_producto', 'ProductoController@cargarExcelInventario')->name('productos.cargar_inventario');
    Route::post('producto/informacion_producto', 'ProductoController@cargarExcelInventario')->name('productos.informacion_producto');
    Route::post('producto/editar-producto', 'ProductoController@editarProducto')->name('productos.editar_producto');
    Route::post('producto/venta-producto', 'ProductoController@informacionProducto')->name('productos.venta_producto');
    Route::post('producto/venta-procesar', 'ProductoController@procesarVenta')->name('productos.venta_procesar');
    Route::post('producto/venta-sms', 'ProductoController@reenviarSms')->name('productos.venta_sms');
    Route::post('producto/informe-generar', 'ProductoController@reportesVenta')->name('productos.venta_reportes');

   
    Route::get('ventas', 'ProductoController@venta')->name('productos.venta');



    Route::get('estudiantes', 'EstudianteController@index')->name('estudiantes.index');
    Route::get('grados', 'GradoController@index')->name('grados.index');
    Route::get('reportes', 'AsignaturaController@index')->name('asignaturas.reportes');
    Route::post('reportes-buscar', 'AsignaturaController@index')->name('asignaturas.reportes-buscar');
    Route::get('reportes-detalle', 'AsignaturaController@indexDetallado')->name('asignaturas.reportes-detalle');
    Route::post('reportes-buscar-detalle', 'AsignaturaController@indexDetallado')->name('asignaturas.reportes-buscar-detalle');
    
    Route::get('reportes-total', 'AsignaturaController@indexTotal')->name('asignaturas.reportes-total');
    Route::post('reportes-buscar-total', 'AsignaturaController@indexTotal')->name('asignaturas.reportes-buscar-total');
    
    
    
    
    
    Route::get('reportes-estadisticos', 'AsignaturaController@reportesEstadisticos')->name('asignaturas.reportes-estadisticos');
    Route::get('reportes-recargas', 'AsignaturaController@reportesRecargas')->name('asignaturas.reportes-recargas');
    Route::post('reportes-estadisticos-buscar', 'AsignaturaController@reportesEstadisticos')->name('sucursal.cuadre-ganancia');
    Route::post('reportes-recargas-buscar', 'AsignaturaController@reportesRecargas')->name('reportes.reportes-recargas');
    
    Route::get('reportes-estados', 'AsignaturaController@reportesEstados')->name('asignaturas.reportes-estados');
    Route::get('consignaciones', 'AsignaturaController@consignaciones')->name('asignaturas.consignaciones-ver');
    Route::post('consignaciones', 'AsignaturaController@consignaciones')->name('asignaturas.consignaciones');
    Route::post('consignaciones/procesar', 'AsignaturaController@consignacionesProcesar')->name('asignaturas.consignaciones-procesar');
    //Route::get('reportes', 'ProductoController@estadosCuenta')->name('asignaturas.index');
    Route::post('asignatura/consultar', 'AsignaturaController@index')->name('asignaturas.index-consultar');
    Route::post('asignatura/crear', 'AsignaturaController@crearAsignatura')->name('asignaturas.crear-asignatura');
    Route::post('asignatura/cargar_evidencias', 'AsignaturaController@cargarExcelEvidencias')->name('asignaturas.cargar_evidencias');
    
    Route::get('/configuraciones', 'ParametroController@index')->name('configuracion.index');

    Route::post('configuraciones/informacion', 'ParametroController@consultarConfiguraciones')->name('configuracion.informacion-configuracion');
    Route::post('grados/guardar-grado', 'GradoController@store')->name('grados.guardar-grado');
    Route::post('asignatura/guardar-asignatura', 'AsignaturaController@editarAsignatura')->name('asignaturas.guardar-asignatura');
    Route::post('evidencias', 'AsignaturaController@indexEvidencias')->name('asignaturas.evidencias');
    Route::post('evidencia/guardar-evidencia', 'AsignaturaController@editarEvidencia')->name('evidencias.guardar-evidencia');
    Route::post('estudiantes/consultar', 'EstudianteController@index')->name('estudiantes.index-consultar');
    Route::get('estudiantes/matricula', 'EstudianteController@vistaMatricula')->name('estudiantes.matriculas');
    Route::get('estudiantes/{codestudiante}/detalle-estudiante', 'EstudianteController@detalleEstudiante')->name('estudiantes.detalle');
    Route::post('estudiantes/matricula-procesar', 'EstudianteController@procesarMatricula')->name('estudiantes.matriculas-procesar');
   







    Route::post('get-files', 'PaginaController@obtenerFicheros')->name('paginas.ficheros');
    Route::get('cargar-imagen', 'PaginaController@mostrarImagen')->name('paginas.cargar-imagen');
    Route::post('guardar-pagina', 'PaginaController@store')->name('paginas.guardar-pagina');
    Route::post('eliminar-pagina', 'PaginaController@eliminarPagina')->name('paginas.eliminar-pagina');
    Route::post('subir-imagen-crop', 'PaginaController@guardarImagenCrop')->name('paginas.guardar-imagen-crop');
    Route::post('cortar-imagen-crop', 'PaginaController@cortarImagenCrop')->name('paginas.cortar-imagen-crop');
    Route::post('subir-archivo', 'PaginaController@guardarArchivo')->name('paginas.guardar-archivo');
    Route::post('eliminar-archivo', 'PaginaController@eliminarArchivo')->name('paginas.eliminar-archivo');

    // visualziar notificaciones
    Route::get('/{notificacion}/notificacion', 'DashboardController@notificacion')->name('principal.notificacion');

    
    Route::get('convenios', 'ConvenioController@index')->name('convenios.index');

});

/*
 * |--------------------------------------------------------------------------
 * | Autocomplete route
 * |--------------------------------------------------------------------------
 * |
 */
Route::get("/autocomplete", 'AutoCompleteController@index')->name('autocomplete.index');

/*
 * |--------------------------------------------------------------------------
 * | Errores
 * |--------------------------------------------------------------------------
 * |
 */
 Route::get('test', function () {
    return view('errors.test');
})->name(403);
Route::get('403', function () {
    return view('errors.403');
})->name(403);
Route::get('419', function () {
    return view('errors.empleado-403');
})->name('errors.empleado-403');
Route::get('419', function () {
    return view('errors.computador-noautorizado');
})->name('errors.computador-noautorizado');
Route::get('404', function () {
    return view('errors.404');
})->name(404);