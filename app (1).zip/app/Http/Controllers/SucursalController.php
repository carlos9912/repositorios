<?php

namespace App\Http\Controllers;



use Carbon\Carbon;
use App\Enums\ESiNo;
use App\Models\Menu;
use App\Models\Curso;
use App\Models\Documento;
use App\Enums\EActivo;
use App\Models\Pagina;
use App\Models\Perfil;
use App\Models\Horario;
use App\Models\Permiso;
use App\Models\Usuario;
use App\Models\Apertura;
use App\Models\Empleado;
use App\Models\Sucursal;
use App\Models\Parametro;
use App\Models\Estudiante;
use App\Models\Movimiento;
use Illuminate\Support\Arr;
use App\Enums\EEstadoPagina;
use App\Models\Consignacion;
use Illuminate\Http\Request;
use Codedge\Fpdf\Facades\Fpdf;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;


class SucursalController extends Controller

{
    /**
     *
     * @tutorial Method Description: constructor class
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */

    public function __construct()
    {
        $this->middleware('auth');
    }





    public function bloqueo(Request $request){
        $sucursal = Sucursal::find($request->codsucursal);
        $sucursal->update(['bloqueo'=>$request->bloqueo]);
        return response()->json([
            'formulario' => $sucursal
        ]);
    }

    /**
     *
     * @tutorial Method Description: carga la vista de crear pagina
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */

    public function index(Request $request)
    {
        if(!blank(\Auth::user()->codempleado)){
            return redirect()->route('errors.empleado-403');
        }
        return view('sucursal.index');
    }


    public function indexConsultar(Request $request)
    {
        
        $listAsignaturas = [];
        if(!blank($request->codcurso)){
            $listAsignaturas = DB::table('asignatura AS a')->leftJoin('rel_asignaturadocente AS rel_a','rel_a.codasignatura','=','a.codasignatura')->where('curso','=',$request->codcurso)->orderBy('curso')->select('a.*','rel_a.coddocente')->get();
            $listDocentes = [];
            $listReturn = [];
            foreach($listAsignaturas as $asignatura){
                $listDocentes[$asignatura->codasignatura][] = $asignatura->coddocente;
                $asignatura->coddocente = $listDocentes[$asignatura->codasignatura];
                $listReturn[$asignatura->codasignatura] = $asignatura;
            } 
            $listAsignaturas = $listReturn;
        }
        return view('sucursal.listado');
    }
    
    public function indexConsultar2(Request $request)
    {
        $listAsignaturas = [];
        if(!blank($request->codcurso)){
            $listAsignaturas = DB::table('asignatura AS a')->leftJoin('rel_asignaturadocente AS rel_a','rel_a.codasignatura','=','a.codasignatura')->where('curso','=',$request->codcurso)->orderBy('curso')->select('a.*','rel_a.coddocente')->get();
            $listDocentes = [];
            $listReturn = [];
            foreach($listAsignaturas as $asignatura){
                $listDocentes[$asignatura->codasignatura][] = $asignatura->coddocente;
                $asignatura->coddocente = $listDocentes[$asignatura->codasignatura];
                $listReturn[$asignatura->codasignatura] = $asignatura;
            } 
            $listAsignaturas = $listReturn;
        }
        return view('sucursal.listado2');
    }



    public function abrirFormulario(Request $request){
        if(blank($request->codsucursal)){
            $sucursal= new Sucursal();
        }else{
            $sucursal = Sucursal::find($request->codsucursal);
        }
        $documentos = $sucursal->documentos;
        $listDocumentos = [];
        foreach($documentos as $documento){
            $listDocumentos[$documento->tipo] = $documento;
        }
        return response()->json([
            'formulario' => view('sucursal.partials.form')->with([
                'sucursal' => $sucursal,
                'documentos' => $listDocumentos
            ])->render()
        ]);
    }

    

    public function abrirFormularioEmpleados(Request $request){
        if(blank($request->codsucursal)){
            $sucursal= new Sucursal();
        }else{
            $sucursal = Sucursal::find($request->codsucursal);
        }
        return response()->json([
            'formulario' => view('sucursal.partials.form-empleados')->with([
                'sucursal' => $sucursal,
            ])->render()
        ]);
        

    }

    

    public function abrirFormularioHorarios(Request $request){
        if(blank($request->codsucursal)){
            $sucursal= new Sucursal();
        }else{
            $sucursal = Sucursal::find($request->codsucursal);
        }
        return response()->json([
            'formulario' => view('sucursal.partials.form-horarios')->with([
                'sucursal' => $sucursal,
            ])->render()
        ]);
       

    }

    

    



    public function vincularEmpleado(Request $request){
        $sucursal = Sucursal::find($request->codsucursal);
        $sucursal->empleados()->attach($request->codempleado, [
            'cargo' => $request->cargo,
            'estado' => 1,
            'fecha_vinculacion' => Carbon::now()
        ]);
        return response()->json([
            'formulario' => view('sucursal.partials.form-empleados')->with([
               'sucursal' => $sucursal,
            ])->render()
        ]);
        
    }


    public function comisiones(Request $request)
    {
        $fecha = Carbon::now();
        $sucursal = Sucursal::find($request->codsucursal);
        DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->where('codsucursal','=',$sucursal->codsucursal)->where('codrel','<=',$request->codrel)->update([
            'estado_pago' => 2,
            'fecha_pago' => $fecha
        ]);
        $sucursal->movimientos_comision()->attach(new Movimiento(),[
            'tipo_movimiento' => 30,
            'valor_real' => $request->valor,
            'fecha_movimiento' => $fecha,
            'estado' => 1,
            'saldo_inicial' => $sucursal->saldo,
            'saldo_final' => $sucursal->saldo-$request->valor,
            'estado_pago' => 2
        ]);
        $saldo = $sucursal->saldo-$request->valor;
        $sucursal->update([
            'saldo' => $saldo
        ]);
        return redirect()->route('sucursal.estado-cuenta',[$sucursal->codsucursal])->with(['mensaje'=>1]);
    }


    public function manejoCaja(Request $request)
    {
        $sucursal = session('sucursal');
        $apertura = $sucursal->aperturas()->where('estado','=',1)->whereBetween('fecha', [
            Carbon::parse(Carbon::today())->format('Y-m-d').' 00:00:00',
            Carbon::parse(Carbon::today())->format('Y-m-d').' 23:59:59'
        ])->first();
        if(blank($request->codcaja)){
            $sucursal->aperturas()->save(new Apertura([
                'empleado_registra' => \Auth::user()->codempleado,
                'tipo_registro' => 1,
                'estado' => 1,
                'fecha' => Carbon::now()
            ]));
        }else{
            $aperturaActual = Apertura::find($request->codcaja);
            $aperturaActual->update([
                'estado' => 2,
                'fecha_cierre' => Carbon::now(),
                'empleado_cierra' => \Auth::user()->codempleado,
            ]);
        }
        
        return redirect()->route('transacciones');

    }

    public function reporteCierre(Request $request)
    {
        
        
        $sucursal = Sucursal::find(base64_decode($request->m));
        $apertura = $sucursal->aperturas()->where('estado','=',2)->whereBetween('fecha', [
            Carbon::parse(Carbon::today())->format('Y-m-d').' 00:00:00',
            Carbon::parse(Carbon::today())->format('Y-m-d').' 23:59:59'
        ])->first();
        if(blank($apertura)){
            $apertura = new Apertura();
        }
        if(blank($apertura->empleado_cierra)){
            $empleado = new Empleado();
            $empleadoCierra = new Empleado();
        }else{
            $empleado = Empleado::find($apertura->empleado_registra);
            $empleadoCierra = Empleado::find($apertura->empleado_cierra);
        }
        $valorGanancia = 0;
        $valorGananciaR = 0;
        $valorEnvio = 0;
        $valorRetiro = 0;
        $valorVentas = 0;
        $cantidades = [1 => ["cant"=>0, "valor"=>0],2 => ["cant"=>0, "valor"=>0],3 => ["cant"=>0, "valor"=>0],4 => ["cant"=>0, "valor"=>0],5 => ["cant"=>0, "valor"=>0],30 => ["cant"=>0, "valor"=>0]];
        $cantEnvio = 0;
        $cantRetiro = 0;
        $valorPorcentaje = 0;
        foreach(DB::table('rel_sucursal_movimiento AS r')->leftJoin('movimientos as m', 'm.codmovimiento', 'r.codmovimiento')->leftjoin('tarifas AS t','t.codtarifa','=','r.codtarifa')->join('sucursales AS s','s.codsucursal','=','r.codsucursal')->where('r.codsucursal','=',$sucursal->codsucursal)->where('r.estado', '=', 1)->whereBetween('r.fecha_movimiento', [
            Carbon::parse(Carbon::today())->format('Y-m-d').' 00:00:00',
            //'2019-01-01 00:00:00',
            Carbon::parse(Carbon::today())->format('Y-m-d').' 23:59:59'
        ])->select('r.*','m.cod_empleado_envia','m.cod_empleado_retira','t.*','s.nombres AS nombreSucursal', 's.ubicacion')->get() as $ventas){
            $valor_comision = $ventas->costo_envia;
            $valor_comision = blank($ventas->porcentaje_envia) ? $valor_comision : $valor_comision+$ventas->valor_real*$ventas->porcentaje_envia/100;
            $valor_comisionr = $ventas->costo_paga;
            $valor_comisionr = blank($ventas->porcentaje_envia) ? $valor_comisionr : $valor_comisionr+$ventas->valor_real*$ventas->porcentaje_envia/100;
            $cantidades[$ventas->tipo_movimiento]["cant"]++;
            $cantidades[$ventas->tipo_movimiento]["valor"]+=$ventas->valor_real;
            $valor_iva = $ventas->iva_costo*1000/100;
            $ventas->iva_porcentaje = "1.".$ventas->iva_porcentaje;
            $costo = $ventas->costo==0 ? ($ventas->porcentaje*$ventas->valor_real/100) : ($ventas->costo) + ($ventas->porcentaje*$ventas->valor_real/100); 
            $valor_iva = blank($ventas->iva_porcentaje) ? $valor_iva : ($costo-$valor_comision-$valor_comisionr)-($costo-$valor_comision-$valor_comisionr)/$ventas->iva_porcentaje;
            $valorVentas+=$valor_iva;
            $ganancia = $costo-$valor_iva-$valor_comision-$valor_comisionr;
            
            $valorPorcentaje+=$ventas->valor_real;
            $comision = $valor_comision+$valor_comisionr;
            if(($ventas->tipo_movimiento==1)){
                $cantidades[$ventas->tipo_movimiento]["valor"]+=$costo;
                $valorGanancia+=$valor_comision;
                $valorEnvio+=$ventas->valor_real;
                $cantEnvio++;
            }else{
                $valorGananciaR+=$valor_comisionr;
                $valorRetiro+=$ventas->valor_real;
                $cantRetiro++;
            }
                
        }
        $cantConsignaciones = 0;
        $valorConsignaciones = 0;
        $cantConsignacionesR = 0;
        $valorConsignacionesR = 0;
        foreach($sucursal->consignaciones as $movimiento){
            if($movimiento->estado==3){
                $estado = 'RECHAZADO';
            }else if($movimiento->estado==2){
                $estado = 'PENDIENTE';
            }else {
                if($movimiento->tipo==2){
                    $cantConsignacionesR++;
                    $valorConsignacionesR+=$movimiento->valor;
                }else{
                    $cantConsignaciones++;
                    $valorConsignaciones+=$movimiento->valor;   
                }
            }
            
        }

        $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->where('codsucursal','=',$sucursal->codsucursal)->select(DB::raw('SUM(valor_comision) as comision'))->first();
        $comisionAcumulada = $comisionAcumulada->comision;

        $pdf = new Fpdf();
        $pdf::AddPage('P',array(100,220));
        $pdf::Image('img/logo-factura.jpg',40,9,18);
        $pdf::SetMargins(5,1);
        $pdf::Ln();
        $pdf::SetFont('Helvetica','B',8);
        $pdf::Cell(55,5,'AFAINVERSIONES S.A.S',0,0,"L");
        $pdf::SetFont('Helvetica','B',4);
        $pdf::SetFont('Arial','B',5);
        $pdf::Ln();
        $pdf::Cell(55,2,'Nit. 901.192.632-6',0,0,"L");
        $pdf::Ln();
        $pdf::Cell(55,2,'Carrera 13 No. 23 - 77 Oficina 102',0,0,"L");
        $pdf::Ln();
        $pdf::Cell(55,2,'Bucaramanga - Santander',0,0,"L");
        $pdf::Ln();
        $pdf::Cell(55,2,utf8_decode('(7) 6960663 - 3205624402'),0,0,"L");
        $pdf::Ln();
        $pdf::Cell(55,2,utf8_decode('Actividad ICA 306999'),0,0,"L");
        $pdf::Ln();
        $pdf::Cell(40,2,utf8_decode('Tarifa 7.2 x 1000'),0,0,"L");
        $pdf::Ln();
        $pdf::Ln();
        $pdf::SetFont('Arial','B',6);
        $pdf::Ln();
        
        $pdf::SetFont('Arial','B',6.5);
        $pdf::SetFillColor(233);
        $pdf::Cell(55,5,utf8_decode('DETALLE CIERRE CAJA'),'TB',0,'C',true);
        $pdf::Ln();
        $pdf::MultiCell(55,5,utf8_decode('SUC-'.str_pad($sucursal->codsucursal, 4, "0", STR_PAD_LEFT).' - '.strtoupper($sucursal->nombres)),0,'R');
        //$pdf::Ln();
        $pdf::cell(15,3,utf8_decode('DIRECCIÓN'),0,"","L");
        $pdf::MultiCell(40,3,utf8_decode(strtoupper($sucursal->direccion)),0,"R");
        //$pdf::Ln();
        $pdf::cell(15,3,utf8_decode('BARRIO'),0,"","L");
        $pdf::cell(40,3,utf8_decode(strtoupper($sucursal->barrio)),0,"","R");
        $pdf::Ln();
        $pdf::cell(15,4,utf8_decode('CUPO'),0,"","L");
        $pdf::cell(40,4,utf8_decode(strtoupper(number_format($sucursal->cupo))),0,"","R");
        $pdf::Ln();
        $pdf::Cell(15,3,utf8_decode('FECHA'),0,0,"L");
        $pdf::Cell(40,3,utf8_decode(Carbon::parse(Carbon::now())->format(trans('general.format_datetime'))),0,0,"R");
        $pdf::Ln();
       
        $pdf::SetFont('Arial','',6.5);
        $pdf::Cell(5,3,utf8_decode('A'),0,0,"C");
        $pdf::Cell(12,3,utf8_decode(Carbon::parse($apertura->fecha)->format(trans('general.format_time'))),0,0,"C");
        $pdf::MultiCell(38,3,utf8_decode(str_pad($empleado->codempleado, 4, "0", STR_PAD_LEFT).' '.strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,"R");
        
        $pdf::Cell(5,3,utf8_decode('C'),0,0,"C");
        $pdf::Cell(12,3,utf8_decode(Carbon::parse($apertura->fecha_cierre)->format(trans('general.format_time'))),0,0,"L");
        $pdf::MultiCell(38,3,utf8_decode(str_pad($empleadoCierra->codempleado, 4, "0", STR_PAD_LEFT).' '.strtoupper($empleadoCierra->nombres.' '.$empleadoCierra->apellidos)),0,"R");
        //$pdf::Ln();
        
        //$pdf::Ln();
        //$pdf::Ln();
        $pdf::cell(15,2,utf8_decode(''),'B',"","L");
        $pdf::cell(40,2,utf8_decode(''),'B',"","R");
        $pdf::Ln();
        $pdf::SetFont('Arial','B',7);
        $pdf::cell(55,5,utf8_decode('INGRESOS EN EFECTIVO'),0,"","C");
        $pdf::Ln();
        $pdf::SetDash(0.5,0.5);
        $pdf::SetFont('Arial','',6.5);
        $pdf::cell(30,4,utf8_decode('ENVIO GIROS'),1,"","L");
        $pdf::cell(5,4,utf8_decode(number_format($cantidades[1]["cant"])),'TB',"","C");
        $pdf::cell(20,4,utf8_decode('$ '.strtoupper(number_format($cantidades[1]["valor"]))),1,"","R");
        $pdf::Ln();
        $pdf::cell(30,4,utf8_decode('RECARGAS'),'L',"","L");
        $pdf::cell(5,4,utf8_decode(number_format($cantidades[4]["cant"])),'LBR',"","C");
        $pdf::cell(20,4,utf8_decode('$ '.strtoupper(number_format($cantidades[4]["valor"]))),'R',"","R");
        $pdf::Ln();
        $pdf::cell(30,4,utf8_decode('GIROS BANCARIOS'),1,"","L");
        $pdf::cell(5,4,utf8_decode(number_format($cantidades[3]["cant"])),0,"","C");
        $pdf::cell(20,4,utf8_decode('$ '.strtoupper(number_format($cantidades[3]["valor"]))),1,"","R");
        $pdf::Ln();
        $pdf::cell(30,4,utf8_decode('PAGOS'),'LB',"","L");
        $pdf::cell(5,4,utf8_decode(number_format($cantidades[5]["cant"])),1,"","C");
        $pdf::cell(20,4,utf8_decode('$ '.strtoupper(number_format($cantidades[5]["valor"]))),'BR',"","R");
        $pdf::Ln(5);
        $pdf::SetFont('Arial','B',6.5);
        $pdf::cell(30,4,utf8_decode('VALOR'),0,"","L", true);
        $pdf::cell(5,4,utf8_decode(number_format($cantidades[1]["cant"]+$cantidades[3]["cant"]+$cantidades[4]["cant"]+$cantidades[5]["cant"])),0,"","C", true);
        $pdf::cell(20,4,utf8_decode('$ '.strtoupper(number_format($cantidades[1]["valor"]+$cantidades[3]["valor"]+$cantidades[4]["valor"]+$cantidades[5]["valor"]))),0,"","R", true);
        $pdf::Ln();
        $pdf::SetDash(0);
        $pdf::cell(15,2,utf8_decode(''),'B',"","L");
        $pdf::cell(40,2,utf8_decode(''),'B',"","R");
        $pdf::Ln();
        $pdf::SetFont('Arial','B',7);
        $pdf::cell(55,5,utf8_decode('EGRESOS EN EFECTIVO'),0,"B","C");
        $pdf::Ln();
        $pdf::SetFont('Arial','',6.5);
        $pdf::SetDash(0.5,0.5);
        $pdf::cell(30,4,utf8_decode('RETIRO GIROS'),1,"","L");
        $pdf::cell(5,4,utf8_decode(number_format($cantidades[2]["cant"])),'TB',"","C");
        $pdf::cell(20,4,utf8_decode('$ '.strtoupper(number_format($cantidades[2]["valor"]))),1,"","R");
        $pdf::SetDash(0);
        $pdf::SetFont('Arial','B',6.5);
        $pdf::Ln(5);
        $pdf::cell(30,4,utf8_decode('VALOR'),0,"","L", true);
        $pdf::cell(5,4,utf8_decode(number_format($cantidades[2]["cant"])),0,"","C", true);
        $pdf::cell(20,4,utf8_decode("$ ".strtoupper(number_format($cantidades[2]["valor"]))),0,"","R", true);
        $pdf::Ln();
        $pdf::cell(15,2,utf8_decode(''),'B',"","L");
        $pdf::cell(40,2,utf8_decode(''),'B',"","R");
        $pdf::Ln();
        $pdf::SetDash(0);
        $pdf::SetFont('Arial','B',6.5);
        $pdf::cell(55,5,utf8_decode('RESUMEN'),0,"B","C");
        $pdf::Ln();
        $pdf::SetDash(0.5,0.5);
        $pdf::SetFont('Arial','',6.5);
        $pdf::cell(30,4,utf8_decode('INGRESOS EFECTIVO'),1,"","L", false);
        $pdf::SetFont('Arial','B',6.5);
        $pdf::cell(5,4,utf8_decode(number_format($cantidades[1]["cant"]+$cantidades[3]["cant"]+$cantidades[4]["cant"]+$cantidades[5]["cant"])),'TB',"","C", false);
        $pdf::cell(20,4,utf8_decode('$ '.strtoupper(number_format($cantidades[1]["valor"]+$cantidades[3]["valor"]+$cantidades[4]["valor"]+$cantidades[5]["valor"]))),1,"","R", false);
        $pdf::Ln();
        
        $pdf::SetFont('Arial','',6.5);
        $pdf::cell(30,4,utf8_decode('EGRESOS EFECTIVO'),'LB',"","L");
        $pdf::SetFont('Arial','B',6.5);
        $pdf::cell(5,4,utf8_decode(number_format($cantidades[2]["cant"])),'RBL',"","C");
        $pdf::cell(20,4,utf8_decode("$ ".strtoupper(number_format($cantidades[2]["valor"]))),'RB',"","R");;
        $pdf::Ln(5);
        
        $pdf::SetFont('Arial','',6.5);
        $pdf::cell(30,4,utf8_decode('TOTAL EFECTIVO'),0,"","L", true);
        $pdf::SetFont('Arial','B',6.5);
        $pdf::cell(5,4,utf8_decode(number_format($cantidades[1]["cant"]+$cantidades[3]["cant"]+$cantidades[4]["cant"]+$cantidades[5]["cant"]+$cantidades[2]["cant"])),0,"","C", true);
        $pdf::cell(20,4,utf8_decode("$ ".strtoupper(number_format($cantidades[1]["valor"]+$cantidades[3]["valor"]+$cantidades[4]["valor"]+$cantidades[5]["valor"]-$cantidades[2]["valor"]))),0,"","R", true);;
        $pdf::Ln(5);
        $pdf::SetFont('Arial','',6.5);
        $pdf::cell(40,5,utf8_decode('COMISIONES ACUMULADAS'),0,"","L", true);
        $pdf::SetFont('Arial','B',6.5);
        $pdf::cell(15,5,utf8_decode('$ '.strtoupper(number_format($comisionAcumulada))),0,"","R", true);
        $pdf::Ln();
        $pdf::SetDash(0);
        $pdf::cell(15,2,utf8_decode(''),'B',"","L");
        $pdf::cell(40,2,utf8_decode(''),'B',"","R");
        $pdf::Ln();
        $pdf::Ln();
        $pdf::cell(55,5,utf8_decode('CONSIGNACIONES'),0,"B","C");
        $pdf::Ln();
        $pdf::SetDash(0.5,0.5);
        $pdf::SetFont('Arial','',6.5);
        $pdf::cell(30,4,utf8_decode('A FAVOR DE GIROS AFA'),1,"","L");
        $pdf::cell(5,4,utf8_decode($cantConsignaciones),'TB',"","C");
        $pdf::SetFont('Arial','B',7);
        $pdf::cell(20,4,utf8_decode('$ '.number_format($valorConsignaciones)),1,"","R");
        
        $pdf::Ln(7);
        
        $pdf::Output();
    }


    public function consolidadoCierre(Request $request)
    {
        $empleado = Empleado::all()->first();
        $sucursal = Sucursal::find(base64_decode($request->m));
        $empleado = $sucursal->empleados()->first();        
        $cantConsignaciones = 0;
        $valorConsignaciones = 0;
        $cantConsignacionesR = 0;
        $valorConsignacionesR = 0;
        //$request->fecha = Carbon::parse(Carbon::today())->format('Y-m-d');
        $pdf = new Fpdf();
        $pdf::AddPage('P','letter');
        $pdf::Image('img/logo-factura.jpg',9,9,18);
        $pdf::SetMargins(5,1);
        $pdf::Ln(20);
        $pdf::SetFont('Arial','',8);
        $pdf::SetFillColor(233);
        $pdf::Cell(205,5,utf8_decode('DETALLE CIERRE CAJA'),'',0,'C',true);
        $pdf::Ln(8);
        $pdf::Cell(102.5,5,utf8_decode('FECHA DE OPERACION: '.$request->fecha),'',0,'L');
        $pdf::Cell(102.5,5,utf8_decode('FECHA DE GENERACION: '.date('Y/m/d')),'',0,'L');
        $pdf::Ln();
        $pdf::Cell(102.5,5,utf8_decode('SUCURSAL: '.strtoupper($sucursal->nombres)),0,0,"L");
        $pdf::Cell(102.5,5,utf8_decode('CAJERO: '.strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,0,"L");
        $pdf::Ln();
        $pdf::Cell(102.5,5,utf8_decode('CODIGO PUNTO: '.$sucursal->codsucursal),0,0,"L");
        $pdf::Cell(102.5,5,utf8_decode('PERFIL CAJERO: PRINCIPAL'),0,0,"L");
        $pdf::Ln(8);
        $pdf::Cell(205,7,utf8_decode('$ '.number_format($sucursal->saldo).' DE TU CUPO $ '.number_format($sucursal->cupo)),'',0,'L',true);
        $pdf::Ln(8);
        $pdf::SetFont('Arial','B',8);
        $pdf::cell(25,5,utf8_decode('No. FACTURA'),1,"","L", true);
        $pdf::cell(25,5,utf8_decode('TIPO'),1,"","L", true);
        $pdf::cell(30,5,utf8_decode('VALOR'),1,"","L", true);
        $pdf::cell(40,5,utf8_decode('FECHA'),1,"","L", true);
        $pdf::cell(30,5,utf8_decode('COMISIONES PAP'),1,"","L", true);
        $pdf::cell(55,5,utf8_decode('CAJERO'),1,"","L", true);
        $pdf::Ln();
        $valorGanancia = 0;
        $valorGananciaR = 0;
        $valorEnvio = 0;
        $valorRetiro = 0;
        $valorVentas = 0;
        $cantEnvio = 0;
        $cantRetiro = 0;
        $valorPorcentaje = 0;
        $codsucursal = NULL;
        $pdf::SetFont('Arial','',8);
        foreach(DB::table('rel_sucursal_movimiento AS r')->leftJoin('movimientos as m', 'm.codmovimiento', 'r.codmovimiento')->join('tarifas AS t','t.codtarifa','=','r.codtarifa')->join('sucursales AS s','s.codsucursal','=','r.codsucursal')->where('r.codsucursal','=',$sucursal->codsucursal)->whereBetween('r.fecha_movimiento', [
            $request->fecha.' 00:00:00',
            $request->fecha.' 23:59:59'
        ])->select('r.*','m.cod_empleado_envia','m.cod_empleado_retira','t.*','s.nombres AS nombreSucursal', 's.ubicacion')->get() as $ventas){
            $valor_comision = $ventas->costo_envia;
            $valor_comision = blank($ventas->porcentaje_envia) ? $valor_comision : $valor_comision+$ventas->valor_real*$ventas->porcentaje_envia/100;
            $valor_comisionr = $ventas->costo_paga;
            $valor_comisionr = blank($ventas->porcentaje_envia) ? $valor_comisionr : $valor_comisionr+$ventas->valor_real*$ventas->porcentaje_envia/100;
            
            $valor_iva = $ventas->iva_costo*1000/100;
            $ventas->iva_porcentaje = "1.".$ventas->iva_porcentaje;
            $costo = $ventas->costo==0 ? ($ventas->porcentaje*$ventas->valor_real/100) : ($ventas->costo) + ($ventas->porcentaje*$ventas->valor_real/100); 
            $valor_iva = blank($ventas->iva_porcentaje) ? $valor_iva : ($costo-$valor_comision-$valor_comisionr)-($costo-$valor_comision-$valor_comisionr)/$ventas->iva_porcentaje;
            $valorVentas+=$valor_iva;
            $ganancia = $costo-$valor_iva-$valor_comision-$valor_comisionr;
            
            $valorPorcentaje+=$ventas->valor_real;
            $comision = $valor_comision+$valor_comisionr;
            if(($ventas->tipo_movimiento==1)){
                $valorGanancia+=$valor_comision;
                $valorEnvio+=$ventas->valor_real;
                $cantEnvio++;
            }else{
                $valorGananciaR+=$valor_comisionr;
                $valorRetiro+=$ventas->valor_real;
                $cantRetiro++;
            }
            $valorComision= $ventas->tipo_movimiento==1 ? number_format($valor_comision,0) : number_format($valor_comisionr,0);
            $pdf::cell(25,5,utf8_decode('V-'.str_pad($ventas->codmovimiento, 4, "0", STR_PAD_LEFT)),1,"","L");
            $pdf::cell(25,5,utf8_decode($ventas->tipo_movimiento==1 ? 'ENVÍO' : 'RETIRO'),1,"","L");
            $pdf::cell(30,5,utf8_decode('$ '.number_format($ventas->valor_real)),1,"","L");
            $pdf::cell(40,5,utf8_decode(Carbon::parse($ventas->fecha_movimiento)->format(trans('general.format_datetime'))),1,"","L");
            $pdf::cell(30,5,utf8_decode('$ '.$valorComision),1,"","L");
            $usuario = Empleado::find($ventas->tipo_movimiento==1 ? $ventas->cod_empleado_envia : $ventas->cod_empleado_retira);
            if(blank($usuario)){
                $usuario = new Empleado();
            }
            $pdf::cell(55,5,utf8_decode($usuario->nombreCompleto()),1,"","L");
            $pdf::Ln();
                
        }
        $pdf::Ln(8);
        $pdf::Cell(205,7,utf8_decode('CONSIGNACIONES'),'',0,'C',true);
        $pdf::Ln(8);
        
        $pdf::cell(25,5,utf8_decode('CÓDIGO'),1,"","L", true);
        $pdf::cell(25,5,utf8_decode('BANCO'),1,"","L", true);
        $pdf::cell(30,5,utf8_decode('TIPO CUENTA'),1,"","L", true);
        $pdf::cell(40,5,utf8_decode('VALOR'),1,"","L", true);
        $pdf::cell(30,5,utf8_decode('FECHA'),1,"","L", true);
        $pdf::cell(55,5,utf8_decode('ESTADO'),1,"","L", true);
        $pdf::Ln();
        foreach($sucursal->consignaciones()->whereBetween('fecha_registro', [
            $request->fecha.' 00:00:00',
            $request->fecha.' 23:59:59'
        ])->get() as $movimiento){
            $pdf::cell(25,5,utf8_decode($movimiento->tipo==2 ? 'INGRESO' : 'EGRESO'),1,"","L");
            $pdf::cell(25,5,utf8_decode($movimiento->banco),1,"","L");
            $pdf::cell(30,5,utf8_decode('AHORROS'),1,"","L");
            $pdf::cell(40,5,utf8_decode('$ '.number_format($movimiento->valor)),1,"","L");
            $pdf::cell(30,5,utf8_decode(Carbon::parse($movimiento->fecha_registro)->format('Y-m-d h:i a')),1,"","L");
            $estado = 'APROBADO';
            if($movimiento->estado==3){
                $estado = 'RECHAZADO';
            }else if($movimiento->estado==2){
                $estado = 'PENDIENTE';
            }
            $pdf::cell(55,5,utf8_decode($estado),1,"","L");
            $pdf::Ln();
            if($movimiento->tipo==2){
                $cantConsignacionesR++;
                $valorConsignacionesR+=$movimiento->valor;
            }else{
                $cantConsignaciones++;
                $valorConsignaciones+=$movimiento->valor;   
            }
        }
        $pdf::Ln(8);
        $pdf::Cell(100,7,utf8_decode('INGRESOS EN EFECTIVO'),'',0,'C',true);
        $pdf::Cell(5,7,utf8_decode(''),'',0,'C');
        $pdf::Cell(100,7,utf8_decode('EGRESOS EN EFECTIVO'),'',0,'C',true);
        $pdf::Ln();

        
        $pdf::cell(15,5,utf8_decode('CANT'),1,"","L");
        $pdf::cell(30,5,utf8_decode('VALOR'),1,"","L");
        $pdf::cell(25,5,utf8_decode('FECHA'),1,"","L");
        $pdf::cell(30,5,utf8_decode('COMISIONES PAP'),1,"","L");
        
        $pdf::cell(5,5,utf8_decode(''),0,"","L");
        
        $pdf::cell(15,5,utf8_decode('CANT'),1,"","L");
        $pdf::cell(30,5,utf8_decode('VALOR'),1,"","L");
        $pdf::cell(25,5,utf8_decode('FECHA'),1,"","L");
        $pdf::cell(30,5,utf8_decode('COMISIONES PAP'),1,"","L");
        
        $pdf::Ln();
        $pdf::cell(15,5,utf8_decode($cantEnvio),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorEnvio)),1,"","L");
        $pdf::cell(25,5,utf8_decode($request->fecha),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorGanancia)),1,"","L");
        
        $pdf::cell(5,5,utf8_decode(''),0,"","L");
        
        $pdf::cell(15,5,utf8_decode($cantRetiro),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorRetiro)),1,"","L");
        $pdf::cell(25,5,utf8_decode($request->fecha),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorGananciaR)),1,"","L");
        
        $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->where('codsucursal','=',$sucursal->codsucursal)->select(DB::raw('SUM(valor_comision) as comision'))->first();
        $comisionAcumulada = $comisionAcumulada->comision;
        
        $pdf::Ln(12);
        $pdf::Cell(42.5,7,utf8_decode(''),'',0,'C');
        $pdf::Cell(120,7,utf8_decode('VALOR TOTAL'),'',0,'C',true);
        $pdf::Ln();
        $pdf::Cell(42.5,7,utf8_decode(''),'',0,'C');
        $pdf::cell(35,5,utf8_decode('TOTAL MOVIMIENTOS'),1,"","L");
        $pdf::cell(30,5,utf8_decode('VALOR'),1,"","L");
        $pdf::cell(25,5,utf8_decode('FECHA'),1,"","L");
        $pdf::cell(30,5,utf8_decode('COMISIONES PAP'),1,"","L");
        $pdf::Ln();
        $pdf::Cell(42.5,7,utf8_decode(''),'',0,'C');
        $pdf::cell(35,5,utf8_decode($cantRetiro+$cantEnvio),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorRetiro+$valorEnvio)),1,"","L");
        $pdf::cell(25,5,utf8_decode($request->fecha),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorGananciaR+$valorGanancia)),1,"","L");
        
        
        $pdf::Output();
    }

    public function extracto(Request $request)
    {
        $empleado = Empleado::all()->first();
        $sucursal = Sucursal::find(base64_decode($request->m));
        $empleado = $sucursal->empleados()->first();        
        $cantConsignaciones = 0;
        $valorConsignaciones = 0;
        $cantConsignacionesR = 0;
        $valorConsignacionesR = 0;
        $giros = 0;
        $totales = [];
        $request->fecha = Carbon::parse(Carbon::today())->format('Y-m-d').' 23:59:59';
        $inicio = date('Y').'-01-01 00:00:00';
        $fin = $request->fecha;
        $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado','=','1')->whereBetween('r.fecha_movimiento',[
            $inicio,
            $fin
        ])->where('codsucursal','=',$sucursal->codsucursal)->where('tipo_movimiento','=','1')->select(DB::raw('SUM(valor_real) as valor'))->first();
        $comisionAcumulada = $comisionAcumulada->valor;
        $giros+=$comisionAcumulada;
        $totales["enviado"]=$comisionAcumulada;
        $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->whereBetween('r.fecha_movimiento',[
            $inicio,
            $fin
        ])->where('codsucursal','=',$sucursal->codsucursal)->select(DB::raw('SUM(valor_comision) as comision'))->first();
        $comisionAcumulada = $comisionAcumulada->comision;
        $totales["comision"]=$comisionAcumulada;
        $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado','=','1')->whereBetween('r.fecha_movimiento',[
            $inicio,
            $fin
        ])->where('codsucursal','=',$sucursal->codsucursal)->where('tipo_movimiento','=','2')->select(DB::raw('SUM(valor_real) as valor'))->first();
        $comisionAcumulada = $comisionAcumulada->valor;
        $giros-=$comisionAcumulada;
        $totales["recibido"]=$comisionAcumulada;
        $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado','=','1')->whereBetween('r.fecha_movimiento',[
            $inicio,
            $fin
        ])->where('codsucursal','=',$sucursal->codsucursal)->where('tipo_movimiento','=','4')->where('estado','=','1')->select(DB::raw('SUM(valor_real) as valor'))->first();
        $movimientos = DB::table('rel_sucursal_movimiento AS r')->where('estado','=','1')->whereBetween('r.fecha_movimiento',[
            $inicio,
            $fin
        ])->where('codsucursal','=',$sucursal->codsucursal)->where('estado','=','1')->get();
        $datosGiros = [
            "enviado" => [
                "total" => 0,
                "cantidad" => 0,
                "comision" => 0,
            ],
            "pagado" => [
                "total" => 0,
                "cantidad" => 0,
                "comision" => 0,
            ],
            "pagado" => [
                "total" => 0,
                "cantidad" => 0,
                "comision" => 0,
            ],
            "recibos" => [
                "total" => 0,
                "cantidad" => 0,
                "comision" => 0,
            ],
            "recargas" => [
                "total" => 0,
                "cantidad" => 0,
                "comision" => 0,
            ],
            "consignaciones" => [
                "total" => 0,
                "cantidad" => 0,
                "comision" => 0,
            ]
        ];
        foreach($movimientos as $movimiento){
            if($movimiento->estado==1){
                if($movimiento->tipo_movimiento==1){
                    $datosGiros["enviado"]["total"]+=$movimiento->valor_real;
                    $datosGiros["enviado"]["comision"]+=$movimiento->valor_comision;
                    $datosGiros["enviado"]["cantidad"]++;
                }else if($movimiento->tipo_movimiento==2){
                    $datosGiros["pagado"]["total"]+=$movimiento->valor_real;
                    $datosGiros["pagado"]["comision"]+=$movimiento->valor_comision;
                    $datosGiros["pagado"]["cantidad"]++;
                }else if($movimiento->tipo_movimiento==5){
                    $datosGiros["recibos"]["total"]+=$movimiento->valor_real;
                    $datosGiros["recibos"]["comision"]+=$movimiento->valor_comision;
                    $datosGiros["recibos"]["cantidad"]++;
                }else if($movimiento->tipo_movimiento==4){
                    $datosGiros["recargas"]["total"]+=$movimiento->valor_real;
                    $datosGiros["recargas"]["comision"]+=$movimiento->valor_comision;
                    $datosGiros["recargas"]["cantidad"]++;
                }else if($movimiento->tipo_movimiento==3){
                    $datosGiros["consignaciones"]["total"]+=$movimiento->valor_real;
                    $datosGiros["consignaciones"]["comision"]+=$movimiento->valor_comision;
                    $datosGiros["consignaciones"]["cantidad"]++;
                }
            }
        }
        //dd($datosGiros);

        $comisionAcumulada = $comisionAcumulada->valor;
        $totales["recargas"]=$comisionAcumulada;
        $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado','=','1')->whereBetween('r.fecha_movimiento',[
            $inicio,
            $fin
        ])->where('codsucursal','=',$sucursal->codsucursal)->where('tipo_movimiento','=','4')->where('estado','=','3')->select(DB::raw('SUM(valor_real) as valor'))->first();
        $comisionAcumulada = $comisionAcumulada->valor;
        $totales["consignaciones"]=$comisionAcumulada;
        $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado','=','1')->whereBetween('r.fecha_movimiento',[
            $inicio,
            $fin
        ])->where('codsucursal','=',$sucursal->codsucursal)->where('tipo_movimiento','=','5')->where('estado','=','3')->select(DB::raw('SUM(valor_real) as valor'))->first();
        $comisionAcumulada = $comisionAcumulada->valor;
        $totales["pagos"]=$comisionAcumulada;
        

        $comisionSucursal = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->where('codsucursal','=',$sucursal->codsucursal)->select(DB::raw('SUM(valor_comision) as comision'))->first();
        $comisionSucursal = $comisionSucursal->comision;
        $pdf = new Fpdf();
        $pdf::SetDrawColor(233);
        $pdf::AddPage('P','letter');
        $pdf::Image('img/afalogo.jpg',17,9,35);
        $pdf::Image('img/logo-giros.jpg',17,45,35);
        $pdf::SetMargins(5,1);
        $pdf::Ln();
        $pdf::SetFillColor(233);
        $pdf::SetX(70);
        $pdf::SetFont('Arial','B',6);
        $pdf::SetFillColor(1,16,65);
        $pdf::SetTextColor(255);
        $pdf::Cell(140,5,utf8_decode('INFORMACIÓN DE SUCURSAL'),0,0,"L", true);
        $pdf::SetTextColor(0);
        $pdf::SetFont('Arial','',8);
        $pdf::Ln();
        $pdf::SetX(70);
        $pdf::SetFont('Arial','B',12);
        $pdf::Cell(140,7,utf8_decode('S'.str_pad($sucursal->codsucursal, 4, "0", STR_PAD_LEFT).' - '.strtoupper($sucursal->nombres)),0,0,"L");
        $pdf::SetFont('Arial','',7);
        $pdf::Ln();
        $pdf::SetX(70);
        $pdf::Cell(30,3.5,utf8_decode('ESTADO SUCURSAL:'),0,0,'L');
        $pdf::Cell(100,3.5,utf8_decode($sucursal->bloqueo!=1 ? 'ACTIVA' : 'BLOQUEADA'),0,0,'L');
        $pdf::Ln();
        $pdf::SetX(70);
        $pdf::Cell(30,3.5,utf8_decode('FECHA GENERACIÓN'),0,0,'L');
        $pdf::Cell(100,3.5,utf8_decode(Carbon::now()),0,0,'L');
        $pdf::Ln();
        $pdf::SetX(70);
        $pdf::Cell(30,3.5,utf8_decode('FECHA INICIO'),0,0,'L');
        $pdf::Cell(25,3.5,utf8_decode($request->fecha),0,0,'L');
        $pdf::Ln();
        $pdf::SetX(70);
        $pdf::Cell(30,3.5,utf8_decode('FECHA FIN'),0,0,'L');
        $pdf::Cell(33,3.5,utf8_decode($request->fecha),0,0,'L');
        $pdf::Cell(30,3.5,utf8_decode(''),0,0,'L');
        $pdf::Cell(100,3.5,utf8_decode(''),0,0,'L');
        $pdf::Ln(10); 
        $yTemp = $pdf::GetY();
        $pdf::Image('img/documentos/saldo-icono.jpg',55+83,$yTemp,18);
        $pdf::Image('img/documentos/cupo-icono.jpg',60+31,$yTemp,18);
        $pdf::Image('img/documentos/comision-icono.jpg',62+116,$yTemp,18);
        $pdf::RoundedRect(70, $yTemp-2, 136.7+3, 30,1,'12');
        $pdf::Ln(16); 
        $y1 = $pdf::GetY();
        $pdf::SetXY(70, $y1-18);
        
        $pdf::Cell(205/6*2-10,23,utf8_decode(''),0,0,'C');
        $pdf::Cell(205/6,23,utf8_decode(''),'LR',0,'C');
        $pdf::Cell(205/6+3+10,23,utf8_decode(''),0,0,'C');

        $pdf::SetXY(70, $y1);
        $pdf::SetX(70);
        $pdf::Cell(205/6*2-10,5,utf8_decode('CUPO AUTORIZADO'),0,0,'C');
        $pdf::Cell(205/6,5,utf8_decode('SALDO A LA FECHA'),0,0,'C');
        $pdf::Cell(205/6+3+10,5,utf8_decode('COMISIONES ACUMULADAS'),0,0,'C');
        $pdf::Ln();
        $pdf::SetX(70);
        $pdf::SetTextColor(255);
        $pdf::SetFont('Arial','B',12);
        $pdf::Cell(205/6*2-10,7,utf8_decode('$ '.number_format($sucursal->cupo)),0,0,'C', true);
        $pdf::Cell(205/6,7,utf8_decode('$ '.number_format($sucursal->saldo)),0,0,'C', true);
        $pdf::Cell(205/6+3+10,7,utf8_decode('$ '.number_format($comisionSucursal)),0,0,'C', true);
        $pdf::SetTextColor(0);
        $pdf::SetTextColor(255);
        $pdf::Ln(10);
        $pdf::Cell(205,7,utf8_decode('DETALLE DE EXTRACTO'),0,0,'C', true);
        $pdf::Ln(10);
        $pdf::Cell(205/2-2,7,utf8_decode('GIROS'),0,0,'C', true);
        $pdf::Cell(4,5,utf8_decode(''),0,0,'C');
        $pdf::Cell(205/2-2,7,utf8_decode('FACTURAS'),0,0,'C', true);
        $pdf::SetTextColor(0);
        $pdf::SetFillColor(233);
        $pdf::Ln();
        $pdf::SetFont('Arial','B',12);
        $pdf::SetFont('Arial','b',8);
        $pdf::Cell(35,3.5,utf8_decode('Descripción'),0,0,'C', true);
        $pdf::Cell(10,3.5,utf8_decode('Cant.'),0,0,'C', true);
        $pdf::Cell(35,3.5,utf8_decode('Valor'),0,0,'C', true);
        $pdf::Cell(20.5,3.5,utf8_decode('Comisión'),0,0,'C', true);
        $pdf::Cell(4,3.5,utf8_decode(''),0,0,'C');
        $pdf::SetFont('Arial','b',8);
        $pdf::Cell(35,3.5,utf8_decode('Descripción'),0,0,'C', true);
        $pdf::Cell(10,3.5,utf8_decode('Cant.'),0,0,'C', true);
        $pdf::Cell(35,3.5,utf8_decode('Valor'),0,0,'C', true);
        $pdf::Cell(20.5,3.5,utf8_decode('Comisión'),0,0,'C', true);
        $pdf::SetFont('Arial','',8);
        $pdf::Ln();
        $pdf::SetFont('Arial','B',12);
        $pdf::SetFont('Arial','',8);
        $pdf::Cell(35,5,utf8_decode('Total giros envíados'),0,0,'L');
        $pdf::SetFont('Arial','b',8);
        $pdf::Cell(10,5,utf8_decode(' '.number_format($datosGiros["enviado"]["cantidad"])),'LR',0,'C');
        $pdf::Cell(35,5,utf8_decode('$ '.number_format($datosGiros["enviado"]["total"])),'LR',0,'R');
        $pdf::Cell(20.5,5,utf8_decode('$ '.number_format($datosGiros["enviado"]["comision"])),'LR',0,'R');
        $pdf::Cell(4,5,utf8_decode(''),0,0,'C');
        $pdf::SetFont('Arial','',8);
        $pdf::Cell(35,5,utf8_decode('Total facturas pagadas'),1,0,'L');
        $pdf::SetFont('Arial','b',8);
        $pdf::Cell(10,5,utf8_decode(number_format($datosGiros["recibos"]["cantidad"])),'1',0,'C');
        $pdf::Cell(35,5,utf8_decode('$ '.number_format($datosGiros["recibos"]["total"])),'1',0,'R');
        $pdf::Cell(20.5,5,utf8_decode('$ '.number_format($datosGiros["recibos"]["comision"])),'1',0,'R');
        $pdf::SetFont('Arial','',8);
        $pdf::Ln();
        
        $pdf::Cell(35,5,utf8_decode('Total giros pagados'),0,0,'L');
        $pdf::SetFont('Arial','b',8);
        $pdf::Cell(10,5,utf8_decode(' '.number_format($datosGiros["pagado"]["cantidad"])),'LR',0,'C');
        $pdf::Cell(35,5,utf8_decode('$ ('.number_format($datosGiros["pagado"]["total"]).')'),'LR',0,'R');
        $pdf::Cell(20.5,5,utf8_decode('$ '.number_format($datosGiros["pagado"]["comision"])),'LR',0,'R');
        $pdf::Cell(4,5,utf8_decode(''),0,0,'C');
        $pdf::SetFont('Arial','',8);
        
        $pdf::Ln();
        
        $pdf::SetFont('Arial','b',8);
        $pdf::Cell(35,5,utf8_decode('Total movimientos'),0,0,'L', true);
        $pdf::Cell(10,5,utf8_decode(' '.number_format($datosGiros["pagado"]["cantidad"]+$datosGiros["enviado"]["cantidad"])),'LR',0,'C', true);
        $pdf::Cell(35,5,utf8_decode('$ '.number_format($datosGiros["enviado"]["total"]-$datosGiros["pagado"]["total"]).''),0,0,'R', true);
        $pdf::Cell(20.5,5,utf8_decode('$ '.number_format($datosGiros["enviado"]["comision"]+$datosGiros["pagado"]["comision"]).''),0,0,'R', true);
        $pdf::Cell(4,5,utf8_decode(''),0,0,'C');
        $pdf::SetFont('Arial','b',8);
        
        $pdf::Ln(10);
        $pdf::SetFillColor(1,16,65);
        $pdf::SetFont('Arial','B',12);
        $pdf::SetTextColor(255);
        $pdf::Cell(205/2-2,7,utf8_decode('RECARGAS'),1,0,'C', true);
        $pdf::Cell(4,5,utf8_decode(''),0,0,'C');
        $pdf::Cell(205/2-2,7,utf8_decode('CONSIGNACIONES'),1,0,'C', true);
        $pdf::SetTextColor(0);
        $pdf::SetFillColor(233);
        $pdf::SetDrawColor(233);
        $pdf::Ln();
        $pdf::SetFont('Arial','B',12);
        $pdf::SetFont('Arial','b',8);
        $pdf::Cell(40,3.5,utf8_decode('Descripción'),0,0,'C', true);
        $pdf::Cell(40,3.5,utf8_decode('Valor'),0,0,'C', true);
        $pdf::Cell(20.5,3.5,utf8_decode('Comisión'),0,0,'C', true);
        $pdf::Cell(4,3.5,utf8_decode(''),0,0,'C');
        $pdf::SetFont('Arial','b',8);
        $pdf::Cell((205/2-2)/2,3.5,utf8_decode('Descripción'),0,0,'C', true);
        $pdf::Cell(29.7,3.5,utf8_decode('Valor'),0,0,'C', true);
        $pdf::Cell(20.5,3.5,utf8_decode('Comisión'),0,0,'C', true);
        $pdf::SetFont('Arial','',8);
        $pdf::Ln();
        $pdf::SetFont('Arial','B',12);
        $pdf::SetFont('Arial','',8);
        $pdf::Cell(35,5,utf8_decode('Total recargas realizadas'),1,0,'L');
        $pdf::SetFont('Arial','b',8);
        $pdf::Cell(10,5,utf8_decode(number_format($datosGiros["recargas"]["cantidad"])),'1',0,'C');
        $pdf::Cell(35,5,utf8_decode('$ '.number_format($datosGiros["recargas"]["total"])),'1',0,'R');
        $pdf::Cell(20.5,5,utf8_decode('$ '.number_format($datosGiros["recargas"]["comision"])),'1',0,'R');
        $pdf::Cell(4,5,utf8_decode(''),0,0,'C');
        $pdf::SetFont('Arial','',8);
        $pdf::Cell(35,5,utf8_decode('Total consign. registradas'),1,0,'L');
        $pdf::SetFont('Arial','b',8);
        $pdf::Cell(10,5,utf8_decode($datosGiros["consignaciones"]["cantidad"]),1,0,'C');
        $pdf::Cell(35,5,utf8_decode('$ '.number_format($datosGiros["consignaciones"]["total"]).''),'1',0,'R');
        $pdf::Cell(20.5,5,utf8_decode('$ '.number_format($datosGiros["consignaciones"]["comision"])),'1',0,'R');
        $pdf::SetFont('Arial','',8);


        $data = array('Giros' => ($datosGiros["enviado"]["total"]-$datosGiros["pagado"]["total"]), 'Pagos' => $datosGiros["recibos"]["total"], 'Recargas' => $datosGiros["recargas"]["total"], 'Consignaciones' => $datosGiros["consignaciones"]["total"]);

        $col1=array(1,16,65);
        $col2=array(0,172,172);
        $col3=array(52,143,226);
        $col4=array(255,0,0);

        $pdf::Ln(8);
        
        $pdf::SetFont('Arial', '', 10);
        $valX = $pdf::GetX();
        $valY = $pdf::GetY()+6;
        
        $pdf::Ln(8);
        
        $pdf::SetXY(5, $valY-5);
        $pdf::SetFont('Arial', 'B', 10);
        $pdf::Cell(205/2-2.5,5,utf8_decode('MOVIMIENTOS REALIZADOS'),'1',0,'C', true);
        $pdf::Cell(5,5,utf8_decode(''),0,0,'C');
        $pdf::Cell(205/2-2.5,5,utf8_decode('COMISIONES'),'1',0,'C', true);
        $pdf::SetFont('Arial', '', 10);
        $pdf::SetXY(10, $valY);
        $pdf::PieChart(95, 35, $data, '%l (%p)', array($col1,$col2,$col3,$col4));
        $pdf::RoundedRect(5, $valY-5, 100, 40,1,'34');
        $data = array('Giros' => ($datosGiros["enviado"]["comision"]+$datosGiros["pagado"]["comision"]), 'Pagos' => $datosGiros["recibos"]["comision"], 'Recargas' => $datosGiros["recargas"]["comision"], 'Consignaciones' => $datosGiros["consignaciones"]["comision"]);

        $pdf::SetXY(115, $valY);
        $pdf::PieChart(95, 35, $data, '%l (%p)', array($col1,$col2,$col3,$col4));
        $pdf::RoundedRect(110, $valY-5, 100, 40,1,'1234');

        $pdf::SetXY($valX, $valY + 40);
        $pdf::Output();
        exit;
        
        $pdf::SetTextColor(0);
        $pdf::Ln(30); 
        $pdf::Cell(41,5,utf8_decode(number_format($totales["enviado"])),1,0,'C');
        $pdf::Cell(41,5,utf8_decode(number_format($totales["recibido"])),1,0,'C');
        $pdf::Cell(41,5,utf8_decode(number_format($totales["pagos"])),1,0,'C');
        $pdf::Cell(41,5,utf8_decode(number_format($totales["recargas"])),1,0,'C');
        $pdf::Cell(41,5,utf8_decode(number_format($totales["consignaciones"])),1,0,'C');
        $pdf::Ln(8);
        $pdf::Cell(102.5,5,utf8_decode('FECHA DE OPERACION: '.$request->fecha),'',0,'L');
        $pdf::Cell(102.5,5,utf8_decode('FECHA DE GENERACION: '.date('Y/m/d')),'',0,'L');
        $pdf::Ln();
        $pdf::Cell(102.5,5,utf8_decode('CAJERO: '.strtoupper($empleado->nombres.' '.$empleado->apellidos)),0,0,"L");
        $pdf::Ln();
        $pdf::Cell(102.5,5,utf8_decode('CODIGO PUNTO: '.$sucursal->codsucursal),0,0,"L");
        $pdf::Cell(102.5,5,utf8_decode('PERFIL CAJERO: PRINCIPAL'),0,0,"L");
        $pdf::Ln(8);
        $pdf::Cell(205,7,utf8_decode('$ '.number_format($sucursal->saldo).' DE TU CUPO $ '.number_format($sucursal->cupo)),'',0,'L',true);
        $pdf::Ln(8);
        $pdf::SetFont('Arial','B',8);
        $pdf::cell(25,5,utf8_decode('No. FACTURA'),1,"","L", true);
        $pdf::cell(25,5,utf8_decode('TIPO'),1,"","L", true);
        $pdf::cell(30,5,utf8_decode('VALOR'),1,"","L", true);
        $pdf::cell(40,5,utf8_decode('FECHA'),1,"","L", true);
        $pdf::cell(30,5,utf8_decode('COMISIONES PAP'),1,"","L", true);
        $pdf::cell(55,5,utf8_decode('CAJERO'),1,"","L", true);
        $pdf::Ln();
        $valorGanancia = 0;
        $valorGananciaR = 0;
        $valorEnvio = 0;
        $valorRetiro = 0;
        $valorVentas = 0;
        $cantEnvio = 0;
        $cantRetiro = 0;
        $valorPorcentaje = 0;
        $codsucursal = NULL;
        $pdf::SetFont('Arial','',8);
        foreach(DB::table('rel_sucursal_movimiento AS r')->leftJoin('movimientos as m', 'm.codmovimiento', 'r.codmovimiento')->join('tarifas AS t','t.codtarifa','=','r.codtarifa')->join('sucursales AS s','s.codsucursal','=','r.codsucursal')->where('r.codsucursal','=',$sucursal->codsucursal)->whereBetween('r.fecha_movimiento', [
            $request->fecha.' 00:00:00',
            $request->fecha.' 23:59:59'
        ])->select('r.*','m.cod_empleado_envia','m.cod_empleado_retira','t.*','s.nombres AS nombreSucursal', 's.ubicacion')->get() as $ventas){
            $valor_comision = $ventas->costo_envia;
            $valor_comision = blank($ventas->porcentaje_envia) ? $valor_comision : $valor_comision+$ventas->valor_real*$ventas->porcentaje_envia/100;
            $valor_comisionr = $ventas->costo_paga;
            $valor_comisionr = blank($ventas->porcentaje_envia) ? $valor_comisionr : $valor_comisionr+$ventas->valor_real*$ventas->porcentaje_envia/100;
            
            $valor_iva = $ventas->iva_costo*1000/100;
            $ventas->iva_porcentaje = "1.".$ventas->iva_porcentaje;
            $costo = $ventas->costo==0 ? ($ventas->porcentaje*$ventas->valor_real/100) : ($ventas->costo) + ($ventas->porcentaje*$ventas->valor_real/100); 
            $valor_iva = blank($ventas->iva_porcentaje) ? $valor_iva : ($costo-$valor_comision-$valor_comisionr)-($costo-$valor_comision-$valor_comisionr)/$ventas->iva_porcentaje;
            $valorVentas+=$valor_iva;
            $ganancia = $costo-$valor_iva-$valor_comision-$valor_comisionr;
            
            $valorPorcentaje+=$ventas->valor_real;
            $comision = $valor_comision+$valor_comisionr;
            if(($ventas->tipo_movimiento==1)){
                $valorGanancia+=$valor_comision;
                $valorEnvio+=$ventas->valor_real;
                $cantEnvio++;
            }else{
                $valorGananciaR+=$valor_comisionr;
                $valorRetiro+=$ventas->valor_real;
                $cantRetiro++;
            }
            $valorComision= $ventas->tipo_movimiento==1 ? number_format($valor_comision,0) : number_format($valor_comisionr,0);
            $pdf::cell(25,5,utf8_decode('V-'.str_pad($ventas->codmovimiento, 4, "0", STR_PAD_LEFT)),1,"","L");
            $pdf::cell(25,5,utf8_decode($ventas->tipo_movimiento==1 ? 'ENVÍO' : 'RETIRO'),1,"","L");
            $pdf::cell(30,5,utf8_decode('$ '.number_format($ventas->valor_real)),1,"","L");
            $pdf::cell(40,5,utf8_decode(Carbon::parse($ventas->fecha_movimiento)->format(trans('general.format_datetime'))),1,"","L");
            $pdf::cell(30,5,utf8_decode('$ '.$valorComision),1,"","L");
            $usuario = Empleado::find($ventas->tipo_movimiento==1 ? $ventas->cod_empleado_envia : $ventas->cod_empleado_retira);
            if(blank($usuario)){
                $usuario = new Empleado();
            }
            $pdf::cell(55,5,utf8_decode($usuario->nombreCompleto()),1,"","L");
            $pdf::Ln();
                
        }
        $pdf::Ln(8);
        $pdf::Cell(205,7,utf8_decode('CONSIGNACIONES'),'',0,'C',true);
        $pdf::Ln(8);
        
        $pdf::cell(25,5,utf8_decode('CÓDIGO'),1,"","L", true);
        $pdf::cell(25,5,utf8_decode('BANCO'),1,"","L", true);
        $pdf::cell(30,5,utf8_decode('TIPO CUENTA'),1,"","L", true);
        $pdf::cell(40,5,utf8_decode('VALOR'),1,"","L", true);
        $pdf::cell(30,5,utf8_decode('FECHA'),1,"","L", true);
        $pdf::cell(55,5,utf8_decode('ESTADO'),1,"","L", true);
        $pdf::Ln();
        foreach($sucursal->consignaciones()->whereBetween('fecha_registro', [
            $request->fecha.' 00:00:00',
            $request->fecha.' 23:59:59'
        ])->get() as $movimiento){
            $pdf::cell(25,5,utf8_decode($movimiento->tipo==2 ? 'INGRESO' : 'EGRESO'),1,"","L");
            $pdf::cell(25,5,utf8_decode($movimiento->banco),1,"","L");
            $pdf::cell(30,5,utf8_decode('AHORROS'),1,"","L");
            $pdf::cell(40,5,utf8_decode('$ '.number_format($movimiento->valor)),1,"","L");
            $pdf::cell(30,5,utf8_decode(Carbon::parse($movimiento->fecha_registro)->format('Y-m-d h:i a')),1,"","L");
            $estado = 'APROBADO';
            if($movimiento->estado==3){
                $estado = 'RECHAZADO';
            }else if($movimiento->estado==2){
                $estado = 'PENDIENTE';
            }
            $pdf::cell(55,5,utf8_decode($estado),1,"","L");
            $pdf::Ln();
            if($movimiento->tipo==2){
                $cantConsignacionesR++;
                $valorConsignacionesR+=$movimiento->valor;
            }else{
                $cantConsignaciones++;
                $valorConsignaciones+=$movimiento->valor;   
            }
        }
        $pdf::Ln(8);
        $pdf::Cell(100,7,utf8_decode('INGRESOS EN EFECTIVO'),'',0,'C',true);
        $pdf::Cell(5,7,utf8_decode(''),'',0,'C');
        $pdf::Cell(100,7,utf8_decode('EGRESOS EN EFECTIVO'),'',0,'C',true);
        $pdf::Ln();

        
        $pdf::cell(15,5,utf8_decode('CANT'),1,"","L");
        $pdf::cell(30,5,utf8_decode('VALOR'),1,"","L");
        $pdf::cell(25,5,utf8_decode('FECHA'),1,"","L");
        $pdf::cell(30,5,utf8_decode('COMISIONES PAP'),1,"","L");
        
        $pdf::cell(5,5,utf8_decode(''),0,"","L");
        
        $pdf::cell(15,5,utf8_decode('CANT'),1,"","L");
        $pdf::cell(30,5,utf8_decode('VALOR'),1,"","L");
        $pdf::cell(25,5,utf8_decode('FECHA'),1,"","L");
        $pdf::cell(30,5,utf8_decode('COMISIONES PAP'),1,"","L");
        
        $pdf::Ln();
        $pdf::cell(15,5,utf8_decode($cantEnvio),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorEnvio)),1,"","L");
        $pdf::cell(25,5,utf8_decode($request->fecha),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorGanancia)),1,"","L");
        
        $pdf::cell(5,5,utf8_decode(''),0,"","L");
        
        $pdf::cell(15,5,utf8_decode($cantRetiro),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorRetiro)),1,"","L");
        $pdf::cell(25,5,utf8_decode($request->fecha),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorGananciaR)),1,"","L");
        
        $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->where('codsucursal','=',$sucursal->codsucursal)->select(DB::raw('SUM(valor_comision) as comision'))->first();
        $comisionAcumulada = $comisionAcumulada->comision;
        
        $pdf::Ln(12);
        $pdf::Cell(42.5,7,utf8_decode(''),'',0,'C');
        $pdf::Cell(120,7,utf8_decode('VALOR TOTAL'),'',0,'C',true);
        $pdf::Ln();
        $pdf::Cell(42.5,7,utf8_decode(''),'',0,'C');
        $pdf::cell(35,5,utf8_decode('TOTAL MOVIMIENTOS'),1,"","L");
        $pdf::cell(30,5,utf8_decode('VALOR'),1,"","L");
        $pdf::cell(25,5,utf8_decode('FECHA'),1,"","L");
        $pdf::cell(30,5,utf8_decode('COMISIONES PAP'),1,"","L");
        $pdf::Ln();
        $pdf::Cell(42.5,7,utf8_decode(''),'',0,'C');
        $pdf::cell(35,5,utf8_decode($cantRetiro+$cantEnvio),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorRetiro+$valorEnvio)),1,"","L");
        $pdf::cell(25,5,utf8_decode($request->fecha),1,"","L");
        $pdf::cell(30,5,utf8_decode('$ '.number_format($valorGananciaR+$valorGanancia)),1,"","L");
        
        
        $pdf::Output();
    }



    public function asignarHorario(Request $request){
        $sucursal = Sucursal::find($request->codsucursal);
        $dataSucursal=$request->all();
        unset($dataSucursal["_token"]);
        unset($dataSucursal["codhorario"]);
        if($request->jornada_continua_lv==1){
            $dataSucursal["horario_m_lv"] = '';
            $dataSucursal["horario_t_lv"] = '';
        }else{
            $dataSucursal["horario_c_lv"] = '';
            $dataSucursal["jornada_continua_lv"] = 0;
        }
        if($request->jornada_continua_s==1){
            $dataSucursal["horario_m_s"] = '';
            $dataSucursal["horario_t_s"] = '';
        }else{
            $dataSucursal["horario_c_s"] = '';
            $dataSucursal["jornada_continua_s"] = 0;
        }
        if($request->jornada_continua_d==1){
            $dataSucursal["horario_m_d"] = '';
            $dataSucursal["horario_t_d"] = '';
        }else{
            $dataSucursal["horario_c_d"] = '';
            $dataSucursal["jornada_continua_d"] = 0;
        }
        if(blank($request->codhorario)){
            $horario = new Horario($dataSucursal);
            $horario->save();
        }else{
            $horario = Horario::find($request->codhorario);
            $horario->update($dataSucursal);
           
        }
        return response()->json([
            'formulario' => view('sucursal.partials.form-horarios')->with([
                'sucursal' => $sucursal,
            ])->render()
        ]);
    }

    



    

    public function eliminar(Request $request){
    
        $sucursal = sucursal::destroy($request->codsucursal);
        
        return response()->json([
            'formulario' => $sucursal
        ]);

        

    }



    public function registrarConsignacion(Request $request){
        $file = \Illuminate\Support\Facades\Input::file('soporte');
        $sucursal = Sucursal::find($request->codsucursal);
        //$nombre = time().'.'.$file->getClientOriginalExtension();
        $destinationPath = 'soportes';
        $mensaje = "Ocurrió un error a la hora de registrar la consignación";
        $error=1;
        //if($file->move($destinationPath,$nombre)){
        if(1==1){
            if($request->prestamo==1){
                $sucursal->consignaciones()->save(new Consignacion([
                'valor' => $request->valor,
                'soporte' => $request->soporte,
                'fecha_registro' => Carbon::now(),
                'estado' => 1,
                'tipo' => 2,
                'banco' => $request->banco
                ]));
                
                $sucursal->update([
    
                    'saldo'=>$sucursal->saldo+$request->valor
    
                ]);
        
                
            }else{
                
                    $sucursal->consignaciones()->save(new Consignacion([
                    'valor' => $request->valor,
                    'soporte' => $request->soporte,
                    'fecha_registro' => Carbon::now(),
                    'estado' => 2,
                    'tipo' => 1,
                    'banco' => $request->banco
                    ]));
                
                
            }
            
            $mensaje = "La consignación se registro con éxito";
            $error=0;
        }
        return redirect()->route('sucursal.estado-cuenta', [
            $sucursal->codsucursal
        ]);
        exit();
    
       
       
        dd($file,$request->all());
    }



    /**

     *

     * @tutorial Method Description: carga la vista de crear pagina

     * @author Bayron Tarazona ~bayronthz@gmail.com

     * @since {15/03/2018}

     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory

     */

    public function crearSucursal(Request $request)

    {
        $file = \Illuminate\Support\Facades\Input::file('documentos');
        
        $dataSucursal=$request->all();
        unset($dataSucursal["_token"]);
        unset($dataSucursal["celular_confirmar"]);
        
        $mensaje = "Ocurrió un error a la hora de registrar la consignación";
        $error=1;
        
        if(blank($request->codsucursal)){
            $Sucursal = new Sucursal($dataSucursal);
            $Sucursal->save();
            $request->mensaje = "Asignatura guardada con éxito";
        }else{
            $Sucursal = Sucursal::find($request->codsucursal);
            $Sucursal->update($dataSucursal);
        }
        if(!blank($file)){
            foreach($file as $tipoDocumento => $documento){
                $nombre = $tipoDocumento.'-'.time().'.'.$documento->getClientOriginalExtension();
                $destinationPath = 'documentacion';
                if($documento->move($destinationPath,$nombre)){
                    $Sucursal->documentos()->save(new Documento([
                        'tipo' => $tipoDocumento,
                        'ruta' => $nombre
                    ]));
                    echo "ok<br>";
                }
            }
        }
        return redirect()->route('sucursal.index', [
            'mensaje' => "Operación realizada con éxito",
        ]);
        exit();
        return view('asignaturas.index',[
            'mensaje' => "Asignatura guardada con éxito",
            'listEstudiantes' => $listAsignaturas,
            'listDocentes' => DB::table('docente')->pluck('nombres', 'coddocente'),
            'listGrados' => DB::table('curso')->orderBy('orden')->pluck('nombrecurso', 'codcurso'),
            'menus' => Menu::listMenusHijos(),
            'codcurso' => $request->codcurso
        ]);
    }


}

