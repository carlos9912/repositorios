<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\Usuario;
use App\Models\Permiso;
use App\Models\Menu;
use App\Enums\EActivo;
use App\Enums\ESiNo;
use App\Enums\EIcono;
use App\Models\Perfil;
use App\Models\Pagina;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class MenuController extends Controller
{



    /**
     *
     * @tutorial Method Description: constructor class
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function __construct()
    {
        $this->middleware('auth');
    }



    /**
     *
     * @tutorial Method Description: Ordena los hijos del menu seleccionado
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function ordenar(Request $request)
    {
        //$lista = json_decode($request->lista_ordenada, true);
        try{
            DB::beginTransaction();
            //Se itera la lista recibida por el sorteable y se actualiza la posicion de ordenamiento
            foreach ($request->lista_ordenada as $orden => $id_menu) {
                $menu = Menu::find($id_menu)->first();
                $dataMenu = [
                    'orden' =>$orden+1,
                    'fecha_modificacion' => Carbon::now(),
                    'id_usuario_modifica' => Auth::user()->id_usuario
                ];
                $menu->update($dataMenu);
            };
            $notificacion = [
                'message' => trans("menus.menus_ordenado_exito"),
                'type' => 'success'
            ];
            DB::commit();
        } catch (\Exception $e) {
            $notificacion = [
                'message' => trans("menus.menus_ordenado_fallo"),
                'type' => 'error'
            ];
            report($e);
            DB::rollBack();
        }
        
        return response()->json([
            'notificacion' => $notificacion
        ]);
    }

    /**
     *
     * @tutorial Method Description: Permite visualizar el menu de la plataforma
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function visualizarMenu()
    {
        //Se asignan los colores de la plantilla
        $colorMenu = [
                'warning' => 'color-1',
                'success' => 'color-2',
                'danger' => 'color-3',
                'info' => 'color-4',
                'purple' => 'color-5',
                'pink' => 'color-6'
            ];

        //Se consultan los menus y se organizan para pintarlos en la navbar
        $listMenus = Menu::listMenusTotal();
        $listaHijos = [];
        foreach ($listMenus as $key => $menu) {
            if($menu->activo==ESiNo::index(ESiNo::Si)->getId()){
                $listaHijos[$menu->id_menu_padre][$menu->id_menu] = $menu;
            }
        }
        return view('menus.visualizar-menu',[
            'listMenus'=>$listaHijos,
            'coloresPlantilla' => $colorMenu,
            'pagina' => new Pagina(),
            'breadcumn' => []
            ]);
    }
    
    /**
     *
     * @tutorial Method Description: Guarda lel menu
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function store(Request $request)
    {
        //Se inicializa la variable class_icon la cual puede contener imagen o icono dependiendo lo que el usuario escoja
        $class_icon = '';
        //Si selecciono icono se asigna directamente, en caso contrario se sube la imagen
        if($request->imagen==EIcono::index(EIcono::No)->getId()) {
            $class_icon = $request->class_icon;
        }else if($request->imagen==EIcono::index(EIcono::Si)->getId()) {
            $file = \Illuminate\Support\Facades\Input::file('file');
            if(blank($file) && !(blank($request->id_menu))){
                $menu = Menu::find($request->id_menu);
                $class_icon = $menu->class_icon;
            }else{
                $destinationPath = config('app.filesArchivos');
                $fileName =  time().'.' . $file->getClientOriginalExtension();
                //Se guarda la imagen en la carpeta correspondiente
                $uploaded = Storage::put($destinationPath."/" . $fileName, file_get_contents($file->getRealPath()));
                if($uploaded){
                    $class_icon = $fileName;
                }
            }
        }
        //Se capturan los atributos del menu 
        $activo = $request->get('activo', ESiNo::index(ESiNo::No)->getId());
        $dataMenu = [
            'nombre' => $request->nombre,
            'id_menu_padre' => $request->id_menu_padre,
            'url' => $request->url,
            'target' => $request->target,
            'color' => $request->color,
            'activo' => $activo,
            'imagen' => $request->imagen,
            'class_icon' => $class_icon,
        ];
        //Si es vacio el id_menu quiere decir que el Menu es nuevo y se guarda, caso contrario se actualiza la informacion
        if(blank($request->id_menu)){
            $dataMenu = array_merge($dataMenu,[
                'fecha_registro' => Carbon::now(),
                'id_usuario_registra' => Auth::user()->id_usuario
            ]);
            $menu = Menu::create($dataMenu);
        }else{
            $menu = Menu::find($request->id_menu);
            $dataMenu = array_merge($dataMenu,[
                'fecha_modificacion' => Carbon::now(),
                'id_usuario_modifica' => Auth::user()->id_usuario
            ]);
            $menu->update($dataMenu);
        }
        $listMenu="<option></option>";
        foreach(DB::table('menus')->orderBy(DB::raw('coalesce(id_menu_padre,0)'),'ASC')->orderBy('id_menu','ASC')->get() as $menus){
            $listMenu.="<option value='".$menus->id_menu."'>".$menus->nombre."</option>";
        }
        return response()->json([
            'menus' => $listMenu,
            'tablaMenu' => view('menus.partials.tabla-menu')->with([
                'listMenus' => Menu::where('id_menu','>',1)->orderBy('id_menu')->get(),
            ])->render()
        ]);
    }

    

    /**
     *
     * @tutorial Method Description: Carga la pagina de administracion de menus
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function index()
    {
        //Se crea array con las clases de los iconos, para pasarlo como options en los select
        $optionAtributos = [];
        foreach (DB::table('iconos')->get() as $icono) {
            $optionAtributos[$icono->clase] = [
                'data-icon' => $icono->clase.' fa-2x'
            ];
        }
        //Se consultas los menus
        $listMenus = Menu::where('id_menu','>',1)->orderBy('orden')->get();
        return view('menus.index',[
            'tablaMenu' => view('menus.partials.tabla-menu')->with([
                'listMenus' => Menu::where('id_menu','>',1)->orderBy('id_menu')->get() 
            ])->render(),
            'listMenus' => $listMenus,
            'menus' => DB::table('menus')->orderBy(DB::raw('coalesce(id_menu_padre,0)'),'ASC')->orderBy('id_menu','ASC')->pluck('nombre', 'id_menu'),
            'iconos' => DB::table('iconos')->pluck('nombre', 'clase'),
            'opcionIconos' => $optionAtributos
        ]);
    }

    /**
     *
     * @tutorial Method Description: Consulta a traves de una peticion ajax la informacion e hijos de un menu seleccionado
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function consultarMenu(Request $request)
    {
        //Se consulta la informacion del menu y los hijos que tenga para reutilizar el metodo en el editar y en el ordenar
        $menu = Menu::find($request->id_menu);
        $hijos = $menu->menus()->orderBy('orden','ASC')->get();
        return response()->json([
            'menus' => $menu,
            'menusHijos' => $hijos
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

}
