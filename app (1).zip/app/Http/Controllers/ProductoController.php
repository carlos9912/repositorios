<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Usuario;
use App\Models\Producto;
use App\Models\Inventario;
use App\Models\Venta;
use App\Models\Parametro;
use App\Models\Permiso;
use App\Models\Curso;
use App\Models\Estudiante;
use App\Enums\EActivo;
use App\Enums\ESiNo;
use App\Enums\EEstadoPagina;
use App\Models\Perfil;
use App\Models\Pagina;
use App\Models\Menu;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Excel;
use Nexmo;
use Curl;

class ProductoController extends Controller
{



    /**
     *
     * @tutorial Method Description: constructor class
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function __construct()
    {
        $this->middleware('auth');
    }


    /**
     *
     * @tutorial Method Description: carga la vista de crear pagina
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function index(Request $request)
    {
        $listStock = [];
        foreach(DB::table('inventario')->where('estado','1')->groupBy('codproducto')->select('codproducto', DB::raw('count(*)'))->get() as $inventario){
            $listStock[$inventario->codproducto] = $inventario->count;
        }
        return view('productos.index',[
            'listProductos'=> Producto::all(),
            'listStock' => $listStock,
            'listGrados' => [1=>'PINES-WIFI'] ,
            'menus' => Menu::listMenusHijos()
            ]);
    }
    
    /**
     *
     * @tutorial Method Description: carga la vista de crear pagina
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function crearProducto(Request $request)
    {
        $dataAsignatura=[
            'nombre' => $request->nombre,// character varying(100),
            'valor_venta' => $request->valor_venta,// numeric,
            'porcentaje' => $request->porcentaje,// character varying(100),
            'utilidad' => $request->utilidad,// timestamp without time zone DEFAULT now(),
            'descripcion' => $request->descripcion,// integer,
            'codcategoria' => $request->codcategoria,
        ];
        $producto = new Producto($dataAsignatura);
        $producto->save();
        $request->mensaje = "Asignatura guardada con éxito";
        
        return redirect()->route('productos.index');
        exit();
        return view('asignaturas.index',[
            'mensaje' => "Asignatura guardada con éxito",
            'listEstudiantes' => $listAsignaturas,
            'listDocentes' => DB::table('docente')->pluck('nombres', 'coddocente'),
            'listGrados' => DB::table('curso')->orderBy('orden')->pluck('nombrecurso', 'codcurso'),
            'menus' => Menu::listMenusHijos(),
            'codcurso' => $request->codcurso
        ]);
    }

    public function cargarExcelInventario(Request $request)
    {
        try {
            $contadorFila = 1;
            $producto = Producto::find($request->codproducto);
            Excel::load($request->archivo, function ($reader) use ($producto) {
                $excel = $reader->get();
                // iteracción
                $reader->each(function ($row) use ($producto) {
                    if(!blank($row->inventario)){
                        $inventario = new Inventario([
                            'pin' => $row->inventario,
                            'estado' => 1,
                            'fecha_ingreso' => Carbon::now()
                        ]);
                        $producto->inventario()->save($inventario);
                    }
                });
            });
            $notificacion = [
                'mensaje' => trans("colegios.cargue_excel_exito")
            ];
        } catch (\Exception $e) {
            $notificacion = [
                'mensaje' => trans("colegios.error")
            ];
            report($e);
        }
        return redirect()->route('productos.index', [
            'mensaje' => "Evidencias guardadas con éxito",
        ]);
        //return response()->json($notificacion);
    }


    /**
     *
     * @tutorial Method Description: carga la vista de crear pagina
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function editarProducto(Request $request)
    {
        $producto = Producto::find($request->codproducto);
        
        $producto->update([
            'nombre'=> $request->nombre,
            'valor_venta'=> $request->valor_venta,
            'porcentaje'=> $request->porcentaje,
            'utilidad'=> $request->utilidad,
        ]);
        return response()->json([
            'mensaje' => 'Producto: '.$producto->nombre.' actualizado con éxito'
        ]);
    }


    public function venta(Request $request){
        return view('productos.venta',[
            'listProductos' => DB::table('productos as p')->join('categorias as c','c.id_categoria','=','p.codcategoria')->pluck(DB::raw("(c.nombre||' - '||p.nombre) as nombre"), 'p.codproducto'),
            'listVentas' => DB::table('venta as v')->join('inventario as i','i.codinventario','=','v.codinventario')->join('productos as p','i.codproducto','=','p.codproducto')->join('usuarios as u','v.cod_punto','=','u.id_usuario')->where('cod_punto','=',\Auth::user()->id_usuario)->orderBy('codventa','DESC')->limit(10)->get()
        ]);
    }

    public function reportesVenta(Request $request){
        $listVentas = DB::table('venta as v')->join('inventario as i','i.codinventario','=','v.codinventario')->join('productos as p','i.codproducto','=','p.codproducto')->join('usuarios as u','v.cod_punto','=','u.id_usuario');
        if(!blank($request->codproducto)){
            $listVentas = $listVentas->where('p.codproducto','=',$request->codproducto);
        }
        if(\Auth::user()->email==1){
            $listVentas = $listVentas->where('v.cod_punto','=',\Auth::user()->id_usuario);
        }else if(!blank($request->codvendedor)){
            $listVentas = $listVentas->where('v.cod_punto','=',$request->codvendedor);
        }
        if(!blank($request->inicio)&&!blank($request->fin)){
            $listVentas = $listVentas->whereBetween('v.fecha_transaccion',[
                Carbon::parse(str_replace('/','-',$request->inicio))->format('Y-m-d').' 00:00:00',
                Carbon::parse(str_replace('/','-',$request->fin))->format('Y-m-d').' 23:59:59'
            ]);
        }
        return response()->json([
            'tablaVentas' => view('productos.partials.venta-detalle')->with([
                'listVentas' => $listVentas ->orderBy('codventa','DESC')->get(),
                'fechaInicio' => $request->inicio,
                'fechaFin' => $request->fin,
            ])->render(),
            'fechas' => 'inicio'.$request->inicio.' fin'.$request->fin
        ]);
    }


    public function estadosCuenta(Request $request){
        return view('productos.venta',[
            'listProductos' => DB::table('productos as p')->join('categorias as c','c.id_categoria','=','p.codcategoria')->pluck(DB::raw("(c.nombre||' - '||p.nombre) as nombre"), 'p.codproducto'),
            'listVentas' => DB::table('venta as v')->join('inventario as i','i.codinventario','=','v.codinventario')->join('productos as p','i.codproducto','=','p.codproducto')->join('usuarios as u','v.cod_punto','=','u.id_usuario')->where('cod_punto','=',\Auth::user()->id_usuario)->orderBy('codventa','DESC')->limit(10)->get()
        ]);
    }


    public function procesarVenta(Request $request){
        $producto = Producto::find($request->codproducto);
        $inventario = $producto->inventario()->where('estado','=',1)->first();
        if(!blank($inventario)){
            $inventario->ventas()->save(new Venta([
                'cod_punto' => \Auth::user()->id_usuario,
                'valor' => $producto->valor_venta,
                'fecha_transaccion' => Carbon::now(),
                'celular' => str_replace(' ','',$request->celular),
                'valor_entregado' => $request->valor_entregado
            ]));
            $inventario->update(['estado'=>2, 'fecha_venta'=> Carbon::now()]);
            $user = \Auth::user();
            $user->update(['saldo' => $user->saldo+$producto->valor_venta]);
            $response = Curl::to('https://www.cellvoz.com/APIlib/SMSAPI.php')
            ->withData( array( 'user' => '00486102149','key'=>'b4dfbfa8247793ed2faa9b5d4c5e44c9f3a58f78', 'num'=>'57'.str_replace(' ','',$request->celular),'sms'=>$producto->nombre.': 1 Copia el PIN '.$inventario->pin.' 2 Conectate a la wi-fi del vecino  3 Ingresa a la dirección digital.com, pega tu PIN y click en navegar.'))
            ->post();
            return response()->json([
                'error' => 0,
                'mensaje' => 'Venta registrada con éxito',
                'tablaVentas' => view('productos.partials.venta-detalle-reporte')->with([
                    'listVentas' => DB::table('venta as v')->join('inventario as i','i.codinventario','=','v.codinventario')->join('productos as p','i.codproducto','=','p.codproducto')->join('usuarios as u','v.cod_punto','=','u.id_usuario')->where('cod_punto','=',\Auth::user()->id_usuario)->orderBy('codventa','DESC')->limit(10)->get()
                ])->render()
            ]);
        }else{
            return response()->json([
                'error' => 1,
                'mensaje' => 'La venta no se pudo registrar<br>Intentelo nuevamente',
            ]);

        }
    }

    public function reenviarSms(Request $request){
        $venta = Venta::find($request->codventa);
        $inventario = Inventario::find($venta->codinventario);
        $producto = Producto::find($inventario->codproducto);
        $response = Curl::to('https://www.cellvoz.com/APIlib/SMSAPI.php')
        ->withData( array( 'user' => '00486102149','key'=>'b4dfbfa8247793ed2faa9b5d4c5e44c9f3a58f78', 'num'=>'57'.str_replace(' ','',$venta->celular),'sms'=>$producto->nombre.': 1 Copia el PIN '.$inventario->pin.' 2 Conectate a la wi-fi del vecino  3 Ingresa a la dirección digital.com, pega tu PIN y click en navegar.'))
        ->post();
        return response()->json([
            'error' => 0,
            'mensaje' => 'Venta registrada con éxito'.$response,
            
        ]);
    }

    public function informacionProducto(Request $request){
        $producto = Producto::find($request->codproducto);
        return response()->json([
            'cantidad' => count($producto->inventario()->where('estado','=',1)->get()),
            'nombre' => $producto->nombre,
            'precio' => number_format($producto->valor_venta),
            'valor' => $producto->valor_venta
        ]);
        
    }

    /**
     *
     * @tutorial Method Description: carga la vista de crear pagina
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function detalleEstudiante(Request $request)
    {
        $estudiante = Estudiante::find(decrypt($request->codestudiante));
        $grado = $estudiante->cursoActivo();
        return view('estudiantes.estudiante-detalle',[
            "estudiante" => $estudiante,
            "grado" => $grado,
            "observaciones" => $estudiante->observaciones
        ]);
    }

    /**
     *
     * @tutorial Method Description: carga la vista de crear pagina
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function procesarMatricula(Request $request)
    {
        $estudiante = Estudiante::find($request->codestudiante);
        $grado = $estudiante->cursoActivo();
        DB::table('rel_cursoestudiante')
        ->where('codrelcursoestudiante', $grado->codrelcursoestudiante)
        ->update(['estado' => ($request->matricular) ? 3 : 4 ]);
        if($request->promocion==ESiNo::index(ESiNo::Si)->getId()){
            $gradoSiguiente = Curso::find($grado->siguiente);
            $estudiante->cursos()->attach($gradoSiguiente, [
                'numero' => $grado->numero,
                'observacion' => "ESTUDIANTE PROMOVIDO Y MATRICULADO",
                'estado' => 1,
                'fecha' => Carbon::now()
            ]);
        }else{
            $estudiante->cursos()->attach($grado, [
                'numero' => $grado->numero,
                'observacion' => "ESTUDIANTE NO PROMOVIDO Y MATRICULADO",
                'estado' => 1,
                'fecha' => Carbon::now()
            ]);
        }
        
        return response()->json([
            'mensaje' => 'Matricula registrada con éxito'
        ]);
    }

    /**
     *
     * @tutorial Method Description: Show the application dashboard.
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function footerPrincipal()
    {
        return view('principal.editar-footer',["pagina" => Pagina::find(0),"menus" => []]);
    }


    /**
     *
     * @tutorial Method Description: Carga la vista de editar pagina
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function editarPagina(Pagina $pagina)
    {
        return view('principal.editar-pagina',[
            'pagina'=>$pagina,
            'menus' => Menu::listMenusHijos()
            ]);
    }

    
    /**
     *
     * @tutorial Method Description: Guarda la pagina
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function store(Request $request)
    {
        //Valida que el texto editar este vacio para saber si se esta editando la informacion de la pagina (nombre, activo, etc) o la informacion del contenido (background, contenido)
        if(blank($request->editar)){
            //Se obtienen los atributos de la pagina
            $datosPagina = [
                'pagina_editor' => $request->pagina_editor,
                'pagina_mostrar' => $request->pagina_mostrar,
                'img_background' => $request->img_background,
                'estado' => EEstadoPagina::index(EEstadoPagina::GUARDADA)->getId()
            ];
            //Se valida si la pagina existe o no, para crear o actualizar
            if(blank($request->id_pagina)){
                //Se unen los atributos obtenidos anteriormente, con los atributos faltantes a la hora de crear 
                $datosPagina = array_merge($datosPagina,[
                    'fecha_creacion' => Carbon::now(),
                    'id_usuario_registra' => Auth::user()->id_usuario,
                    'id_menu' => $request->id_menu,
                    'principal' => $request->get('principal',ESiNo::index(ESiNo::No)->getId()),
                    'activo' => $request->get('activo',ESiNo::index(ESiNo::No)->getId()),
                    'titulo' => $request->nombre
                ]);
                //Si la pagina es principal actualiza todos los hijos de ese menu a 2 para que solo quede como principal esta pagina
                if($datosPagina["principal"] == ESiNo::index(ESiNo::Si)->getId()){
                    Menu::find($datosPagina["id_menu"])->paginas()->update([
                        "principal" => ESiNo::index(ESiNo::No)->getId()
                    ]);
                }
                //Se guarda la pagina
                $pagina = Pagina::create($datosPagina);

            }else{
                //Se consulta la pagina a actualizar
                $pagina = Pagina::find($request->id_pagina);
                
                $datosPagina = array_merge($datosPagina,[
                    'fecha_modificacion' => Carbon::now(),
                    'id_usuario_modifica' => Auth::user()->id_usuario
                ]);
                //Se actualiza la informacion de la pagina
                $pagina->update($datosPagina);
            }
            return response()->json([
                'success' => 'success',
                'idPagina' => $pagina->id_pagina
            ]);
        }else{
            //Captura el estado anterior de la pagina para saber si pasa a Publicada o Suspendida
            $estadoAnterior = $request->estadoAnterior;
            
            //Si la pagina es principal actualiza todos los hijos de ese menu a 2 para que solo quede como principal esta pagina
            $principal = $request->get('principal',ESiNo::index(ESiNo::No)->getId());
            if($principal == ESiNo::index(ESiNo::Si)->getId()){
                Menu::find($request->id_menu)->paginas()->update([
                    "principal" => ESiNo::index(ESiNo::No)->getId()
                ]);
            }
            $estadoActual = ($estadoAnterior == EEstadoPagina::index(EEstadoPagina::GUARDADA)->getId()) ? ((blank($request->estado)) ? $estadoAnterior : EEstadoPagina::index(EEstadoPagina::PUBLICADA)->getId()) : ((blank($request->estado)) ? EEstadoPagina::index(EEstadoPagina::SUSPENDIDA)->getId() : EEstadoPagina::index(EEstadoPagina::PUBLICADA)->getId());
            //Se consulta la pagina a actualizar
            $pagina = Pagina::find($request->id_pagina);
            $datosPagina = [
                        'titulo' => $request->titulo,
                        'id_menu' => $request->id_menu,
                        'estado' => $estadoActual,
                        'principal' => $principal,
                        'fecha_modificacion' => Carbon::now(),
                        'id_usuario_modifica' => Auth::user()->id_usuario
                    ];
            //Se actualiza la informacion de la pagina
            $pagina->update($datosPagina);
            return response()->json([
                'tablaPaginas' => view('principal.partials.tabla-paginas')->with([
                    'listPaginas' => Pagina::listadoPagina(),
                ])->render()
            ]);
        }
    }

    

    /**
     *
     * @tutorial Method Description: Consulta los ficheros para mostrarlos en el administrador de archivos
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function obtenerFicheros(Request $request){
        
        //Obtiene la ruta enviada del lado del cliente
        $rutaActual = $request->get('rutaActual');
        $rutaMiniaturas = 'storage/files/watermark';
        //Si la ruta no existe quiere decir que se encuentra en la ventana principal
        $rutaActual = (blank($rutaActual)) ? 'public/files/' : $rutaActual ;
        //Consulta los archivos en el directorio de storage
        $listArchivos = Storage::files($rutaActual);
        $listArchivos = array_reverse($listArchivos);
        if($request->ext=='img'){
            $listArchivos = preg_grep('/^.*\.(jpg|jpeg|png|gif)$/i', $listArchivos);
        }else if($request->ext=='pdf'){
            $listArchivos = preg_grep('/^.*\.(pdf)$/i', $listArchivos);
        }
        //Consulta los folders del directorio
        $listCarpetas = Storage::directories($rutaActual);
        //Explodea la ruta para validar si se pinta la carpeta de salir nivel o no
        $ruta = explode('/',str_replace('../','*',$rutaActual));
        $contadorHaciaAtras = 0;
        $contadoVacios = 0;
        foreach ($ruta as $value) {
            $contadorHaciaAtras+= ($value=="*") ? 1 : 0;
            $contadoVacios+= (blank($value)) ? 1 : 0;
        }
        $salirNivel = (count($ruta)-($contadorHaciaAtras+$contadorHaciaAtras+$contadoVacios) == 2) ? false : true;
        //Llama el partials del administrador de archivos, le pasa los parametros luego retorna los datos el html de dicho partial
        return response()->json([
            'html' => view('principal.partials.file_manager')->with([
                'listCarpetas' => $listCarpetas,
                'listArchivos' => $listArchivos,
                'rutaActual' => $rutaActual,
                'salirNivel' => $salirNivel,
                'miniaturas' => $rutaMiniaturas,
                'wizard' => $request->wizard
                ])->render()
        ]);
        //return [$files, $listCarpetas];
    }

    /**
     *
     * @tutorial Method Description: Realiza el cropeado y guardado de la imagen
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function guardarImagenCrop(Request $request)
    {
        //Se obtiene el archivo subido
        $file = \Illuminate\Support\Facades\Input::file('file');
        //Se capturan las propiedades del cropper
        $opcionesCropper = json_decode($request->dataCrop);
        //Se declaran los meses para las carpetas
        $meses = [
            '1' => 'ENERO',
            '2' => 'FEBRERO',
            '3' => 'MARZO',
            '4' => 'ABRIL',
            '5' => 'MAYO',
            '6' => 'JUNIO',
            '7' => 'JULIO',
            '8' => 'AGOSTO',
            '9' => 'SEPTIEMBRE',
            '10' => 'OCTUBRE',
            '11' => 'NOVIEMBRE',
            '12' => 'DICIEMBRE'
        ];
        //Se crea la ruta
        $destinationPath = config('app.files').$meses[date('n')+1];
        //Se crea el directorio enc aos que no exista
        Storage::makeDirectory($destinationPath);
        //Se asigna un nombre a la imagen
        $png_url = time().".jpg";
        //Se asigna la ruta completa que de la imagen para guardarla
        $rutaImg = public_path('../storage/app/'.$destinationPath.'/'.$png_url);
        $rutaImgWaterMark = public_path('../storage/app/public/files/watermark/'.$png_url);
        $parametro = Parametro::find(1);
        try{
            //Se crea una nueva instancía de una imagen a partir del archivo subido
            $img =\Image::make(file_get_contents($file->getRealPath()))->encode('jpg', 75);
            
            //Se aumenta el maximo de memoria, valor definido por eminson
            ini_set('memory_limit', '2500M');
            //Se valida que exista el rotate en la imagen y que este sea mayor a 0
            if(property_exists($opcionesCropper, 'rotate') && (int)$opcionesCropper->rotate!=0){
                //Se calcula el angulo a rotar ya que el cropper.js trabaja con valores diferentes
                //Los valores de Image intervention son contrarios a las manecillas del reloj => http://image.intervention.io 
                $angulo = ($opcionesCropper->rotate>0) ? (360 + $opcionesCropper->rotate*-1) : $opcionesCropper->rotate*-1;
                //Se rota la imagen y se coloca fondo blanco por si llega a quedar pedazos de la imagen fuera del cropper
                $img->rotate($angulo,'#FFFFFF');
            }
            //Se corta la imagen con los parametros seleccionados por el usuario
            //Los valores de Image intervention son enteros, cropper.js es mucho mas precisa y admite decimales
            //Teniendo en cuenta esto, se redondean hacia abajo los valores => http://image.intervention.io 
            $img->crop(round($opcionesCropper->width,0), round($opcionesCropper->height,0), round($opcionesCropper->x,0), round($opcionesCropper->y,0));
            //Se valida que la dimension de la imagen no sea mayor a la permitida
            if($img->width()>$parametro->ancho_galeria){
                $ratio=$parametro->ancho_galeria/$img->width();
                $altura=$img->height()*$ratio;
                $img->resize($parametro->ancho_galeria,$altura);
            }
            //Se guarda la imagen en la ruta especificada y se comprime para disminuir el peso
            $img->save($rutaImg, 40);
            //se crea y guarda una imagen miniatura de la imagen original
            $img->resize(170,127);
            $img->save($rutaImgWaterMark);
            $rutaWatermark = url('storage/files/watermark/'.$png_url);
            $ruta = url('storage/files/'.$meses[date('n')+1].'/'.$png_url);
        } catch (\Exception $e) {
            report($e);
        }
        //Se retorna a la vista
        return response()->json([
            'success' => 'success',
            'rutaWatermark' => $rutaWatermark,
            'ruta' => $ruta,
            'nombre' => date('m-d-Y G:ia',str_replace('.jpg','',$png_url))
        ]);
        
    }


    /**
     *
     * @tutorial Method Description: Realiza el cropeado y guardado de la imagen
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function cortarImagenCrop(Request $request)
    {
        //Se obtiene el archivo subido
        $opcionesCropper = json_decode($request->dataCrop);
        //Se asigna la ruta completa que de la imagen para guardarla
        $ruta = config('app.files').$request->imagen;
        $rutaImg = public_path('../storage/app/public/files/'.str_replace('storage/files/','',$request->imagen));
        //Se consulta el nombre para cambiar la marca de agua
        $nombreArchivo = explode('/',$request->imagen);
        //Sec rea la ruta de la marca de agua
        $rutaImgWaterMark = public_path('../storage/app/public/files/watermark/'.$nombreArchivo[count($nombreArchivo)-1]);
        try{
            ini_set('memory_limit', '250541502
            0M');
            //Se crea la imagen con la ruta establecida
            $img = \Image::make($rutaImg);
            //Se valida que exista el rotate en la imagen y que este sea mayor a 0
            if(property_exists($opcionesCropper, 'rotate') && (int)$opcionesCropper->rotate!=0){
                //Se calcula el angulo a rotar ya que el cropper.js trabaja con valores diferentes
                //Los valores de Image intervention son contrarios a las manecillas del reloj => http://image.intervention.io 
                $angulo = ($opcionesCropper->rotate>0) ? (360 + $opcionesCropper->rotate*-1) : $opcionesCropper->rotate*-1;
                //Se rota la imagen y se coloca fondo blanco por si llega a quedar pedazos de la imagen fuera del cropper
                $img->rotate($angulo,'#FFFFFF');
            }
            //Se corta la imagen con los parametros seleccionados por el usuario
            //Los valores de Image intervention son enteros, cropper.js es mucho mas precisa y admite decimales
            //Teniendo en cuenta esto, se redondean hacia abajo los valores => http://image.intervention.io 
            $img->crop(round($opcionesCropper->width,0), round($opcionesCropper->height,0), round($opcionesCropper->x,0), round($opcionesCropper->y,0));
            //Se guarda la imagen
            $img->save($rutaImg,70);
            //se crea y guarda una imagen miniatura de la imagen original
            $img->resize(170,127);
            $img->save($rutaImgWaterMark);

        } catch (\Exception $e) {
            report($e);
        }
        //Se retorna a la vista
        return response()->json([
            'success' => 'success'
        ]);
        
    }
    /**
     *
     * @tutorial Method Description: Elimina el archivo y la miniatura que el usuario seleccione
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function eliminarArchivo(Request $request){
        //Divide el nombre para poder capturar solo la carpeta final y el nombre.jpg
        $nombreArchivo = explode('/',$request->rutaArchivo);
        //Divide el nombre de la miniatura para poder capturar solo la carpeta final y el nombre.jpg
        $nombreMiniatura = explode('/',$request->rutaMiniatura);
        //Elimina el archivo 
        $rutaEliminar = config('app.files').$nombreArchivo[count($nombreArchivo)-2]."/".$nombreArchivo[count($nombreArchivo)-1];
        //Elimina el archivo miniatura
        $rutaEliminarMiniatura = config('app.files').$nombreMiniatura[count($nombreArchivo)-2]."/".$nombreMiniatura[count($nombreArchivo)-1];
        $eliminar = Storage::delete($rutaEliminar);
        $eliminarMiniatura = Storage::delete($rutaEliminarMiniatura);
        //Se retorna a la vista
        return response()->json([
            'success' => ($eliminar && $eliminarMiniatura) ? true : false,
            'rutaActual' => $request->rutaActual
        ]);
    }


    /**
     *
     * @tutorial Method Description: Show the application dashboard.
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function visualizarPagina(Pagina $pagina)
    {
        //$pagina = Pagina::find(1);
        $paginaFooter = Pagina::find(0);
        return view('principal.visualizar-pagina',[
            'pagina'=>$pagina,
            'footer' => $paginaFooter
            ]);
    }

    
    /**
     *
     * @tutorial Method Description: Guarda la imagen o los pdgs que el usuario envie
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function guardarArchivo(Request $request){
        $file = \Illuminate\Support\Facades\Input::file('file');
        //Se declaran los meses para las carpetas
        $meses = [
            '1' => 'ENERO',
            '2' => 'FEBRERO',
            '3' => 'MARZO',
            '4' => 'ABRIL',
            '5' => 'MAYO',
            '6' => 'JUNIO',
            '7' => 'JULIO',
            '8' => 'AGOSTO',
            '9' => 'SEPTIEMBRE',
            '10' => 'OCTUBRE',
            '11' => 'NOVIEMBRE',
            '12' => 'DICIEMBRE'
        ];
        //Se crea la ruta
        $destinationPath = config('app.files').$meses[date('n')+1];
        //Se crea el directorio enc aos que no exista
        Storage::makeDirectory($destinationPath);
        
        try{
            if($request->tipoArchivo=='img'){
                //Se asigna un nombre a la imagen
                $png_url = time().".jpg";
                //Se asigna la ruta completa que de la imagen para guardarla
                $rutaImg = public_path('../storage/app/'.$destinationPath.'/'.$png_url);
                $rutaImgWaterMark = public_path('../storage/app/public/files/watermark/'.$png_url);
                //Se crea una nueva instancía de una imagen a partir del archivo subido
                $img =\Image::make(file_get_contents($file->getRealPath()))->encode('jpg', 75);
                //Se valida que la dimension de la imagen no sea mayor a la permitida
                if($img->width()>$parametro->ancho_galeria){
                    $ratio=$parametro->ancho_galeria/$img->width();
                    $altura=$img->height()*$ratio;
                    $img->resize($parametro->ancho_galeria,$altura);
                }
                //Se guarda la imagen en la ruta especificada y se comprime para disminuir el peso
                $img->save($rutaImg, 40); 
                //Se crea y guarda una miniatura de la imagen
                $img->resize(170,127);
                $img->save($rutaImgWaterMark);
            }else{
                //Le asigna el nombre al pdf
                $fileName =  time().'.' . $file->getClientOriginalExtension();
                //Lo guarda en la carpeta correspondiente
                $uploaded = Storage::put($destinationPath."/" . $fileName, file_get_contents($file->getRealPath()));
            }
            
        } catch (\Exception $e) {
            report($e);
        }
        //Se retorna a la vista
        return response()->json([
            'success' => 'success'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     *
     * @tutorial Method Description: Consulta la informacion de la pagina
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function consultarPagina(Request $request)
    {
        $pagina = Pagina::find($request->id_pagina);
        return response()->json([
            'informacionPagina' => view('principal.partials.editar-paginas')->with([
                'pagina' => $pagina,
                'menus' => Menu::listMenusHijos()
            ])->render(),
        ]);
    }

    /**
     *
     * @tutorial Method Description: Muestra la iamgen en la vista para recortarla
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function mostrarImagen(Request $request)
    {
        
        return view('principal.cortar-imagen',[
            'imagen'=>$request->ruta,
            'numero' => rand(1, 100)
        ]);
    
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     *
     * @tutorial Method Description: Carga la vista de administrar paginas
     * @author Bayron Tarazona ~ bayronthz@gmail.com
     * @since {02/10/2018}
     */
    public function administrarPagina(Request $request){
        
        return view('principal.administrar-paginas',[
            'tablaPaginas' => view('principal.partials.tabla-paginas')->with([
                'listPaginas' => Pagina::listadoPagina($request->id_menu, $request->rango_fechas, $request->principal),
            ])->render(),
            'menus' => Menu::listMenusHijos()
        ]);
    }


    public function eliminarPagina(Request $request)
    {
        $pagina = Pagina::find($request->id_pagina);
        $pagina->delete();
        return response()->json([
            'tablaPaginas' => view('principal.partials.tabla-paginas')->with([
                'listPaginas' => Pagina::listadoPagina(),
            ])->render()
        ]);
    }

}
