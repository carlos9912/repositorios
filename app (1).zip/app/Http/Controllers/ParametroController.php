<?php

namespace App\Http\Controllers;



use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use Carbon\Carbon;

use App\Models\Usuario;

use App\Models\Permiso;

use App\Models\Parametro;

use App\Models\Menu;

use App\Enums\EActivo;

use App\Enums\ESiNo;

use App\Enums\EIcono;

use App\Models\Perfil;

use App\Models\Pagina;
use App\Models\Tarifas;

use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Storage;

use Illuminate\Support\Facades\File;



class ParametroController extends Controller

{







    /**

     *

     * @tutorial Method Description: constructor class

     * @author Bayron Tarazona ~ bayronthz@gmail.com

     * @since {02/10/2018}

     */

    public function __construct()

    {

        $this->middleware('auth');

    }



    /**

     *

     * @tutorial Method Description: Carga la pagina de administracion de parametro

     * @author Bayron Tarazona ~ bayronthz@gmail.com

     * @since {02/10/2018}

     */

    public function index()

    {

        //Se consulta los parametros

        $parametro = Parametro::find(1);

        return view('parametro.index',[

            'parametro' => $parametro

        ]);

    }

    public function abrirFormulario(Request $request){
        if(blank($request->codtarifa)){
            $tarifa= new Tarifas();
        }else{
            $tarifa = Tarifas::find($request->codtarifa);
        }
        return response()->json([
            'formulario' => view('configuracion.partials.form-tarifas')->with([
                'tarifa' => $tarifa,
            ])->render()
        ]);
        
    }


    public function tarifas()

    {
        //Se consulta los parametros
        if(!blank(\Auth::user()->codempleado)){
            return redirect()->route('errors.empleado-403');
        }
        $parametro = Parametro::find(1);
        return view('configuracion.tarifas',[
            'parametro' => $parametro
       ]);

    }

    /**
     *
     * @tutorial Method Description: carga la vista de crear pagina
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {15/03/2018}
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function crearTarifa(Request $request)
    {
        $dataTarifa=$request->all();
        unset($dataTarifa["_token"]);
        unset($dataTarifa["celular_confirmar"]);
        unset($dataTarifa["codtarifa"]);
        $dataTarifa["estado"] = 1;
        $dataTarifa["fecha_creacion"] = Carbon::now();
        //dd($dataTarifa);
        if(blank($request->codtarifa)){
            $Tarifa = new Tarifas($dataTarifa);
            $Tarifa->save();
            $request->mensaje = "Asignatura guardada con éxito";
        }else{
            $Tarifa = Tarifas::find($request->codtarifa);
            $Tarifa->update($dataTarifa);
        }
        
        
        return redirect()->route('tarifas.index', [
            'mensaje' => "Operación realizada con éxito",
        ]);
        exit();
        return view('asignaturas.index',[
            'mensaje' => "Asignatura guardada con éxito",
            'listEstudiantes' => $listAsignaturas,
            'listDocentes' => DB::table('docente')->pluck('nombres', 'coddocente'),
            'listGrados' => DB::table('curso')->orderBy('orden')->pluck('nombrecurso', 'codcurso'),
            'menus' => Menu::listMenusHijos(),
            'codcurso' => $request->codcurso
        ]);
    }


    public function eliminarTarifa(Request $request){
        
        $tarifa = Tarifas::destroy($request->codtarifa);
        
        return response()->json([
            'formulario' => $tarifa
        ]);
        
    }



    /**

     *

     * @tutorial Method Description: Consulta la informacion del parametro

     * @author Bayron Tarazona ~ bayronthz@gmail.com

     * @since {02/10/2018}

     */

    public function consultarParametros(Request $request)

    {

        $parametro = Parametro::find(1);

        return response()->json([

            'parametro' => $parametro

        ]);

    }



}

