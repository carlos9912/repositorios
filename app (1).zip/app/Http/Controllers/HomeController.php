<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Menu;
use App\Enums\ESiNo;
use App\Models\Pagina;
use App\Models\Parametro;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }


    public function visualizar(Request $request){
        $breadcum = [];
        $menu = Menu::find($request->get("menu",1));
        $nombre = $request->get("nombre","principal");
        //Consulta la pagina principal y las paginas asociadas el menu
        $paginas = $menu->paginas()->first(); 
        $paginaPpal = $menu->paginas()->where('principal','=',ESiNo::index(ESiNo::Si)->getId())->first();
        //En caso de que la pagina principal no exista, se pinta la primera pagina del menu
        if(blank($paginaPpal)){
            //Si el menu no tiene paginas asociadas se crea una nueva instancia de Pagina
            if(blank($paginas)){
                $paginaPpal=new Pagina();
            }else{
                $paginaPpal = $paginas;
            }
        }
        //Se organiza el breadcum (!!!! - BREADCUM AUN NO IMPLEMENTADO - !!!!)
        foreach ($menu->paginas()->orderBy('principal','asc')->get() as $pagina) {
            $breadcum[$pagina->id_pagina] = $pagina; 
        }
        //dd($breadcum);
        //Se toman los colores de la plantilla
        $colorMenu = [
            'default' => 'color-default',
            'warning' => 'color-1',
            'success' => 'color-2',
            'danger' => 'color-3',
            'info' => 'color-4',
            'purple' => 'color-5',
            'pink' => 'color-6'
        ];
        //Se consultan los parametros
        $parametro = Parametro::find(1);
        //Se consultan los menus hijos
        $listMenus = Menu::listMenusTotal();
        $listaHijos = [];
        //Se organizan los menus para poder pintarlos en la navbar
        foreach ($listMenus as $key => $menu) {
            if($menu->activo==ESiNo::index(ESiNo::Si)->getId()){
                $listaHijos[$menu->id_menu_padre][$menu->id_menu] = $menu;
            }
        }
        $paginaFooter = Pagina::find(0);
        //dd($paginaFooter);
        return view('menus.visualizar-menu',[
            'listMenus'=>$listaHijos,
            'coloresPlantilla' => $colorMenu,
            'pagina' => $paginaPpal,
            'breadcum' => $breadcum,
            'parametro' => $parametro,
            'nombre' => $nombre,
            'footer' => $paginaFooter
            ]);
        
    }

    public function visualizarMenu(Menu $menu, $nombre){
        $breadcum = [];
        //$menu = Menu::find($request->get("menu",1));
        //$nombre = $request->get("nombre","principal");
        //Consulta la pagina principal y las paginas asociadas el menu
        $paginas = $menu->paginas()->first(); 
        $paginaPpal = $menu->paginas()->where('principal','=',ESiNo::index(ESiNo::Si)->getId())->first();
        //En caso de que la pagina principal no exista, se pinta la primera pagina del menu
        if(blank($paginaPpal)){
            //Si el menu no tiene paginas asociadas se crea una nueva instancia de Pagina
            if(blank($paginas)){
                $paginaPpal=new Pagina();
            }else{
                $paginaPpal = $paginas;
            }
        }
        //Se organiza el breadcum (!!!! - BREADCUM AUN NO IMPLEMENTADO - !!!!)
        foreach ($menu->paginas()->orderBy('principal','asc')->get() as $pagina) {
            $breadcum[$pagina->id_pagina] = $pagina; 
        }
        //dd($breadcum);
        //Se toman los colores de la plantilla
        $colorMenu = [
            'default' => 'color-default',
            'warning' => 'color-1',
            'success' => 'color-2',
            'danger' => 'color-3',
            'info' => 'color-4',
            'purple' => 'color-5',
            'pink' => 'color-6'
        ];
        //Se consultan los parametros
        $parametro = Parametro::find(1);
        //Se consultan los menus hijos
        $listMenus = Menu::listMenusTotal();
        $listaHijos = [];
        //Se organizan los menus para poder pintarlos en la navbar
        foreach ($listMenus as $key => $menu) {
            if($menu->activo==ESiNo::index(ESiNo::Si)->getId()){
                $listaHijos[$menu->id_menu_padre][$menu->id_menu] = $menu;
            }
        }
        $paginaFooter = Pagina::find(0);
        //dd($paginaFooter);
        return view('menus.visualizar-menu',[
            'listMenus'=>$listaHijos,
            'coloresPlantilla' => $colorMenu,
            'pagina' => $paginaPpal,
            'breadcum' => $breadcum,
            'parametro' => $parametro,
            'nombre' => $nombre,
            'footer' => $paginaFooter
            ]);
        
    }

    public function navegarPagina(Pagina $pagina, $nombre){
        
        
        $breadcum = [];
        $menu = $pagina->menu;
        $paginaPpal = $pagina;
        //Se organiza el breadcum (!!!! - BREADCUM AUN NO IMPLEMENTADO - !!!!)
        foreach ($menu->paginas()->orderBy('principal','asc')->get() as $pagina) {
            $breadcum[$pagina->id_pagina] = $pagina; 
        }
        //dd($breadcum);
        //Se toman los colores de la plantilla
        $colorMenu = [
            'default' => 'color-default',
            'warning' => 'color-1',
            'success' => 'color-2',
            'danger' => 'color-3',
            'info' => 'color-4',
            'purple' => 'color-5',
            'pink' => 'color-6'
        ];
        //Se consultan los parametros
        $parametro = Parametro::find(1);
        //Se consultan los menus hijos
        $listMenus = Menu::listMenusTotal();
        $listaHijos = [];
        //Se organizan los menus para poder pintarlos en la navbar
        foreach ($listMenus as $key => $menu) {
            if($menu->activo==ESiNo::index(ESiNo::Si)->getId()){
                $listaHijos[$menu->id_menu_padre][$menu->id_menu] = $menu;
            }
        }
        $paginaFooter = Pagina::find(0);
        //dd($paginaFooter);
        return view('menus.visualizar-menu',[
            'listMenus'=>$listaHijos,
            'coloresPlantilla' => $colorMenu,
            'pagina' => $paginaPpal,
            'breadcum' => $breadcum,
            'parametro' => $parametro,
            'nombre' => $nombre,
            'footer' => $paginaFooter
            ]);
        
    }
}
