<?php
namespace App\Http\Controllers;

use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use App\Models\Permiso;
use App\Models\Menu;

/**
 *
 * @tutorial Working Class
 * @author Bayron Tarazona ~bayronthz@gmail.com
 * @since 13/05/2018
 */
class PermisoController extends Controller
{

    /**
     *
     * @tutorial Method Description: Constructor class
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {13/05/2018}
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     *
     * @tutorial Method Description: Display a listing of the resource.
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {13/05/2018}
     * @return Ambigous <\Illuminate\View\View, \Illuminate\Contracts\View\Factory, mixed, \Illuminate\Foundation\Application, \Illuminate\Container\static>
     */
    public function index()
    {
        $list = Permiso::all();
        return view('permisos.index', compact('list'));
    }

    /**
     *
     * @tutorial Method Description: Show the form for creating a new resource.
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {13/05/2018}
     * @return Ambigous <\Illuminate\View\View, \Illuminate\Contracts\View\Factory, mixed, \Illuminate\Foundation\Application, \Illuminate\Container\static>
     */
    public function create()
    {
        $menus = Menu::orderBy('orden')->pluck('nombre', 'id_menu');
        
        return view('permisos.create', compact('menus'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request            
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // valida los campos y obtiene los valores
        $data = request()->validate([
            'nombre' => 'required|unique:permisos|min:3|max:255',
            'url' => 'required|min:3|max:64'
        ]);
        
        $permiso = Permiso::create($request->all());
        
        return redirect()->route('permisos.index');
    }

    /**
     * Display the specified resource.
     *
     * @param int $id            
     * @return \Illuminate\Http\Response
     */
    public function show(Permiso $permiso)
    {
        return view('permisos.show', compact('permiso'));
    }

    /**
     *
     * @tutorial Method Description: Show the form for editing the specified resource.
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {14/05/2018}
     * @param Permiso $permiso            
     * @return Ambigous <\Illuminate\View\View, \Illuminate\Contracts\View\Factory, mixed, \Illuminate\Foundation\Application, \Illuminate\Container\static>
     */
    public function edit(Permiso $permiso)
    {
        return view('permisos.edit', compact('permiso'));
    }

    /**
     *
     * @tutorial Method Description: Update the specified resource in storage.
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {14/05/2018}
     * @param Request $request            
     * @param Permiso $permiso            
     * @return Ambigous <\Illuminate\Http\RedirectResponse, mixed, \Illuminate\Support\HigherOrderTapProxy>
     */
    public function update(Request $request, Permiso $permiso)
    {
        // valida los campos y obtiene los valores
        $data = request()->validate([
            'nombre' => [
                Rule::unique('permisos')->ignore($permiso->id_permiso, 'id_permiso'),
                'required',
                'max:255',
                'min:3'
            ],
            'url' => 'required|min:3|max:64'
        ]);
        $permiso->update($request->all());
        
        return redirect()->route('permisos.index');
    }

    /**
     *
     * @tutorial Method Description: Remove the specified resource from storage.
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {14/05/2018}
     * @param Permiso $permiso            
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(Permiso $permiso)
    {
        $correct = false;
        if (! blank($permiso->id_permiso)) {
            if (blank($permiso->perfiles)) {
                $correct = $permiso->delete();
                $message = __('permisos.delete_status', [
                    'nombre' => $permiso->nombre
                ]);
            } else {
                $message = trans('permisos.delete_error', [
                    'nombre' => $permiso->nombre
                ]);
            }
        }
        return response()->json([
            'message' => $message,
            'correct' => $correct
        ]);
    }
}