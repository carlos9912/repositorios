<?php



namespace App\Http\Controllers;







use Illuminate\Http\Request;



use App\Models\Usuario;



use App\Models\Permiso;



use App\Enums\EActivo;



use App\Enums\ESiNo;



use App\Models\Perfil;



use App\Models\Persona;



use Illuminate\Support\Facades\Auth;







class UsuarioController extends Controller



{







    /**



     * Display a listing of the resource.



     *



     * @return \Illuminate\Http\Response



     */



    public function index()



    {



        //



    }







    /**



     * Show the form for creating a new resource.



     *



     * @return \Illuminate\Http\Response



     */



    public function create()



    {



        //



    }







    /**



     * Store a newly created resource in storage.



     *



     * @param \Illuminate\Http\Request $request



     * @return \Illuminate\Http\Response



     */



    public function store(Request $request)



    {



        //



    }







    



    /**



     * @tutorial Method Description: Resetea las claves de un colegio 



     * ;



     * @since {6 sep. 2018}



     * @param Request $request



     * @return \Illuminate\Http\JsonResponse



     */



    public function passwordCliente(Request $request)



    {



        $usuario = Usuario::find($request->id);



        $pass = Usuario::generaPassword();



        $usuario->update([



            "password" => bcrypt($pass),



            "acceso_inicial" => ESiNo::index(ESiNo::Si)->getId()



        ]);



        return response()->json([



            'mensaje' => trans("general.resetear_clave", ['nombre' => $usuario->username, 'pass' => $pass])



        ]);

;

    }







    public function editarCliente(Request $request){



        $usuario = Usuario::find($request->id);



        $pass = Usuario::generaPassword();



        $usuario->update([



            "nombres" => $request->nombres,



            "apellidos" => $request->apellidos,



            "numero_identificacion" => $request->numero_identificacion,



            "porcentaje" => $request->porcentaje,



            "cupo" => $request->cupo



        ]);



        return response()->json([



            'mensaje' => trans("general.resetear_clave", ['nombre' => $usuario->username, 'pass' => 0])



        ]);



    }







    







    /**



     * Show the form for editing the specified resource.



     *



     * @param int $id



     * @return \Illuminate\Http\Response



     */



    public function edit($id)



    {



        //



    }







    /**



     * Update the specified resource in storage.



     *



     * @param \Illuminate\Http\Request $request



     * @param int $id



     * @return \Illuminate\Http\Response



     */



    public function update(Request $request, $id)



    {



        //



    }







    /**



     * Remove the specified resource from storage.



     *



     * @param int $id



     * @return \Illuminate\Http\Response



     */



    public function destroy($id)



    {



        //



    }







    /**



     * @tutorial Method Description: Carga la informacion de los usuarios por perfiles



     * ;



     * @since {17 sep. 2018}



     * @param Request $request



     * @return \Illuminate\Http\JsonResponse



     */



    public function informacionUsuariosPerfil(Request $request)



    {



        $perfil = Perfil::find($request->get("id_perfil"));



        if(!blank($request->get("id_usuario"))){



            $usuarioU = Usuario::find($request->get("id_usuario"));



            $usuarioU->update([



                'activo' => (EActivo::index(EActivo::Si)->getId()==$usuarioU->activo) ? EActivo::index(EActivo::No)->getId() : EActivo::index(EActivo::Si)->getId()



            ]);



        }



        $listUsuarios = [];



        foreach ($perfil->usuarios()->orderBy('username')->get() as $usuario) {



            $infoUsuario=[



                "id_usuario"=>$usuario->id_usuario,



                "id_perfil" => $perfil->id_perfil,



                "nombre" => (blank($usuario->persona)) ? '' : $usuario->persona->nombreCompleto(),



                "usuario" => $usuario->username,



                "activo" => (EActivo::index(EActivo::No)->getId()==$usuario->activo) ? "<a type='button' class='btn waves-effect waves-light btn-outline-secondary btn-sm' onclick='activarUsuario(".$perfil->id_perfil.",".$usuario->id_usuario.")' ><i class='fa fa-times-circle text-danger'></i></a>" : "<a type='button' class='btn waves-effect waves-light btn-outline-secondary btn-sm' onclick='activarUsuario(".$perfil->id_perfil.",".$usuario->id_usuario.")' ><i class='fa fa-check-circle text-success'></i></a>",



                



            ];



            $listUsuarios[] = $infoUsuario;



        }



        return response()->json([



            "list" => $listUsuarios,



            "mensaje" => trans("conaced.usuario_cambiar_estado")



        ]);



    }



    



    /**



     * @tutorial Method Description: Valida que el usuario este auntenticado y lo envia a cambiar la contrase�a



     * ;



     * @since {17 sep. 2018}



     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory



     */



    public function validarPassword()



    {



        $usuario=Auth::user();



        return view('auth/change-password', compact('usuario'));



    }











    /**



     * @tutorial Method Description: Cambia la contrase�a del usuario y redirecciona a logout para que el usuario inicie sesion de nuevo



     * ;



     * @since {17 sep. 2018}



     * @param Request $request



     * @return \Illuminate\Http\JsonResponse



     */



    public function passwordUsuario(Request $request)



    {



        $persona = Persona::find($request->get("id"));



        $usuario = Usuario::where('id_persona', $persona->id_persona)->first();



        $pass = Usuario::generaPassword();



        $usuario->update([



            "password" => bcrypt($pass),



            "acceso_inicial" => ESiNo::index(ESiNo::Si)->getId()



        ]);



        return response()->json([



            'mensaje' => trans("federaciones.resetear_clave", ['nombre' => $usuario->username, 'pass' => $pass])



        ]);



    }





    public function cambiarPassword(Request $request){
        $usuario=Auth::user();
        $usuario->update([
            'acceso_inicial' => ESiNo::index(ESiNo::No)->getId(),
            'password' => bcrypt($request->get("passwordNueva"))
        ]);
        return response()->json([
            'mensaje' => trans("Se actualizó la contraseña con éxito")
        ]);
    }



}



