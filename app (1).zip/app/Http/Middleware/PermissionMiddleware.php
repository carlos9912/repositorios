<?php
namespace App\Http\Middleware;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Closure;

/**
 *
 * @tutorial Working Class
 * @author Bayron Tarazona ~bayronthz@gmail.com
 * @since 06/05/2018
 */
class PermissionMiddleware
{

    /**
     *
     * @tutorial Method Description: Handle an incoming request.
     * @author Bayron Tarazona ~bayronthz@gmail.com
     * @since {06/05/2018}
     * @param Request $request            
     * @param Closure $next            
     * @param string $permission            
     * @return Ambigous <\Illuminate\Routing\Redirector, \Illuminate\Http\RedirectResponse, mixed, \Illuminate\Foundation\Application, \Illuminate\Container\static>
     */
    public function handle(Request $request, Closure $ne, $permission = '')
    {
        if (Auth::guest()) {
            return redirect('/login');
        }
        if (! $request->user()->can($permission)) {
            abort(403);
        }
        return $ne($request);
    }
}
