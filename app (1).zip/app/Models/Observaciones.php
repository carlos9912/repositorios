<?php

namespace App\Models;



use Illuminate\Database\Eloquent\Model;

use Illuminate\Support\Facades\DB;

use Carbon\Carbon;



/**

 *

 * @tutorial Working Class

 * ;

 * @since {28/05/2018}

 */

class Observaciones extends Model

{



    /**

     *

     * @var string

     */

    protected $table = 'observacion';



    /**

     *

     * @var string

     */

    protected $primaryKey = 'codobservacion';



    /**

     *

     * @var boolean

     */

    public $timestamps = false;



    /**

     *

     * @var array

     */

    protected $fillable = [

        'codobservacion',// serial NOT NULL,

        'coddocente',// integer,

        'codrelce',// integer,

        'codestudiante',// integer,

        'estado',// numeric,

        'tipo',// character varying(100),

        'detalle',// character varying(5000),

        'fecha',// date,

    ];



    

    /**

     *

     * @tutorial Method Description: obtiene el menu padre

     * @author Bayron Tarazona ~ bayronthz@gmail.com

     * @since {11/10/2018}

     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo

     */

    public function estudiante()

    {

        return $this->belongsTo('App\Models\Estudiante', 'codestudiante');

    }



   

}

