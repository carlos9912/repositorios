
@php
use Carbon\Carbon;
@endphp
<div class="row">
    @if(\Auth::user()->email!=1)
    <div class="col-sm-9">
        <table class="table table-vcenter mar-top" id="tablaDatatable">
            <thead>
                <tr>
                    <th class="min-w-td">No. Transacción</th>
                    <th class="min-w-td text-left">Producto</th>
                    <th class="text-right">Valor Venta</th>
                    <th class="text-right">Celular</th>
                    <th class="text-center">Fecha</th>
                    <th class="text-center">Cliente</th>
                    <th style="width: 10%;"></th>
                </tr>
            </thead>
            <tbody>
            @php
                $secuencia = 0;
                $valorVentas = 0;
                $valorPorcentaje = 0;
            @endphp
            @if(count($listVentas)>0)
                @foreach($listVentas as $ventas)
                    <tr>
                        <td class="min-w-td">TR-900{{$ventas->codventa}}</td>
                        <td class="min-w-td text-left">{{$ventas->nombre}} </td>
                        <td class="text-right">$ {{number_format($ventas->valor)}} </td>
                        @php
                            $valorVentas+=($ventas->valor);
                            $valorPorcentaje+=($ventas->valor)/100*$ventas->porcentaje;
                        @endphp
                        <td class="text-right">{{$ventas->celular}}</td>
                        <td class="text-right">{{Carbon::parse($ventas->fecha_transaccion)->format(trans('general.format_datetime'))}}</td>
                        <td class="text-right">{{$ventas->nombres}} {{$ventas->apellidos}} </td>
                        <td class="text-center" style="width: 10%;">
                            <a data-fancybox data-type="iframe" class="btn btn-purple btn-sm" data-src="{{url('factura').'?codigo='.$ventas->codventa}}" href="javascript:;">
                                <i class="ti ti-printer"></i>
                            </a>
                        </td>
                    </tr>
                @endforeach
            @endif    
                
            </tbody>
        </table>
    </div>
    <div class="col-md-3">
		<!--Tile-->
        <!--===================================================-->
        <div class="panel panel-success panel-colorful">
            <div class="pad-all media">
                <div class="media-left">
                    <i class="demo-pli-male icon-3x icon-fw"></i>
                </div>
                <div class="media-body">
                    <p class="text-2x mar-no media-heading">$ {{number_format($valorVentas)}} </p>
                    <span>Valor Ventas</span>
                </div>
            </div>
        </div>
        <!--===================================================-->


        <!--Tile-->
        <!--===================================================-->
        <div class="panel panel-primary panel-colorful">
            <div class="pad-all media">
                <div class="media-left">
                    <i class="demo-pli-add-cart icon-3x icon-fw"></i>
                </div>
                <div class="media-body">
                    <p class="text-2x mar-no media-heading">$ {{number_format($valorPorcentaje)}} </p>
                    <span>Utilidades</span>
                </div>
            </div>
        </div>
        <!--===================================================-->

    </div>
@else

    <div class="col-sm-5">
            <table class="table table-vcenter mar-top" id="tablaDatatable">
                <thead>
                    <tr>
                        <th class="min-w-td">No. Transacción</th>
                        <th class="min-w-td text-left">Producto</th>
                        <th class="text-right">Valor Venta</th>
                        <th class="text-right">Celular</th>
                        <th class="text-center">Fecha</th>
                        <th style="width: 10%;"></th>
                    </tr>
                </thead>
                <tbody>
                @php
                    $secuencia = 0;
                    $valorVentas = 0;
                    $valorPorcentaje = 0;
                @endphp
                @if(count($listVentas)>0)
                    @foreach($listVentas as $ventas)
                        <tr>
                            <td class="min-w-td">TR-900{{$ventas->codventa}}</td>
                            <td class="min-w-td text-left">{{$ventas->nombre}} </td>
                            <td class="text-right">$ {{number_format($ventas->valor)}} </td>
                            @php
                                $valorVentas+=($ventas->valor);
                                $valorPorcentaje+=($ventas->valor)/100*$ventas->porcentaje;
                            @endphp
                            <td class="text-right">{{$ventas->celular}}</td>
                            <td class="text-right">{{Carbon::parse($ventas->fecha_transaccion)->format(trans('general.format_datetime'))}}</td>
                            <td class="text-center" style="width: 10%;">
                                <a data-fancybox data-type="iframe" class="btn btn-purple btn-sm" data-src="{{url('factura').'?codigo='.$ventas->codventa}}" href="javascript:;">
                                    <i class="ti ti-printer"></i>
                                </a>
                            </td>
                        </tr>
                    @endforeach
                @endif    
                    
                </tbody>
        </table>
    </div>
    <div class="col-sm-4">
        <div class="table-responsive">
            <table class="table" id="tablaDatatable2">
                <thead>
                    <tr class="">
                        <td class="">No.</td>
                        <td class="">Fecha</td>
                        <td class="">Banco</td>
                        <td class="">Valor</td>
                        <td class="text-center">Estado</td>
                        <td class="text-center">Soporte</td>
                    </tr>
                </thead>
                <tbody>
                @php
                    $listMovimientos = !blank($fechaInicio) || !blank($fechaFin) ? \Auth::user()->movimientos()->whereBetween('fecha_registro',[
                            Carbon::parse(str_replace('/','-',$fechaInicio))->format('Y-m-d').' 00:00:00',
                            Carbon::parse(str_replace('/','-',$fechaFin))->format('Y-m-d').' 23:59:59'
                        ])->get() : \Auth::user()->movimientos;
                        $consignaciones = 0;
                @endphp
                    @foreach($listMovimientos as $movimiento)
                        <tr>
                            <td class="">{{$movimiento->codmovimiento}}</td>
                            <td class="">{{Carbon::parse($movimiento->fecha_registro)->format(trans('general.format_datetime'))}}</td>
                            <td class="">{{$movimiento->banco}}</td>
                            <td class="text-right">$ {{number_format($movimiento->valor)}}</td>
                            <td class="text-center">
                                @if($movimiento->estado==3)
                                    <span class="label label-danger">RECHAZADO</span>
                                @elseif($movimiento->estado==2)
                                    @php $pendientes++; @endphp
                                    <span class="label label-warning">PENDIENTE</span>
                                @else
                                    @php 
                                        $consignaciones+=$movimiento->valor;
                                    @endphp
                                    
                                    <span class="label label-success">APROBADO</span>
                                @endif
                            </td>
                            <td class="text-center">
                                <a data-fancybox data-type="image" href="{{asset('soportes/'.$movimiento->soporte)}}" class="btn btn-xs btn-purple"><i class="ti ti-link"></i></a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-3">
        <!--Tile-->
        <!--===================================================-->
        <div class="panel panel-success panel-colorful">
            <div class="pad-all media">
                <div class="media-left">
                    <i class="demo-pli-male icon-3x icon-fw"></i>
                </div>
                <div class="media-body">
                    <p class="text-2x mar-no media-heading">$ {{number_format($valorVentas)}} </p>
                    <span>Valor Ventas</span>
                </div>
            </div>
        </div>
        <!--===================================================-->


        <!--Tile-->
        <!--===================================================-->
        <div class="panel panel-primary panel-colorful">
            <div class="pad-all media">
                <div class="media-left">
                    <i class="demo-pli-add-cart icon-3x icon-fw"></i>
                </div>
                <div class="media-body">
                    <p class="text-2x mar-no media-heading">$ {{number_format($valorPorcentaje)}} </p>
                    <span>Utilidades</span>
                </div>
            </div>
        </div>
        <!--===================================================-->
        
        <!--Tile-->
        <!--===================================================-->
        <div class="panel panel-warning panel-colorful">
            <div class="pad-all media">
                <div class="media-left">
                    <i class="demo-pli-add-cart icon-3x icon-fw"></i>
                </div>
                <div class="media-body">
                    <p class="text-2x mar-no media-heading">$ {{number_format($consignaciones)}} </p>
                    <span>Consignaciones</span>
                </div>
            </div>
        </div>
        <!--===================================================-->

    </div>
@endif
</div>            
<script>
$('[data-fancybox]').fancybox({
        toolbar  : false,
        smallBtn : true,
        iframe : {
            preload : false
        }
    })
var rowSelection = $('#tablaDatatable').DataTable({
    "responsive": true,
    "aaSorting": [],
    "language": {
        "paginate": {
            "previous": '<i class="demo-psi-arrow-left"></i>',
            "next": '<i class="demo-psi-arrow-right"></i>'
        }
    }
});
var rowSelection = $('#tablaDatatable2').DataTable({
    "responsive": true,
    "aaSorting": [],
    "language": {
        "paginate": {
            "previous": '<i class="demo-psi-arrow-left"></i>',
            "next": '<i class="demo-psi-arrow-right"></i>'
        }
    }
});

</script>