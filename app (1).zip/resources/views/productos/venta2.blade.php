


@extends('layouts.administrador')
@section('title', trans('general.title_crear_pagina'))

@section('content')
<div class="row">
    <div class="col-lg-4">
        <div class="panel panel-success panel-colorful">
            <div class="pad-all">
                <div class="media">
                    <div class="media-left">
                        <img alt="Profile Picture" class="img-md img-circle" src="img/profile-photos/8.png">
                    </div>
                    <div class="media-body pad-top">
                        <h3 class="text-semibold mar-top">Registrar Venta</h3>
                    </div>
                </div>
            </div>
        </div>
        <!--Profile Widget-->
        <!--===================================================-->
        <div class="panel">
            <div class="panel-body" style="padding-top:40px;">
                <p class="text-lg text-semibold mar-btm text-main">Seleccione Producto</p>
                <div class="form-group">
                    {!! Form::select("codproducto", $listProductos, null, ["id"=>"codproducto", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione un producto para la venta", "required" => "required", "onchange" => "return informacionProducto();"]) !!}
                </div>
                <hr>
                <p class="text-semibold">Información</p>
                <div class="list-group bg-trans pad-btm">
                    <a class="list-group-item" id="nombreTxt"><i class="demo-pli-information icon-lg icon-fw"></i> </a>
                    <a class="list-group-item" id="precioTxt"><i class="demo-pli-credit-card-2 icon-lg icon-fw"></i> </a>
                </div>
                <button class="btn btn-primary mar-ver"><i class="ti ti-shopping-cart-full"></i> Registrar Compra</button>
            </div>
        </div>
        <!--===================================================-->


        <!--Profile Widget-->
        <!--========================demo-psi-=======================-->
        
        <!--===================================================-->

    </div>
    <div class="col-lg-6">

        <!--Profile Widget-->
        <!--===================================================-->
        <div class="panel panel-info panel-colorful">
            <div class="pad-all text-center">
                <img alt="Profile Picture" class="img-md img-circle mar-btm" src="img/profile-photos/2.png">
                <p class="text-lg text-semibold">Stephen Tran</p>

                    <div class="btn-group btn-group-justified pad-top">
                    <a href="#" class="btn btn-icon bord-no demo-psi-facebook icon-lg add-tooltip" data-original-title="Facebook" data-container="body"></a>
                    <a href="#" class="btn btn-icon bord-no demo-psi-twitter icon-lg add-tooltip" data-original-title="Twitter" data-container="body"></a>
                    <a href="#" class="btn btn-icon bord-no demo-psi-google-plus icon-lg add-tooltip" data-original-title="Google+" data-container="body"></a>
                    <a href="#" class="btn btn-icon bord-no demo-psi-instagram icon-lg add-tooltip" data-original-title="Instagram" data-container="body"></a>
                </div>
            </div>
        </div>
        <!--===================================================-->

        <!--Profile Widget-->
        <!--===================================================-->
        <div class="panel">
            <div class="panel-body text-center">
                <img alt="Profile Picture" class="img-lg img-circle mar-btm" src="img/profile-photos/5.png">
                <p class="text-lg text-semibold mar-no text-main">Donald Brown</p>
                <p class="text-muted">Web and Graphic designer</p>
                <div class="mar-top">
                    <button class="btn btn-mint">Follow</button>
                    <button class="btn btn-mint">Message</button>
                </div>
            </div>
        </div>
        <!--===================================================-->


    </div>
</div>
@endsection
@section('script')
<script>
function informacionProducto(){
    console.log('entre');
    var codproducto = $("#codproducto").val();
    frameworkApp.setLoadData({
        url: '{{ url("producto/informacion-producto") }}',
        data: {codproducto: codproducto},
        id_container_body: false,
        success: function(data) {
            console.log(data);
        },
        error: function(obj, typeError, text, data) {
            frameworkApp.setToastError("{{ trans('general.error_transaccion') }}");
        }
    });
}
</script>
@endsection