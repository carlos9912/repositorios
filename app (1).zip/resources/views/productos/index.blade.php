
@php
    use App\Models\Estudiante;
use Illuminate\Support\Arr;
@endphp
@extends('layouts.administrador')
@section('title', 'Administrar Productos')
@section('titulo-pagina')
    <div id="page-title">
        <h1 class="page-header text-overflow">Administrador Productos</h1>
    </div>    
@endsection
@section('breadcum')
    <ol class="breadcrumb">
        <li><a href="#"><i class="demo-pli-home"></i></a></li>
        <li class="active">Administrador Productos</li>
    </ol>
@endsection
@section('content')
    <div class="row">
        <div class="panel">
            <div class="panel-body">
                <div class="form-inline pad-top">
                    <div class="row">
                        {{Form::open(['route' => 'estudiantes.index-consultar']) }}  
                            <div class="col-md-3">
                                {!! Form::select("codcurso", $listGrados, null, ["id"=>"director", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione Categoria"]) !!}
                            </div>     
                            <div class="col-md-3 text-left">
                                <button type="submit" class="btn btn-info">BUSCAR</button>
                            </div> 
                            <div class="col-md-6 text-right">
                                <a class="opciones btn btn-purple btnCrear" data-target="#demo-lg-modal" data-toggle="modal">
                                    <i class="ti ti-plus"></i> Crear Producto
                                </a>
                            </div>
                        {{Form::close()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
		<div class="col-md-12">
			<div class="panel">
            <!--===================================================-->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-vcenter mar-top">
                            <thead>
                                <tr>
                                    <th class="min-w-td">No.</th>
                                    <th class="min-w-td">Nombre</th>
                                    <th>Valor Venta</th>
                                    <th>Porcentaje</th>
                                    <th>Utilidad</th>
                                    <th>Stock</th>
                                    <th style="width: 10%;"></th>
                                </tr>
                            </thead>
                            <tbody>
                            @php
                                $secuencia = 0;
                            @endphp
                                @foreach($listProductos as $estudiante)
                                    @php
                                        $secuencia++;
                                    @endphp
                                    <tr>
                                        <td class="min-w-td">{{$secuencia}}</td>
                                        <td><input class="form-control" value="{{$estudiante->nombre}}" name="nombre" id="nombre{{$estudiante->codproducto}}"></td>
                                        <td><input class="form-control" type="number" value="{{$estudiante->valor_venta}}" name="valor_venta" id="valor_venta{{$estudiante->codproducto}}"></td>
                                        <td class="text-center"><input type="number" class="form-control" value="{{$estudiante->porcentaje}}" id="porcentaje{{$estudiante->codproducto}}"></td>
                                        <td><input class="form-control" type="number" value="{{$estudiante->utilidad}}" name="utilidad" id="utilidad{{$estudiante->codproducto}}"></td>
                                        <td>{{Arr::exists($listStock, $estudiante->codproducto) ? $listStock[$estudiante->codproducto] : '-'}} </td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <a class="btn btn-sm btn-primary btn-hover-success add-tooltip btn-editar ti ti-pencil-alt" data-original-title="Editar" data-codproducto="{{$estudiante->codproducto}}" data-container="body"></a>
                                                <a class="btn btn-sm btn-success btn-hover-success add-tooltip btn-evidencias ti ti-upload" data-original-title="Stock" data-toggle="modal" data-target="#modalFormArchivo" data-titulo="{{$estudiante->nombre}}" data-codproducto="{{$estudiante->codproducto}}" data-stock="{{Arr::exists($listStock, $estudiante->codproducto) ? $listStock[$estudiante->codproducto] : '0'}}" data-container="body"></a>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modalFormArchivo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="panel">
                    <div class="panel-body text-center bg-danger">
                        <h2 id="tituloStock" style="color: white;"></h2>
                    </div>
                    <div class="pad-all text-center">
                        <p class="text-semibold text-sm text-main text-uppercase">Unidades en Stock</p>
                        <p class="h1 text-thin mar-no" id="unidadStock"></p>
                    </div>
                </div>
                    {!! Form::open(['route' => ['productos.cargar_inventario'], 'id'=>'formAgregar', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
                    {!! Form::hidden('codproducto', null,['id' => 'codproductoInventario']) !!}
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                    </div>
                    <div class="modal-body">
                        <div class="input-group mar-btm">
                            {!! Form::file("archivo", ['id' => "archivo", 'required' => 'required', 'class' => 'form-control', 'aria-describedby' => 'fileHelp','style'=>'height: auto;', 'accept'=>"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"]) !!}
                            <span class="input-group-btn">
                                <button class="btn btn-mint" type="submit">Cargar Inventario</button>
                            </span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
    <div class="modal fade" id="modalEditar" role="dialog" tabindex="-1" aria-labelledby="modalWindow" aria-hidden="true">
    </div>
    <div id="demo-lg-modal" class="modal fade" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="panel panel-mint panel-bordered">
                        <div class="panel-heading">
                            <div class="panel-control">
                                
                            </div>
                        </div>
                        <div class="panel-body mar-top">
                            <div id="iconosLista" class="clearfix demo-icon-list">
                                <div class="panel-body">
                                {{Form::open(['route' => 'productos.crear-producto', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarAsignatura']) }}  
                                    
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Categoria</label>
                                                {!! Form::select("codcategoria", $listGrados, null, ["id"=>"id_menu_padre", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione Categoria", "required" => "required"]) !!}
                                            </div>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="form-group">
                                                <label class="control-label">Nombre Producto</label>
                                                {!! Form::text('nombre', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Valor</label>
                                                {!! Form::text('valor_venta', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Porcentaje</label>
                                                {!! Form::text('porcentaje', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Utilidad</label>
                                                {!! Form::text('utilidad', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                            </div>
                                        </div>
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label class="control-label">Descripción</label>
                                                {!! Form::textarea('descripcion', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <button class="btn btn-mint" type="submit">Guardar Producto</button>
                                            </div>
                                        </div>
                                        
                                    </div>
                                {{Form::close()}}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
<script>
    $(window).on('load', function(){
        var rowSelection = $('table').DataTable({
        "responsive": true,
        "language": {
            "paginate": {
                "previous": '<i class="demo-psi-arrow-left"></i>',
                "next": '<i class="demo-psi-arrow-right"></i>'
            }
        }
    });
    $("#agregarAsignatura").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            form.submit();
            return false;
        },
        rules: {
            nombre: 'required',
            codcategoria: 'required',
            valor_venta: 'required',
            porcentaje: 'required',
            utilidad: 'required',
        },
        highlight: function (element, errorClass) {
          $(element).parents('.form-group').addClass('has-feedback has-error');
          $(element).parents('.form-group').removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parents('.form-group').removeClass('has-feedback has-error');
          $(element).parents('.form-group').addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.form-group').find('.chosen-container'));
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
    $('.btn-editar').click(function(){
        var codproducto = $(this).data("codproducto");
        console.log($("#porcentaje"+codproducto).val());
        frameworkApp.setLoadData({
            url: '{{ url("producto/editar-producto") }}',
            data: {
                codproducto: codproducto,
                nombre: $("#nombre"+codproducto).val(),
                valor_venta: $("#valor_venta"+codproducto).val(),
                porcentaje: $("#porcentaje"+codproducto).val(),
                utilidad: $("#utilidad"+codproducto).val()
            },
            id_container_body: false,
            success: function(data) {
                frameworkApp.setToastSuccess(data.mensaje);
            }
        });
    });

    $('.btn-evidencias').click(function(){
        
        var codproducto = $(this).data("codproducto");
        $("#codproductoInventario").val(codproducto);
        $("#unidadStock").html($(this).data("stock"));
        $("#tituloStock").html('<i class="ti-package" style="font-size: 40px;"></i> '+$(this).data("titulo"));
        // $("#tablaEvidencias").html('');
        // frameworkApp.setLoadData({
        //     url: '{{ url("evidencias") }}',
        //     data: {
        //         codasignatura: codasignatura,
        //     },
        //     id_container_body: false,
        //     success: function(data) {
        //         console.log(data);
        //         $("#tablaEvidencias").html(data.html);
        //         $("#modalEditar").modal('show');
        //         //frameworkApp.setToastSuccess(data.mensaje);
        //     }
        // });
    });
    $('table').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            rowSelection.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
    });
    function recargar(){
        location.reload();
    }
</script>
    
@endsection