
@php
    use App\Models\Estudiante;
use Illuminate\Support\Arr;
use Carbon\Carbon;
@endphp
@extends('layouts.administrador')
@section('title', 'Administrar Productos')
@section('style')
    <style>
        .checkbox label:after, 
        .radio label:after {
            content: '';
            display: table;
            clear: both;
        }

        .checkbox .cr,
        .radio .cr {
            position: relative;
            display: inline-block;
            border: 1px solid #a9a9a9;
            border-radius: .25em;
            width: 1.3em;
            height: 1.3em;
            float: left;
            margin-right: .5em;
        }

        .radio .cr {
            border-radius: 50%;
        }

        .checkbox .cr .cr-icon,
        .radio .cr .cr-icon {
            position: absolute;
            font-size: .8em;
            line-height: 0;
            top: 50%;
            left: 20%;
        }

        .radio .cr .cr-icon {
            margin-left: 0.04em;
        }

        .checkbox label input[type="checkbox"],
        .radio label input[type="radio"] {
            display: none;
        }

        .checkbox label input[type="checkbox"] + .cr > .cr-icon,
        .radio label input[type="radio"] + .cr > .cr-icon {
            transform: scale(3) rotateZ(-20deg);
            opacity: 0;
        }

        .checkbox label input[type="checkbox"]:checked + .cr > .cr-icon,
        .radio label input[type="radio"]:checked + .cr > .cr-icon {
            transform: scale(1) rotateZ(0deg);
            opacity: 1;
        }

        .checkbox label input[type="checkbox"]:disabled + .cr,
        .radio label input[type="radio"]:disabled + .cr {
            opacity: .5;
        }
    </style>
@endsection
@section('content')
<div class="row">
    <div class="col-lg-4">
        <div class="panel panel-success panel-colorful">
            <div class="pad-all">
                <div class="media">
                    <div class="media-left">
                        <img alt="Profile Picture" class="img-md img-circle" src="img/profile-photos/8.png">
                    </div>
                    <div class="media-body pad-top">
                        <h3 class="text-semibold mar-top" style="margin-top: 7px;">Registrar Venta</h3>
                    </div>
                </div>
            </div>
        </div>
        <!--Profile Widget-->
        <!--===================================================-->
        <div class="panel" id="contenedorVentas">
            <div class="panel-body" style="padding-top:40px;">
                <p class="text-lg text-semibold mar-btm text-main">Seleccione Producto</p>
                <div class="input-group mar-btm">
                    <input type="hidden" id="cantidadProducto" value>
                    <input type="hidden" id="valorProducto" value>
                    {!! Form::select("codproducto", $listProductos, null, ["id"=>"codproducto", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione un producto para la venta", "required" => "required"]) !!}
                    <span class="input-group-btn">
                        <button class="btn btn-mint" type="button"><i class="ti ti-reload"></i></button>
                    </span>
                </div>
                <hr>
                <p class="text-semibold">Información</p>
                <div class="list-group bg-trans">
                    <a class="list-group-item" id="nombreTxt"><i class="demo-pli-information icon-lg icon-fw"></i> </a>
                    <a class="list-group-item" id="precioTxt"><i class="demo-pli-credit-card-2 icon-lg icon-fw"></i> </a>
                    <a class="list-group-item" id="cantidadTxt"><i class="demo-pli-credit-card-2 icon-lg icon-fw"></i> </a>
                </div>
                <input type="text" class="form-control" id="telefono" name="telefono" data-inputmask="'mask': '999 999 99 99'" placeholder="Ingrese número celular del cliente">
                <div class="row mar-top" id="calcularCambio" style="display: none;">
                    <div class="col-sm-6">
                        <label>Cantidad Recibida</label>
                        <input type="text" class="form-control" name="valor_entregado" id="valor_entregado" placeholder="Ingrese el dinero recibido">
                    </div>
                    <div class="col-sm-6">
                        <h1 class="text-right"><strong id="valor">$ 0</strong><br><small style="font-size:10px;">Cambio a entregar</small></h1>
                        
                    </div>
                </div>
                
                <button class="btn btn-primary mar-ver procesarVenta">
                    <i class="ti ti-shopping-cart-full"></i> Registrar Compra
                </button>
                <div class="checkbox text-right">
                    <input id="calcular" class="magic-checkbox" type="checkbox">
                    <label for="calcular">Calcular cambio?</label>
                </div>
            </div>
        </div>
        <div class="panel" id="contenedorVentas">
            <div class="panel-body" id="contenedorResumenPadre">
            </div>
        </div>
        <!--===================================================-->


        <!--Profile Widget-->
        <!--========================demo-psi-=======================-->
        
        <!--===================================================-->

    </div>
    <div class="col-lg-8">

        <!--Profile Widget-->
        <!--===================================================-->
        <div class="panel panel-info panel-colorful">
            <div class="pad-all">
                <div class="media">
                    <div class="media-left">
                        <img alt="Profile Picture" class="img-md img-circle" src="img/profile-photos/8.png">
                    </div>
                    <div class="media-body pad-top">
                        <h3 class="text-semibold mar-top" style="margin-top: 7px;">Últimas ventas realizadas</h3>
                    </div>
                </div>
            </div>
        </div>
        <!--===================================================-->

        <!--Profile Widget-->
        <!--===================================================-->
        <div class="panel" id="contenedorReportes">
            <div class="panel-body">
                <div class="table-responsive" id="tableReportes">
                    <table class="table table-vcenter mar-top">
                        <thead>
                            <tr>
                                <th class="min-w-td">No. Transacción</th>
                                <th class="min-w-td text-left">Producto</th>
                                <th class="text-right">Valor Venta</th>
                                <th class="text-right">Celular</th>
                                <th class="text-center">Fecha</th>
                                <th class="text-center">Cliente</th>
                                <th style="width: 10%;"></th>
                            </tr>
                        </thead>
                        <tbody>
                        @php
                            $secuencia = 0;
                            $valorVentas = 0;
                            $valorPorcentaje = 0;
                        @endphp
                        @if(count($listVentas)>0)
                            @foreach($listVentas as $ventas)
                                <tr>
                                    <td class="min-w-td">TR-900{{$ventas->codventa}}</td>
                                    <td class="min-w-td text-left">{{$ventas->nombre}} </td>
                                    <td class="text-right">$ {{number_format($ventas->valor)}} </td>
                                    @php
                                        $valorVentas+=($ventas->valor);
                                        $valorPorcentaje+=($ventas->valor)/100*$ventas->porcentaje;
                                    @endphp
                                    <td class="text-right">{{$ventas->celular}}</td>
                                    <td class="text-right">{{Carbon::parse($ventas->fecha_transaccion)->format(trans('general.format_datetime'))}}</td>
                                    <td class="text-right">{{$ventas->nombres}} {{$ventas->apellidos}} </td>
                                    <td class="text-center" style="width: 10%;">
                                        <a data-fancybox data-type="iframe" class="btn btn-purple btn-sm" data-src="{{url('factura').'?codigo='.$ventas->codventa}}" href="javascript:;">
                                            <i class="ti ti-printer"></i>
                                        </a>
                                        <a class="btn btn-info btn-sm enviarMensaje" onclick="return sms({{$ventas->codventa}})" href="javascript:;">
                                            <i class="ti ti-email"></i>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        @endif    
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--===================================================-->


    </div>
</div>
<div class="col-md-12" style="display: none;" id="contenedorResumen2" style="display: none;">
    <div class="row">
        <div class="col-sm-6">
            <!--Tile-->
            <!--===================================================-->
            <div class="panel panel-success panel-colorful">
                <div class="pad-all media">
                    <div class="media-left">
                        <i class="demo-pli-male icon-3x icon-fw"></i>
                    </div>
                    <div class="media-body">
                        <p class="text-2x mar-no media-heading">$ {{number_format($valorVentas)}} </p>
                        <span>Valor Ventas</span>
                    </div>
                </div>
            </div>
            <!--===================================================-->
        </div>
        <div class="col-sm-6">
            <!--Tile-->
            <!--===================================================-->
            <div class="panel panel-primary panel-colorful">
                <div class="pad-all media">
                    <div class="media-left">
                        <i class="demo-pli-add-cart icon-3x icon-fw"></i>
                    </div>
                    <div class="media-body">
                        <p class="text-2x mar-no media-heading">$ {{number_format($valorPorcentaje)}} </p>
                        <span>Utilidades</span>
                    </div>
                </div>
            </div>
            <!--===================================================-->
        </div>
    </div>  
</div>
    
@endsection
@section('script')
<link rel="https://cdn.jsdelivr.net/gh/RobinHerbots/jquery.inputmask@5.0.0-beta.87/css/inputmask.css"/>
<script src="https://cdn.jsdelivr.net/gh/RobinHerbots/jquery.inputmask@5.0.0-beta.87/dist/jquery.inputmask.min.js"></script>
<script>
$(document).ready(function() {
    
    var html = $("#contenedorResumen2").html();
    $("#contenedorResumen2").remove();
    $("#contenedorResumenPadre").html(html);
	$('[data-fancybox]').fancybox({
        toolbar  : false,
        smallBtn : true,
        iframe : {
            preload : false
        }
    })
});
    Number.prototype.format = function(n, x) {
        var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
        return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
    };
    $(".fancybox").fancybox();
    $(window).on('load', function(){
        var rowSelection = $('table').DataTable({
        "responsive": true,
        "aaSorting": [],
        "language": {
            "paginate": {
                "previous": '<i class="demo-psi-arrow-left"></i>',
                "next": '<i class="demo-psi-arrow-right"></i>'
            }
        }
    });
    $('#contenedorReportes').css("min-height",$('#contenedorVentas').height());
    $(":input").inputmask();
    $("input[type='checkbox']").change(function() {
        if(this.checked) {
            $("#calcularCambio").show();
        }else{
            $("#calcularCambio").hide();
        }
    });
    $( "#valor_entregado" ).keyup(function() {
        	
        if($(this).val()!=''){
            $("#valor").text("$ "+($(this).val()-$("#valorProducto").val()).format()); 
        }else{
            $("#valor").text('$ 0');
        }
    });
    
    
    $("#agregarAsignatura").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            form.submit();
            return false;
        },
        rules: {
            nombre: 'required',
            codcategoria: 'required',
            valor_venta: 'required',
            porcentaje: 'required',
            utilidad: 'required',
        },
        highlight: function (element, errorClass) {
          $(element).parents('.form-group').addClass('has-feedback has-error');
          $(element).parents('.form-group').removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parents('.form-group').removeClass('has-feedback has-error');
          $(element).parents('.form-group').addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.form-group').find('.chosen-container'));
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    $('.chosen-select').change(function(){
        var codproducto = $(this).val();
        infoProductos(codproducto);
    });
    $('.btn-reload').click(function(){
        var codproducto = $("#codproducto").val();
        infoProductos(codproducto);
    });
    $('.procesarVenta').click(function(){
        $('.procesarVenta').prop( "disabled", true );
        if($("#codproducto").val()=='' || $("#telefono").val().replace(/\s+/g, '').length != 10){
            if($("#codproducto").val()==''){

                frameworkApp.setAlert("Debe escoger un producto");
            } else
            if($("#telefono").val().replace(/\s+/g, '').length != 10){
                frameworkApp.setAlert('Debe escribir el número de celular del cliente');
            }

            $('.procesarVenta').prop( "disabled", false );
        }else if($("#cantidadProducto").val()==0){
                frameworkApp.setAlert('El producto no tiene stock disponible para venta en el momento<br><strong>Intentelo mas tarde</strong>');
            $('.procesarVenta').prop( "disabled", false );
        }else if($("#valor_entregado").val()!='' && Number($("#valor_entregado").val())<Number($("#valorProducto").val())){
            frameworkApp.setToastError('El valor recibido es inferior al precio de venta<br><strong>Verifique la cantidad ingresada</strong>');
            $('.procesarVenta').prop( "disabled", false );
        }else{
            frameworkApp.setLoadData({
                url: '{{ url("producto/venta-procesar") }}',
                data: {
                    codproducto: $("#codproducto").val(),
                    celular: $("#telefono").val(),
                    valor_entregado: $("#valor_entregado").val()
                },
                id_container_body: false,
                success: function(data) {
                    console.log(data);
                    if(data.error==0){
                        $('.procesarVenta').prop( "disabled", false); 
                        $("#codproducto").val('');
                        $("#nombreTxt").html('<i class="demo-pli-information icon-lg icon-fw"></i> ');
                        $("#precioTxt").html('<i class="demo-pli-credit-card-2 icon-lg icon-fw"></i> ');
                        $("#cantidadTxt").html('<i class="demo-pli-credit-card-2 icon-lg icon-fw"></i> ');
                        $("#cantidadProducto").val(0);
                        $("#valorProducto").val(0);
                        $("#telefono").val('');
                        $("#valor_entregado").val('');
                        $("#valor").html('$ 0');
                        $("#tableReportes").html(data.tablaVentas);
                        var html = $("#contenedorResumen").html();
                        $("#contenedorResumen").remove();
                        $("#contenedorResumenPadre").html(html);
                        $("#contenedorResumen").show();
                        $("#codproducto").trigger("chosen:updated");
                        frameworkApp.setToastSuccess(data.mensaje);
                    }else{
                        frameworkApp.setToastError(data.mensaje);
                    }
                }
            });
        }
         
    });
    $('table').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            rowSelection.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
    });
    function recargar(){
        location.reload();
    }

    function sms(codventa){
        frameworkApp.setLoadData({
            url: '{{ url("producto/venta-sms") }}',
            data: {
                codventa: codventa
            },
            id_container_body: false,
            success: function(data) {
                console.log(data);
                frameworkApp.setToastSuccess(data.mensaje);
            }
        });
    }

    function infoProductos(codproducto){
        frameworkApp.setLoadData({
            url: '{{ url("producto/venta-producto") }}',
            data: {
                codproducto: codproducto
            },
            id_container_body: false,
            success: function(data) {
                $("#nombreTxt").html('<i class="demo-pli-information icon-lg icon-fw"></i> '+data.nombre);
                $("#precioTxt").html('<i class="demo-pli-credit-card-2 icon-lg icon-fw"></i> '+data.precio);
                $("#cantidadTxt").html('<i class="demo-pli-credit-card-2 icon-lg icon-fw"></i> '+data.cantidad);
                $("#cantidadProducto").val(data.cantidad);
                $("#valorProducto").val(data.valor);
            }
        });
    }
</script>
    
@endsection