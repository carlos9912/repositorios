<?php

	use Carbon\Carbon;
	use App\Enums\EEstadoVinculacion;
	use App\Enums\ETipoDocumento;
	use App\Models\Apertura;
	use App\Models\Empleado;
	use App\Models\Sucursal;
	use App\Models\Horario;
	use Jenssegers\Agent\Agent;
	
$date = Carbon::now();
$json = '{"result":{"success":false,"message":"El saldo para la venta es insuficiente."},"data":{}}';
$someArray = json_decode($json, true);
//dd($someArray["result"]["message"]); 
$dia = $date->format('w');
$hora = $date->format('d/m/y H:i');
if(blank(session('sucursal'))){
$sucursal = '';
}else{

$sucursal = Sucursal::find(session('sucursal')->codsucursal);

}

$sucursal = blank($sucursal) ? new Sucursal() : $sucursal;
$horario = $sucursal->horarios()->first();
$horario = $sucursal->horarios()->first();
$horario = blank($horario) ? new Horario() : $horario;
$apertura = $sucursal->aperturas()->where('estado','=',1)->first();
$apertura = blank($apertura) ? new Apertura() : $apertura;
$valido = false;
$validar_apertura = !blank($apertura->fecha)&&$date->format('d/m/y')==Carbon::parse($apertura->fecha)->format('d/m/y') ? true : false;
//dd($validar_apertura);
//dd(request());

$cantSucursales = DB::table('sucursales')->select(DB::raw('COUNT(*) as cantidad'))->first();
$cantSucursales = $cantSucursales->cantidad;
$ListSucursales = [];
foreach(DB::table('sucursales')->orderByRaw("departamento asc, municipio ASC")->get() as $sucursal){
    $ListSucursales[strtoupper($sucursal->departamento)][strtoupper($sucursal->municipio)][] = $sucursal;
}
//echo "<body>".DNS1D::getBarcodeSVG("4157707266014651802020015278982239000000001861149620191105", "C128",2,100)."</body>";

?>
 
<?php if(!blank($horario)): ?>
	<?php $__env->startSection('content'); ?>
	
		<div class="row">
			<div class="col-xl-5 col-lg-6">
				<img src="img/actualizacion.jpg" class="img-fluid">
				<!-- begin tabs -->
				<ul class="nav nav-tabs nav-tabs-inverse nav-justified nav-justified-mobile" data-sortable-id="index-2">
						<li class="nav-item"><a href="#latest-post" data-toggle="tab" class="nav-link active"><i class="fa fa-camera fa-lg m-r-5"></i> <span class="d-none d-md-inline">Ultimas noticias</span></a></li>
						<li class="nav-item"><a href="#purchase" data-toggle="tab" class="nav-link"> <span class="d-none d-md-inline"></span></a></li>
						<li class="nav-item"><a href="#email" data-toggle="tab" class="nav-link"> <span class="d-none d-md-inline"></span></a></li>
					</ul>
					<div class="tab-content" data-sortable-id="index-3" style="text-transform: none !important;">
						<div class="tab-pane fade active show" id="latest-post">
							<div class="height-md" data-scrollbar="true">
								<ul class="media-list media-list-with-divider">
									@foreach(DB::table('noticias')->orderBy('codnoticia','desc')->get() as $noticia)
										<li class="media media-lg">
											<a href="javascript:;" class="pull-left">
												<img class="media-object rounded" src="img/gallery-1.jpg" alt="" />
											</a>
											<div class="media-body">
												<h5 class="media-heading">{{$noticia->titulo}}<br><p style="font-size: 80%;">{{$noticia->fecha}}</p></h5>
												{!!$noticia->descripcion!!}
											</div>
										</li>
									@endforeach
								</ul>
							</div>
						</div>
						
					</div>
					<!-- end tabs -->
				<div class="panel panel-inverse">
					<!-- begin panel-heading -->

					
					<div class="panel-heading ui-sortable-handle">
						
						<h4 class="panel-title">Archivos</h4>
					</div>
					<!-- end panel-heading -->
					<!-- begin panel-body -->

					
					<div class="panel-body">
					    <div id="jstree-default">
							<ul>
								<li data-jstree='{"opened":false}' >Documentos administrativos
									<ul>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/ACTA DE CAPACITACION PARA CAJEROS -COLABORADORES.pdf')); ?>');"  ><i class="fa fa-file"></i> ACTA DE CAPACITACIÓN PARA CAJEROS -COLABORADORES</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/AUTORIZACION DE VINCULACION Y TRATAMIENTO DE DATOS (DATA CREDITO) GIROS AFA.pdf')); ?>')"  ><i class="fa fa-file"></i> AUTORIZACIÓN DE VINCULACIÓN Y TRATAMIENTO DE DATOS (DATA CREDITO) GIROS AFA</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/COMPROMISO ADECUACION ESTABLECIMIENTO DE COMERCIO.pdf')); ?>')"  ><i class="fa fa-file"></i> COMPROMISO ADECUACION ESTABLECIMIENTO DE COMERCIO</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/ENTREGA DE EQUIPOS AL PUNTO.pdf')); ?>')"  ><i class="fa fa-file"></i> ENTREGA DE EQUIPOS AL PUNTO</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/FORMATO REPORTE DE INGRESOS.pdf')); ?>')" ><i class="fa fa-file"></i> FORMATO REPORTE DE INGRESOS</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/SOLICITUD CAMBIO DE CAJERO.pdf')); ?>')"  ><i class="fa fa-file"></i> SOLICITUD CAMBIO DE CAJERO</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/SOLICITUD DE AUMENTO DE CUPO PARA PUNTOS DE ATENCION GIROS AFA.pdf')); ?>')"  class="text-light" style="color: white"><i class="fa fa-file"></i> SOLICITUD DE AUMENTO DE CUPO PARA PUNTOS DE ATENCIÓN GIROS AFA</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/SOLICITUD DE AUMENTO DE CUPO TEMPORAL.pdf')); ?>')"  class="text-light" style="color: white"><i class="fa fa-file"></i> SOLICITUD DE AUMENTO DE CUPO TEMPORAL</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/SOLICITUD DE DESVINCULACION PAP.pdf')); ?>')"  class="text-light" style="color: white"><i class="fa fa-file"></i> SOLICITUD DE DESVINCULACIÓN PAP</a></li>
									</ul>											
								</li>
								<li data-jstree='{"opened":false}' >Cuentas bancarias giros afa
									<ul>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/CUENTAS.pdf')); ?>')"  ><i class="fa fa-file"></i> CUENTAS BANCARIAS GIROS AFA </a></li>
									</ul>
								</li>
								<li data-jstree='{"opened":false}' >Manuales y procedimientos
									<ul>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/FORMATO DEVOLUCION TARIFA.pdf')); ?>')"  ><i class="fa fa-file"></i> FORMATO DEVOLUCION TARIFA</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/PLANILLA CONSIGNACION CAJA FUERTE A GIROS AFA.pdf')); ?>')"  ><i class="fa fa-file"></i> PLANILLA CONSIGNACIÓN CAJA FUERTE A GIROS AFA</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/REPORTE OPERACION SOSPECHOSA - ROSI.pdf')); ?>')"  ><i class="fa fa-file"></i> REPORTE OPERACIÓN SOSPECHOSA - ROSI</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/SOLICITUD DE ACTIVACION MANUAL DE GIRO.pdf')); ?>')"  ><i class="fa fa-file"></i> SOLICITUD DE ACTIVACIÓN MANUAL DE GIRO</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/SOLICITUD DE INSUMOS.pdf')); ?>')"  ><i class="fa fa-file"></i> SOLICITUD DE INSUMOS</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/SOLICITUD MODIFICACION INFORMACION DEL CLIENTE.pdf')); ?>')"  ><i class="fa fa-file"></i> SOLICITUD MODIFICACIÓN INFORMACIÓN DEL CLIENTE</a></li>
										
									</ul>
								</li>
								<li data-jstree='{"opened":false}' >Soporte tecnico
									<ul>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/SOLICITUD DE CAMBIO Y REPORTE DE FALLAS EN DISPOSITIVOS ELECTRONICOS.pdf')); ?>')"  ><i class="fa fa-file"></i> SOLICITUD DE CAMBIO Y REPORTE DE FALLAS EN DISPOSITIVOS ELECTRONICOS</a></li>
										<li data-jstree='{ "icon" : "fab fa-adobe fa-lg text-danger" }' style="white-space: normal !important;"><a target="_blank" class="text-inverse btn-files" onclick="abrirPdf('<?php echo e(asset('premium/files/SOLICITUD DE INSUMOS.pdf')); ?>')"  ><i class="fa fa-file"></i> SOLICITUD DE INSUMOS</a></li>
									</ul>
								</li>
							</ul>
						</div>
					</div>
					<!-- end panel-body -->
				</div>
			</div>
			<div class="col-sm-5">
			
						<div class="note note-primary text-center fade show">
							<strong>Convenios</strong> 
						</div>
						<div class="row">
							@foreach(DB::table('convenios')->where('codcategoria','=',1)->get() as $convenio)
								<div class="col-sm-1 mb-4 p-0">
									<a data-toggle="tooltip" data-placement="top" title="{{$convenio->nombre}}">
										<img src="{{asset('img/convenios/'.$convenio->img)}}" alt="" class="img-fluid img-thumbnail" style="    border-radius: 50%;">
									</a>
									
								</div>
							@endforeach
						</div>
						<div class="note note-primary text-center fade show">
							<strong>Giros a Bancos</strong> 
						</div>
						<div class="row">
							@foreach(DB::table('convenios')->where('codcategoria','=',3)->get() as $convenio)
								<div class="col-sm-1 mb-4 p-0">
									<a data-toggle="tooltip" data-placement="top" title="{{$convenio->nombre}}">
										<img src="{{asset('img/convenios/'.$convenio->img)}}" alt="" class="img-fluid img-thumbnail" style="    border-radius: 50%;">
									</a>
									
								</div>
							@endforeach
						</div>
						<div class="note note-primary text-center fade show">
							<strong>Giros a tarjetas de credito</strong> 
						</div>
						<div class="row">
							@foreach(DB::table('convenios')->where('codcategoria','=',4)->get() as $convenio)
								<div class="col-sm-1 mb-4 p-0">
									<a data-toggle="tooltip" data-placement="top" title="{{$convenio->nombre}}">
										<img src="{{asset('img/convenios/'.$convenio->img)}}" alt="" class="img-fluid img-thumbnail" style="    border-radius: 50%;">
									</a>
									
								</div>
							@endforeach
						</div>
				</div>
			<div class="col-xl-2 col-lg-6">
				<!-- begin card -->
				<div class="card border-0 bg-dark text-white mb-3">
					<!-- begin card-body -->
					<div class="card-body">
						<!-- begin title -->
						<div class="mb-3 text-grey">
							<b>Nuevos puntos</b>
						</div>
						<!-- end title -->
						@foreach(DB::table('sucursales')->orderBy('codsucursal','desc')->limit(3)->get() as $suc)
						<!-- begin row -->
						<div class="row align-items-center p-b-1">
							<!-- begin col-4 -->
							
							<!-- end col-4 -->
							<!-- begin col-8 -->
							<div class="col-12">
								<div class="m-b-2 text-truncate">
									<b>SUC-{{str_pad($suc->codsucursal, 4, "0",STR_PAD_LEFT)}}</b>
									{{$suc->nombres}}
								</div>
								<div class="text-grey m-b-2 f-s-11">{{$suc->direccion}} {{$suc->barrio}}</div>
								<div class="text-grey m-b-2 f-s-11">{{$suc->municipio}}, {{$suc->departamento}}</div>
							</div>
							<!-- end col-8 -->
						</div>
						<!-- end row -->
						<hr class="bg-white-transparent-2 m-t-20 m-b-20">
						@endforeach
					</div>
					<!-- end card-body -->
				</div>
				<!-- end card -->
				<div class="card border-0 bg-dark text-white text-truncate mb-3">
					<!-- begin card-body -->
					<div class="card-body">
						<!-- begin title -->
						<div class="mb-3 text-grey">
							<b class="mb-3">Total de sucursales</b> 
						</div>
						<!-- end title -->
						<!-- begin store-session -->
						<div class="d-flex align-items-center mb-1">
							<h2 class="text-white mb-0"><span data-animation="number" data-value="70719">{{$cantSucursales}}</span></h2>
						</div>
						<!-- end store-session -->
					</div>
					<!-- end card-body -->
				</div>
			</div>
		</div>

		<a data-fancybox="" data-type="iframe" href="#" class="btn btn-primary btn-archivos" style="display: none;">
			Open demo
		</a>



		
	@endsection

	@section('script')
		<script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>
		<style type="text/css">
		html{ height:100%; }
		body{ height:100%; margin:0; padding:0; }
		#map_canvas{ height:100%; width:100%; }
		</style>
		
		<script type="text/javascript">
			$(function(){
				//$(".slimScrollDiv").css("height","400px")
				$('.btn-files').click(function(){
					console.log('A'+$(this).data("archivo"));
				});
			});
			$('.text-inverse').fancybox({
				toolbar  : false,
				smallBtn : true,
				iframe : {
					preload : false
				}
			});
			
		
		</script>
		<script>
			$('#jstree-default').jstree({
				"core": {
					"themes": {
						"responsive": false
					}            
				},
				"types": {
					"default": {
						"icon": "fa fa-folder text-warning fa-lg"
					},
					"file": {
						"icon": "fa fa-file text-inverse fa-lg"
					}
				},
				"plugins": ["types"]
			});

			$('#jstree-default').on('select_node.jstree', function(e,data) { 
				var link = $('#' + data.selected).find('a');
				if (link.attr("href") != "#" && link.attr("href") != "javascript:;" && link.attr("href") != "") {
					if (link.attr("target") == "_blank") {
						link.attr("href").target = "_blank";
					}
					document.location.href = link.attr("href");
					return false;
				}
			});
			
			$(".numeric").on({
				"focus": function(event) {
					$(event.target).select();
				},
				"keyup": function(event) {
					$(event.target).val(function(index, value) {
					return value.replace(/\D/g, "")
						.replace(/\B(?=(\d{3})+(?!\d)\.?)/g, ",");
					});
				}
			});
			function abrirPdf(ruta){	
				$('.btn-archivos').attr('href',ruta);
				$('.btn-archivos').click();
			}
			
		</script>
	@endsection


<?php else: ?>

<?php $__env->startSection('content'); ?>
	
<div class="row">
	<!-- begin col-3 -->
	<div class="col-lg-8">
		<div class="widget widget-stats bg-red">
			<div class="stats-icon"><i class="fa fa-calendar"></i></div>
			<div class="stats-info">
				<h4>No es posible realizar transacciones</h4>
				<p>No dispone de horario para operar.<br>Por favor contacte con el administrador</p>	
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
	
<?php endif; ?>

<?php echo $__env->make('layouts.administrador', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



