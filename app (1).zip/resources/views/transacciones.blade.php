

@php
	use App\Support\Util;
	use App\Models\RecargaPaquete;
	use Carbon\Carbon;
	use App\Enums\EEstadoVinculacion;
	use App\Enums\ETipoDocumento;
	use App\Models\Apertura;
	use App\Models\Empleado;
	use App\Models\Sucursal;
	use App\Models\Horario;
	if(\Auth::user()->bloqueo==1){
		echo '<script>window.location = "'.url('/empleado-bloqueo').'";</script>';
	}
	$date = Carbon::now();

	$dia = $date->format('w');
	$hora = $date->format('d/m/y H:i');
	$sucursal = Sucursal::find(session('sucursal')->codsucursal);

	if($sucursal->bloqueo == 1){
		echo '<script>window.location = "'.url('/sucursal-bloqueo').'";</script>';
	}
	$horario = $sucursal->horarios()->first();
	$horario = $sucursal->horarios()->first();
	$horario = blank($horario) ? new Horario() : $horario;
	$apertura = $sucursal->aperturas()->orderBy('codrel','desc')->first();
	$apertura = blank($apertura) ? new Apertura() : $apertura;
	$valido = false;
	$validar_apertura = !blank($apertura->fecha)&&$date->format('d/m/y')==Carbon::parse($apertura->fecha)->format('d/m/y') ? true : false;
	//dd($validar_apertura);
	//dd(request());

	if($dia==0){
		
	}else if($dia==5){

	}else{
		if($horario->jornada_continua_lv==1){
			$rangos = explode(' - ', $horario->horario_c_lv);
		}else{
			/*$mañana = explode(' - ', $horario->horario_m_lv);
			$mañanaPrimero = explode(' ', $mañana[0]);
			$mañanaSegundo = explode(" ", $mañana[1]);
			$mañanaPrimeroP = Carbon::parse($mañanaPrimero[0]);
			if($mañanaPrimero[1]=='pm.'){
				$mañanaPrimeroP->addHours(12);
			}
			$mañanaSegundoP = Carbon::parse($mañanaSegundo[0]);
			if($mañanaSegundo[1]=='pm.'){
				$mañanaSegundoP->addHours(12);
			}

			$tarde = explode(' - ', $horario->horario_t_lv);
			$tardePrimero = explode(" ", $tarde[0]);
			$tardeSegundo = explode(" ", $tarde[1]);
			$tardePrimeroP = Carbon::parse($tardePrimero[0]);
			if($tardePrimero[1]=='pm.'){
				$tardePrimeroP->addHours(12);
			}
			$tardeSegundoP = Carbon::parse($tardeSegundo[0]);
			if($tardeSegundo[1]=='pm.'){
				$tardeSegundoP->addHours(12);
			}
			if($hora->min($mañanaPrimeroP->format('H:i'))&&$hora<$mañanaSegundoP->format('H:i')){
				$valido = true;
			}else if($hora>$tardePrimeroP->format('H:i')&&$hora<$tardeSegundoP->format('H:i')){
				$valido = true;
			}*/
		}
	}
@endphp
@extends('layouts.administrador') 
@if(!blank($horario))
	@section('content')
		<style>
			.modal-title{
				text-align: center;
			}
			.modal-header button{
				display: none!important;
			}
			.bootbox-input{

			}
			.selected{
				background-color: #2d353c !important;
    			border-color: #2d353c !important;
			}
		</style>
		<div class="row">
			<div class="col-sm-12">
				<div class="panel panel-inverse">
					<div class="panel-heading">
						<b>Transacciones</b>
					</div>
					<div class="panel-body">
						<div class="row">
							<!-- end col-4 -->
							<div class="col-lg-3">
								<!-- begin panel -->
								<div class="panel">
									<div class="panel-body pl-0 pt-0 pr-3" style="border-right: 1px solid black">
										<a href="#" class="widget-card widget-card-rounded mb-0" data-id="widget">
											<div class="widget-card-cover"></div>
											<div class="widget-card-content">
												<h5 class="f-s-12 text-black-transparent-7" data-id="widget-elm" data-light-class="f-s-12 text-black-transparent-7" data-dark-class="f-s-12 text-white-transparent-7"><b>Datos Sucursal</b></h5>
												<h4 class="m-b-10"><b>{{$sucursal->nombres}}</b></h4>
												<h6 class="m-b-10"><b>Cupo: $ {{number_format($sucursal->cupo)}}</b></h6>
												<h6><b id="saldoSucursal">Saldo a consignar: $ {{number_format($sucursal->saldo)}}</b></h6>
											</div>
											
										</a>
										
										
												
										<hr>
										{{Form::open(['route' => 'sucursal.abrir-caja', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'abrirCaja']) }} 
											@if($apertura->estado==1&&$validar_apertura)
											<input type="hidden" name="codcaja" value="{{$apertura->estado==1 ? $apertura->codrel : ''}}"> 
												<div class="widget-list widget-list-rounded">
												<!-- begin widget-list-item -->
												<a href="#" class="widget-list-item btn-caja">
													<div class="widget-list-media icon">
													<i class="fa fa-desktop bg-green text-inverse"></i>
													</div>
													<div class="widget-list-content">
													<h5 class="widget-list-title">Caja abierta</h5>
													</div>
													<div class="widget-list-action text-nowrap text-grey-darker text-right">
													Cerrar
													<i class="fa fa-angle-right text-muted t-plus-1 fa-lg m-l-5"></i>
													</div>
												</a>
												<!-- end widget-list-item -->
												</div>
												
											@elseif($apertura->estado==2&&$validar_apertura)
												<div class="col-lg-12">
													<div class="widget widget-stats bg-red">
														<div class="stats-icon"><i class="fa fa-desktop"></i></div>
														<div class="stats-info">
															<h4>CAJA CERRADA</h4>
															<h4>La caja del día se encuentra cerra y no es posible realizar mas operaciones con la caja cerrada</h4>	
														</div>
														<div class="stats-link">
															<a href="#modal-without-animation" data-toggle="modal">Ver detalles <i class="fa fa-arrow-alt-circle-right"></i></a>
															<div class="modal" id="modal-without-animation">
																<div class="modal-dialog modal-lg">
																	<div class="modal-content">
																		<div class="modal-header">
																			<h4 class="modal-title">Detalle de cierre</h4>
																		</div>
																		<div class="modal-body">
																			<table class="table text-dark">
																				<thead>
																					<tr>
																						<td>Usuario</td>
																						<td>Fecha</td>
																					</tr>
																				</thead>
																				<tbody class="">
																					<tr>
																						<td class="text-left">
																						@php
																							$empleado = Empleado::find($apertura->empleado_registra);
																							echo $empleado->nombreCompleto();
																						@endphp
																						</td>
																						<td>{{($apertura->fecha)}}</td>
																					</tr>
																				</tbody>
																			</table>
																		</div>
																		<div class="modal-footer">
																			<a href="javascript:;" class="btn btn-white" data-dismiss="modal">Cerrar</a>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<a data-fancybox="" data-type="iframe" href="{{url('sucursal-cierre')}}?m={{base64_encode($sucursal->codsucursal)}}" class="btn btn-primary btn-factura fa fa-print"></a>	
														
												</div>
											@else
												<div class="widget-list widget-list-rounded">

												
												<!-- begin widget-list-item -->
												<a href="#" class="widget-list-item btn-caja">
													<div class="widget-list-media icon">
													<i class="fa fa-desktop bg-danger text-inverse"></i>
													</div>
													<div class="widget-list-content">
													<h4 class="widget-list-title">Caja cerrada</h4>
													</div>
													<div class="widget-list-action text-nowrap text-grey-darker text-right">
													Abrir
													<i class="fa fa-angle-right text-muted t-plus-1 fa-lg m-l-5"></i>
													</div>
												</a>
												<!-- end widget-list-item -->
												</div>
											@endif
										{{Form::close()}}
										<hr>
										@if($apertura->estado==1&&$validar_apertura && ($sucursal->cupo>=$sucursal->saldo))
										<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
											<a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">Giros</a>
											<a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Pagos</a>
											<a class="nav-link" id="recargas-pills" data-toggle="pill" href="#recargas" role="tab" aria-controls="v-pills-profile" aria-selected="false">Recargas</a>
											<a class="nav-link" id="soat-pills" data-toggle="pill" href="#v-soat-settings" role="tab" aria-controls="v-pills-profile" aria-selected="false">SOAT</a>
										</div>
										<hr>
										@endif
										
									</div>
									
								</div>
								<!-- end panel -->
							</div>
							<!-- begin col-4 -->
							<!-- end col-4 -->
							<div class="col-lg-9">
								<div class="tab-content" id="v-pills-tabContent">
									<div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
										
										@if($apertura->estado==1&&$validar_apertura)
										<div class="row">
											@if($sucursal->cupo>=$sucursal->saldo)
											<div class="col-sm-12">
												<h4 class="text-green">Realizar Transacción</h4>
												<hr>
											</div>
											<div class="col-sm-4">
												<form onkeydown="return event.key != 'Enter';">
													<div class="form-group row m-b-15">
														<label class="col-form-label col-md-12">identificación</label>
														<div class="col-md-12">
															<div class="input-group m-b-10">
																
																{!! Form::hidden('tk',base_convert(1,10,16),['id'=>'tk'])!!}
																{!! Form::text('identificacion', null, ['class' => 'nombre-menu form-control identificacion-cliente' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'identificacion_envio' ]) !!}
																<div class="input-group-prepend">
																	<button class="btn btn-primary btn-buscar btn-identificacion_envio btn-accion" type="button"><i class="fa fa-search"></i></button>
																	<button class="btn btn-primary btn-buscar-recibe btn-identificacion_envio_recibe btn-accion" type="button" style="display:none;"><i class="fa fa-search"></i></button>
																</div>
															</div>
														</div>
													</div>
													<div class="form-group row">
														<label class="col-md-3 col-form-label pt-1"></label>
														<div class="col-md-9">
															<div class="custom-control custom-radio mb-1">
																<input type="radio" id="customRadio1" name="customRadio" class="custom-control-input" value="identificacion_envio" checked>
																<label class="custom-control-label" for="customRadio1">Enviar dinero</label>
															</div>
															<div class="custom-control custom-radio">
																<input type="radio" id="customRadio2" name="customRadio" class="custom-control-input" value="identificacion_envio_recibe">
																<label class="custom-control-label" for="customRadio2">Reclamar dinero</label>
															</div>
														</div>
													</div>
												
												</form>
												<hr>
											</div>
											@else
											    
												<div class="col-sm-12">
													<img src='img/sincupo.png' class="mx-auto d-block" style="width: 70%;">
												</div>
											@endif
											
											<div class="col-lg-12" id="transaccion-contenedor">
											</div>
										</div>
										
										@else
											<img src='img/cerrado.png' class="mx-auto d-block" style="width: 70%;">
										@endif
									</div>
									<div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
										<div class="row">
											<div class="col-sm-12">
											<h4 class="text-green">Realizar Pago</h4>
												<hr>
												<div class="form-group row m-b-15">
													<a href="#" class="btn btn-default btn-categorias p-5" data-codigo="3" style="width: 160px; height: 160px;">
														<img src="{{asset('img/logos/consignaciones.png')}}" alt="" style="width: 150px; height: 150px;">
													</a>
													<a href="#" class="btn btn-default btn-categorias p-5" data-codigo="4" style="width: 160px; height: 160px;">
														<img src="{{asset('img/logos/pago tarjetas.png')}}" alt="" style="width: 150px; height: 150px;">
													</a>
													<a href="#" class="btn btn-default btn-categorias p-5" data-codigo="1" style="width: 160px; height: 160px;">
														<img src="{{asset('img/logos/facturas.png')}}" alt="" style="width: 150px; height: 150px;">
													</a>
													<a href="#" class="btn btn-default btn-categorias p-5" data-codigo="5" style="width: 160px; height: 160px;">
														<img src="{{asset('img/logos/servicio publico.png')}}" alt="" style="width: 150px; height: 150px;">
													</a>
													<a href="#" class="btn btn-default btn-categorias p-5" data-codigo="6" style="width: 160px; height: 160px;">
														<img src="{{asset('img/logos/revistas.png')}}" alt="" style="width: 150px; height: 150px;">
													</a>
													<a href="#" class="btn btn-default p-5 btn-mostrar" style="display: none;" data-codigo="0" style="width: 160px; height: 160px;">
														<img src="{{asset('img/logos/cancelar.png')}}" alt="" style="width: 150px; height: 150px;">
													</a>
												</div>
											</div>
											<div class="col-sm-5">
												<div class="panel-body pb-0">
													@if(1==2)
													<div class="form-group row m-b-15">
														<label class="col-form-label col-md-12">Categoria</label>
														<div class="col-md-12">
															<div class="input-group m-b-10">
																{!! Form::select("categoria", $categorias, null, ['id'=>'categoria', "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione categoria", "required" => "required"]) !!}
															</div>
														</div>
													</div>
													@endif
													<div class="form-group row convenio-select" style="display: none;">
													
            											<h5 class="text-green">Seleccione convenio</h5>
														<div class="col-md-12">
															<div class="input-group m-b-10">
																{!! Form::select("convenio", [], null, ['id'=>'convenio', "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione convenio", "required" => "required"]) !!}
															</div>
														</div>
													</div>
													<div class="form-group row convenio-img" style="display: none;">
            											<h5 class="text-green">Seleccione convenio</h5>
													</div>
												</div>
											</div>
											<div class="col-sm-12 px-0">
												<div id="pagoContenedor">
												
												</div>
											</div>
										</div>
									</div>
									<div class="tab-pane fade" id="recargas" role="tabpanel" aria-labelledby="v-pills-messages-tab">
										{{Form::open(['route' => 'recargas.registrar', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'registrarRecarga']) }} 
											<div class="row">
												<div class="col-sm-6 px-0">
													<h5 class="mb-3" style="text-transform: none;">1. Selecciona el operador</h5>
													<!-- begin row -->
													<div class="row row-space-2 m-b-5">
														@foreach(DB::table('recargas_paquetes')->where('codrecpaq', '<', '153')->where('tipo', '=', 1)->whereNull('codpadre')->get() as $recarga)
														<div class="col-2 {{$recarga->tipo==3 ? 'paquete' : 'operador'}}">
															<a href="#" class="btn btn-default widget-card widget-card-rounded square m-b-2 btn-recarga " data-codpadre="{{$recarga->tipo==3 ? $recarga->codigo : ''}}" data-operador="{{$recarga->tipo==1 ? $recarga->codigo : ''}}" data-nombreoperador="{{$recarga->nombre}}">
																<div class="widget-card-cover m-5" style="background-image: url({{asset('img/logos/'.$recarga->imagen)}}); background-size: contain;"></div>
															</a>
														</div>
														@endforeach
													</div>
													<div class="row row-space-2 m-b-5">
													    
														@foreach(DB::table('recargas_paquetes')->where('codrecpaq', '<', '153')->where('tipo', '=', 3)->whereNull('codpadre')->get() as $recarga)
														<div class="col-2 {{$recarga->tipo==3 ? 'paquete' : 'operador'}}">
															<a href="#" class="btn btn-default widget-card widget-card-rounded square m-b-2 btn-recarga " data-codpadre="{{$recarga->tipo==3 ? $recarga->codigo : ''}}" data-operador="{{$recarga->tipo==1 ? $recarga->codigo : ''}}" data-nombreoperador="{{$recarga->nombre}}">
																<div class="widget-card-cover m-5" style="background-image: url({{asset('img/logos/'.$recarga->imagen)}}); background-size: contain;"></div>
															</a>
														</div>
														@endforeach
													</div>
													<div class="row row-space-2 m-b-5">
														<div class="col-2 paquete">
															<a href="#" class="btn btn-default widget-card widget-card-rounded square m-b-2 btn-recarga " data-codpadre="21" data-operador="" data-nombreoperador="SNR">
																<div class="widget-card-cover m-5" style="background-image: url({{asset('img/logos/snr.png')}}); background-size: contain;"></div>
															</a>
														</div>
														<div class="col-2 operador">
															<a href="#" class="btn btn-default widget-card widget-card-rounded square m-b-2 btn-recarga" data-codpadre="" data-operador="18" data-nombreoperador="WPLAY">
																<div class="widget-card-cover m-5" style="background-image: url(https://www.afainversiones.com/public/img/logos/wplay.png); background-size: contain;"></div>
															</a>
														</div>
														<div class="col-2 paquete">
															<a href="#" class="btn btn-default widget-card widget-card-rounded square m-b-2 btn-recarga " data-codpadre="10052" data-operador="" data-nombreoperador="SPOTIFY">
																<div class="widget-card-cover m-5" style="background-image: url({{asset('img/logos/spotify.png')}}); background-size: contain;"></div>
															</a>
														</div>
														<div class="col-2 paquete">
															<a href="#" class="btn btn-default widget-card widget-card-rounded square m-b-2 btn-recarga " data-codpadre="10050" data-operador="" data-nombreoperador="NETFLIX">
																<div class="widget-card-cover m-5" style="background-image: url({{asset('img/logos/netflix.png')}}); background-size: contain;"></div>
															</a>
														</div>
													</div>
													<div class="input-group m-b-10 paquete-contenedor" style="display: none;">
														<div id="paquete" style="width: 100%;"></div>
													</div>
													<!-- end row -->
												</div>
												<div class="col-sm-6 pr-0 pl-2">
													<h5 class="mb-3" style="text-transform: none;">2. Ingresa número celular</h5>
														<input type="hidden" name="tipo" id="tipo">
														<input type="hidden" name="valor" id="valorrecarga">
														<input type="hidden" name="operador" id="operador">
														<input type="hidden" name="snr" id="snr">
														<input type="hidden" name="nombreoperador" id="nombreoperador">
														<input type="text" class="form-control form-control-lg font-weight-bold" name="numero" id="numerocelular" style="font-size: 25px">
													<hr>
													
													<div class="row row-space-2 m-b-5 valor-recargas">
														<div class="col-sm-12">
															<h5 class="mb-3" style="text-transform: none;">3. Escoge el valor</h5>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="1000">
																<img src="{{asset('img/logos/1000.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="2000">
																<img src="{{asset('img/logos/2000.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="3000">
																<img src="{{asset('img/logos/3000.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="4000">
																<img src="{{asset('img/logos/40.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="5000">
																<img src="{{asset('img/logos/5000.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="10000">
																<img src="{{asset('img/logos/10000.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="20000">
																<img src="{{asset('img/logos/20000.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="30000">
																<img src="{{asset('img/logos/30000.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="40000">
																<img src="{{asset('img/logos/40000.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="50000">
																<img src="{{asset('img/logos/50000.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="100000">
																<img src="{{asset('img/logos/100000.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-2">
															<a href="#" class="btn btn-default btn-valores p-5" data-valor="0">
																<img src="{{asset('img/logos/otro.png')}}" alt="" class="img-fluid">
															</a>
														</div>
														<div class="col-sm-12 otro-valor" style="display: none;">
															<hr class="mb-2">
															<label for="">¿Cual?</label>
															<input type="text" class="form-control form-control-lg font-weight-bold numeric otro-valor-caja" style="font-size: 25px">
														</div>
														
													</div>
													<div class="row contenedor-datos" style="display: none;">
														<div class="col-sm-12">
															<h5 class="mb-3" style="text-transform: none;">3. Ingrese información adicional</h5>
															<label for="">Nro. Matricula</label>
															<input type="text" class="form-control font-weight-bold" name="matricula" id="matricula">
															<label for="">Correo electronico</label>
															<input type="text" class="form-control font-weight-bold" name="correo" id="correo">
																									
														</div>
													</div>
													<div class="row contenedor-datos-wplay" style="display: none;">
														<div class="col-sm-12">
															<h5 class="my-3" style="text-transform: none;">3. Ingrese información adicional</h5>
															<label for="">Nro. Identificación</label>
															<input type="text" class="form-control font-weight-bold" name="identificacion" id="identificacion">
														</div>
													</div>
													<div class="row">
														<div class="col-sm-12 mt-3">
															<button class="btn btn-primary" type="submit">Enviar Recarga</button>
														</div>
													</div>
												</div>
												<div class="col-sm-5">
														
												</div>
											</div>
										{{Form::close()}}
									</div>
									<div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
										<div class="row">
											<div class="col-sm-4">
												<div class="card border-0">
													<img class="card-img-top mx-auto d-block" src="{{asset('img/logos/snr.png')}}" style="width: 70%;" alt="">
													<div class="card-body" style="text-transform: none;">
														<h6 class="card-title m-t-0 m-b-10 text-justify">- El certificado llegará al correo electroníco indicado por el cliente</h6>
														<h6 class="card-title m-t-0 m-b-10 text-justify">- Debe ingresar el número de matricula sin el codigo de oficina de registro</h6>
														<h6 class="mt-4 font-weight-bold text-justify">Si tienes alguna duda, comuniquese con AFAINVERSIONES antes de realizar la transacción</h6>
													</div>
												</div>
											</div>
											<div class="col-sm-8">
												{{Form::open(['route' => 'recargas.registrar', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'registrarSNR']) }} 
													<div class="row">
														<div class="col-sm-6">
															<div class="form-group">
																<label for="">Oficina de registro</label>
																<select name="operador" id="operador-snr" class="chosen-select" data-placeholder="Seleccione la oficina de registro">
																	<option value=""></option>
																	@foreach(Util::getMunicipios() as $key => $municipio)
																		<option value="{{$key}}">{{$municipio}} ({{$key}})</option>
																	@endforeach
																</select>
															</div>
														</div>
														<div class="col-sm-6">
															<div class="form-group">
																<label for="">Número de matricula</label>
																<input type="text" class="form-control" name="matricula" id="matriculasnr">
															</div>
														</div>
														<div class="col-sm-6">
															<div class="form-group">
																<label for="">Número de celular</label>
																<input type="text" class="form-control" name="matricula" id="celularsnr">
															</div>
														</div>	
														<div class="col-sm-6">
															<div class="form-group">
																<label for="">Correo electroníco</label>
																<input type="text" class="form-control" name="matricula" id="correosnr">
																<small>Correo al que llegará el certificado en formato PDF</small>
															</div>
														</div>		
													</div>
													<button class="btn btn-primary">Validar certificado</button>
												{{Form::close()}}
											</div>
											
										</div>
									</div>
									<div class="tab-pane fade" id="v-soat-settings" role="tabpanel" aria-labelledby="v-soat-settings-tab">
										<div class="row">
											<div class="col-sm-4">
												<div class="card border-0">
													<img class="card-img-top mx-auto d-block" src="{{asset('img/logos/soat.jpg')}}" style="width: 70%;" alt="">
													<div class="card-body" style="text-transform: none;">
														<h6 class="card-title m-t-0 m-b-10 text-justify">- El SOAT llegará al correo electroníco indicado por el cliente</h6>
														<h6 class="card-title m-t-0 m-b-10 text-justify">- Puede descargar el SOAT en el siguiente link <a href="https://clientes.axacolpatria.co/descargar-soat" target="_blank">https://clientes.axacolpatria.co/descargar</a></h6>
														<h6 class="card-title m-t-0 m-b-10 text-justify">- Debe ingresar el número de matricula cedula del propietario del vehiculo para poder consultarlo en el RUNT</h6>
														<h6 class="mt-4 font-weight-bold text-justify">Si tienes alguna duda, comuniquese con AFAINVERSIONES antes de realizar la transacción</h6>
													</div>
												</div>
											</div>
											<div class="col-sm-8">
												{{Form::open(['route' => 'soat.registrar', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'registrarSOAT']) }} 
													<input type="hidden" name="valor" id="valorsoat">
													<div class="row">
														<div class="col-sm-6">
															<div class="form-group">
																<label for="">Tipo de vehiculo</label>
																<select name="tipo_vehiculo" id="tipo_vehiculo" class="form-control" data-placeholder="Seleccione tipo de vehiculo">
																	<option value=""></option>
																	<option value="AUTOMOVIL">AUTOMOVIL</option>
																	<option value="MOTO">MOTOCICLETA</option>
																</select>
															</div>
														</div>
														<div class="col-sm-6">
															<div class="form-group">
																<label for="">Número de placa</label>
																<input type="text" class="form-control" name="placa" id="placa">
															</div>
														</div>
														<div class="col-sm-6">
															<div class="form-group">
																<label for="">Tipo de identificacion</label>
																<select name="tipo_identificacion" id="tipo_identificacion" class="form-control" data-placeholder="Seleccione tipo de identificacion">
																	<option value=""></option>
																	<option value="T">Tarjeta de identidad</option>
																	<option value="C">Cédula de ciudadanía</option>
																	<option value="E">Cédula de extranjería</option>
																	<option value="N">Número de identificación tributario</option>
																</select>
															</div>
														</div>
														<div class="col-sm-6">
															<div class="form-group">
																<label for="">Número de identificación</label>
																<input type="text" class="form-control" name="identificacion" id="identificacion">
															<small>Número de identificación del tomador de la póliza</small>
															</div>
														</div>	
														<div class="col-sm-6">
															<div class="form-group">
																<label for="">Número de celular</label>
																<input type="text" class="form-control" name="celular" id="celular">
															</div>
														</div>	
														<div class="col-sm-6">
															<div class="form-group">
																<label for="">Correo electroníco</label>
																<input type="text" class="form-control" name="correo" id="correo">
																<small>Correo al que llegará el SOAT en formato PDF</small>
															</div>
														</div>		
													</div>
													<button class="btn btn-primary">Validar SOAT</button>
												{{Form::close()}}
											</div>
											
										</div>
									</div>
								</div>
							</div>
							
							<!-- end col-4 -->
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-3">
				
			</div>
			<div class="col-9">
				
			</div>
		</div>
		<div class="row">
		<div class="col-sm-12">
			
		</div>
		</div>
		<div id="demo-lg-modal" class="modal fade" tabindex="-1">
			<div class="modal-dialog modal-lg" id="form-modal">
			</div>
		</div>
		@if(!blank(session('last_m'))&&session('last_m')!=0)
			
			<a data-fancybox="" data-type="iframe" href="{{url('factura')}}?m={{(session('last_m'))}}" class="btn btn-primary btn-factura" style="display: none;">
				Open demo
			</a>
			@php
				session(['last_m' =>  0]);
			@endphp
		@endif
		<a data-fancybox="" data-type="iframe" href="#" class="btn btn-primary btn-recarga-recibo" style="display: none;">
			Open demo
		</a>
	@endsection
	@section('script')
		<script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>
		<script>
		
			$(function(){
				$('#navbarButton').click();
				$('.otro-valor-caja').keyup(function(){
					valor = ($(this).val().replace(/,/gi, ''));
					console.log(valor);
					$("#valorrecarga").val(Number(valor));
				});
				$("#registrarRecarga").validate({
					ignore: ":not(.chosen-select):checkbox",
					submitHandler: function(form) {
						
						if($("#tipo").val()==2 && ($("#valorrecarga").val()==''||$("#valorrecarga").val()<=0)){
							frameworkApp.setAlert('Debe especificar un valor para la recarga');
						}else if($("#operador").val()==''){
							frameworkApp.setAlert('Debe seleccionar un operador para la recarga');
						}else{
							if($("#snr").val()==21){
								$(".loader2").show();
								//form.submit();
								$.ajax({
									url: "{{ route('convenios.valirdar-snr') }}",
									headers: {
										'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
									},
									type: 'post',
									data: $('#registrarRecarga').serialize(),
									success: function(result){
										console.log(result);
										$(".loader2").hide();
										if(result.success){
											html = 'Por favor verifique la información del certificado <br><br>Oficina: <br><h4><b>'+$("#nombreoperador").val()+'</b></h4>';
											html+='Nro. Matricula: <br><h4><b>'+$("#operador").val()+'-'+$("#matricula").val()+'</b></h4>';
											html+='Valor: <br><h4><b>'+numeral($("#valorrecarga").val()).format('0,0')+'</b></h4>';
											html+='Dirección: <br><h4><b>'+result.informacion["data"]["address"]+'</b></h4>';
											bootbox.confirm({
												message: html,
												buttons: {
													confirm: {
														label: 'Todo es correcto, enviar!',
														className: 'btn-success'
													},
													cancel: {
														label: 'Corregir información',
														className: 'btn-danger'
													}
												},
												callback: function (result) {
													if(result){
														$(".loader2").show();
														//form.submit();
														$.ajax({
															url: "{{ route('recargas.registrar') }}",
															headers: {
																'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
															},
															type: 'post',
															data: $('#registrarRecarga').serialize(),
															success: function(result){
																console.log(result);
																$(".loader2").hide();
																if(result.estado==1){
																console.log('entre');
																	$('.btn-recarga-recibo').attr('href','{{url('factura-recarga')}}?codrecarga='+result.codrecarga);
																	$('.btn-recarga-recibo').click();
																	$('.btn-recarga').removeClass('selected');
																	$('.btn-valores').removeClass('selected');
																	$("#numerocelular").val('');
																	$("#paquete-contenedor").hide();
																	$("#saldoSucursal").html("SALDO A CONSIGNAR: $"+result.saldo);
																}else{
																	frameworkApp.setAlert('La recarga no se realizó por el siguiente motivo: <br><h4>'+result.mensaje+"</h4> <br>Por favor vuelva a intentarlo, en caso de que el error persista contactar con AFAINVERSIONES");
																}
															}
														});
														//form.submit();
													}
												}
											});
										}else{
											frameworkApp.setAlert('Ocurrió un problema con la compra del certificado: <br><br>Mensaje: '+result.message+'<br><br>Valide la información y vuelva a intentarlo.<br><br><small>Si el error persiste comuniquese con AFAINVERSIONES</small>');
										}
									}
								});
							}else if($("#operador").val()==18){
								$(".loader2").show();
								//form.submit();
								$.ajax({
									url: "{{ route('convenios.valirdar-wplay') }}",
									headers: {
										'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
									},
									type: 'post',
									data: $('#registrarRecarga').serialize(),
									success: function(result){
										console.log(result);
										$(".loader2").hide();
										if(result.success){
											html = 'Por favor verifique la información de la recarga<br><h4><b>'+$("#nombreoperador").val()+'</b></h4>';
											html+='Nro. Celular: <br><h4><b>'+$("#numerocelular").val()+'</b></h4>';
											html+='Nro. identificación: <br><h4><b>'+$("#identificacion").val()+'</b></h4>';
											html+='Valor: <br><h4><b>'+numeral($("#valorrecarga").val()).format('0,0')+'</b></h4>';
											html+='Nombre del cliente: <br><h4><b>'+result.informacion["data"]["client_name"]+'</b></h4>';
											bootbox.confirm({
												message: html,
												buttons: {
													confirm: {
														label: 'Todo es correcto, enviar!',
														className: 'btn-success'
													},
													cancel: {
														label: 'Corregir información',
														className: 'btn-danger'
													}
												},
												callback: function (result) {
													if(result){
														$(".loader2").show();
														//form.submit();
														$.ajax({
															url: "{{ route('recargas.registrar') }}",
															headers: {
																'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
															},
															type: 'post',
															data: $('#registrarRecarga').serialize(),
															success: function(result){
																console.log(result);
																$(".loader2").hide();
																if(result.estado==1){
																console.log('entre');
																	$('.btn-recarga-recibo').attr('href','{{url('factura-recarga')}}?codrecarga='+result.codrecarga);
																	$('.btn-recarga-recibo').click();
																	$('.btn-recarga').removeClass('selected');
																	$('.btn-valores').removeClass('selected');
																	$("#numerocelular").val('');
																	$("#paquete-contenedor").hide();
																	$("#saldoSucursal").html("SALDO A CONSIGNAR: $"+result.saldo);
																}else{
																	frameworkApp.setAlert('La recarga no se realizó por el siguiente motivo: <br><h4>'+result.mensaje+"</h4> <br>Por favor vuelva a intentarlo, en caso de que el error persista contactar con AFAINVERSIONES");
																}
															}
														});
														//form.submit();
													}
												}
											});
										}else{
											frameworkApp.setAlert('Ocurrió un problema con la compra del certificado: <br><br>Mensaje: '+result.message+'<br><br>Valide la información y vuelva a intentarlo.<br><br><small>Si el error persiste comuniquese con AFAINVERSIONES</small>');
										}
									}
								});
							}else{
								html = 'Por favor verifique la información de la recarga<br><br>Operador: <br><h4><b>'+$("#nombreoperador").val()+'</b></h4>';
								html+='Teléfono: <br><h4><b>'+$("#numerocelular").val()+'</b></h4>';
								html+='Valor: <br><h4><b>'+numeral($("#valorrecarga").val()).format('0,0')+'</b></h4>';
								bootbox.confirm({
									message: html,
									buttons: {
										confirm: {
											label: 'Todo es correcto, enviar!',
											className: 'btn-success'
										},
										cancel: {
											label: 'Corregir información',
											className: 'btn-danger'
										}
									},
									callback: function (result) {
										if(result){
											$(".loader2").show();
											//form.submit();
											$.ajax({
												url: "{{ route('recargas.registrar') }}",
												headers: {
													'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
												},
												type: 'post',
												data: $('#registrarRecarga').serialize(),
												success: function(result){
													console.log(result);
													$(".loader2").hide();
													if(result.estado==1){
													console.log('entre');
														$('.btn-recarga-recibo').attr('href','{{url('factura-recarga')}}?codrecarga='+result.codrecarga);
														$('.btn-recarga-recibo').click();
														$('.btn-recarga').removeClass('selected');
														$('.btn-valores').removeClass('selected');
														$("#numerocelular").val('');
														$("#paquete-contenedor").hide();
														$("#saldoSucursal").html("SALDO A CONSIGNAR: $"+result.saldo);
													}else{
														frameworkApp.setAlert('La recarga no se realizó por el siguiente motivo: <br><h4>'+result.mensaje+"</h4> <br>Por favor vuelva a intentarlo, en caso de que el error persista contactar con AFAINVERSIONES");
													}
												}
											});
											//form.submit();
										}
									}
								});
								//	alert($("#valorrecarga").val()+"-"+$("#operador").val());
							}
							
						}
						return false;
					},
					rules: {
						numero: 'required',
					},
					highlight: function (element, errorClass) {
						$(element).parent().addClass('has-feedback has-error');
						$(element).parent().removeClass('has-feedback has-success');
					},
					unhighlight: function (element, errorClass) {
						$(element).parent().removeClass('has-feedback has-error');
						$(element).parent().addClass('has-feedback has-success');
					},
					errorPlacement: function(error, element) {
						if(element.hasClass("no-label")){

						} else if(element.parents('.input-group').length > 0) {
							error.insertAfter(element.parents('.input-group'));
						} else if(element.parents('.form-group').find('.chosen-container').length > 0){
							error.parent().insertAfter(element);
						} else if(element.parents('.radio').find('.chosen-container').length > 0){
							error.insertAfter(element.parents('.radio').find('.chosen-container'));
						} else {
							error.insertAfter(element);
						}
					}
				});
				$("#registrarSNR").validate({
					ignore: ":not(.chosen-select):checkbox",
					submitHandler: function(form) {
						
						if(1==1){
							if(21==21){
								$(".loader2").show();
								//form.submit();
								$.ajax({
									url: "{{ route('convenios.valirdar-snr') }}",
									headers: {
										'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
									},
									type: 'post',
									data: $('#registrarSNR').serialize(),
									success: function(result){
										console.log(result);
										$(".loader2").hide();
										if(result.success){
											html = 'Por favor verifique la información del certificado <br><br>Oficina: <br><h4><b>'+$("#nombreoperador").val()+'</b></h4>';
											html+='Nro. Matricula: <br><h4><b>'+$("#operador").val()+'-'+$("#matricula").val()+'</b></h4>';
											html+='Valor: <br><h4><b>'+numeral(21000).format('0,0')+'</b></h4>';
											html+='Dirección: <br><h4><b>'+result.informacion["data"]["address"]+'</b></h4>';
											bootbox.confirm({
												message: html,
												buttons: {
													confirm: {
														label: 'Todo es correcto, enviar!',
														className: 'btn-success'
													},
													cancel: {
														label: 'Corregir información',
														className: 'btn-danger'
													}
												},
												callback: function (result) {
													if(result){
														$(".loader2").show();
														//form.submit();
														$.ajax({
															url: "{{ route('recargas.registrar') }}",
															headers: {
																'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
															},
															type: 'post',
															data: $('#registrarRecarga').serialize(),
															success: function(result){
																console.log(result);
																$(".loader2").hide();
																if(result.estado==1){
																console.log('entre');
																	$('.btn-recarga-recibo').attr('href','{{url('factura-recarga')}}?codrecarga='+result.codrecarga);
																	$('.btn-recarga-recibo').click();
																	$('.btn-recarga').removeClass('selected');
																	$('.btn-valores').removeClass('selected');
																	$("#numerocelular").val('');
																	$("#paquete-contenedor").hide();
																	$("#saldoSucursal").html("SALDO A CONSIGNAR: $"+result.saldo);
																}else{
																	frameworkApp.setAlert('La recarga no se realizó por el siguiente motivo: <br><h4>'+result.mensaje+"</h4> <br>Por favor vuelva a intentarlo, en caso de que el error persista contactar con AFAINVERSIONES");
																}
															}
														});
														//form.submit();
													}
												}
											});
										}else{
											frameworkApp.setAlert('Ocurrió un problema con la compra del certificado: <br><br>Mensaje: '+result.message+'<br><br>Valide la información y vuelva a intentarlo.<br><br><small>Si el error persiste comuniquese con AFAINVERSIONES</small>');
										}
									}
								});
							}else{
								html = 'Por favor verifique la información de la recarga<br><br>Operador: <br><h4><b>'+$("#nombreoperador").val()+'</b></h4>';
								html+='Teléfono: <br><h4><b>'+$("#numerocelular").val()+'</b></h4>';
								html+='Valor: <br><h4><b>'+numeral($("#valorrecarga").val()).format('0,0')+'</b></h4>';
								bootbox.confirm({
									message: html,
									buttons: {
										confirm: {
											label: 'Todo es correcto, enviar!',
											className: 'btn-success'
										},
										cancel: {
											label: 'Corregir información',
											className: 'btn-danger'
										}
									},
									callback: function (result) {
										if(result){
											$(".loader2").show();
											//form.submit();
											$.ajax({
												url: "{{ route('recargas.registrar') }}",
												headers: {
													'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
												},
												type: 'post',
												data: $('#registrarRecarga').serialize(),
												success: function(result){
													console.log(result);
													$(".loader2").hide();
													if(result.estado==1){
													console.log('entre');
														$('.btn-recarga-recibo').attr('href','{{url('factura-recarga')}}?codrecarga='+result.codrecarga);
														$('.btn-recarga-recibo').click();
														$('.btn-recarga').removeClass('selected');
														$('.btn-valores').removeClass('selected');
														$("#numerocelular").val('');
														$("#paquete-contenedor").hide();
														$("#saldoSucursal").html("SALDO A CONSIGNAR: $"+result.saldo);
													}else{
														frameworkApp.setAlert('La recarga no se realizó por el siguiente motivo: <br><h4>'+result.mensaje+"</h4> <br>Por favor vuelva a intentarlo, en caso de que el error persista contactar con AFAINVERSIONES");
													}
												}
											});
											//form.submit();
										}
									}
								});
								//	alert($("#valorrecarga").val()+"-"+$("#operador").val());
							}
							
						}
						return false;
					},
					rules: {
						numero: 'required',
					},
					highlight: function (element, errorClass) {
						$(element).parent().addClass('has-feedback has-error');
						$(element).parent().removeClass('has-feedback has-success');
					},
					unhighlight: function (element, errorClass) {
						$(element).parent().removeClass('has-feedback has-error');
						$(element).parent().addClass('has-feedback has-success');
					},
					errorPlacement: function(error, element) {
						if(element.hasClass("no-label")){

						} else if(element.parents('.input-group').length > 0) {
							error.insertAfter(element.parents('.input-group'));
						} else if(element.parents('.form-group').find('.chosen-container').length > 0){
							error.parent().insertAfter(element);
						} else if(element.parents('.radio').find('.chosen-container').length > 0){
							error.insertAfter(element.parents('.radio').find('.chosen-container'));
						} else {
							error.insertAfter(element);
						}
					}
				});
				
				$("#registrarSOAT").validate({
					ignore: ":not(.chosen-select):checkbox",
					submitHandler: function(form) {
						
						if(1==1){
							if(21==21){
								$(".loader2").show();
								//form.submit();
								$.ajax({
									url: "{{ route('soat.validar') }}",
									headers: {
										'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
									},
									type: 'post',
									data: $('#registrarSOAT').serialize(),
									success: function(result){
										console.log(result);
										$(".loader2").hide();
										if(1==1){
    										if(result.success){
												html = 'Por favor verifique la información del vehiculo <br><br>';
												
												html = 'Por favor verifique la información del vehiculo <br><br>';
												html+='Número de placa: <br><h4><b>'+result.informacion["data"]["suscriber"]+'</b></h4>';
												html+='Marca: <br><h4><b>'+result.informacion["data"]["trademark"]+'</b></h4>';
												html+='Modelo: <br><h4><b>'+result.informacion["data"]["model"]+'</b></h4>';
												html+='Propietario: <br><h4><b>'+result.informacion["data"]["client_name"]+'</b></h4>';
												html+='Valor: <br><h4><b>'+numeral(result.informacion["data"]["amount"]).format('0,0')+'</b></h4>';
												$("#valorsoat").val(result.informacion["data"]["amount"]);
												bootbox.confirm({
													message: html,
													buttons: {
														confirm: {
															label: 'Todo es correcto, enviar!',
															className: 'btn-success'
														},
														cancel: {
															label: 'Corregir información',
															className: 'btn-danger'
														}
													},
													callback: function (result) {
														if(result){
															$(".loader2").show();
															//form.submit();
															$.ajax({
																url: "{{ route('soat.registrar') }}",
																headers: {
																	'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
																},
																type: 'post',
																data: $('#registrarSOAT').serialize(),
																success: function(result){
																	console.log(result);
																	$(".loader2").hide();
																	if(result.estado==1){
																	console.log('entre');
																		$('.btn-recarga-recibo').attr('href','{{url('factura-soat')}}?codsoat='+result.codsoat);
																		$('.btn-recarga-recibo').click();
																		$('.btn-recarga').removeClass('selected');
																		$('.btn-valores').removeClass('selected');
																		$("#numerocelular").val('');
																		$("#paquete-contenedor").hide();
																		$("#saldoSucursal").html("SALDO A CONSIGNAR: $"+result.saldo);
																	}else{
																		frameworkApp.setAlert('La recarga no se realizó por el siguiente motivo: <br><h4>'+result.mensaje+"</h4> <br>Por favor vuelva a intentarlo, en caso de que el error persista contactar con AFAINVERSIONES");
																	}
																}
															});
															//form.submit();
														}
													}
												});
											}else{
												frameworkApp.setAlert('Ocurrió un problema con la compra del certificado: <br><br>Mensaje: '+result.message+'<br><br>Valide la información y vuelva a intentarlo.<br><br><small>Si el error persiste comuniquese con AFAINVERSIONES</small>');
											}
										}
										
									}
								});
							}else{
								html = 'Por favor verifique la información de la recarga<br><br>Operador: <br><h4><b>'+$("#nombreoperador").val()+'</b></h4>';
								html+='Teléfono: <br><h4><b>'+$("#numerocelular").val()+'</b></h4>';
								html+='Valor: <br><h4><b>'+numeral($("#valorrecarga").val()).format('0,0')+'</b></h4>';
								bootbox.confirm({
									message: html,
									buttons: {
										confirm: {
											label: 'Todo es correcto, enviar!',
											className: 'btn-success'
										},
										cancel: {
											label: 'Corregir información',
											className: 'btn-danger'
										}
									},
									callback: function (result) {
										if(result){
											$(".loader2").show();
											//form.submit();
											$.ajax({
												url: "{{ route('recargas.registrar') }}",
												headers: {
													'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
												},
												type: 'post',
												data: $('#registrarRecarga').serialize(),
												success: function(result){
													console.log(result);
													$(".loader2").hide();
													if(result.estado==1){
													console.log('entre');
														$('.btn-recarga-recibo').attr('href','{{url('factura-recarga')}}?codrecarga='+result.codrecarga);
														$('.btn-recarga-recibo').click();
														$('.btn-recarga').removeClass('selected');
														$('.btn-valores').removeClass('selected');
														$("#numerocelular").val('');
														$("#paquete-contenedor").hide();
														$("#saldoSucursal").html("SALDO A CONSIGNAR: $"+result.saldo);
													}else{
														frameworkApp.setAlert('La recarga no se realizó por el siguiente motivo: <br><h4>'+result.mensaje+"</h4> <br>Por favor vuelva a intentarlo, en caso de que el error persista contactar con AFAINVERSIONES");
													}
												}
											});
											//form.submit();
										}
									}
								});
								//	alert($("#valorrecarga").val()+"-"+$("#operador").val());
							}
							
						}
						return false;
					},
					rules: {
						tipo_vehiculo: 'required',
						placa: 'required',
						tipo_identificacion: 'required',
						identificacion: 'required',
						celular: 'required',
						correo: {
							required: true,
							email: true
						},
					},
					highlight: function (element, errorClass) {
						$(element).parent().addClass('has-feedback has-error');
						$(element).parent().removeClass('has-feedback has-success');
					},
					unhighlight: function (element, errorClass) {
						$(element).parent().removeClass('has-feedback has-error');
						$(element).parent().addClass('has-feedback has-success');
					},
					errorPlacement: function(error, element) {
						if(element.hasClass("no-label")){

						} else if(element.parents('.input-group').length > 0) {
							error.insertAfter(element.parents('.input-group'));
						} else if(element.parents('.form-group').find('.chosen-container').length > 0){
							error.parent().insertAfter(element);
						} else if(element.parents('.radio').find('.chosen-container').length > 0){
							error.insertAfter(element.parents('.radio').find('.chosen-container'));
						} else {
							error.insertAfter(element);
						}
					}
				});
				
				$('.chosen-container').css('width','100%');
				
				$('.btn-mostrar').click(function(){
					btn = $(this);
					btn.hide();
					$('.btn-categorias').show();
					$(".convenio-select").hide();
					$(".convenio-img").hide();
					$('.btn-categorias').removeClass('selected');
					$("#pagoContenedor").html('');
					//btn.addClass('selected');
				});
				$('.btn-recarga').click(function(){
					btn = $(this);
					$("#snr").val('');
					$("#operador").val(btn.data("operador"));
					$("#tipo").val(1);
					$("#nombreoperador").val(btn.data("nombreoperador"));
					$('.valor-recargas').show();
					$(this).parents('.col-sm-6').find('.btn-recarga').each(function(){
						$(this).removeClass('selected');
					});
					$("#valorrecarga").val('');
					$('.btn-valores').removeClass('selected');
					if(btn.data("codpadre")!=''){
						//$('.operador').removeClass("col-2").addClass("col-1");
						$('.valor-recargas').hide();
						$('.paquete-contenedor').show();
						codpadre = btn.data("codpadre");
						console.log(codpadre);
						$(".loader2").show();
						$.ajax({				
							dataType: 'json',
							headers: {
								'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							},
							type: 'POST',
							url: '{{ url("recargas/buscar-paquete") }}',				
							data: {codpadre: codpadre},
							success: function(data) {
								console.log(data.convenios);
								//$("#convenio").empty(); 
								
								$("#paquete").html(data.convenios); 
								$('#paquete').trigger("chosen:updated");
								$(".loader2").hide();
								if(btn.data("codpadre")==21){
									$("#snr").val(21);
									$(".contenedor-datos").show();
									$(".contenedor-datos").find('input').attr('required', true);
								}else{
									$("#snr").val('');
									$(".contenedor-datos").hide();
									$(".contenedor-datos").find('input').removeAttr('required');

								}
							},
							error: function(obj, typeError, text, data) {
								console.log(obj);
								frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
							},
						});
						
					}else{
						//$('.operador').removeClass("col-1").addClass("col-2");
						$('.paquete-contenedor').hide();
						if(btn.data("operador")==18){
							$('.contenedor-datos-wplay').show();
							
						}else{
							
							$('.contenedor-datos-wplay').hide();
						}
					}
					btn.addClass('selected');
				});
				$('.btn-valores').click(function(){
					btn = $(this);
					$("#valorrecarga").val(btn.data("valor"));
					$(this).parents('.col-sm-6').find('.btn-valores').each(function(){
						$(this).removeClass('selected');
					});
					btn.addClass('selected');
					if(btn.data("valor")==0){
						$('.otro-valor').show();
					}else{
						$('.otro-valor').hide();
					}
				});
				$('.btn-categorias').click(function(){
					$("#pagoContenedor").html('');
					$('.btn-mostrar').show();
					btn = $(this);
					$("#valorrecarga").val(btn.data("valor"));
					$(this).parents('.row').find('.btn-categorias').each(function(){
						$(this).removeClass('selected');
						$(this).hide();
					});
					btn.addClass('selected');
					btn.show();
					$(".loader2").show();
					codcategoria = btn.data("codigo");
					$(".loader2").show();
					$.ajax({				
						dataType: 'json',
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						type: 'POST',
						url: '{{ url("convenios/buscar") }}',				
						data: {codcategoria: codcategoria},
						success: function(data) {
							console.log(data.convenios);
							//$("#convenio").empty(); 
							if((codcategoria==3 || codcategoria==4)){
								$(".convenio-select").hide();
								$(".convenio-img").show();
								$(".convenio-img").html(data.convenios); 
							}else{
								$(".convenio-select").show();
								$(".convenio-img").hide();
								$("#convenio").html(data.convenios); 
        						$('#convenio').trigger("chosen:updated");
							}
							
							$(".loader2").hide();
						},
						error: function(obj, typeError, text, data) {
							console.log(obj);
							frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
						},
					});
				});
			});
			$(".numeric").on({
				"focus": function(event) {
					$(event.target).select();
				},
				"keyup": function(event) {
					$(event.target).val(function(index, value) {
					return value.replace(/\D/g, "")
						.replace(/\B(?=(\d{3})+(?!\d)\.?)/g, ",");
					});
				}
			});
			function paquete(ev){
				//console.log(ev);
				//console.log($(ev).data("valor"));
				$("#tipo").val(2);
				$("#operador").val($(ev).data("value"));
				$("#nombreoperador").val($(ev).text());
				$("#valorrecarga").val($(ev).data("valor"));
				$(".list-group").find('a').removeClass("active");
				$(".list-group").find('a').removeClass("text-white");
				$(ev).addClass("active");
				$(ev).addClass("text-white");
				
			}
			$(".paquete-btn").change(function(){
				console.log($(this));
				
				
			});
			$(".chosen-select").chosen();
			$("#categoria").change(function(){
				codcategoria = $(this).val();
				$("#pagoContenedor").html("");
				if(codcategoria !=''){
					$(".loader2").show();
					$.ajax({				
						dataType: 'json',
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						type: 'POST',
						url: '{{ url("convenios/buscar") }}',				
						data: {codcategoria: codcategoria},
						success: function(data) {
							console.log(data.convenios);
							//$("#convenio").empty(); 
							
							$("#convenio").html(data.convenios); 
        					$('#convenio').trigger("chosen:updated");
							$(".loader2").hide();
						},
						error: function(obj, typeError, text, data) {
							console.log(obj);
							frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
						},
					});
				}
			});
			$("#convenio").change(function(){
				convenio = $(this).val();
				console.log(convenio);
				if(convenio !=''){
					$(".loader2").show();
					$.ajax({				
						dataType: 'json',
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						type: 'POST',
						url: '{{ url("convenios/detalle") }}',				
						data: {codconvenio: convenio},
						success: function(data) {
							console.log(data);
							//$("#convenio").empty(); 
							$("#pagoContenedor").html(data.formulario);
							$(".loader2").hide();
						},
						error: function(obj, typeError, text, data) {
							console.log(obj);
							frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
						},
					});
				}
			});
			function consultarConvenio(convenio){
				if(convenio !=''){
					$(".loader2").show();
					$.ajax({				
						dataType: 'json',
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						type: 'POST',
						url: '{{ url("convenios/detalle") }}',				
						data: {codconvenio: convenio},
						success: function(data) {
							console.log(data);
							//$("#convenio").empty(); 
							$("#pagoContenedor").html(data.formulario);
							$(".loader2").hide();
						},
						error: function(obj, typeError, text, data) {
							console.log(obj);
							frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
						},
					});
				}
			}
			$(".convenio-pick").click(function(){
				convenio = $(this).data('codconvenio');
				console.log(convenio);
				if(convenio !=''){
					$(".loader2").show();
					$.ajax({				
						dataType: 'json',
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						type: 'POST',
						url: '{{ url("convenios/detalle") }}',				
						data: {codconvenio: convenio},
						success: function(data) {
							console.log(data);
							//$("#convenio").empty(); 
							$("#pagoContenedor").html(data.formulario);
							$(".loader2").hide();
						},
						error: function(obj, typeError, text, data) {
							console.log(obj);
							frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
						},
					});
				}
			});
			$('.identificacion-cliente').keyup(function(){
				$('#transaccion-contenedor').fadeOut("fast",function(){
					$('#transaccion-contenedor').html('');
				});
			});
			$('.custom-control-input').change(function(){
				console.log($(this).val());
				$('#transaccion-contenedor').fadeOut("fast",function(){
					$('#transaccion-contenedor').html('');
				});
				$(".identificacion-cliente").attr("id",$(this).val());
				$(".btn-accion").hide();
				$('.btn-'+$(this).val()).show();
			});
			$('.btn-caja').click(function(){
				bootbox.confirm({
					@if($apertura->estado==1&&$validar_apertura)
					message: "<br>La caja se encuentra abierta<br><br><b>¿Desea cerrar la caja y finalizar operaciones?<br>NO PODRA VOLVER A REALIZAR OPERACIONES UNA VEZ FINALICE!</b>",
					@else
					message: "<br>La caja se encuentra cerrada<br><br><b>¿Desea abrir la caja e iniciar operaciones?</b>",
					@endif
					buttons: {
						cancel: {
							label: 'Cancelar',
							className: 'btn-danger'
						},
						confirm: {
							@if($apertura->estado==1&&$validar_apertura)
							label: 'Cerrar caja',
							@else
							label: 'Abrir caja',
							@endif
							
							className: 'btn-success'
						}
					},
					callback: function (result) {
						if(result){
							$("#abrirCaja").submit();
						}
					}
				});
			});
			$('.btn-factura').click();
			$('.btn-buscar').click(function(){
				$('#transaccion-contenedor').show();
				$(".loader2").show();
				
				$.ajax({				
					dataType: 'json',
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					type: 'POST',
					url: '{{ url("clientes/buscar") }}',				
					data: {identificacion: $("#identificacion_envio").val(), tk:  $("#tk").val()},
					success: function(data) {
						console.log(data);
						if(data.identificacion==-1){
							bootbox.confirm({
								message: "<br>El número de identificación no se encuentra en la base de datos<br>¿Desea registrarlo?",
								buttons: {
									confirm: {
										label: 'Registrar',
										className: 'btn-success'
									},
									cancel: {
										label: 'Verificar identificación',
										className: 'btn-danger'
									}
								},
								callback: function (result) {
									if(result){
										var codcliente = $(this).data("codcliente");
										$.ajax({
											url: "{{ url('clientes/consultar-transacciones') }}",
											headers: {
												'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
											},
											type: 'post',
											data: {
												codcliente: codcliente
											},
											success: function(result){
												console.log(0);
												$("#demo-lg-modal").modal("show");
												$('#form-modal').html(result.formulario);
											}
										});
									}
								}
							});
						}else{
							if(data.ti==3){
								bootbox.alert('No es posible realizar el envío debido a que el usuario es menor de edad');
							}else{
								$('#giro-contenedor').html(data.html);
								$('#transaccion-contenedor').html(data.html);
							}
						}
						$(".loader2").hide();
					},
					error: function(obj, typeError, text, data) {
						console.log(obj);
						frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
					},
				});
				
			});
			$("#identificacion_envio").on('keyup', function (e) {
				if (e.keyCode === 13) {
					$('.btn-'+$("input[type='radio']:checked").val()).click();
					//alert($("input[type='radio']:checked").val());
				}
			});
			$('.btn-buscar-recibe').click(function(){
				$('#transaccion-contenedor').show();
				$(".loader2").show();
				
				$.ajax({				
					dataType: 'json',
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					type: 'POST',
					url: '{{ url("clientes/buscar") }}',				
					data: {identificacion: $("#identificacion_envio_recibe").val(), tk:  $("#tk").val()},
					success: function(data) {
						$(".loader2").hide();
						var codigo_cliente = data.codigo;
						console.log(codigo_cliente);
						if(data.identificacion==-1){
							bootbox.confirm({
								message: "<br>El número de identificación no se encuentra en la base de datos<br>¿Desea registrarlo?",
								buttons: {
									confirm: {
										label: 'Registrar',
										className: 'btn-success'
									},
									cancel: {
										label: 'Verificar identificación',
										className: 'btn-danger'
									}
								},
								callback: function (result) {
									if(result){
										if(result){
											var codcliente = $(this).data("codcliente");
											$.ajax({
												url: "{{ url('clientes/consultar-transacciones') }}",
												headers: {
													'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
												},
												type: 'post',
												data: {
													codcliente: codcliente
												},
												success: function(result){
													console.log(0);
													$("#demo-lg-modal").modal("show");
													$('#form-modal').html(result.formulario);
												}
											});
										}
									}
								}
							});
						}else{
							bootbox.prompt({
					
								buttons: {
									confirm: {
										label: 'Verificar giro',
										className: 'btn-success'
									},
									cancel: {
										label: 'No tengo un código',
										className: 'btn-danger'
									}
								},
								inputType: 'number',
								title: "Ingrese el código enviado por mensaje de texto", 
								locale: 'custom',
								callback: function (result) {
									$(".loader2").show();
										setTimeout(function(){ 
											$.ajax({				
											dataType: 'json',
											headers: {
												'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
											},
											type: 'POST',
											url: '{{ url("clientes/buscar-giro") }}',				
											data: {codcliente: codigo_cliente, codigo:  result},
											success: function(data) {
												console.log(data);
												if(data.existe==1){
													$('#giro-contenedor-recibe').html(data.html);
													$('#transaccion-contenedor').html(data.html);
												}else if(data.existe==0){
													$('#giro-contenedor-recibe').html('');
													frameworkApp.setAlert('Con el código <b>'+result+'</b> el cliente no tiene giros registrado');
												}else if(data.existe==2){
													$('#giro-contenedor-recibe').html('');
													frameworkApp.setAlert('El giro con el código <b>'+result+'</b> ya fue cobrado por parte del cliente');
												}
											},
											error: function(obj, typeError, text, data) {
												console.log(obj);
												frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
											},
										});

										$(".loader2").hide();
									}, 500);
									
								}
							});	
						}
						
					},
					error: function(obj, typeError, text, data) {
						console.log(obj);
						frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
					},
				});
				
			});
		</script>
	@endsection
@else
@section('content')
	
<div class="row">
	<!-- begin col-3 -->
	<div class="col-lg-8">
		<div class="widget widget-stats bg-red">
			<div class="stats-icon"><i class="fa fa-calendar"></i></div>
			<div class="stats-info">
				<h4>No es posible realizar transacciones</h4>
				<p>No dispone de horario para operar.<br>Por favor contacte con el administrador</p>	
			</div>
		</div>
	</div>
</div>
@endsection
	
@endif
