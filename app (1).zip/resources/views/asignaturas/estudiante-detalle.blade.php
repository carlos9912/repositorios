@php
    $colores = ["POR MEJORAR" => "task-danger","INFORMATIVA" => "task-info","POSITIVA" => "task-success"]
@endphp
@extends('layouts.admin')
@section('title', trans('general.title_administrar_archivos'))
@section('content')
<div class="panel">
  <div class="panel-body">
      <div class="fixed-fluid">
          <div class="fixed-md-200 pull-sm-left fixed-right-border">

              <!-- Simple profile -->
              <div class="text-center">
                  <div class="pad-ver">
                      <img src="{{asset('img/fotos/'.$estudiante->img)}}" class="img-lg img-circle" alt="Profile Picture">
                  </div>
                  <p class="text-lg text-semibold mar-no text-main">{{$estudiante->nombreCompleto()}}</p>
                <p class="text-sm">{{$estudiante->documento()}}</p>
                <p class="text-lg"><span class="label label-mint">GRADO ACTUAL: {!!$grado->nombrecurso!!}</span></p>
                <button class="btn btn-block btn-success btn-lg">Follow</button>
              </div>
              <hr>

              <!-- Profile Details -->
              <p class="pad-ver text-main text-sm text-uppercase text-bold">About Me</p>
              <p><i class="demo-pli-map-marker-2 icon-lg icon-fw"></i> San Jose, CA</p>
              <p><a href="#" class="btn-link"><i class="demo-pli-internet icon-lg icon-fw"></i> http://www.themeon.net</a></p>
              <p><i class="demo-pli-old-telephone icon-lg icon-fw"></i>(123) 456 1234</p>
              <p class="text-sm text-center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>


              <hr>
              <p class="pad-ver text-main text-sm text-uppercase text-bold">Skills</p>
              <ul class="list-inline">
                  <li class="tag tag-sm">PHP Programming</li>
                  <li class="tag tag-sm">Marketing</li>
                  <li class="tag tag-sm">Graphic Design</li>
                  <li class="tag tag-sm">Sketch</li>
                  <li class="tag tag-sm">Photography</li>
              </ul>

              <hr>
              <p class="pad-ver text-main text-sm text-uppercase text-bold">Gallery</p>
              <div class="row img-gallery">
                  <div class="col-xs-6">
                      <img class="img-responsive" src="img/thumbs/img-3.jpg" alt="thumbs">
                  </div>
                  <div class="col-xs-6">
                      <img class="img-responsive" src="img/thumbs/img-6.jpg" alt="thumbs">
                  </div>
                  <div class="col-xs-6">
                      <img class="img-responsive" src="img/thumbs/img-4.jpg" alt="thumbs">
                  </div>
                  <div class="col-xs-6">
                      <img class="img-responsive" src="img/thumbs/img-2.jpg" alt="thumbs">
                  </div>
                  <div class="col-xs-6">
                      <img class="img-responsive" src="img/thumbs/img-5.jpg" alt="thumbs">
                  </div>
                  <div class="col-xs-6">
                      <img class="img-responsive" src="img/thumbs/img-1.jpg" alt="thumbs">
                  </div>
              </div>
          </div>
          <div class="fluid">
            <div class="row">
                <div class="col-sm-4">
                    <!-- Upcoming Tasklist -->
                    <!---------------------------------->
                    <div>
                        <h4 class="text-main">Observaciones</h4>
                        <p class="text-muted text-sm">Observaciones realizadas al estudiante</p>
                        <hr>
                        <ul id="demo-tasklist-upcoming" class="sortable-list tasklist list-unstyled ui-sortable">
                            @foreach($observaciones as $observacion)
                                @php
                                    $docente = \App\Models\Docente::find($observacion->coddocente);
                                    $docente = blank($docente) ? new \App\Models\Docente() : $docente;
                                @endphp
                                <li id="demo-tasklist-1" class="{{$colores[$observacion->tipo]}} ui-sortable-handle">
                                    <p class="pad-btm bord-btm text-justify" >
                                        <b>OBSERVACIÓN:</b> {{$observacion->detalle}}<br>
                                        <b>RESPUESTA:</b> {{$observacion->respuesta}}
                                    </p>
                                    <a href="#" class="task-footer">
                                        <span class="box-inline">
                                            <img class="img-xs img-circle" src="{{asset('img/fotos/1.png')}}" alt="task-user">
                                            {{$docente->nombreCompleto()}}
                                        </span>
                                        <span class="text-sm">{{$observacion->fecha}}</span>
                                    </a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <!---------------------------------->
        
        
                </div>
                <div class="col-sm-4">
                    <!-- Upcoming Tasklist -->
                    <!---------------------------------->
                    <div>
                        <h4 class="text-main header-title m-t-0">Ficha Acumulativa</h4>
                        <p class="text-muted text-sm"></p>
                        <hr>
        
                        <ul id="demo-tasklist-inprogress" class="sortable-list tasklist list-unstyled ui-sortable">
                            <li id="demo-tasklist-5" class="ui-sortable-handle">
                                <p class="text-bold text-main text-sm">
                                        <i class="fa fa-heart fa-2x"></i> AREA SOCIOAFECTIVA
                                </p>
                                <p class="pad-btm bord-btm">To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it?</p>
                                <a href="#" class="task-footer">
                                    <span class="text-sm"><i class="demo-pli-clock icon-fw text-main"></i>9:25</span>
                                </a>
                            </li>
                            <li id="demo-tasklist-6" class="task-success ui-sortable-handle">
                                <p class="text-bold text-main text-sm">
                                    <i class="fa fa-lightbulb-o fa-2x"></i> AREA COGNOSCITIVA
                                </p>
                                <p class="pad-btm bord-btm">The new common language will be more simple and regular than the existing European languages.</p>
                                <a href="#" class="task-footer">
                                    <span class="box-inline">
                                        <img class="img-xs img-circle" src="img/profile-photos/8.png" alt="task-user">
                                        Brenda Fuller
                                    </span>
                                </a>
                            </li>
                            <li id="demo-tasklist-7" class="task-info ui-sortable-handle">
                                <p class="text-bold text-main text-sm">#68464</p>
                                <p class="pad-btm bord-btm">To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words. </p>
                                <a href="#" class="task-footer">
                                    <span class="box-inline">
                                        <label class="label label-warning">Feature Request</label>
                                        <label class="label label-danger">Bug</label>
                                    </span>
                                </a>
                            </li>
                            <li id="demo-tasklist-8" class="task-danger ui-sortable-handle">
                                <p class="pad-btm bord-btm">The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators.</p>
                                <a href="#" class="task-footer">
                                    <span class="box-inline">
                                        Broken links <label class="badge badge-info mar-lft">9</label>
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!---------------------------------->
        
        
        
                </div>
                <div class="col-sm-4">
        
        
                    <!-- Upcoming Tasklist -->
                    <!---------------------------------->
                    <div>
                        <h4 class="text-main header-title m-t-0">Completed</h4>
                        <p class="text-muted text-sm">To an English person, it will seem like simplified.</p>
                        <hr>
        
                        <ul id="demo-tasklist-completed" class="sortable-list tasklist list-unstyled ui-sortable">
                            <li id="demo-tasklist-9" class="task-success ui-sortable-handle">
                                <div class="task-img">
                                    <img class="img-responsive" src="img/shared-img-3.jpg" alt="Image">
                                </div>
                                <p class="pad-btm bord-btm">No one rejects, dislikes, or avoids pleasure itself, because it is pleasure.</p>
                                <a href="#" class="task-footer">
                                    <span class="box-inline">
                                        <span class="pad-rgt"><i class="demo-pli-heart-2"></i> 54K</span>
                                    </span>
                                    <span class="text-sm"><i class="demo-pli-clock icon-fw text-main"></i>03:08</span>
                                </a>
                            </li>
                            <li id="demo-tasklist-10" class="task-warning ui-sortable-handle">
                                <p class="text-bold text-main text-sm">#54686</p>
                                <p class="pad-btm bord-btm">The European languages are members of the same family. Their separate existence is a myth.</p>
                                <a href="#" class="task-footer">
                                    <span class="box-inline">
                                        <img class="img-xs img-circle" src="img/profile-photos/1.png" alt="task-user">
                                        Aaron Chavez
                                    </span>
                                    <span class="text-sm"><i class="demo-pli-clock icon-fw text-main"></i>10:47</span>
                                </a>
                            </li>
                            <li id="demo-tasklist-11" class="task-info ui-sortable-handle">
                                <p class="text-bold text-main text-sm">#68464</p>
                                <p class="pad-btm bord-btm">To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words. </p>
                                <a href="#" class="task-footer">
                                    <span class="box-inline">
                                        <label class="label label-warning">Feature Request</label>
                                        <label class="label label-danger">Bug</label>
                                    </span>
                                </a>
                            </li>
                            <li id="demo-tasklist-12" class="task-success ui-sortable-handle">
                                <p class="text-bold text-main text-sm">#34625</p>
                                <img class="img-responsive mar-btm" src="img/shared-img.jpg" alt="Image">
                                <p class="pad-btm bord-btm">No one rejects, dislikes, or avoids pleasure itself, because it is pleasure.</p>
                                <a href="#" class="task-footer">
                                    <span class="box-inline">
                                        <span class="pad-rgt"><i class="demo-pli-heart-2"></i> 54K</span>
                                    </span>
                                    <span class="text-sm"><i class="demo-pli-clock icon-fw text-main"></i>03:08</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!---------------------------------->
        
        
                </div>
            </div>
          </div>
      </div>
  </div>
</div>
@endsection
