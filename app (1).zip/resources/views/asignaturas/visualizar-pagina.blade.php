@extends('layouts.app')
@section('contenido')
<style>
    .alert-purple {
        background-color: #b269be;
        border-color: transparent;
        border-left: 3px solid #773383;
        color: #fff;
    }
    .alert-pink {
        background-color: #ee87aa;
        border-color: transparent;
        border-left: 3px solid #e62063;
        color: #fff;
    }
    .alert-warning {
        background-color: #f7bb2b;
        border-color: transparent;
        border-left: 3px solid #b07c03;
        color: #fff;
    }
    .alert-info {
        background-color: #37aee3;
        border-color: transparent;
        border-left: 3px solid #116f99;
        color: #fff;
    }
    .alert-success {
        background-color: #9cc56c;
        border-color: transparent;
        border-left: 3px solid #648e33;
        color: #fff;
    }
    .alert-dark {
        background-color: #676f78;
        border-color: transparent;
        border-left: 3px solid #31373e;
        color: #fff;
    }
    .pad-all {
        margin: 15px;    
        padding: 15px;
        border-radius: 10px;
    }
    .column{
        margin-bottom: 15px;
        margin-top: 15px;
    }
    .bord-all {
        border: 1px solid rgba(200,200,200)!important;
    }
    .bord-btm {
        border-bottom: 1px solid rgba(200,200,200)!important;
    }
    .bord-top {
        border-top: 1px solid rgba(200,200,200)!important;
    }
    .bord-rgt {
        border-right: 1px solid rgba(200,200,200)!important;
    }
    .bord-lft {
        border-left: 1px solid rgba(200,200,200)!important;
    }
    .bord-ver {
        border-right: 1px solid rgba(200,200,200)!important;
        border-left: 1px solid rgba(200,200,200)!important;
    }
    .bord-hor {
        border-top: 1px solid rgba(200,200,200)!important;
        border-bottom: 1px solid rgba(200,200,200)!important;
    }
    .text-success-hr{
        border-color: #79af3a !important;
    }
    .text-info-hr{
        border-color: #0391d1 !important;
    }
    .text-primary-hr{
        border-color: #1c3550 !important;
    }
    .text-warning-hr{
        border-color: #db9a00 !important;
    }
    .text-purple-hr{
        border-color: #953ca4 !important;
    }
    .text-pink-hr{
        border-color: #ed417b !important;
    }
    .hr-delgado{
        border-top: 1px solid;
    }
    .hr-normal{
        border-top: 2px solid;
    }
    .hr-ancho{
        border-top: 4px solid;
    }
    .row {
        margin-right: 0px !important;
        margin-left: 0px !important;
    }
</style>
    {!!$pagina->pagina_mostrar!!}
    
@endsection
@section('scripts')
<script>
    $(".courseSingleSection").css("background",'{!!$pagina->img_background!!}');
</script>
@endsection

@section('footer')
   
@endsection