@extends('layouts.admin')
@section('title', trans('general.title_administrar_archivos'))
@section('content')
  <div class="row">
    <div class="col-sm-6 col-sm-offset-1">
      <div class="panel panel-success bord-all">
        <div class="panel-heading">
          <h3 class="panel-title text-bold">{{trans('archivos.imagen_subir_editar')}}</h3>
        </div>
        <div class="panel-body row" style="min-height: 590px;">
          <div class="col-md-12" >
            <!-- <h3 class="page-header">Demo:</h3> -->
            <div class="img-container">
              <img src="img/choose-img.png" alt="Picture" id="">
            </div>
            <div class="col-md-12 docs-buttons">
                <!-- <h3 class="page-header">Toolbar:</h3> -->
                <div class="btn-group">
                  <button class="btn btn-primary" data-method="setDragMode" data-option="move" type="button" title="Move">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setDragMode", "move")">
                      <span class="fa fa-arrows"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="setDragMode" data-option="crop" type="button" title="Crop">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setDragMode", "crop")">
                      <span class="fa fa-crop"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="zoom" data-option="0.1" type="button" title="Zoom In">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("zoom", 0.1)">
                      <span class="fa fa-search-plus"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="zoom" data-option="-0.1" type="button" title="Zoom Out">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("zoom", -0.1)">
                      <span class="fa fa-search-minus"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="rotate" data-option="-45" type="button" title="Rotate Left">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("rotate", -45)">
                      <span class="fa fa-rotate-left"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="rotate" data-option="45" type="button" title="Rotate Right">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("rotate", 45)">
                      <span class="fa fa-rotate-right"></span>
                    </span>
                  </button>
                </div>
        
                <div class="btn-group">
                  <button class="btn btn-primary" data-method="disable" type="button" title="Disable">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("disable")">
                      <span class="fa fa-lock"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="enable" type="button" title="Enable">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("enable")">
                      <span class="fa fa-unlock"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="reset" type="button" title="Reset">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("reset")">
                      <span class="fa fa-refresh"></span>
                    </span>
                  </button>
                  
                </div>
                
                <div class="btn-group btn-group" data-toggle="buttons">
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="1.7777777777777777" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio1" name="aspestRatio" value="1.7777777777777777" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 16 / 9)">
                      16:9
                    </span>
                  </label>
                  <label class="btn btn-primary active" id="aspestRatio2Label" data-method="setAspectRatio" data-option="1.3333333333333333" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio2" name="aspestRatio" value="1.3333333333333333" type="radio" selected>
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 4 / 3)">
                      4:3
                    </span>
                  </label>
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="1" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio3" name="aspestRatio" value="1" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 1 / 1)">
                      1:1
                    </span>
                  </label>
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="0.6666666666666666" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio4" name="aspestRatio" value="0.6666666666666666" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 2 / 3)">
                      2:3
                    </span>
                  </label>
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="NaN" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio5" name="aspestRatio" value="NaN" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", NaN)">
                      Free
                    </span>
                  </label>
                </div>
                <button type="button" class="btn btn-secondary" style="display: none;" data-method="getData" data-option="" data-target="#putData" id="btnDataCropper">
                  <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="cropper.getData()">
                    Get Data
                  </span>
                </button>
                <label class="btn btn-success btn-upload" for="inputImage" title="Upload image file">
                    {{Form::open(['route' => 'paginas.guardar-imagen-crop', 'id' => 'informacionDocente']) }}
                      {!! Form::hidden('dataCrop', null,['id' => 'putData']) !!}
                      <input class="sr-only" id="inputImage" name="file" type="file" accept="image/*">
                    {!! Form::close() !!}
                    <span class="docs-tooltip" data-toggle="tooltip" title="Import image with Blob URLs">
                    <span class="fa fa-upload"></span>
                    {{trans('botones.subir_imagen')}}
                  </span>
                </label>
                <button class="btn btn-mint" data-method="getCroppedCanvas" type="button">
                  <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("getCroppedCanvas")">
                      <span class="fa fa-check"></span>
                      
                      {{trans('botones.finalizar')}}
                  </span>
                </button>
              </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group pad-lft">
                        <label class="control-label">{{trans('archivos.imagen_ancho')}}</label>
                        <div class="input-group mar-btm">
                            <span class="input-group-addon"><i class="fa fa-arrows-h"></i></span>
                            <input type="text" class="form-control" id="dataWidth" readonly>
                            <span class="input-group-addon">{{trans('archivos.imagen_pixeles')}}</span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group pad-rgt">
                        <label class="control-label">{{trans('archivos.imagen_alto')}}</label>
                        <div class="input-group mar-btm">
                            <span class="input-group-addon"><i class="fa fa-arrows-v"></i></span>
                            <input type="text" class="form-control" id="dataHeight" readonly>
                            <span class="input-group-addon">{{trans('archivos.imagen_pixeles')}}</span>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-primary bord-all">
            <div class="panel-heading">
                <h3 class="panel-title text-bold">{{trans('botones.subir_imagen')}}</h3>
            </div>
            <div class="panel-body">
                <p>
                    <div class="alert alert-primary">
                        {!!trans('archivos.imagen_subir_tutorial')!!}
                    </div>
                </p>
                <br>
                <!--===================================================-->
                {!! Form::open(['route' => ['paginas.guardar-imagen-crop'], 'id'=>'formAgregarImg', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
                <input type="hidden" name="tipoArchivo" value="img">
                  <div class="form-group">
                      <div class="input-group mar-btm">
                          {!! Form::file("file", ['id' => "fileImg", 'class' => 'form-control', 'aria-describedby' => 'fileHelp','style'=>'height: auto;', 'accept' => '/img' ]) !!}
                          @if ($errors->has('file'))
                              <span class="invalid-feedback">
                                  <strong>{{ $errors->first('file-image')  }}</strong>
                              </span>
                          @endif
                          <span class="input-group-btn">
                              <button class="btn btn-mint" type="submit">{{trans('botones.subir')}}</button>
                          </span>
                      </div>
                  </div>
                {!! Form::close()!!}
                <!--===================================================-->
            </div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-info bord-all">
            <div class="panel-heading">
                <h3 class="panel-title text-bold"> {!!trans('archivos.pdf_subir')!!}</h3>
            </div>
            <div class="panel-body">
                <p>
                    <div class="alert alert-info">
                        {!!trans('archivos.pdf_subir_tutorial')!!}
                    </div>
                </p>
                <br>
                <!--===================================================-->
                {!! Form::open(['route' => ['paginas.guardar-imagen-crop'], 'id'=>'formAgregarPdf', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
                  <input type="hidden" name="tipoArchivo" value="pdf">
                  <div class="form-group">
                      <div class="input-group mar-btm">
                          {!! Form::file("file", ['id' => "filePdf", 'class' => 'form-control', 'aria-describedby' => 'fileHelp','style'=>'height: auto;', 'accept' => '/img' ]) !!}
                          @if ($errors->has('file'))
                              <span class="invalid-feedback">
                                  <strong>{{ $errors->first('file-image')  }}</strong>
                              </span>
                          @endif
                          <span class="input-group-btn">
                              <button class="btn btn-mint" type="submit">{{trans('botones.subir')}}</button>
                          </span>
                      </div>
                  </div>
                {!! Form::close()!!}
                <!--===================================================-->
        
            </div>
        </div>
    </div>
  </div>
  <!-- Show the cropped image in modal -->
  <div class="modal fade docs-cropped" id="getCroppedCanvasModal" aria-hidden="true" aria-labelledby="getCroppedCanvasTitle" role="dialog" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bord-btm">
          <h4 class="modal-title" id="getCroppedCanvasTitle">{{trans('archivos.imagen_terminada')}}</h4>
          <div class="pull-right">
            <button type="button" class="btn btn-danger" data-dismiss="modal">{{trans('botones.seguir_editando')}}</button>
            <a class="btn btn-primary" id="download" href="javascript:void(0);" onclick="return convasToBlob();">{{trans('botones.subir')}}</a>
          </div>
        </div>
        <div class="modal-body" id="modalBodyCanvas"></div>
        <!-- <div class="modal-footer">
          <button class="btn btn-primary" data-dismiss="modal" type="button">Close</button>
        </div> -->
        
      </div>
      
    </div>
  </div>
@endsection

@section('script')
  <script src="{{asset('plugins/cropperjs/dist/cropper.js')}}"></script>
  <script src="{{asset('plugins/cropperjs/configuracion.js')}}"></script>
  <script src="{{asset('plugins/canvas-blob/js/canvas-to-blob.min.js')}}"></script>

  <script>
    $(document).ready(function () {
      $.validator.addMethod('filesize', function(value, element, param) {
        return this.optional(element) || (element.files[0].size <= param) 
			}); 
      $("#formAgregarImg").validate({
          ignore: ":hidden:not(.chosen-select)",
          submitHandler: function(form) {
            var loading = frameworkApp.setLoading();            
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                dataType: 'json',
                type:'POST',
                url: '{{ url("subir-archivo") }}',
                data: new FormData($("#formAgregarImg")[0]),
                processData: false,
                contentType: false,
                id_container_body: false,
                success: function(data) {
                    console.log(0);
                    $("#fileImg").val(null);
                    loading.remove();
                    alert("{{trans('archivos.imagen_subir_exito')}}");
                    window.opener.nameFunction(data.ruta);
                    //$('#getCroppedCanvasModal').modal('hide');
                },
            });
          },
          rules: {
            file: {
              accept: "image/*",
              filesize: 8388608,
              required: true
            }
          },
          messages: {
              file: {
                accept: "{{ trans('general.extension_failed', ['ext' => 'jpg, gif, png, jpeg']) }}",
                filesize: "{{ trans('general.size_failed') }}"
            },
          }, 
          highlight: function (element, errorClass) {
            $(element).parents('.form-group').addClass('has-feedback has-error');
            $(element).parents('.form-group').removeClass('has-feedback has-success');
          },
          unhighlight: function (element, errorClass) {
            $(element).parents('.form-group').removeClass('has-feedback has-error');
            $(element).parents('.form-group').addClass('has-feedback has-success');
          },
          errorPlacement: function(error, element) {
            if(element.parents('.input-group').length > 0) {
              error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.chosen').length > 0){
              error.insertAfter(element.parents('.chosen').find('.chosen-container'));
            } else {
              error.insertAfter(element);
            }
          }
      });
      $("#formAgregarPdf").validate({
        ignore: ":hidden:not(.chosen-select)",
        submitHandler: function(form) {
          var loading = frameworkApp.setLoading();              
          $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              dataType: 'json',
              type:'POST',
              url: '{{ url("subir-archivo") }}',
              data: new FormData($("#formAgregarPdf")[0]),
              processData: false,
              contentType: false,
              id_container_body: false,
              success: function(data) {
                  console.log(0);
                  $("#filePdf").val(null);
                  loading.remove();
                  alert("{{trans('archivos.pdf_subir_exito')}}");
                  window.opener.nameFunction();
              },
          });
        },
        rules: {
          file: {
            accept: "application/pdf",
              filesize: 8388608,
              required: true
            }
          },
        messages: {
          file: {
            accept: "{{ trans('general.extension_failed', ['ext' => 'XLS, XLSX']) }}",
            filesize: "{{ trans('general.size_failed') }}"
          },
        }, 
        highlight: function (element, errorClass) {
          $(element).parents('.form-group').addClass('has-feedback has-error');
          $(element).parents('.form-group').removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parents('.form-group').removeClass('has-feedback has-error');
          $(element).parents('.form-group').addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
          if(element.parents('.input-group').length > 0) {
            error.insertAfter(element.parents('.input-group'));
          } else if(element.parents('.chosen').length > 0){
            error.insertAfter(element.parents('.chosen').find('.chosen-container'));
          } else {
              error.insertAfter(element);
          }
        }
      });
      $("#aspestRatio2Label").click();
        $('#getCroppedCanvasModal').on('show.bs.modal', function (e) {
          $("#btnDataCropper").click();
        });
      });

      function convasToBlob() {
        if($('#inputImage').val()!=''){

        
          var loading = frameworkApp.setLoading();
          $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              dataType: 'json',
              type:'POST',
              url: '{{ url("subir-imagen-crop") }}',
              data: new FormData($("#informacionDocente")[0]),
              processData: false,
              contentType: false,
              id_container_body: false,
              success: function(data) {
                  console.log(0);
                  loading.remove();
                  $('#getCroppedCanvasModal').modal('hide');
                  alert("{{trans('archivos.imagen_subir_editar_exito')}}");
                  window.opener.nameFunction()
              },
          });
        }else{
          alert("debe seleccionar una imagen para cargar");
        }
      }
      function nameFunction() {
          $("#refrescarItem").click();
      }
  </script>
@endsection
@section('style')
    <link  href="{{asset('plugins/cropperjs/dist/cropper.css')}}" rel="stylesheet">
    <link  href="{{asset('plugins/cropperjs/configuracion.css')}}" rel="stylesheet">
@endsection