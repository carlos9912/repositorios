
@php
    use App\Models\Estudiante;
    use Illuminate\Support\Arr;
@endphp
@extends('layouts.administrador')
@section('title', trans('general.title_crear_pagina'))
@section('titulo-pagina')
    <div id="page-title">
        <h1 class="page-header text-overflow">Administrador Estudiantes</h1>
    </div>    
@endsection
@section('breadcum')
    <ol class="breadcrumb">
        <li><a href="#"><i class="demo-pli-home"></i></a></li>
        <li class="active">Administrador Estudiantes</li>
    </ol>
@endsection
@section('style')
    <style>
        .modal-body{
            max-height: calc(100vh - 200px);
            overflow-y: auto;
        }
    </style>
@endsection
@section('content')
<div class="row">
    <div class="col-sm-12">
        <div class="ibox">
            <div class="ibox-content">
                <span class="text-muted small float-right">Último ingreso de nota: <i class="fa fa-clock-o"></i> 2:10 pm - 12.06.2014</span>
                <h2>Notas - {{$asignatura->nombreasignatura}} </h2>
                <div class="input-group">
                </div>
                <div class="clients-list">
                <span class="float-right small text-muted">1406 Elements</span>
                <ul class="nav nav-tabs">
                    @foreach($periodos as $periodo)
                        <li class="{{$periodo->estado==2 ? 'active' : ''}}"><a class="nav-link" data-toggle="tab" href="#tab-{{$periodo->codperiodo}}"><i class="fa fa-user"></i>{{$periodo->nombreperiodo}} </a></li>
                    @endforeach
                </ul>
                <div class="tab-content">
                    <div id="tab-1" class="tab-pane active">
                        <div class="full-height-scroll" style="overflow: hidden; width: auto; height: 100%;">
                            <hr>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <th class="">Nombre Estudiante</th>
                                        @foreach($listEvidencias[$asignatura->codasignatura] as $codEvidencia => $evidencias)
                                            <th class="text-center" >{{$codEvidencia}} </th>
                                        @endforeach
                                        <th class="text-center" >AJ</th>
                                        <th class="text-center" >AI</th>
                                        <th class="text-center" >OBS</th>
                                        <th class="text-center" >...</th>
                                    </thead>
                                    <tbody>
                                        @foreach($listEstudiantes as $estudiante)
                                            @php
                                                $nota = null;
                                                $listNotasEstudiante = Arr::exists($listNotas,$estudiante->codestudiante) ? $listNotas[$estudiante->codestudiante] : [];
                                            @endphp
                                            <tr>
                                                <td class="">{{$estudiante->nombres.' '.$estudiante->apellidos}} </td>
                                                @foreach($listEvidencias[$asignatura->codasignatura] as $codEvidencia => $evidencias)
                                                    @php
                                                        $nota = Arr::exists($listNotasEstudiante,$evidencias->codlogro.(1)) ? $listNotasEstudiante[$evidencias->codlogro.(1)] : null; 
                                                    @endphp
                                                        <td class="{{$evidencias->actitudinal=="1" ? 'warning' : 'info'}} " style="width: 1% !important;">
                                                            @if(!blank($nota))
                                                                <input type="text" class="form-control" id="nota{{$estudiante->codestudiante.$nota->nota}}" value="{{$nota->nota}}" style="width: 45px; border-radius: 5px;"> 
                                                            @endif
                                                        </td>
                                                @endforeach
                                                @if(!blank($nota))
                                                    <td class="text-center">
                                                    <input type="text" class="form-control" value="{{$nota->ausj}}" style="width: 45px; border-radius: 5px;"> 
                                                        </td>
                                                    <td class="text-center">
                                                        <input type="text" class="form-control" value="{{$nota->ausencia}}" style="width: 45px; border-radius: 5px;"> 
                                                    </td>
                                                    <td class="text-center">
                                                        <button class="btn btn-primary"><i class="fa fa-comment"></i></button>
                                                    </td>
                                                @else
                                                    <td>
                                                    </td>
                                                    <td>
                                                    </td>
                                                    <td>
                                                    </td>
                                                @endif
                                                <td class="text-center">
                                                    <button class="btn btn-primary"><i class="fa fa-edit"></i></button>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script>
    var rowSelection = $('table').DataTable({
        "responsive": true,
        "pageLength": 25,
        "language": {
            "paginate": {
                "previous": '<i class="demo-psi-arrow-left"></i>',
                "next": '<i class="demo-psi-arrow-right"></i>'
            }
        }
    });
    $('.btn-evidencias').click(function(){
        var codasignatura = $(this).data("codasignatura");
        $("#codasignaturaEvidencias").val(codasignatura);
        $("#tablaEvidencias").html('');
        frameworkApp.setLoadData({
            url: '{{ url("evidencias") }}',
            data: {
                codasignatura: codasignatura,
            },
            id_container_body: false,
            success: function(data) {
                console.log(data);
                $("#tablaEvidencias").html(data.html);
                $("#modalEditar").modal('show');
                //frameworkApp.setToastSuccess(data.mensaje);
            }
        });
    });
    $('.btn-editar').click(function(){
        var codasignatura = $(this).data("codasignatura");
        frameworkApp.setLoadData({
            url: '{{ url("asignatura/guardar-asignatura") }}',
            data: {
                codasignatura: codasignatura,
                nombreasignatura: $("#nombre"+codasignatura).val(),
                lema: $("#lema"+codasignatura).val(),
                ih: $("#ih"+codasignatura).val(),
                codigo: $("#codigo"+codasignatura).val(),
                coddocente: $("#coddocente"+codasignatura).val(),
                coddocenteaux: $("#coddocenteAux"+codasignatura).val()
            },
            id_container_body: false,
            success: function(data) {
                frameworkApp.setToastSuccess(data.mensaje);
            }
        });
    });
    function recargar(){
        location.reload();
    }
</script>
    
@endsection