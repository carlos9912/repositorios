

@php

use App\Models\Estudiante;

use Illuminate\Support\Arr;

use Carbon\Carbon;
@endphp

@extends('layouts.administrador')

@section('title', trans('general.title_crear_pagina'))

@section('titulo-pagina')

<div id="page-title">

    <h1 class="page-header text-overflow">Reportes</h1>

</div>    

@endsection

@section('breadcum')

<ol class="breadcrumb">

    <li><a href="#"><i class="demo-pli-home"></i></a></li>

    <li class="active">Administrador Reportes</li>

</ol>

@endsection

@section('content')

<div class="row">

    <div class="col-lg-12">
        <div class="panel panel-inverse">
            <!-- begin panel-heading -->
            <div class="panel-heading">
                <h4 class="panel-title">Reportes de giros</h4>
            </div>
            <!-- end panel-heading -->
            <!-- begin panel-body -->
            <div class="panel-body">
                {{Form::open(['route' => 'asignaturas.reportes-buscar', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarAsignatura']) }}
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label>Rango de fecha</label>
                                <div class="input-group" id="default-daterange">
                                    <input id="daterange" type="text" name="rango_fecha" class="form-control" value="{{request('rango_fecha')}}" placeholder="Especifique una fecha a buscar" autocomplete="false" />
                                    <span class="input-group-append">
                                    <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label>Estado</label>
                                <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" aria-hidden="true" id="estado" name="estado" data-placeholder="Seleccione un estado">
                                    <optgroup label="Estado">
                                        <option value=""></option>
                                        <option value="0">Todos</option>
                                        <option value="1">Pagado</option>
                                        <option value="2">Pendiente</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label>Sucursal</label>
                                <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" id="codsucursal" name="codsucursal" aria-hidden="true" data-placeholder="Seleccione un sucursal">
                                    <optgroup label="Sucursales">
                                    <option value=""></option>
                                    <!-- foreach(DB::table('sucursals AS e')->leftJoin('rel_sucursal_sucursal AS r','r.codsucursal','=','e.codsucursal')->where('r.codsucursal','<>',$sucursal->codsucursal)->get() as $estudiante) -->
                                    @foreach(DB::table('sucursales AS s')->get() as $sucursal)
                                        <option value="{{$sucursal->codsucursal}}" {{$sucursal->codsucursal==request('codsucursal') ? 'selected' : ''}}>{{$sucursal->nombres.' '.$sucursal->ubicacion}}</option>
                                    @endforeach
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group mt-4">
                                <button class="btn btn-primary" type="submit">Buscar</button>
                                <button class="btn btn-success abrir-modal" type="button">Busqueda avanzada</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- end panel-body -->
        </div>
        <!-- end panel -->

        <div class="panel panel-body">


            <div class="panel-body" id="tableReportes">

                <div class="row">

                    @if(\Auth::user()->email!=1)

                        <div class="col-sm-12">

                            <table class="table table-vcenter mar-top" id="tablaDatatable">
                                <thead>
                                    <tr>
                                        <th class="min-w-td">No. Factura</th>
                                        <th class="min-w-td text-left">Sucursal Envía</th>
                                        <th class="min-w-td text-left">Sucursal Retira</th>
                                        <th class="min-w-td text-center">Valor</th>
                                        <th class="text-center">Fecha</th>
                                        <th class="text-right">Tarifa</th>
                                        <th class="text-right">Costo</th>
                                        <th class="text-right">Iva</th>
                                        <th class="text-right">Gan. Envia</th>
                                        <th class="text-right nosort">Gan. Paga</th>
                                        <th class="text-right">Ganancia</th>
                                        <th class="text-right">Estado</th>
                                        <th style="width: 10%;"></th>
                                    </tr>
                                </thead>
                                <tbody style=" text-transform: uppercase;">
                                @php
                                    $valorGanancia = 0;
                                    $valorVentas = 0;
                                    $valorPorcentaje = 0;
                                    $codmovimiento = NULL;
                                @endphp
                                @foreach($listVentas as $ventas)
                                        @php 
                                            $valor_comision = $ventas->costo_envia;
                                            $valor_comision = blank($ventas->porcentaje_envia) ? $valor_comision : $valor_comision+$ventas->valor_real*$ventas->porcentaje_envia/100;
                                            $valor_comisionr = $ventas->costo_paga;
                                            $valor_comisionr = blank($ventas->porcentaje_envia) ? $valor_comisionr : $valor_comisionr+$ventas->valor_real*$ventas->porcentaje_envia/100;
                                            $valorPorcentaje+= $ventas->valor_real;
                                            $valor_iva = $ventas->iva_costo*1000/100;
                                            $ventas->iva_porcentaje = "1.".$ventas->iva_porcentaje;
                                            $costo = $ventas->costo==0 ? ($ventas->porcentaje*$ventas->valor_real/100) : ($ventas->costo) + ($ventas->porcentaje*$ventas->valor_real/100); 
                                            $valor_iva = blank($ventas->iva_porcentaje) ? $valor_iva : ($costo-$valor_comision-$valor_comisionr)-($costo-$valor_comision-$valor_comisionr)/$ventas->iva_porcentaje;
                                            $valorVentas+=$valor_iva;
                                            $ganancia = $costo-$valor_iva-$valor_comision-$valor_comisionr;
                                            $valorGanancia+=$ganancia;
                                        @endphp
                                        @if($codmovimiento!=$ventas->codmovimiento)
                                        <tr>
                                            <td class="min-w-td">FV-000{{$ventas->codmovimiento}}</td>
                                            <td class="text-left"> {{($ventas->nombreSucursal)}}<br><small>{{($ventas->ubicacion)}}</small>  </td>
                                            <td class="text-left"> {{($ventas->nombreSucursalRetira)}}<br><small>{{($ventas->ubicacionRetira)}}</small>  </td>
                                            <td class="text-right">$ {{number_format($ventas->valor_real)}} </td>
                                            <td class="text-right">{{Carbon::parse($ventas->fecha_movimiento)->format(trans('general.format_datetime'))}}</td>
                                            <td class="text-right">
                                                $ {{number_format($ventas->valor_inicial,0)}} - $ {{number_format($ventas->valor_final,0)}}
                                            </td>
                                            <td class="text-right">
                                                $ {{number_format($costo)}}
                                            </td>
                                            <td class="text-right">
                                                $ {{number_format($valor_iva)}}
                                            </td>
                                            <td class="text-right">
                                                $ {{number_format($valor_comision)}}
                                            </td>
                                            <td class="text-right">
                                                $ {{number_format($valor_comisionr)}}
                                            </td>
                                            <td class="text-right">
                                                $ {{number_format($ganancia,0)}}
                                            </td>
                                            <td>
                                                @if($ventas->estado==1)
                                                    <span class="label label-green">Pagado</span>
                                                @elseif($ventas->estado==2)
                                                    <span class="label label-warning">Pendiente</span>
                                                @elseif($ventas->estado==3)
                                                    <span class="label label-danger">Revertido</span>
                                                @endif
                                            </td>
                                            <td class="text-center" style="width: 10%;">
                                                @if($ventas->estado==2)
                                                <a class="btn btn-danger btn-sm btn-revertir fa fa-undo text-white" data-codgiro="{{$ventas->codmovimiento}}">
                                                    <i class="ti ti-printer"></i>
                                                </a>
                                                @endif
                                                <a data-fancybox data-type="iframe" class="btn btn-purple btn-sm fa fa-search" data-src="{{url('factura').'?m='.$ventas->codmovimiento}}"  href="javascript:;">
                                                    <i class="ti ti-printer"></i>
                                                </a>
                                                @if($ventas->estado==1)
                                                <a data-fancybox data-type="iframe" class="btn btn-dark btn-sm fa fa-search" data-src="{{url('factura-retira').'?m='.$ventas->codmovimiento}}"  href="javascript:;">
                                                    <i class="ti ti-printer"></i>
                                                </a>
                                                @endif
                                                @if(!blank($ventas->ocupacion)&&!blank($ventas->origen_ingresos))
                                                <a data-fancybox data-type="iframe" class="btn btn-dark btn-sm fa fa-file" data-src="{{url('reporte-ingresos').'?m='.$ventas->codmovimiento}}"  href="javascript:;">
                                                    <i class="ti ti-printer"></i>
                                                </a>
                                                @endif
                                            </td>
                                        </tr>
                                        @endif
                                        @php 
                                            $codmovimiento = $ventas->codmovimiento;
                                        @endphp
                                    @endforeach   
                                </tbody>
                            </table>
                        </div>

                    @endif

                </div>

            </div>

        </div>

    </div>

</div>

<div id="demo-lg-modal" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-lg" id="form-modal" style="max-width: 80%;">
        <div class="modal-content">
            <div class="modal-body">
                {{Form::open(['route' => 'asignaturas.reportes-buscar', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarAsignatura']) }}
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label>Código de giro</label>
                                {!! Form::text('valor', null, ['class' => 'nombre-menu form-control numeric' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'valor' ]) !!}
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label>Valor</label>
                                <div class="input-group">
                                    {!! Form::text('valor', null, ['class' => 'nombre-menu form-control numeric' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'valor' ]) !!}
                                    <div class="input-group-append">
                                        <select name="" id="" class="form-control">
                                            <option value="">Igual</option>
                                            <option value="">Mayor</option>
                                            <option value="">Menor</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label>Rango de fecha</label>
                                <div class="input-group" id="default-daterange">
                                    <input id="daterange" type="text" name="rango_fecha" class="form-control" value="{{request('rango_fecha')}}" placeholder="Especifique una fecha a buscar" autocomplete="false" />
                                    <span class="input-group-append">
                                    <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label>Estado</label>
                                <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" aria-hidden="true" id="estado" name="estado" data-placeholder="Seleccione un estado">
                                    <optgroup label="Estado">
                                        <option value=""></option>
                                        <option value="0">Todos</option>
                                        <option value="1">Pagado</option>
                                        <option value="2">Pendiente</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label>Sucursal</label>
                                <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" id="codsucursal" name="codsucursal" aria-hidden="true" data-placeholder="Seleccione un sucursal">
                                    <optgroup label="Sucursales">
                                    <option value=""></option>
                                    <!-- foreach(DB::table('sucursals AS e')->leftJoin('rel_sucursal_sucursal AS r','r.codsucursal','=','e.codsucursal')->where('r.codsucursal','<>',$sucursal->codsucursal)->get() as $estudiante) -->
                                    @foreach(DB::table('sucursales AS s')->get() as $sucursal)
                                        <option value="{{$sucursal->codsucursal}}" {{$sucursal->codsucursal==request('codsucursal') ? 'selected' : ''}}>{{$sucursal->nombres.' '.$sucursal->ubicacion}}</option>
                                    @endforeach
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group mt-4">
                                <button class="btn btn-primary" type="submit">Buscar</button>
                                <button class="btn btn-success abrir-modal" type="button">Busqueda avanzada</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')

<script>
    $('.abrir-modal').click(function(){
        $("#demo-lg-modal").modal("show");
    });

    $(function(){
        $('#navbarButton').click();
        $('.chosen-container').css('width','100%');
    });
    $(".default-select2").chosen();
    $('[data-fancybox]').fancybox({
        toolbar  : false,
        smallBtn : true,
        iframe : {
            preload : false
        }
    });
    $('#daterange').daterangepicker({

        locale: {
        format: 'DD/MM/YYYY'
        },

        todayBtn: "linked",

        language: 'es',

        autoclose: true,
        ranges: {
            'Hoy': [moment(), moment()],
            'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Ultimos 7 días': [moment().subtract(6, 'days'), moment()],
            'Ultimos 30 días': [moment().subtract(29, 'days'), moment()],
            'Este mes': [moment().startOf('month'), moment().endOf('month')],
            'El mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },

        todayHighlight: true

    });

    @if(blank(request('rango_fecha')))
        $('#daterange').val('');
    @endif


    $('.btn-revertir').click(function(){
        var btn = $(this);
        bootbox.confirm({
            message: "<br>Esta seguro de revertir el giro?<br>Quedará como destinatario la misma persona que realizó el envío",
            buttons: {
                confirm: {
                    label: 'Revertir',
                    className: 'btn-success'
                },
                cancel: {
                    label: 'No revertir',
                    className: 'btn-danger'
                }
            },
            callback: function (result) {
                if(result){
                    console.log(btn.data("codgiro"));
                    frameworkApp.setLoadData({
                        url: '{{ url("clientes/revertir-giro") }}',
                        data: {
                            codgiro: btn.data("codgiro"),
                        },
                        id_container_body: false,
                        success: function(data) {
                            bootbox.alert("<strong>Transacción exitosa</strong><br>");     
                        }
                    });
                }
            }
        });
        
    });

    $('#demo-dp-range .input-daterange').datepicker({

        format: "dd/mm/yyyy",

        todayBtn: "linked",

        language: 'es',

        autoclose: true,

        todayHighlight: true

    });


    var handleDataTableButtons=function(){"use strict";0!==$("table").length&&$("table").DataTable(
    {
        dom:"Bfrtip",
        buttons:[
            {extend:"copy",className:"btn-sm"},
            {extend:"excel",className:"btn-sm"},
            {extend:"pdf",className:"btn-sm"},
            {extend:"print",className:"btn-sm"}
            ],
            responsive:!0
        
    }
    )},
    TableManageButtons=function(){"use strict";return{init:function(){handleDataTableButtons()}}}();
    TableManageButtons.init();
    $('.btn-evidencias').click(function(){

        var codasignatura = $(this).data("codasignatura");

        $("#codasignaturaEvidencias").val(codasignatura);

        $("#tablaEvidencias").html('');

        frameworkApp.setLoadData({

            url: '{{ url("evidencias") }}',

            data: {

                codasignatura: codasignatura,

            },

            id_container_body: false,

            success: function(data) {

                console.log(data);

                $("#tablaEvidencias").html(data.html);

                $("#modalEditar").modal('show');

                //frameworkApp.setToastSuccess(data.mensaje);

            }

        });

    });

    $('.btn-editar').click(function(){

        var codasignatura = $(this).data("codasignatura");

        frameworkApp.setLoadData({

            url: '{{ url("asignatura/guardar-asignatura") }}',

            data: {

                codasignatura: codasignatura,

                nombreasignatura: $("#nombre"+codasignatura).val(),

                lema: $("#lema"+codasignatura).val(),

                ih: $("#ih"+codasignatura).val(),

                coddocente: $("#coddocente"+codasignatura).val(),

                coddocenteaux: $("#coddocenteAux"+codasignatura).val()

            },

            id_container_body: false,

            success: function(data) {

                frameworkApp.setToastSuccess(data.mensaje);

            }

        });

    });

    function recargar(){

        location.reload();

    }

</script>



@endsection