


@php
    use App\Enums\EDocumentoSucursal;
    use App\Models\Estudiante;
    use Illuminate\Support\Arr;
    use Carbon\Carbon;
    $pendientes = 0;
    $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->where('codsucursal','=',$sucursal->codsucursal)->select(DB::raw('SUM(valor_comision) as comision'))->first();
    $comisionAcumulada = $comisionAcumulada->comision;
    $ultimoMovimiento = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->where('codsucursal','=',$sucursal->codsucursal)->orderBy('codrel','desc')->select('codrel')->first();
    $sucursal->tipo_cuenta = $sucursal->tipo_cuenta_sucursal==1 ? 'Ahorros' : 'Corriente';
    $listTarifas = [];
    foreach(DB::table('tarifas_convenios AS t')->get() as $tarifa){
        $listTarifas[$tarifa->codtarifa] = $tarifa;
    }
@endphp
@php
    $valorGanancia = 0;
    $valorEnvio = 0;
    $valorRetiro = 0;
    $valorVentas = 0;
    $valorPorcentaje = 0;
    $valorConsignaciones = 0;
    $valorRecargas = 0;
    $valorServicios = 0;
    $valorOtros = 0;
    $valorComisiones = 0;
    $valorSoat = 0;
    $codsucursal = NULL;
    $rangoFechas = request('rango_fecha');
    if(blank($rangoFechas)){
        $inicio = date('Y-m-d').' 00:00:00';
        $fin = date('Y-m-d').' 23:59:59';
    }else{
        $rangoFechas = explode(' - ',$rangoFechas);
        $inicio = Carbon::parse(str_replace('/','-',$rangoFechas[0]))->format('Y-m-d').' 00:00:00';
        $fin = Carbon::parse(str_replace('/','-',$rangoFechas[1]))->format('Y-m-d').' 23:59:59';
    }
@endphp
@foreach(DB::table('rel_sucursal_movimiento AS r')->leftjoin('tarifas AS t', function ($join) {
    $join->on('t.codtarifa', '=', 'r.codtarifa')
        ->whereNotNull('r.codmovimiento');
})->join('sucursales AS s','s.codsucursal','=','r.codsucursal')->where('r.codsucursal','=',$sucursal->codsucursal)->whereBetween('r.fecha_movimiento',[
    $inicio,
    $fin
])->select('r.*','t.*','s.nombres AS nombreSucursal', 's.ubicacion', 'r.codtarifa', 'r.estado')->get() as $ventas)
        @if($ventas->tipo_movimiento==3)
            @php
            if(blank($ventas->codtarifa)){
                $costo = 0;
            }else{
                $costo = $listTarifas[$ventas->codtarifa]->costo==0 ? ($listTarifas[$ventas->codtarifa]->porcentaje*$ventas->valor_real/100) : ($listTarifas[$ventas->codtarifa]->costo) + ($listTarifas[$ventas->codtarifa]->porcentaje*$ventas->valor_real/100); 
                
            }
                $valorConsignaciones+=$ventas->valor_real+$costo;
            @endphp
        @elseif($ventas->tipo_movimiento==4)
            @php
                    $valorRecargas+= $ventas->estado==1 ? $ventas->valor_real : 0;
            @endphp
        @elseif($ventas->tipo_movimiento==5)
            @php
                    $valorServicios+= $ventas->estado==1 ? $ventas->valor_real : 0;
            @endphp
        @elseif($ventas->tipo_movimiento==6)
            @php
                    $valorOtros+= $ventas->estado==1 ? $ventas->valor_real : 0;
            @endphp
        @elseif($ventas->tipo_movimiento==7)
            @php
                    $valorSoat+= $ventas->estado==1 ? $ventas->valor_real : 0;
            @endphp
        @elseif($ventas->tipo_movimiento==30)
            @php
                    $valorComisiones+= $ventas->estado==1 ? $ventas->valor_real : 0;
            @endphp
        @else
            @php 
                $valor_comision = $ventas->costo_envia;
                $valor_comision = blank($ventas->porcentaje_envia) ? $valor_comision : $valor_comision+$ventas->valor_real*$ventas->porcentaje_envia/100;
                $valor_comisionr = $ventas->costo_paga;
                $valor_comisionr = blank($ventas->porcentaje_paga) ? $valor_comisionr : $valor_comisionr+$ventas->valor_real*$ventas->porcentaje_paga/100;
                
                $valor_iva = $ventas->iva_costo*1000/100;
                $ventas->iva_porcentaje = "1.".$ventas->iva_porcentaje;
                $costo = $ventas->costo==0 ? ($ventas->porcentaje*$ventas->valor_real/100) : ($ventas->costo) + ($ventas->porcentaje*$ventas->valor_real/100); 
                $valor_iva = blank($ventas->iva_porcentaje) ? $valor_iva : ($costo-$valor_comision-$valor_comisionr)-($costo-$valor_comision-$valor_comisionr)/$ventas->iva_porcentaje;
                $valorVentas+=$valor_iva;
                $ganancia = $costo-$valor_iva-$valor_comision-$valor_comisionr;
                
                $valorPorcentaje+=$ventas->valor_real;
                $comision = $valor_comision+$valor_comisionr;
                if(($ventas->tipo_movimiento==1)){
                    $valorGanancia+=$valor_comision;
                    $valorEnvio+=$ventas->valor_real;
                }else{
                    $valorGanancia+=$valor_comisionr;
                    $valorRetiro+=$ventas->valor_real;
                }
            @endphp
        @endif
        @php
            $codsucursal = $ventas->codsucursal;
        @endphp
    @endforeach  
@extends('layouts.administrador')
@section('title', trans('general.title_crear_pagina'))
@section('titulo-pagina')
<div id="page-title">
    <h1 class="page-header text-overflow">Reportes</h1>
</div>    
@endsection
@section('breadcum')
<ol class="breadcrumb">
    <li><a href="#"><i class="demo-pli-home"></i></a></li>
    <li class="active">Administrador Reportes</li>
</ol>
@endsection
@section('content')
<div class="row">
    <div class="col-lg-4">
        <div class="panel">
            <div class="panel-body">
                <a href="#" class="mb-0" data-id="widget">
                    <div class="widget-card-cover"></div>
                    <div class="widget-card-content">
                        <h5 class="f-s-12 text-black-transparent-7" data-id="widget-elm" data-light-class="f-s-12 text-black-transparent-7" data-dark-class="f-s-12 text-white-transparent-7"><b>Datos Sucursal</b></h5>
                        <h4 class="m-b-10"><b>{{$sucursal->nombres}}<small><br>{{$sucursal->ubicacion}}</small></b></h4>
                        <h4><b id="saldoSucursal">Saldo a consignar: $ {{number_format($sucursal->saldo)}}</b></h4>
                        <h6><b>Cupo: $ {{number_format($sucursal->cupo)}}</b></h6>
                        
                        @if(!blank($sucursal->deposito))
                            <h6 class="text-primary"><b>Deposito $ {{number_format($sucursal->deposito)}}</b></h6>
                        @endif
                        <h6><b>disponible $ {{number_format($sucursal->cupo-$sucursal->saldo)}}</b></h6>
                        <h6><b>utilizado {{number_format($sucursal->saldo*100/$sucursal->cupo)}}%</b></h6>
                        <h6><b>Fecha vinculación {{Carbon::parse($sucursal->fecha_creacion)->format(trans('general.format_date'))}}</b></h6>
                    
                    </div>
                    
                </a>
                
                @if($sucursal->saldo>0)
                @if(!blank(\Auth::user()->codempleado))
                <div class="row">
                    <div class="col-sm-12">
                        <a class="btn btn-success text-white pull-right"data-toggle="modal" data-target="#modalFormArchivo">Registrar Consignación</a>
                    </div>
                </div>
                @endif
                @endif
                @if(blank(\Auth::user()->codempleado))
                <div class="row">
                    <div class="col-sm-12">
                        <a class="btn btn-success text-white pull-right"data-toggle="modal" data-target="#modalFormArchivo">Registrar Prestamo</a>
                    </div>
                </div>
              
                @endif
                <hr>
                <a class="mb-0" data-id="widget">
                    <div class="widget-card-cover"></div>
                    <div class="widget-card-content bottom">
                        <h4>Comisiones acumuladas: ${{number_format($comisionAcumulada)}} </h4>
                    </div>
                </a>
                @if($comisionAcumulada>0&&blank(\Auth::user()->codempleado))
                <div class="col-lg-12">
                    <button class="btn btn-primary pagar-comision">Pagar comisiones a sucursal</button>
                </div>
                @endif
                <br>
                
            </div>
        </div>
      
        
        
        
    </div>
    <div class="col-lg-8">
        {!!Form::open(['route' => 'sucursal.estado-cuenta-buscar', 'id'=>'formBuscarEstado', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
            {{Form::hidden('codsucursal', $sucursal->codsucursal)}}
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>RANGO FECHA ESTADO</label>
                        <div class="input-group" id="default-daterange">
                            <input id="daterange" type="text" name="rango_fecha" class="form-control" value="{{request('rango_fecha')}}" placeholder="Especifique una fecha a buscar" autocomplete="false" />
                            <span class="input-group-append">
                            <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-1">
                    <label>...</label>
                    <button type="submit" class="btn btn-primary">Buscar</button>
                </div>
            </div>
        {{Form::close()}}
        
        <!-- begin nav-tabs -->
        <ul class="nav nav-tabs" style="background: #f3f1f1;">
            <li class="nav-item">
                <a href="#default-tab-1" data-toggle="tab" class="nav-link active">
                    <span class="d-sm-none">Resumen </span>
                    <span class="d-sm-block d-none font-weight-bold">Resumen</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#default-tab-2" data-toggle="tab" class="nav-link">
                    <span class="d-sm-none">Mov.</span>
                    <span class="d-sm-block d-none font-weight-bold">Movimientos</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#default-tab-3" data-toggle="tab" class="nav-link">
                    <span class="d-sm-none">Tab 3</span>
                    <span class="d-sm-block d-none font-weight-bold">Consignaciones</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#default-tab-4" data-toggle="tab" class="nav-link">
                    <span class="d-sm-none">Tab 3</span>
                    <span class="d-sm-block d-none font-weight-bold">Documentación</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#default-tab-5" data-toggle="tab" class="nav-link">
                    <span class="d-sm-none">Tab 3</span>
                    <span class="d-sm-block d-none font-weight-bold">...</span>
                </a>
            </li>
        </ul>
        <!-- end nav-tabs -->
        <!-- begin tab-content -->
        <div class="tab-content">
            <!-- begin tab-pane -->
            <div class="tab-pane fade active show" id="default-tab-1">
                <div class="row">
                <!-- begin col-6 -->
                    <div class="col-sm-6">
                        <!-- begin card -->
                        <div class="card border-0 bg-dark text-white text-truncate mb-3">
                            <!-- begin card-body -->
                            <div class="card-body">
                                <!-- begin title -->
                                <div class="mb-3 text-grey">
                                    <b class="mb-3">Giros
                                    
                                    </b> 
                                    <span class="ml-2"><i class="fa fa-info-circle" data-toggle="popover" data-trigger="hover" data-title="Conversion Rate" data-placement="top" data-content="Percentage of sessions that resulted in orders from total number of sessions." data-original-title="" title=""></i></span>
                                </div>
                                <!-- end title -->
                                <!-- begin conversion-rate -->
                                <div class="d-flex align-items-center mb-1">
                                    <h2 class="text-white mb-0">$ <span data-animation="number" data-value="2.19">{{number_format($valorPorcentaje)}}</span></h2>
                                    <div class="ml-auto">
                                        <div id="conversion-rate-sparkline"></div>
                                    </div>
                                </div>
                                <!-- end conversion-rate -->
                                <!-- begin percentage -->
                                <div class="mb-4 text-grey">
                                    <i class="fa fa-caret-down"></i>  Total movimientos
                                </div>
                                <!-- end percentage -->
                                <!-- begin info-row -->
                                <div class="d-flex mb-2">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-arrow-alt-circle-up text-warning"> </i>
                                        &nbsp;ENVIOS
                                    </div>
                                    <div class="d-flex align-items-center ml-auto">
                                        <div class="text-grey f-s-11"><i class="fa fa-dollar-sign"></i> <span data-animation="number" data-value="262">{{number_format($valorEnvio)}}</span></div>
                                    </div>
                                </div>
                                <!-- end info-row -->
                                <!-- begin info-row -->
                                <div class="d-flex mb-2">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-arrow-alt-circle-down text-success"> </i>
                                        &nbsp;RETIROS
                                    </div>
                                    <div class="d-flex align-items-center ml-auto">
                                        <div class="text-grey f-s-11"><i class="fa fa-dollar-sign"></i> <span data-animation="number" data-value="11">{{number_format($valorRetiro)}}</span></div>
                                    </div>
                                </div>
                                <!-- end info-row -->
                            </div>
                            <!-- end card-body -->
                        </div>
                        <!-- end card -->
                        
                    </div>
                    <!-- end col-6 -->
                    <div class="col-sm-6">
                        <div class="card border-0 bg-dark text-white overflow-hidden">
                            <!-- begin card-body -->
                            <div class="card-body">
                                <!-- begin row -->
                                <h5 class="text-white">DETALLE CIERRE CAJA</h5>
                                <div class="form-group row mb-0">
                                    <input type="hidden" class="form-control datepicker" id="fecha_nacimiento" name="fecha_nacimiento" id="start" autocomplete="off"/>
                                    <div class="col-md-3">
                                        {!! Form::select("dia", [], '', ["id"=>"fecha_dia_nac", "class" => "form-control no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "required" => "required"]) !!}
                                    </div>
                                    <div class="col-md-4">
                                        {!! Form::select("mes", [], '', ["id"=>"fecha_mes_nac", "class" => "form-control no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "required" => "required"]) !!}
                                    </div>
                                    <div class="col-md-3">
                                        {!! Form::select("anualidad", [], '', ["id"=>"fecha_anualidad_nac", "class" => "form-control no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "required" => "required"]) !!}
                                    </div>
                                    <div class="col-md-2">
                                        <a data-fancybox="" data-type="iframe" href="{{url('sucursal-consolidado')}}?m={{base64_encode($sucursal->codsucursal)}}" class="btn btn-primary btn-factura fa fa-print" title="Cierre de Caja Detallado"></a>
                                    </div>
                                </div>  
                                <!-- end row -->
                            </div>
                            <!-- end card-body -->
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="row">

                            <div class="col-sm-6">
                                <!-- begin card -->
                                <div class="card border-0 bg-dark text-white text-truncate mb-3">
                                    <!-- begin card-body -->
                                    <div class="card-body">
                                        <!-- begin title -->
                                        <div class="mb-3 text-grey">
                                            <b class="mb-3">Pagos
                                            
                                            </b> 
                                            <span class="ml-2"><i class="fa fa-info-circle" data-toggle="popover" data-trigger="hover" data-title="Conversion Rate" data-placement="top" data-content="Percentage of sessions that resulted in orders from total number of sessions." data-original-title="" title=""></i></span>
                                        </div>
                                        <!-- end title -->
                                        <!-- begin conversion-rate -->
                                        <div class="d-flex align-items-center mb-1">
                                            <h2 class="text-white mb-0">$ <span data-animation="number" data-value="2.19">{{number_format($valorServicios)}}</span></h2>
                                            <div class="ml-auto">
                                                <div id="conversion-rate-sparkline"></div>
                                            </div>
                                        </div>
                                        <!-- end conversion-rate -->
                                        <!-- begin percentage -->
                                        <div class="mb-4 text-grey">
                                            <i class="fa fa-caret-down"></i>  Total movimientos
                                        </div>
                                        <!-- end percentage -->
                                    </div>
                                    <!-- end card-body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <div class="col-sm-6">
                                <!-- begin card -->
                                <div class="card border-0 bg-dark text-white text-truncate mb-3">
                                    <!-- begin card-body -->
                                    <div class="card-body">
                                        <!-- begin title -->
                                        <div class="mb-3 text-grey">
                                            <b class="mb-3">Recargas
                                            
                                            </b> 
                                            <span class="ml-2"><i class="fa fa-info-circle" data-toggle="popover" data-trigger="hover" data-title="Conversion Rate" data-placement="top" data-content="Percentage of sessions that resulted in orders from total number of sessions." data-original-title="" title=""></i></span>
                                        </div>
                                        <!-- end title -->
                                        <!-- begin conversion-rate -->
                                        <div class="d-flex align-items-center mb-1">
                                            <h2 class="text-white mb-0">$ <span data-animation="number" data-value="2.19">{{number_format($valorRecargas)}}</span></h2>
                                            <div class="ml-auto">
                                                <div id="conversion-rate-sparkline"></div>
                                            </div>
                                        </div>
                                        <!-- end conversion-rate -->
                                        <!-- begin percentage -->
                                        <div class="mb-4 text-grey">
                                            <i class="fa fa-caret-down"></i>  Total movimientos
                                        </div>
                                        <!-- end percentage -->
                                    </div>
                                    <!-- end card-body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <div class="col-sm-6">
                                <!-- begin card -->
                                <div class="card border-0 bg-dark text-white text-truncate mb-3">
                                    <!-- begin card-body -->
                                    <div class="card-body">
                                        <!-- begin title -->
                                        <div class="mb-3 text-grey">
                                            <b class="mb-3">Consignaciones
                                            
                                            </b> 
                                            <span class="ml-2"><i class="fa fa-info-circle" data-toggle="popover" data-trigger="hover" data-title="Conversion Rate" data-placement="top" data-content="Percentage of sessions that resulted in orders from total number of sessions." data-original-title="" title=""></i></span>
                                        </div>
                                        <!-- end title -->
                                        <!-- begin conversion-rate -->
                                        <div class="d-flex align-items-center mb-1">
                                            <h2 class="text-white mb-0">$ <span data-animation="number" data-value="2.19">{{number_format($valorConsignaciones)}}</span></h2>
                                            <div class="ml-auto">
                                                <div id="conversion-rate-sparkline"></div>
                                            </div>
                                        </div>
                                        <!-- end conversion-rate -->
                                        <!-- begin percentage -->
                                        <div class="mb-4 text-grey">
                                            <i class="fa fa-caret-down"></i>  Total movimientos
                                        </div>
                                        <!-- end percentage -->
                                    </div>
                                    <!-- end card-body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <div class="col-sm-6">
                                <!-- begin card -->
                                <div class="card border-0 bg-dark text-white text-truncate mb-3">
                                    <!-- begin card-body -->
                                    <div class="card-body">
                                        <!-- begin title -->
                                        <div class="mb-3 text-grey">
                                            <b class="mb-3">Comisiones pagadas
                                            
                                            </b> 
                                            <span class="ml-2"><i class="fa fa-info-circle" data-toggle="popover" data-trigger="hover" data-title="Conversion Rate" data-placement="top" data-content="Percentage of sessions that resulted in orders from total number of sessions." data-original-title="" title=""></i></span>
                                        </div>
                                        <!-- end title -->
                                        <!-- begin conversion-rate -->
                                        <div class="d-flex align-items-center mb-1">
                                            <h2 class="text-white mb-0">$ <span data-animation="number" data-value="2.19">{{number_format($valorComisiones)}}</span></h2>
                                            <div class="ml-auto">
                                                <div id="conversion-rate-sparkline"></div>
                                            </div>
                                        </div>
                                        <!-- end conversion-rate -->
                                        <!-- begin percentage -->
                                        <div class="mb-4 text-grey">
                                            <i class="fa fa-caret-down"></i>  Total comisiones pagadas
                                        </div>
                                        <!-- end percentage -->
                                    </div>
                                    <!-- end card-body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <div class="col-sm-6">
                                <!-- begin card -->
                                <div class="card border-0 bg-dark text-white text-truncate mb-3">
                                    <!-- begin card-body -->
                                    <div class="card-body">
                                        <!-- begin title -->
                                        <div class="mb-3 text-grey">
                                            <b class="mb-3">SOAT
                                            
                                            </b> 
                                            <span class="ml-2"><i class="fa fa-info-circle" data-toggle="popover" data-trigger="hover" data-title="Conversion Rate" data-placement="top" data-content="Percentage of sessions that resulted in orders from total number of sessions." data-original-title="" title=""></i></span>
                                        </div>
                                        <!-- end title -->
                                        <!-- begin conversion-rate -->
                                        <div class="d-flex align-items-center mb-1">
                                            <h2 class="text-white mb-0">$ <span data-animation="number" data-value="2.19">{{number_format($valorSoat)}}</span></h2>
                                            <div class="ml-auto">
                                                <div id="conversion-rate-sparkline"></div>
                                            </div>
                                        </div>
                                        <!-- end conversion-rate -->
                                        <!-- begin percentage -->
                                        <div class="mb-4 text-grey">
                                            <i class="fa fa-caret-down"></i>  Total movimientos
                                        </div>
                                        <!-- end percentage -->
                                    </div>
                                    <!-- end card-body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <div class="col-sm-6">
                                <!-- begin card -->
                                <div class="card border-0 bg-dark text-white text-truncate mb-3">
                                    <!-- begin card-body -->
                                    <div class="card-body">
                                        <!-- begin title -->
                                        <div class="mb-3 text-grey">
                                            <b class="mb-3">Otros
                                            
                                            </b> 
                                            <span class="ml-2"><i class="fa fa-info-circle" data-toggle="popover" data-trigger="hover" data-title="Conversion Rate" data-placement="top" data-content="Percentage of sessions that resulted in orders from total number of sessions." data-original-title="" title=""></i></span>
                                        </div>
                                        <!-- end title -->
                                        <!-- begin conversion-rate -->
                                        <div class="d-flex align-items-center mb-1">
                                            <h2 class="text-white mb-0">$ <span data-animation="number" data-value="2.19">{{number_format($valorOtros)}}</span></h2>
                                            <div class="ml-auto">
                                                <div id="conversion-rate-sparkline"></div>
                                            </div>
                                        </div>
                                        <!-- end conversion-rate -->
                                        <!-- begin percentage -->
                                        <div class="mb-4 text-grey">
                                            <i class="fa fa-caret-down"></i>  Total movimientos
                                        </div>
                                        <!-- end percentage -->
                                    </div>
                                    <!-- end card-body -->
                                </div>
                                <!-- end card -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end tab-pane -->
            <!-- begin tab-pane -->
            <div class="tab-pane fade" id="default-tab-2">
                <div class="panel panel-body">
                    <div class="panel-body" id="tableReportes">
                        <div class="row">
                            @if(\Auth::user()->email!=1)
                                <div class="col-sm-12">
                                    <table class="table table-vcenter mar-top" id="tablaDatatable">
                                        <thead>
                                            <tr>
                                                <th class="min-w-td">No. FV</th>
                                                <th class="min-w-td text-left">Sucursal</th>
                                                <th class="min-w-td text-center">Valor</th>
                                                <th class="text-right {{(blank(\Auth::user()->codempleado)) ? '' : 'hide'}}">Iva</th>
                                                <th class="text-center">Fecha</th>
                                                <th class="text-right">Tarifa</th>
                                                <th class="text-right">Gan. Suc.</th>
                                                @if(blank(\Auth::user()->codempleado))
                                                    <th class="text-right">Gan. Gral</th>
                                                    <th class="text-right">Saldo Inicial</th>
                                                    <th class="text-right">Saldo Final</th>
                                                @endif
                                                <th style="width: 10%;"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @php
                                            $valorGanancia = 0;
                                            $valorEnvio = 0;
                                            $valorRetiro = 0;
                                            $valorVentas = 0;
                                            $valorPorcentaje = 0;
                                            $valorConsignaciones = 0;
                                            $codsucursal = NULL;
                                        @endphp
                                        @foreach(DB::table('rel_sucursal_movimiento AS r')->leftjoin('tarifas AS t', function ($join) {
                                        $join->on('t.codtarifa', '=', 'r.codtarifa')
                                            ->whereNotNull('r.codmovimiento');
                                        })->join('sucursales AS s','s.codsucursal','=','r.codsucursal')->where('r.codsucursal','=',$sucursal->codsucursal)->whereBetween('r.fecha_movimiento',[
                                            $inicio,
                                            $fin
                                        ])->select('r.*','t.*','s.nombres AS nombreSucursal', 's.ubicacion', 'r.codtarifa', 'r.estado')->orderBy('r.codrel', 'desc')->get() as $ventas)
                                                @if($ventas->tipo_movimiento==3)
                                                @php
                                                if(blank($ventas->codtarifa)){
                                                    $costo = 0;
                                                }else{
                                                    $costo = $listTarifas[$ventas->codtarifa]->costo==0 ? ($listTarifas[$ventas->codtarifa]->porcentaje*$ventas->valor_real/100) : ($listTarifas[$ventas->codtarifa]->costo) + ($listTarifas[$ventas->codtarifa]->porcentaje*$ventas->valor_real/100); 
                                                    
                                                }
                                                    $valorConsignaciones+=$ventas->valor_real+$costo+$ventas->valor_comision;
                                                @endphp
                                                <tr>
                                                    <td class="min-w-td">FV-{{str_pad($ventas->codconsignacion, 4, "0", STR_PAD_LEFT)}}</td>
                                                    <td class="text-left">
                                                    <i class="fas fa-arrow-alt-circle-right text-primary"> </i> Consign.
                                                    </td>
                                                    <td class="text-right">$ {{number_format($ventas->valor_real)}} </td>
                                                    <td class="text-right {{(blank(\Auth::user()->codempleado)) ? '' : 'hide'}}">
                                                        -
                                                    </td>
                                                    <td class="text-right">{{Carbon::parse($ventas->fecha_movimiento)->format(trans('general.format_datetime'))}}</td>
                                                    <td class="text-right">
                                                        Estado: {!!$ventas->estado==1 ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-times-circle text-danger"></i>'!!}
                                                    </td>
                                                    <td class="text-right">
                                                        $ {{number_format($ventas->valor_comision)}}
                                                    </td>
                                                    @if(blank(\Auth::user()->codempleado))
                                                        <td class="text-right">
                                                            $ {{number_format($costo-$ventas->valor_comision,0)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_inicial)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_final)}}
                                                        </td>
                                                    @endif
                                                    <td class="text-center" style="width: 10%;">
                                                        <a data-fancybox data-type="iframe" class="btn btn-warning btn-sm fa fa-search" data-src="{{url('factura-consignacion').'?codconsignacion='.$ventas->codconsignacion}}"  href="javascript:;">
                                                            <i class="ti ti-printer"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                @elseif($ventas->tipo_movimiento==4)
                                                <tr>
                                                    <td class="min-w-td">FV-{{str_pad($ventas->codrecarga, 4, "0", STR_PAD_LEFT)}}</td>
                                                    <td class="text-left">
                                                    <i class="fas fa-arrow-alt-circle-left text-inverse"> </i> RECARGA.
                                                    </td>
                                                    <td class="text-right">$ {{number_format($ventas->valor_real)}} </td>
                                                    <td class="text-right {{(blank(\Auth::user()->codempleado)) ? '' : 'hide'}}">
                                                        -
                                                    </td>
                                                    <td class="text-right">{{Carbon::parse($ventas->fecha_movimiento)->format(trans('general.format_datetime'))}}</td>
                                                    <td class="text-right">
                                                        Estado: {!!$ventas->estado==1 ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-times-circle text-danger"></i>'!!}
                                                    </td>
                                                    <td class="text-right">
                                                        $ {{number_format($ventas->valor_comision)}}
                                                    </td>
                                                    @if(blank(\Auth::user()->codempleado))
                                                        <td class="text-right">
                                                            $ {{number_format($ventas->valor_comision,0)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_inicial)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_final)}}
                                                        </td>
                                                    @endif
                                                    <td class="text-center" style="width: 10%;">
                                                        <a data-fancybox data-type="iframe" class="btn btn-green btn-sm fa fa-search" data-src="{{url('factura-recarga').'?codrecarga='.$ventas->codrecarga}}"  href="javascript:;">
                                                            <i class="ti ti-printer"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                @elseif($ventas->tipo_movimiento==5)
                                                <tr>
                                                    <td class="min-w-td">FV-{{str_pad($ventas->codpago, 4, "0", STR_PAD_LEFT)}}</td>
                                                    <td class="text-left">
                                                    <i class="fas fa-arrow-alt-circle-left text-inverse"> </i> PAGO.
                                                    </td>
                                                    <td class="text-right">$ {{number_format($ventas->valor_real)}} </td>
                                                    <td class="text-right {{(blank(\Auth::user()->codempleado)) ? '' : 'hide'}}">
                                                        -
                                                    </td>
                                                    <td class="text-right">{{Carbon::parse($ventas->fecha_movimiento)->format(trans('general.format_datetime'))}}</td>
                                                    <td class="text-right">
                                                        Estado: {!!$ventas->estado==1 ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-times-circle text-danger"></i>'!!}
                                                    </td>
                                                    <td class="text-right">
                                                        $ {{number_format($ventas->valor_comision)}}
                                                    </td>
                                                    @if(blank(\Auth::user()->codempleado))
                                                        <td class="text-right">
                                                            $ {{number_format($ventas->valor_comision,0)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_inicial)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_final)}}
                                                        </td>
                                                    @endif
                                                    <td class="text-center" style="width: 10%;">
                                                        <a data-fancybox data-type="iframe" class="btn btn-green btn-sm fa fa-search" data-src="{{url('factura-pago').'?codpago='.$ventas->codpago}}"  href="javascript:;">
                                                            <i class="ti ti-printer"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                @elseif($ventas->tipo_movimiento==7)
                                                <tr>
                                                    <td class="min-w-td">ST-{{str_pad($ventas->codsoat, 4, "0", STR_PAD_LEFT)}}</td>
                                                    <td class="text-left">
                                                    <i class="fas fa-arrow-alt-circle-left text-inverse"> </i> SOAT.
                                                    </td>
                                                    <td class="text-right">$ {{number_format($ventas->valor_real)}} </td>
                                                    <td class="text-right {{(blank(\Auth::user()->codempleado)) ? '' : 'hide'}}">
                                                        -
                                                    </td>
                                                    <td class="text-right">{{Carbon::parse($ventas->fecha_movimiento)->format(trans('general.format_datetime'))}}</td>
                                                    <td class="text-right">
                                                        Estado: {!!$ventas->estado==1 ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-times-circle text-danger"></i>'!!}
                                                    </td>
                                                    <td class="text-right">
                                                        $ {{number_format($ventas->valor_comision)}}
                                                    </td>
                                                    @if(blank(\Auth::user()->codempleado))
                                                        <td class="text-right">
                                                            $ {{number_format($ventas->valor_comision,0)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_inicial)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_final)}}
                                                        </td>
                                                    @endif
                                                    <td class="text-center" style="width: 10%;">
                                                        <a data-fancybox data-type="iframe" class="btn btn-green btn-sm fa fa-search" data-src="{{url('factura-soat').'?codsoat='.$ventas->codsoat}}"  href="javascript:;">
                                                            <i class="ti ti-printer"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                @elseif($ventas->tipo_movimiento==30)
                                                <tr>
                                                    <td class="min-w-td"></td>
                                                    <td class="text-left">
                                                    <i class="fas fa-arrow-alt-circle-left text-inverse"> </i> COMPENSACIÓN.<br>
                                                    <small>Saldo inicial: $ {{number_format($ventas->saldo_inicial)}}</small><br>
                                                    <small>Saldo final: $ {{number_format($ventas->saldo_final)}}</small>
                                                    </td>
                                                    <td class="text-right">$ {{number_format($ventas->valor_real)}} </td>
                                                    <td class="text-right {{(blank(\Auth::user()->codempleado)) ? '' : 'hide'}}">
                                                        -
                                                    </td>
                                                    <td class="text-right">{{Carbon::parse($ventas->fecha_movimiento)->format(trans('general.format_datetime'))}}</td>
                                                    <td class="text-right">
                                                        Estado: {!!$ventas->estado==1 ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-times-circle text-danger"></i>'!!}
                                                    </td>
                                                    <td class="text-right">
                                                        -
                                                    </td>
                                                    @if(blank(\Auth::user()->codempleado))
                                                        <td class="text-right">
                                                            -
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_inicial)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_final)}}
                                                        </td>
                                                    @endif
                                                    <td class="text-center" style="width: 10%;">
                                                        -
                                                    </td>
                                                </tr>
                                                @elseif($ventas->tipo_movimiento==6)
                                                <tr>
                                                    <td class="min-w-td">FV-{{str_pad($ventas->codpago, 4, "0", STR_PAD_LEFT)}}</td>
                                                    <td class="text-left">
                                                    <i class="fas fa-arrow-alt-circle-left text-inverse"> </i> OTRO.
                                                    </td>
                                                    <td class="text-right">$ {{number_format($ventas->valor_real)}} </td>
                                                    <td class="text-right {{(blank(\Auth::user()->codempleado)) ? '' : 'hide'}}">
                                                        -
                                                    </td>
                                                    <td class="text-right">{{Carbon::parse($ventas->fecha_movimiento)->format(trans('general.format_datetime'))}}</td>
                                                    <td class="text-right">
                                                        Estado: {!!$ventas->estado==1 ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-times-circle text-danger"></i>'!!}
                                                    </td>
                                                    <td class="text-right">
                                                        $ {{number_format($ventas->valor_comision)}}
                                                    </td>
                                                    @if(blank(\Auth::user()->codempleado))
                                                        <td class="text-right">
                                                            $ {{number_format($ventas->valor_comision,0)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_inicial)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_final)}}
                                                        </td>
                                                    @endif
                                                    <td class="text-center" style="width: 10%;">
                                                        <a data-fancybox data-type="iframe" class="btn btn-green btn-sm fa fa-search" data-src="https://giros-bam.com/factura?codpago={{base64_encode($ventas->codpago)}}"  href="javascript:;">
                                                            <i class="ti ti-printer"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                @else
                                                <tr>
                                                    <td class="min-w-td">FV-{{str_pad($ventas->codmovimiento, 4, "0", STR_PAD_LEFT)}}</td>
                                                    <td class="text-left">
                                                        @if($ventas->tipo_movimiento==1)
                                                            <i class="fas fa-arrow-alt-circle-up text-warning"> </i> Envío
                                                        @else
                                                            <i class="fas fa-arrow-alt-circle-down text-success"> </i> Retiro
                                                        @endif
                                                    </td>
                                                    <td class="text-right">$ {{number_format($ventas->valor_real)}} </td>
                                                    <td class="text-right {{(blank(\Auth::user()->codempleado)) ? '' : 'hide'}}">
                                                    @php 
                                                        $valor_comision = $ventas->costo_envia;
                                                        $valor_comision = blank($ventas->porcentaje_envia) ? $valor_comision : $valor_comision+$ventas->valor_real*$ventas->porcentaje_envia/100;
                                                        $valor_comisionr = $ventas->costo_paga;
                                                        $valor_comisionr = blank($ventas->porcentaje_paga) ? $valor_comisionr : $valor_comisionr+$ventas->valor_real*$ventas->porcentaje_paga/100;
                                                        
                                                        $valor_iva = $ventas->iva_costo*1000/100;
                                                        $ventas->iva_porcentaje = "1.".$ventas->iva_porcentaje;
                                                        $costo = $ventas->costo==0 ? ($ventas->porcentaje*$ventas->valor_real/100) : ($ventas->costo) + ($ventas->porcentaje*$ventas->valor_real/100); 
                                                        $valor_iva = blank($ventas->iva_porcentaje) ? $valor_iva : ($costo-$valor_comision-$valor_comisionr)-($costo-$valor_comision-$valor_comisionr)/$ventas->iva_porcentaje;
                                                        $valorVentas+=$valor_iva;
                                                        $ganancia = $costo-$valor_iva-$valor_comision-$valor_comisionr;
                                                        
                                                        $valorPorcentaje+=$ventas->valor_real;
                                                        $comision = $valor_comision+$valor_comisionr;
                                                        if(($ventas->tipo_movimiento==1)){
                                                            $valorGanancia+=$valor_comision;
                                                            $valorEnvio+=$ventas->valor_real;
                                                        }else{
                                                            $valorGanancia+=$valor_comisionr;
                                                            $valorRetiro+=$ventas->valor_real;
                                                        }
                                                    @endphp
                                                    $ {{number_format($valor_iva)}}
                                                    </td>
                                                    <td class="text-right">{{Carbon::parse($ventas->fecha_movimiento)->format(trans('general.format_datetime'))}}</td>
                                                    <td class="text-right">
                                                        $ {{number_format($ventas->valor_inicial,0)}} - $ {{number_format($ventas->valor_final,0)}}
                                                    </td>
                                                    <td class="text-right">
                                                        $ {{($ventas->tipo_movimiento==1) ? number_format($valor_comision,0) : number_format($valor_comisionr,0)}}
                                                    </td>
                                                    @if(blank(\Auth::user()->codempleado))
                                                        <td class="text-right">
                                                            $ {{number_format($ganancia,0)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_inicial)}}
                                                        </td>
                                                        <td class="text-right">
                                                             {{($ventas->saldo_final)}}
                                                        </td>
                                                    @endif
                                                    <td class="text-center" style="width: 10%;">
                                                        @if($ventas->tipo_movimiento==1)
                                                        <a data-fancybox data-type="iframe" class="btn btn-purple btn-sm fa fa-search" data-src="{{url('factura').'?m='.$ventas->codmovimiento}}"  href="javascript:;">
                                                            <i class="ti ti-printer"></i>
                                                        </a>
                                                        @else
                                                        <a data-fancybox data-type="iframe" class="btn btn-dark btn-sm fa fa-search" data-src="{{url('factura-retira').'?m='.$ventas->codmovimiento}}"  href="javascript:;">
                                                            <i class="ti ti-printer"></i>
                                                        </a>
                                                        @endif
                                                    </td>
                                                </tr>
                                                @endif
                                                @php
                                                    $codsucursal = $ventas->codsucursal;
                                                @endphp
                                            @endforeach   
                                        </tbody>
                                    </table>
                                    <hr>
                                </div>
                                    @if(1==2)
                                    <div class="col-lg-4">
                                        <div class="widget widget-stats bg-red">
                                            <div class="stats-icon"><i class="fas fa-arrow-right"></i></div>
                                            <div class="stats-info">
                                                <h4>Enviado</h4>
                                                <p id="valor-iva">$ {{number_format($valorEnvio)}} </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="widget widget-stats bg-green">
                                            <div class="stats-icon"><i class="fas fa-arrow-down"></i></div>
                                            <div class="stats-info">
                                                <h4>Retiros</h4>
                                                <p id="valor-iva">$ {{number_format($valorRetiro)}} </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="widget widget-stats bg-warning">
                                            <div class="stats-icon"><i class="fas fa-exchange-alt"></i></div>
                                            <div class="stats-info">
                                                <h4>Valor movimientos</h4>
                                                <p id="valor-iva">$ {{number_format($valorPorcentaje)}} </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="widget widget-stats bg-primary">
                                            <div class="stats-icon"><i class="	fas fa-money-check-alt"></i></div>
                                            <div class="stats-info">
                                                <h4>Valor consignaciones</h4>
                                                <p id="valor-iva">$ {{number_format($valorConsignaciones)}} </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="widget widget-stats bg-primary">
                                            <div class="stats-icon"><i class="	fas fa-money-check-alt"></i></div>
                                            <div class="stats-info">
                                                <h4>Valor ganancia sucursal</h4>
                                                <p id="valor-iva">$ {{number_format($valorGanancia)}} </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="widget widget-stats bg-primary">
                                            <div class="stats-icon"><i class="	fas fas fa-poll"></i></div>
                                            <div class="stats-info">
                                                <h4>Código del punto</h4>
                                                <p id="valor-iva">{{$sucursal->codsucursal}} </p>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <!-- end tab-pane -->
            <!-- begin tab-pane -->
            <div class="tab-pane fade" id="default-tab-3">
                <div class="panel panel-body">
                    <h5>Consignaciones</h5>
                    <hr>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr class="">
                                            <td class="">No.</td>
                                            <td class="">Detalle</td>
                                            <td class="">Valor</td>
                                            <td class="text-center">Soporte</td>
                                            <td class="text-center">Estado</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($sucursal->consignaciones as $movimiento)
                                            <tr>
                                                <td class="">CO-{{$movimiento->codmovimiento}}</td>
                                                <td class="">
                                                {{$movimiento->banco}}<br>
                                                    {{Carbon::parse($movimiento->fecha_registro)->format(trans('general.format_datetime'))}}
                                                </td>
                                                <td class="text-right">${{number_format($movimiento->valor)}}</td>
                                                <td class="text-center">
                                                    <a data-fancybox href="{{asset('soportes/'.$movimiento->soporte)}}" class="btn btn-xs btn-purple"><i class="fa fa-link"></i></a>
                                                </td>
                                                <td class="text-center">
                                                    @if($movimiento->estado==3)
                                                        <span class="label label-danger">RECHAZADO</span>
                                                    @elseif($movimiento->estado==2)
                                                        @php $pendientes++; @endphp
                                                        <span class="label label-warning">PENDIENTE</span>
                                                    @else
                                                        <span class="label label-success">APROBADO</span>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end tab-pane -->
            <!-- begin tab-pane -->
            <div class="tab-pane fade" id="default-tab-4">
                <legend>Documentos</legend>
                <div class="row mt-3 p-20">
                    @foreach(EDocumentoSucursal::data() as $documento)
                        @if(Arr::exists($documentos, $documento->getId()))
                        <div class="col-sm-3 text-center mb-3" style="border: 1px solid #e2e7eb; border-radius: 10px;">
                            <label for=""><small><strong>{{$documento->getDescription()}}</strong></small> </label>
                            <br>
                            <a class="btn btn-circle mb-3 btn-primary" data-fancybox="" href="{{asset('/documentacion/'.$documentos[$documento->getId()]->ruta)}}">
                                <i class="fa fa-search text-white"></i>
                            </a>
                        </div>
                        @else
                        <div class="col-sm-2 text-center mb-3" style="border: 1px solid #e2e7eb; border-radius: 10px;">
                            <label for=""><small><strong>{{$documento->getDescription()}}</strong></small> </label>
                            <br>
                            <button class="btn btn-file btn-circle mb-3 btn-danger">
                                <i class="fa fa-times-circle"></i>
                            </button>
                        </div>
                        @endif
                        
                    @endforeach
                </div>
            </div>
            <!-- end tab-pane -->
            <!-- begin tab-pane -->
            <div class="tab-pane fade" id="default-tab-5">
                <div class="panel panel-body">
                    <canvas id="myChart"></canvas>
                </div>
            </div>
            <!-- end tab-pane -->
        </div>
        <!-- end tab-content -->

    </div>
    <div class="col-sm-12">
    

    </div>


</div>



<div class="modal fade" id="modalFormArchivo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                @if(blank(\Auth::user()->codempleado))
                <h3 class="panel-title">REGISTRAR PRESTAMO</h3>
                @else
                <h3 class="panel-title">REGISTRAR CONSIGNACIÓN</h3>
                @endif
                
            </div>
            <div class="modal-body">
                <div class="panel panel-mint">
                    <div class="panel-body">
                        {!!Form::open(['route' => 'sucursal.registrar_consignacion', 'id'=>'formRegistrarConsignacion', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
                            {{Form::hidden('codsucursal', $sucursal->codsucursal)}}
                            {{Form::hidden('prestamo', blank(\Auth::user()->codempleado) ? 1 : 0)}}
                            <div class="form-group">
                                <label class="control-label">Valor</label>
                                <input class="nombre-menu form-control" autocomplete="off" id="valorConsignacion" name="valor" type="number">
                            </div>
                            <div class="form-group">
                                <label class="control-label">Banco</label>
                                <select class="form-control" name="banco" id="banco_combo">
                                    <option value="">Seleccione banco</option>
                                    <option value="Compensación manual">Compensación manual</option>
                                    <option value="Bancolombia">Bancolombia</option>
                                    <option value="Banco de bogota">Banco de Bogota</option>
                                    <option value="Davivienda">Davivienda</option>
                                    <option value="Banco Agrario">Banco Agrario</option>
                                    <option value="Banco Caja Social">Banco Caja Social</option>
                                    <option value="0">Deposito</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Soporte</label>
                                <input class="nombre-menu form-control" autocomplete="off" id="soporte" name="soporte" type="text" placeholder="Ingrese el número de la transacción que aparece en el tiquet">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary">REGISTRAR</button>
                            </div>
                        {{Form::close()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{!!Form::open(['route' => 'sucursal.comisiones', 'id'=>'pagarComision', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
    {{Form::hidden('codsucursal', $sucursal->codsucursal)}}
    {{Form::hidden('codrel', blank($ultimoMovimiento) ? 0 : $ultimoMovimiento->codrel)}}
    {{Form::hidden('valor', $comisionAcumulada)}}
    
{{Form::close()}}
@endsection

@section('script')

<script>

    $(function(){
        
    $('#daterange').daterangepicker({
        locale: {
        format: 'DD/MM/YYYY'
        },

        todayBtn: "linked",

        language: 'es',

        autoclose: true,
        ranges: {
            'Hoy': [moment(), moment()],
            'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Ultimos 7 días': [moment().subtract(6, 'days'), moment()],
            'Ultimos 30 días': [moment().subtract(29, 'days'), moment()],
            'Este mes': [moment().startOf('month'), moment().endOf('month')],
            'El mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },

        todayHighlight: true
    });
        $('table').css("width","100%");
    })
    $('.btn-factura').click(function(){
        $(this).attr("href", '{{url('sucursal-consolidado')}}?m={{base64_encode($sucursal->codsucursal)}}&fecha='+(Number($('#fecha_anualidad_nac').val())) + '/' +
            $('#fecha_mes_nac').val() + '/' + (Number($('#fecha_dia_nac').val())))
    });
    var ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio'],
            datasets: [{
                label: 'No. Giros Enviados',
                data: [12, 19, 3, 5, 2, 3],
                backgroundColor: [
                    'rgba(0, 99, 132, 0.2)',
                    'rgba(0, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(0, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            },{
                label: 'No. Giros Pagados',
                data: [2, 1, 13, 15, 12, 13],
                backgroundColor: [
                    'rgba(0, 0, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(0, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }],
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
    //$('.dataTables_filter').hide();
    $('[data-fancybox]').fancybox({
        toolbar  : false,
        smallBtn : true,
        iframe : {
            preload : false
        }
    });

    $('.pagar-comision').click(function(){
        bootbox.confirm({
            message: "<h4>Esta seguro de pagar la comisión a la sucursal por valor de ${{number_format($comisionAcumulada)}}?</h4><br><br>Datos del representante:<br>Nombre: {{$sucursal->nombres_representante.' '.$sucursal->apellidos_representante}}<br>Cedula: {{$sucursal->cedula_representante}}<br>Cuenta: {{$sucursal->banco_sucursal.'-('.$sucursal->tipo_cuenta.') No. '.$sucursal->cuenta_sucursal}}",
            buttons: {
                confirm: {
                    label: 'Realizar pago!',
                    className: 'btn-success'
                },
                cancel: {
                    label: 'Cancelar',
                    className: 'btn-danger'
                }
            },
            callback: function (result) {
                if(result){
                    bootbox.alert('Comisiones pagadas con éxito');
                    setTimeout(function(){ $("#pagarComision").submit(); }, 1000);
                    
                }
            }
        });
    });
    $('#demo-dp-range .input-daterange').datepicker({
        format: "dd/mm/yyyy",
        todayBtn: "linked",
        language: 'es',
        autoclose: true,
        todayHighlight: true
    });
    var handleDataTableButtons=function(){"use strict";0!==$("table").length&&$("table").DataTable(
    {
        dom:"Bfrtip",
        "aaSorting": [],
        buttons:[
            {extend:"copy",className:"btn-sm"},
            {extend:"excel",className:"btn-sm"},
            {extend:"pdf",className:"btn-sm"},
            {extend:"print",className:"btn-sm"}
            ],
            responsive:!0
    }
    )},
    TableManageButtons=function(){"use strict";return{init:function(){handleDataTableButtons()}}}();
    TableManageButtons.init();

    $('.btn-evidencias').click(function(){
        var codasignatura = $(this).data("codasignatura");
        $("#codasignaturaEvidencias").val(codasignatura);
        $("#tablaEvidencias").html('');
        frameworkApp.setLoadData({
            url: '{{ url("evidencias") }}',
            data: {
                codasignatura: codasignatura,
            },
            id_container_body: false,
            success: function(data) {
                console.log(data);
                $("#tablaEvidencias").html(data.html);
                $("#modalEditar").modal('show');
                //frameworkApp.setToastSuccess(data.mensaje);
            }
        });
    });
    $('.btn-editar').click(function(){
        var codasignatura = $(this).data("codasignatura");
        frameworkApp.setLoadData({
        url: '{{ url("asignatura/guardar-asignatura") }}',
            data: {
                codasignatura: codasignatura,
                nombreasignatura: $("#nombre"+codasignatura).val(),
                lema: $("#lema"+codasignatura).val(),
                ih: $("#ih"+codasignatura).val(),
                coddocente: $("#coddocente"+codasignatura).val(),
                coddocenteaux: $("#coddocenteAux"+codasignatura).val()
            },
            id_container_body: false,
            success: function(data) {
                frameworkApp.setToastSuccess(data.mensaje);
            }
        });
    
    });
    $("#formRegistrarConsignacion").validate({
    ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            if({{$pendientes}}>0){
                        frameworkApp.setAlert("<h4 class='text-center'>¡NO ES POSIBLE REGISTRAR LA CONSIGNACIÓN!</h4><br><br><small>Usted presenta consignaciones pendientes de aprobación, una vez sean registradas podrá registrar una nueva consignación");
            }else{
                var messageConfirm = "¿Esta seguro de registrar la consignación por valor de <b>"+Number($("#valorConsignacion").val()).format()+"</b>?";
                frameworkApp.setConfirm({
                    message: messageConfirm,
                    accept: function () {
                        form.submit();
                    },
                    cancelar : function() {
                        return false;
                    }
                });
                return false;
            }
        },
        rules: {
            valor: {
                required: true,
                digits: true,
                @if(!blank(\Auth::user()->codempleado))
                    max:    function() {
                                return $("#banco_combo").val()==0 ? 9999999999999 : parseInt({{blank($sucursal->saldo) ? 0 : $sucursal->saldo}});
                            },
                @endif
                min: 1,
            },
            banco: 'required',
            soporte: 'required'
        },
        highlight: function (element, errorClass) {
            $(element).parents('.input-group').addClass('has-feedback has-error');
            $(element).parents('.input-group').removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
            $(element).parents('.input-group').removeClass('has-feedback has-error');
            $(element).parents('.input-group').addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    $.dobPicker({
        daySelector: '#fecha_dia_nac', /* Required */
        monthSelector: '#fecha_mes_nac', /* Required */
        yearSelector: '#fecha_anualidad_nac', /* Required */
        dayDefault: 'Día', /* Optional */
        monthDefault: 'Mes', /* Optional */
        yearDefault: 'Año', /* Optional */
        minimumAge: 0, /* Optional */
        maximumAge: 100 /* Optional */
    });

    $("#fecha_dia_nac").val('{{str_pad(date('d'), 2, "0", STR_PAD_LEFT)}}');
    $("#fecha_mes_nac").val('{{str_pad(date('m'), 2, "0", STR_PAD_LEFT)}}');
    $("#fecha_anualidad_nac").val('{{date('Y')}}');

    function recargar(){
        location.reload();
    }

</script>



@endsection