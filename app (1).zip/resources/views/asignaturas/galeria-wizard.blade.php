@extends('layouts.admin')
@section('title', trans('general.title_administrar_archivos'))
@section('nav-bar')
    <li>
        <div class="btn-group mar-top mar-rgt">
            <button class="btn btn-mint btn-block btn-guardar"><i class="fa fa-check"></i> {{trans('botones.finalizar_galeria')}}</button>
        </div>
    </li>
    
@endsection
@section('content')
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-success bord-all">
        <div class="panel-heading">
          <h3 class="panel-title text-bold">{{trans('archivos.imagen_subir_editar')}}</h3>
        </div>
        <div class="panel-body row" style="min-height: 590px;">
          <div class="col-md-12" >
            <!-- <h3 class="page-header">Demo:</h3> -->
            <div class="img-container">
              <img src="img/choose-img.png" alt="Picture" id="">
            </div>
            <div class="col-md-12 docs-buttons">
                <!-- <h3 class="page-header">Toolbar:</h3> -->
                <div class="btn-group">
                  <button class="btn btn-primary" data-method="setDragMode" data-option="move" type="button" title="Move">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setDragMode", "move")">
                      <span class="fa fa-arrows"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="setDragMode" data-option="crop" type="button" title="Crop">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setDragMode", "crop")">
                      <span class="fa fa-crop"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="zoom" data-option="0.1" type="button" title="Zoom In">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("zoom", 0.1)">
                      <span class="fa fa-search-plus"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="zoom" data-option="-0.1" type="button" title="Zoom Out">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("zoom", -0.1)">
                      <span class="fa fa-search-minus"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="rotate" data-option="-45" type="button" title="Rotate Left">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("rotate", -45)">
                      <span class="fa fa-rotate-left"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="rotate" data-option="45" type="button" title="Rotate Right">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("rotate", 45)">
                      <span class="fa fa-rotate-right"></span>
                    </span>
                  </button>
                </div>
        
                <div class="btn-group">
                  <button class="btn btn-primary" data-method="disable" type="button" title="Disable">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("disable")">
                      <span class="fa fa-lock"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="enable" type="button" title="Enable">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("enable")">
                      <span class="fa fa-unlock"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="reset" type="button" title="Reset">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("reset")">
                      <span class="fa fa-refresh"></span>
                    </span>
                  </button>
                  
                </div>
                
                <div class="btn-group btn-group" data-toggle="buttons">
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="1.7777777777777777" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio1" name="aspestRatio" value="1.7777777777777777" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 16 / 9)">
                      16:9
                    </span>
                  </label>
                  <label class="btn btn-primary active" id="aspestRatio2Label" data-method="setAspectRatio" data-option="1.3333333333333333" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio2" name="aspestRatio" value="1.3333333333333333" type="radio" selected>
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 4 / 3)">
                      4:3
                    </span>
                  </label>
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="1" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio3" name="aspestRatio" value="1" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 1 / 1)">
                      1:1
                    </span>
                  </label>
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="0.6666666666666666" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio4" name="aspestRatio" value="0.6666666666666666" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 2 / 3)">
                      2:3
                    </span>
                  </label>
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="NaN" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio5" name="aspestRatio" value="NaN" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", NaN)">
                      Free
                    </span>
                  </label>
                </div>
                <button type="button" class="btn btn-secondary" style="display: none;" data-method="getData" data-option="" data-target="#putData" id="btnDataCropper">
                  <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="cropper.getData()">
                    Get Data
                  </span>
                </button>
                <label class="btn btn-success btn-upload" for="inputImage" title="Upload image file">
                    {{Form::open(['route' => 'paginas.guardar-imagen-crop', 'id' => 'informacionDocente']) }}
                      {!! Form::hidden('dataCrop', null,['id' => 'putData']) !!}
                      <input class="sr-only" id="inputImage" name="file" type="file" accept="image/*">
                    {!! Form::close() !!}
                    <span class="docs-tooltip" data-toggle="tooltip" title="Import image with Blob URLs">
                    <span class="fa fa-upload"></span>
                    {{trans('botones.subir_imagen')}}
                  </span>
                </label>
                <button class="btn btn-mint" data-method="getCroppedCanvas" type="button">
                  <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("getCroppedCanvas")">
                      <span class="fa fa-check"></span>
                      
                      {{trans('botones.finalizar')}}
                  </span>
                </button>
              </div>
            </div>
          </div>
          <div class="col-md-12">
          <button type="button" class="btn btn-primary btn-block btn-archivos">{{trans('archivos.imagen_galeria_seleccionar_archivos')}}</button>
          </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="panel panel-primary bord-all">
            <div class="panel-heading">
              <h3 class="panel-title text-bold">{{trans('archivos.imagen_galeria_preview')}}</h3>
            </div>
              <div class="panel-body row" style="min-height: 590px;">
                <div id="carousel-example-generic" class="carousel slide galleryCarousel" data-ride="carousel">
                  <!-- Indicators -->
                  <ol class="carousel-indicators">
                      
                      
                  </ol>
                  <!-- Wrapper for slides -->
                  <div class="carousel-inner">
                      <div class="item active">
                          <img src="img/example.jpg">
                          <div class="carousel-caption">
                          </div>   
                      </div>
                  </div>
                  <!-- Controls -->
                  <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                      <span class="glyphicon glyphicon-chevron-left"></span>
                  </a>
                  <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                      <span class="glyphicon glyphicon-chevron-right"></span>
                  </a>
              </div>
            </div>
        </div>
    </div>
    <div class="col-sm-2">
        <div class="panel panel-mint bord-all">
            <div class="panel-heading">
              <h3 class="panel-title text-bold">{{trans('archivos.imagen_galeria_seleccionada')}}</h3>
            </div>
            <div id="contentImg" style="display: none">
            </div>
            <div class="panel-body row" style="min-height: 590px;" id="contentGallery">
              
            </div>
        </div>
    </div>
  </div>
  <!-- Show the cropped image in modal -->
  <div class="modal fade docs-cropped" id="getCroppedCanvasModal" aria-hidden="true" aria-labelledby="getCroppedCanvasTitle" role="dialog" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bord-btm">
          <h4 class="modal-title" id="getCroppedCanvasTitle">{{trans('archivos.imagen_terminada')}}</h4>
          <div class="pull-right">
            <button type="button" class="btn btn-danger" data-dismiss="modal">{{trans('botones.seguir_editando')}}</button>
            <a class="btn btn-primary" id="download" href="javascript:void(0);" onclick="return convasToBlob();">{{trans('botones.subir')}}</a>
          </div>
        </div>
        <div class="modal-body" id="modalBodyCanvas"></div>
        <!-- <div class="modal-footer">
          <button class="btn btn-primary" data-dismiss="modal" type="button">Close</button>
        </div> -->
        
      </div>
      
    </div>
  </div>

  
  {{-- MODAL UTILIZADO PARA ADMINISTRAR LOS ARCHIVOS (IMAGENES Y PDF) --}}
  <div id="fileModal" class="modal fade in" tabindex="-1">
      <div class="modal-dialog modal-lg mar-top" style="width: 90%;">
          <div class="modal-content" style="min-height: 600px;">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
              </div>
              <div class="modal-body">
                  <input type="hidden" id="idGallery" name="idGallery" value="">
                  <input type="hidden" id="idImg" name="idImg" value="">
                  <input type="hidden" id="idPdf" name="idPdf" value="">
                  <input type="hidden" id="idBtnArchivo" name="idBtnArchivo" value="">
                  <div class="panel">
                      <div class="pad-all file-manager">
                          <div class="fixed-fluid">
                              <div class="fluid file-panel" id="fileContent">
                                  
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
@endsection

@section('script')
  <script src="{{asset('plugins/cropperjs/dist/cropper.js')}}"></script>
  <script src="{{asset('plugins/cropperjs/configuracion.js')}}"></script>
  <script src="{{asset('plugins/canvas-blob/js/canvas-to-blob.min.js')}}"></script>

  <script>
    $(document).ready(function () {
      $('#fileModal').on('show.bs.modal', function (e) {
          obtenerArchivosDirectorios();
      });
      $.validator.addMethod('filesize', function(value, element, param) {
        return this.optional(element) || (element.files[0].size <= param) 
			}); 
      $("#formAgregarImg").validate({
          ignore: ":hidden:not(.chosen-select)",
          submitHandler: function(form) {
            var loading = frameworkApp.setLoading();            
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                dataType: 'json',
                type:'POST',
                url: '{{ url("subir-archivo") }}',
                data: new FormData($("#formAgregarImg")[0]),
                processData: false,
                contentType: false,
                id_container_body: false,
                success: function(data) {
                    console.log(0);
                    $("#fileImg").val(null);
                    loading.remove();
                    alert("{{trans('archivos.imagen_subir_exito')}}");
                    window.opener.nameFunction(data.ruta);
                    //$('#getCroppedCanvasModal').modal('hide');
                },
            });
          },
          rules: {
            file: {
              accept: "image/*",
              filesize: 8388608,
              required: true
            }
          },
          messages: {
              file: {
                accept: "{{ trans('general.extension_failed', ['ext' => 'jpg, gif, png, jpeg']) }}",
                filesize: "{{ trans('general.size_failed') }}"
            },
          }, 
          highlight: function (element, errorClass) {
            $(element).parents('.form-group').addClass('has-feedback has-error');
            $(element).parents('.form-group').removeClass('has-feedback has-success');
          },
          unhighlight: function (element, errorClass) {
            $(element).parents('.form-group').removeClass('has-feedback has-error');
            $(element).parents('.form-group').addClass('has-feedback has-success');
          },
          errorPlacement: function(error, element) {
            if(element.parents('.input-group').length > 0) {
              error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.chosen').length > 0){
              error.insertAfter(element.parents('.chosen').find('.chosen-container'));
            } else {
              error.insertAfter(element);
            }
          }
      });
      $("#formAgregarPdf").validate({
        ignore: ":hidden:not(.chosen-select)",
        submitHandler: function(form) {
          var loading = frameworkApp.setLoading();              
          $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              dataType: 'json',
              type:'POST',
              url: '{{ url("subir-archivo") }}',
              data: new FormData($("#formAgregarPdf")[0]),
              processData: false,
              contentType: false,
              id_container_body: false,
              success: function(data) {
                  console.log(0);
                  $("#filePdf").val(null);
                  loading.remove();
                  alert("{{trans('archivos.pdf_subir_exito')}}");
                  window.opener.nameFunction();
              },
          });
        },
        rules: {
          file: {
            accept: "application/pdf",
              filesize: 8388608,
              required: true
            }
          },
        messages: {
          file: {
            accept: "{{ trans('general.extension_failed', ['ext' => 'XLS, XLSX']) }}",
            filesize: "{{ trans('general.size_failed') }}"
          },
        }, 
        highlight: function (element, errorClass) {
          $(element).parents('.form-group').addClass('has-feedback has-error');
          $(element).parents('.form-group').removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parents('.form-group').removeClass('has-feedback has-error');
          $(element).parents('.form-group').addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
          if(element.parents('.input-group').length > 0) {
            error.insertAfter(element.parents('.input-group'));
          } else if(element.parents('.chosen').length > 0){
            error.insertAfter(element.parents('.chosen').find('.chosen-container'));
          } else {
              error.insertAfter(element);
          }
        }
      });
      $("#aspestRatio2Label").click();
        $('#getCroppedCanvasModal').on('show.bs.modal', function (e) {
          $("#btnDataCropper").click();
        });
      });
      
      
      $(document).on('click','.btn-guardar', function(){
        if($( "#contentGallery .task-img" ).length>0){
          parent.nameFunction2($("#contentGallery"));
          parent.jQuery.fancybox.close();
        }else{
          alert('{{trans("archivos.error_seleccione_imagenes_galeria")}}');
        }
      });
      $(document).on('click','.btn-archivos', function(){
        
          let id = Math.random().toString(36).substring(7);
          //var id = Math.floor((Math.random() * 20) * 1)*(Math.random() * 20);
          $("#filtroBusqueda").val('img');
          $('#fileModal').modal('show');
          $("#idBtnArchivo").val("");
          $("#idGallery").val("idGallery_" + id);
          $("#idImg").val("");
          $("#idPdf").val("");
          $( "#contentImg" ).html($(this).parent().find('.content-gallery').html());
          $(this).parent().find('.galleryCarousel').attr("id", "idGallery_" + id);
          $(this).parent().find('.carousel-control').attr("href", "#idGallery_" + id);
        
          
          
      });
      function convasToBlob() {
          var loading = frameworkApp.setLoading();
          $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              dataType: 'json',
              type:'POST',
              url: '{{ url("subir-imagen-crop") }}',
              data: new FormData($("#informacionDocente")[0]),
              processData: false,
              contentType: false,
              id_container_body: false,
              success: function(data) {
                  loading.remove();
                  $('#getCroppedCanvasModal').modal('hide');
                  let id = Math.random().toString(36).substring(7);
                  var html = '<div class="panel-body bord-btm pad-no" id="panel-'+id+'">';
                  html+='<div class="panel-control">';
                  html+=' <div class="btn-group dropdown">';
                  html+='   <button data-toggle="dropdown" class="dropdown-toggle btn btn-default btn-active-primary">';
                  html+='     <i class="caret"></i>';
                  html+='   </button>';
                  html+='   <ul class="dropdown-menu dropdown-menu-right">';
                  html+='     <li><a href="#" class="eliminar-elemento-galeria" data-id="'+id+'">Remover</a></li>';
                  html+='   </ul>';
                  html+=' </div>';
                  html+='</div>';
                  html+='<div class="task-img mar-btm mar-top" data-url="'+data.ruta+'" data-nombre="'+data.nombre+'">';
                  html+=' <img class="img-responsive img-center" src="'+data.rutaWatermark+'" alt="Image">';
                  html+='</div>';
                  html+='</div>';

                  $('#contentGallery').append(html);
                  generarGallery();
                  //window.opener.nameFunction()
              },
          });
      }

      $(document).on('click','.eliminar-elemento-galeria', function(){
          var idTarget = $(this).attr("data-id");
          //rowGaleria = $(this).parent('.panel-contenedor');
          console.log(idTarget);
          $("#panel-"+idTarget).remove();
          generarGallery();
          // bootbox.confirm({ 
          //     title: "Desea elminar el elemento?", 
          //     message: "Desea elminar el elemento?",
          //     className: 'panel panel-colorful panel-primary',
          //     callback: function(result){ 
          //         if(result){
          //             rowGaleria.remove();
          //         }
          //     }
          // });
          
      });
      //Genera la galeria a partir de las iamgenes seleccionadas por el usuario
      function generarGallery(){
          //Obtiene el id asignado a la galleria, si es vacio quiere decir que no hay una galeria seleccionada
          var idGallery = 'carousel-example-generic';
          if(idGallery=='') {
              alert('{{trans('archivos.error_seleccione_imagen')}}');
          } else {
              //Limpia la galeria
              $('#'+idGallery+' .carousel-inner').html('');
              $('#'+idGallery+' .carousel-inner').html('<div class="content-gallery" style="display: none;">'+$( "#contentImg" ).html()+'</div>');
              $('#'+idGallery+' .carousel-indicators').html('');
              //Itera las imagenes seleccionadas y las va asignando a la galeria en el html correcto
              $( "#contentGallery .task-img" ).each(function( index ) {
                  $('<div class="item"><img src="'+$( this ).data( "url" )+'" class="img-center"><div class="carousel-caption"></div>   </div>').appendTo('#'+idGallery+' .carousel-inner');
                  $('<li data-target="#'+idGallery+'" data-slide-to="'+index+'"></li>').appendTo('#'+idGallery+' .carousel-indicators');
              });
              //Selecciona como activa la primera imagen
              $('#'+idGallery+' .item').first().addClass('active');
              $('#'+idGallery+' .carousel-indicators > li').first().addClass('active');
              //Recarga el elemento
              $('#'+idGallery).carousel();
              //Oculta el modal
              //$('#fileModal').modal('hide');
              //Limpia las imagenes seleccionadas por el usuario
              //$( "#contentImg" ).html('');
          }
      }
      function seleccionarGallery(ruta, miniatura, nombre){
        let id = Math.random().toString(36).substring(7);
          var html = '<div class="panel-body bord-btm pad-no" id="panel-'+id+'">';
          html+='<div class="panel-control">';
          html+=' <div class="btn-group dropdown">';
          html+='   <button data-toggle="dropdown" class="dropdown-toggle btn btn-default btn-active-primary">';
          html+='     <i class="caret"></i>';
          html+='   </button>';
          html+='   <ul class="dropdown-menu dropdown-menu-right">';
          html+='     <li><a href="#" class="eliminar-elemento-galeria" data-id="'+id+'">Remover</a></li>';
          html+='   </ul>';
          html+=' </div>';
          html+='</div>';
          html+='<div class="task-img mar-btm mar-top" data-url="'+ruta+'" data-nombre="'+nombre+'">';
          html+=' <img class="img-responsive img-center" src="'+miniatura+'" alt="Image">';
          html+='</div>';
          html+='</div>';

          $('#contentGallery').append(html);

          var htmlA = '<div class="row" id="'+id+'">';
          htmlA+= '   <div class="col-sm-8">';
          htmlA+= '       <a href="#" class="list-group-item text-bold pad-no" data-url="'+ruta+'">';
          //El nombre es el texto a mostrar en la lista
          htmlA+='            <span class="text-main"><i class="fa fa-file-img"></i> <small>'+nombre+'</small></span>';
          htmlA+='        </a>';
          htmlA+='    </div>';
          htmlA+='    <div class="col-sm-1" style="margin-right: 5px;">';
          htmlA+='        <a class="grouped_elements btn btn-xs btn-info" href='+ruta+'><i class="fa fa-eye"></i></a>';
          htmlA+='    </div>';
          htmlA+='    <div class="col-sm-1 ">';
          htmlA+='        <a class="btn btn-xs btn-danger eliminar-elemento-galeria"><i class="fa fa-times"></i></a>';
          htmlA+='    </div>';
          htmlA+='</div>';
        //    console.log(a);
        $("#contentImg").append(htmlA);
        generarGallery()
      }
      function obtenerArchivosDirectorios(ruta) { 
          var loading = frameworkApp.setLoading();
          $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              type:'POST',
              url: '{{ route("paginas.ficheros") }}',
              data: {rutaActual: ruta, ext: $("#filtroBusqueda").val(), wizard: true},
              success:function(data){
                  $("#fileContent").html(data.html);
                  loading.remove();
              }
          });
          return false;
      };
      
  </script>
@endsection
@section('style')
    <link  href="{{asset('plugins/cropperjs/dist/cropper.css')}}" rel="stylesheet">
    <link  href="{{asset('plugins/cropperjs/configuracion.css')}}" rel="stylesheet">
    <style>
        .img-center {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
@endsection