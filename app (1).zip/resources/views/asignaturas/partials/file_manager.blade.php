<style>
    .center-img {
        display: block;
        margin-left: auto;
        margin-right: auto;
        height: 49px;
    }
    .view {
        padding: 15px;
    }
    .column.ui-droppable-hover {
        background: #38a53a;
    }
</style>
<div class="fluid file-panel">
    <div class="file-toolbar bord-btm">
        <div class="btn-file-toolbar">
            <a class="btn btn-icon add-tooltip" href="#" data-original-title="Home" data-toggle="tooltip" onclick="obtenerArchivosDirectorios('public/files/')"><i class="icon-2x demo-pli-home"></i></a>
            <a id="refrescarItem" class="btn btn-icon add-tooltip" href="#" data-original-title="Refresh" data-toggle="tooltip" onclick="obtenerArchivosDirectorios('{{$rutaActual}}')"><i class="icon-2x demo-pli-reload-3"></i></a>
        </div>
        <div class="btn-file-toolbar">
        </div>
        <div class="btn-file-toolbar pull-right">
        </div>
    </div>
    <div id="demo-mail-list" class="file-list row" style="min-height: 500px;">
        
        @if ($salirNivel)
            <!--File list item-->
                <div class="col-sm-12 mar-all">
                    <div class="file-attach-icon"></div>
                    <a href="#" class="file-details" onclick="obtenerArchivosDirectorios('{{$rutaActual}}/../')">
                        <div class="media-block">
                            <div class="media-left"><i class="demo-psi-folder"></i></div>
                            <div class="media-body">
                                <p class="file-name single-line">...</p>
                            </div>
                        </div>
                    </a>
                    <hr>
                </div>
        @endif
            
        @foreach ($listCarpetas as $carpeta)
            @if (str_replace(config('app.files'), ' ', $carpeta)!=" watermark")
            <!--File list item-->
            <div class="col-sm-2 mar-all">
                <div class="file-attach-icon"></div>
                <a href="#" class="file-details" onclick="obtenerArchivosDirectorios('{{$carpeta}}')">
                    <div class="media-block">
                        <div class="media-left"><i class="demo-psi-folder"></i></div>
                        <div class="media-body">
                            <p class="file-name single-line">{!! str_replace(config('app.files'), ' ', $carpeta) !!}</p>
                        </div>
                    </div>
                </a>
            </div>  
            @endif
        @endforeach

        @foreach ($listArchivos as $archivo)
            @php
                $nombreArchivo = explode('/',$archivo);
                $existe = file_exists(public_path("../storage/".config('app.files').$archivo));
                $time = explode('.', $nombreArchivo[count($nombreArchivo)-1]);
            @endphp
            @if (strtoupper(substr(strrchr(str_replace(config('app.files'), 'files/', $archivo),'.'),1))=="PDF")
                <!--File list item-->
                <div class="col-sm-2 mar-all bord-hor">
                    <div class="file-settings">
                            <div class="dropdown">
                            <button class="dropdown-toggle btn btn-default btn-active-primary" data-toggle="dropdown" aria-expanded="false">
                                <i class="demo-psi-dot-vertical"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-right" style="opacity: 1;">
                                    <li><a href="#" onclick="cambiarPDF('{!!url("../storage/app/public/".str_replace(config('app.files'), 'files/', $archivo)) !!}')">Seleccionar PDF</a></li>
                                    <li class="divider"></li>
                                    <li><a href="#" onclick="cambiarBtnArchivo('{!!url("../storage/app/public/".str_replace(config('app.files'), 'files/', $archivo)) !!}')">Asignar a Boton</a></li>
                            </ul>
                            </div>
                    </div>
                    <div class="file-attach-icon"></div>
                    <a href="{!! str_replace(config('app.files'), 'files/', $archivo) !!}" class="file-details grouped_elements" >
                        <div class="media-block">
                            <div class="media-left">
                                <i class="fa fa-file-pdf-o"></i>
                            </div>
                            <div class="media-body" style="height: 127px; ">
                                {!!  date('m-d-Y G:ia',$time[0])!!}
                            </div>
                        </div>
                    </a>
                </div>    
            @else
                <!--File list item-->
                <div class="col-sm-2 mar-all bord-hor">
                    <div class="file-settings">
                        <div class="dropdown">
                            <button class="dropdown-toggle btn btn-default btn-active-primary" data-toggle="dropdown" aria-expanded="true"><i class="demo-psi-dot-vertical"></i></button>
                            <ul class="dropdown-menu dropdown-menu-right" style="opacity: 1;">
                                @if (blank($wizard))
                                    <li><a href="#" onclick="cambiarImage('{!!url("../storage/app/public/".str_replace(config('app.files'), 'files/', $archivo)) !!}')">Añadir a Imagen</a></li>
                                    <li><a href="#" onclick="seleccionarGallery('{!! url("../storage/app/public/".str_replace(config('app.files'), 'files/', $archivo)) !!}','{!! date('m-d-Y G:ia',$time[0]) !!}')">Añadir a Galeria</a></li>
                                    <li class="divider"></li>
                                    <li><a href="#" onclick="cambiarBtnArchivo('{!!url("../storage/app/public/".str_replace(config('app.files'), 'files/', $archivo)) !!}')">Asignar a Boton</a></li>
                                    <li><a class="btn btn-danger btn-block" style="color: #fff !important;" href="#" onclick="eliminarArchivo('{!! url("../storage/app/public/".str_replace(config('app.files'), 'files/', $archivo)) !!}','{!! url($miniaturas.'/'.$nombreArchivo[count($nombreArchivo)-1]) !!}','{{$rutaActual}}')"><i class="fa fa-trash"></i> Eliminar</a></li>
                                @else
                                    <li><a href="#" onclick="seleccionarGallery('{!! url("../storage/app/public/".str_replace(config('app.files'), 'files/', $archivo)) !!}','{!! url($miniaturas.'/'.$nombreArchivo[count($nombreArchivo)-1]) !!}','{!! date('m-d-Y G:ia',$time[0]) !!}')">Añadir a Galeria</a></li>
                                @endif
                            </ul>
                        </div>
                    </div>
                    <div class="file-attach-icon"></div>
                    <a href="{!!url("../storage/app/public/".str_replace(config('app.files'), 'files/', $archivo)) !!}" class="file-details grouped_elements text-center" >
                        <div class="media-block pad-ver" style="background-image: url('{!!url($miniaturas.'/'.$nombreArchivo[count($nombreArchivo)-1]) !!}'); height: 109px; background-repeat: no-repeat; background-position: center; position: relative;">
                        </div>
                        {!!  date('m-d-Y G:ia',$time[0])!!}
                    </a>
                </div>
            @endif
        @endforeach
    </ul>
</div>


<script>
    $(function(){
        $("a.grouped_elements").fancybox({closeClick  : false});
    });
</script>