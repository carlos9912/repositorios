        <div class="btn-group mar-top">
            <button class="btn btn-default text-primary" onclick="document.execCommand('redo',false,'');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_undo')}}"><i class="fa fa-repeat"></i></button>
            <button class="btn btn-default text-primary" onclick="document.execCommand('undo',false,'');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_redo')}}"><i class="fa fa-rotate-left"></i></button>
            <button class="btn btn-default text-primary" onclick="document.execCommand('delete',false,'');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_eliminar')}}"><i class="fa fa-trash-o"></i></button>
        </div>

        <div class="btn-group mar-top">
            <div class="btn-group">
                <div class="dropdown" data-toggle="tooltip" data-container="body" data-placement="right" data-original-title="{{trans('paleta.wysiwyg_editor_tamaño')}}">
                    <button class="btn btn-mint dropdown-toggle" data-toggle="dropdown" type="button">
                        <i class="fa fa-text-height"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-right">
                        <li class="dropdown-header">{{trans('paleta.wysiwyg_editor_tamaño_texto')}}</li>
                        <li><a href="#" onclick="document.execCommand('fontSize', false, 1);"><font size="1">Texto</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontSize', false, 2);"><font size="2">Texto</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontSize', false, 3);"><font size="3">Texto</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontSize', false, 4);"><font size="4">Texto</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontSize', false, 5);"><font size="5">Texto</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontSize', false, 6);"><font size="6">Texto</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontSize', false, 7);"><font size="7">Texto</font></a></li>
                    </ul>
                </div>
            </div>
            <div class="btn-group">
                <div class="dropdown" data-toggle="tooltip" data-container="body" data-placement="right" data-original-title="{{trans('paleta.wysiwyg_editor_fuente')}}">
                    <button class="btn btn-mint dropdown-toggle" data-toggle="dropdown" type="button">
                        <i class="fa fa-font"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-right">
                        <li class="dropdown-header">{{trans('paleta.wysiwyg_editor_tipo_fuente')}}</li>
                        <li><a href="#" onclick="document.execCommand('fontName', false, 'Helvetica');"><font face="Helvetica">Helvetica</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontName', false, 'Verdana');"><font face="Verdana">Verdana</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontName', false, 'Lucida Grande');"><font face="Lucida Grande">Lucida Grande</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontName', false, 'Arial');"><font face="Arial">Arial</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontName', false, 'Calibri');"><font face="Calibri">Calibri</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontName', false, 'Comic Sans MS');"><font face="Comic Sans MS">Comic Sans MS</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontName', false, 'Georgia');"><font face="Georgia">Georgia</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontName', false, 'Palatino');"><font face="Palatino">Palatino</font></a></li>
                        <li><a href="#" onclick="document.execCommand('fontName', false, 'Courier New');"><font face="Courier New">Courier New</font></a></li>
                        
                    </ul>
                </div>
            </div>
            <button class="btn btn-mint " onclick="document.execCommand('underline', false, '');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_linea')}}"><i class="fa fa-underline"></i></button>
            <button class="btn btn-mint " onclick="document.execCommand('bold', false, '');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_negrita')}}"><i class="fa fa-bold text-bold"></i></button>
            <button class="btn btn-mint " onclick="document.execCommand('italic', false, '');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_cursiva')}}"><i class="fa fa-italic"></i></button>
            <button class="btn btn-mint " onclick="document.execCommand('strikeThrough', false, '');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_tachado')}}"><i class="fa fa-strikethrough"></i></button>
            <button class="btn btn-mint " id="full" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_color')}}"><i class="fa fa-paint-brush"></i></button>
            <button class="btn btn-mint generar-btn-pdf"><i class="fa fa-code"></i></button>
        </div>
        
        <div class="btn-group mar-top">
            <button class="btn btn-mint " onclick="document.execCommand('justifyLeft',false,'');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_izquierda')}}"><i class="fa fa-align-left"></i></button>
            <button class="btn btn-mint " onclick="document.execCommand('justifyCenter',false,'');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_centro')}}"><i class="fa fa-align-center"></i></button>
            <button class="btn btn-mint " onclick="document.execCommand('justifyRight',false,'');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_derecha')}}"><i class="fa fa-align-right"></i></button>
            <button class="btn btn-mint " onclick="document.execCommand('justifyFull',false,'');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_justificado')}}"><i class="fa fa-align-justify"></i></button>
            <button class="btn btn-mint " onclick="document.execCommand('insertOrderedList',false,'');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_justificado')}}"><i class="fa fa-list-ol"></i></button>
            <button class="btn btn-mint " onclick="document.execCommand('insertUnorderedList',false,'');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_justificado')}}"><i class="fa fa-list-ul"></i></button>
            <button class="btn btn-mint generar-link" onclick="document.execCommand('italic', false, '');" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_editor_link')}}"><i class="fa fa-chain"></i></button>
        </div>

        <div class="btn-group mar-top">
            {{-- <button class="btn btn-warning btn-alignment" data-aligment="bord-btm" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_borde_inferior')}}"><i class="fa fa-caret-square-o-down"></i></button>
            <button class="btn btn-warning btn-alignment" data-aligment="bord-lft" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_borde_izquierda')}}"><i class="fa fa-caret-square-o-left"></i></button>
            <button class="btn btn-warning btn-alignment" data-aligment="bord-rgt" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_borde_derecha')}}"><i class="fa fa-caret-square-o-right"></i></button>
            <button class="btn btn-warning btn-alignment" data-aligment="bord-top" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_borde_arriba')}}"><i class="fa fa-caret-square-o-up"></i></button> --}}
            <button class="btn btn-warning btn-alignment" data-aligment="bord-ver" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_borde_horizontal')}}"><i class="fa fa-arrows-h"></i></button>
            <button class="btn btn-warning btn-alignment" data-aligment="bord-hor" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_borde_vertical')}}"><i class="fa fa-arrows-v"></i></button>
            {{-- <button class="btn btn-warning btn-alignment" data-aligment="bord-all" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_borde_total')}}"><i class="fa fa-square-o"></i></button> --}}
            <button class="btn btn-warning btn-alignment" data-aligment="bord-no" data-toggle="tooltip" data-container="body" data-placement="bottom" data-original-title="{{trans('paleta.wysiwyg_sin_borde')}}"><i class="fa fa-times"></i></button>
        </div>
        