@extends('layouts.admin')
@section('title', trans('general.title_administrar_archivos'))
@section('content')
<div class="col-sm-4 col-md-3 bord-rgt">
	<!-- Contact Widget -->
    <!---------------------------------->
    <div class="panel pos-rel">
        <div class="pad-all text-center">
            <div class="widget-control">
                <a href="#" class="add-tooltip btn btn-trans" data-original-title="Favorite"><span class="favorite-color"><i class="demo-psi-star icon-lg"></i></span></a>
                <div class="btn-group dropdown">
                    <a href="#" class="dropdown-toggle btn btn-trans" data-toggle="dropdown" aria-expanded="false"><i class="demo-psi-dot-vertical icon-lg"></i></a>
                    <ul class="dropdown-menu dropdown-menu-right" style="">
                        <li><a href="#"><i class="icon-lg icon-fw demo-psi-pen-5"></i> Edit</a></li>
                        <li><a href="#"><i class="icon-lg icon-fw demo-pli-recycling"></i> Remove</a></li>
                        <li class="divider"></li>
                        <li><a href="#"><i class="icon-lg icon-fw demo-pli-mail"></i> Send a Message</a></li>
                        <li><a href="#"><i class="icon-lg icon-fw demo-pli-calendar-4"></i> View Details</a></li>
                        <li><a href="#"><i class="icon-lg icon-fw demo-pli-lock-user"></i> Lock</a></li>
                    </ul>
                </div>
            </div>
            <a href="#">
                <img alt="Profile Picture" class="img-lg img-circle mar-ver" style="width: 30%; height: 30%; border-radius: 5%;" src="{{asset('img/fotos/'.$estudiante->img)}}">
                <p class="text-lg text-semibold mar-no text-main">{{$estudiante->nombreCompleto()}}</p>
                <p class="text-sm">{{$estudiante->documento()}}</p>
                <p class="text-lg"><span class="label label-mint">GRADO ACTUAL: {!!$grado->nombrecurso!!}</span></p>
                <hr class="mar-5">
                @if(!blank($estudiante->madre) && $estudiante->madre!='0')
                    <p class="text-sm">{!!$estudiante->madre()!!}</p>
                @endif
                @if(!blank($estudiante->padre)&&$estudiante->acudienpadrete!='0')
                    <hr>
                    <p class="text-sm">{!!$estudiante->padre()!!}</p>
                @endif
                @if(!blank($estudiante->acudiente)&&$estudiante->acudiente!='0')
                    <hr>
                    <p class="text-sm">{!!$estudiante->acudiente()!!}</p>
                @endif
            </a>
            <div class="pad-top btn-groups">
                <a href="#" class="btn btn-icon demo-pli-facebook icon-lg add-tooltip" data-original-title="Facebook" data-container="body"></a>
                <a href="#" class="btn btn-icon demo-pli-twitter icon-lg add-tooltip" data-original-title="Twitter" data-container="body"></a>
                <a href="#" class="btn btn-icon demo-pli-google-plus icon-lg add-tooltip" data-original-title="Google+" data-container="body"></a>
                <a href="#" class="btn btn-icon demo-pli-instagram icon-lg add-tooltip" data-original-title="Instagram" data-container="body"></a>
            </div>
        </div>
    </div>
    <!---------------------------------->
</div>
<div class="col-lg-6">
    <div class="panel panel-primary panel-bordered">
        <div class="panel-heading">
            <h3 class="panel-title">Seleccione la promoción del estudiante</h3>
        </div>
        <!--No Label Form-->
        <!--===================================================-->
        <form class="form-horizontal" id="formPromocion">
            <div class="panel-body">
                <div class="row">
                    <input type="hidden" name="accion" id="accion" value="">
                    <input type="hidden" name="codcurso" id="codcurso" value="">
                    
                    <div class="col-md-9">
                        <h4>El estudiante es promovido al grado {{$gradoSiguiente->nombrecurso}}?</h4>
                        <div class="radio">
                            <input id="demo-form-radio" class="magic-radio" type="radio" name="promocion" value="1" data-codcurso="{!!$grado->siguiente!!}" data-accion="1">
                            <label for="demo-form-radio"><span class="label label-success">Promover Estudiante </span></label>
                        </div>
                        <div class="radio">
                            <input id="demo-form-radio-2" class="magic-radio" type="radio" name="promocion" value="2" data-codcurso="{!!$grado->codcurso!!}" data-accion="3">
                            <label for="demo-form-radio-2"><span class="label label-danger">Reprobar Estudiante </span></label>
                        </div>
                        
                        <br>
                    </div>
                    <div class="col-sm-9">
                        <input id="matricular" name="matricular" value="1" class="magic-checkbox" type="checkbox" checked>
                        <label for="matricular">Matricular</label>
                    </div>
                </div>
            </div>
            <div class="panel-footer text-left">
                <button type="button" class="btn btn-success btn-promover">Realizar Promoción</button>
            </div>
        </form>
        <!--===================================================-->
        <!--End No Label Form-->

    </div>
</div>

@endsection
@section('script')
<script>
    $(document).ready(function () {
        $('.magic-radio').change(function(){
            $("#accion").val($(this).data("accion"));
            $("#codcurso").val($(this).data("codcurso"));
        });
        $('.btn-promover').click(function(){
            var accion = $("#accion").val();
            if(accion==''){
                frameworkApp.setToastError('Debe seleccionar una de las opciones de promoción');
            }else{
                var matriculado = ($("#matricular").prop('checked')) ? "MATRICULAR" : "NO MATRICULAR"; 
                var mensaje = "¿Esta seguro de PROMOVER Y "+matriculado+" al estudiante en el siguiente grado para el año {{\Carbon\Carbon::now()->year}}?";
                if($("input[name='promocion']:checked").val()=="2"){
                    mensaje = "¿Esta seguro de NO PROMOVER Y "+matriculado+" al estudiante en el grado actual para el año {{\Carbon\Carbon::now()->year}}?";
                }
                bootbox.confirm({ 
                    title: "{{trans('general.atencion')}}", 
                    message: mensaje,
                    callback: function(result){ 
                        if(result){
                            frameworkApp.setLoadData({
                                url: '{{ url("estudiantes/matricula-procesar") }}',
                                data: {
                                    codcurso: $("#codcurso").val(),
                                    promocion: $("input[name='promocion']:checked").val(),
                                    matricular: $("#matricular").prop('checked'),
                                    codestudiante: {{$estudiante->codestudiante}}
                                },
                                id_container_body: false,
                                success: function(data) {
                                    frameworkApp.setToastSuccess(data.mensaje);
                                    window.opener.recargar();
                                    setTimeout(function(){ 
                                        window.close();
                                    }, 1000);
                                }
                            });
                        }
                    }
                });
                
            }
            
        });
    });
</script>
@endsection
