

{{Form::model($pagina, ['route' => ['paginas.editar-pagina', $pagina->id_pagina], 'method' => 'POST', 'class' => 'validation-wizard wizard-circle', 'id' => 'editarPagina']) }}  
    <div class="panel-body">
        {!! Form::hidden('estadoAnterior', $pagina->estado, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'estadoAnterior' ]) !!}
        {!! Form::hidden('editar', 1, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'editar' ]) !!}
        {!! Form::hidden('id_pagina', $pagina->id_pagina, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'id_pagina' ]) !!}
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label class="control-label">{{trans('paginas.pagina_nombre')}}</label>
                    {!! Form::text('titulo', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'titulo' ]) !!}
                </div>
            </div>
            <div class="col-sm-12">
                <div class="form-group">
                    <label class="control-label">{{trans('paginas.pagina_menu')}}</label>
                    {!! Form::select("id_menu", $menus, null, ["id"=>"id_menu", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => trans("menus.placeholder_menu_seleccione_padre"), "required" => "required"]) !!}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <label class="control-label">{{trans('paginas.pagina_principal')}}</label>
                <div class="radio mar-top">
                    <input id="principalCk" type="checkbox" name="principal" value="{{App\Enums\ESiNo::index(App\Enums\ESiNo::Si)->getId()}}">
                </div>
            </div>
            
            <div class="col-md-6">
                <label class="control-label">{{trans('paginas.pagina_publicada')}}</label>
                <div class="radio mar-top">
                    <input id="estadoCk" type="checkbox" name="estado" value="{{App\Enums\ESiNo::index(App\Enums\ESiNo::Si)->getId()}}">
                </div>
            </div>
        </div>
        <hr>
        <div class="row" id="btnCrear">
            <div class="col-sm-6">
                <div class="form-group">
                    <button class="btn btn-mint" type="submit">{{trans('botones.guardar')}}</button>
                </div>
            </div>
        </div>
    </div>
{{Form::close()}}

<script type="text/javascript">
    $('.chosen-select').each(function() {
        var options = jQuery.extend({
            place_holder: 'Seleccione una opción',
            place_holder_multiple: 'Seleccione algunas opciones',
            no_results_text: 'Ningún resultado coincide con',
            width: '100%'
        }, $(this).data());
        $(this).chosen({
            "placeholder_text_multiple": options.place_holder_multiple,
            "placeholder_text_single": options.place_holder,
            "no_results_text": options.no_results_text,
            "width": options.width
        });
    });
    $("#editarPagina").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            var loading = frameworkApp.setLoading();
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                url: '{{ url("guardar-pagina") }}',
                data: $("#editarPagina").serialize(),
                success:function(data){
                    loading.remove();
                    $("#tablaPaginas").html(data.tablaPaginas);
                    $("#editarModal").modal('hide');
                    $('#table-paginas').DataTable({
                        "responsive": true,
                        "language": {
                            "paginate": {
                            "previous": '<i class="demo-psi-arrow-left"></i>',
                            "next": '<i class="demo-psi-arrow-right"></i>'
                            }
                        }
                    });
                    $('.add-tooltip').tooltip();
                    $('.add-tooltip').on('click', function () {
                        $(this).attr('data-original-title', 'changed tooltip');
                        $('.add-tooltip').tooltip();
                        $(this).mouseover();
                    });
                    //$("#fileContent").html(data.html);
                }
            });
            return false;
        },
        rules: {
            titulo: 'required',
            id_menu: 'required',
            url: 'required',
        },
        highlight: function (element, errorClass) {
        $(element).parents('.form-group').addClass('has-feedback has-error');
        $(element).parents('.form-group').removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
        $(element).parents('.form-group').removeClass('has-feedback has-error');
        $(element).parents('.form-group').addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.form-group').find('.chosen-container'));
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    @if($pagina->estado==App\Enums\EEstadoPagina::index(App\Enums\EEstadoPagina::PUBLICADA)->getId())
        $('#estadoCk').prop('checked', true);
    @endif
    @if($pagina->principal==App\Enums\ESiNo::index(App\Enums\ESiNo::Si)->getId())
        $('#principalCk').prop('checked', true);
    @endif
    new Switchery(document.getElementById('principalCk'), {color:'#489eed'});
    var mySwitch = new Switchery(document.getElementById('estadoCk'), {color:'#489eed'});
    
    
</script>