    <style>
        .text-success-hr{
            border-color: #79af3a !important;
        }
        .text-info-hr{
            border-color: #0391d1 !important;
        }
        .text-primary-hr{
            border-color: #1c3550 !important;
        }
        .text-warning-hr{
            border-color: #db9a00 !important;
        }
        .text-purple-hr{
            border-color: #953ca4 !important;
        }
        .text-pink-hr{
            border-color: #ed417b !important;
        }
        .hr-delgado{
            border-top: 1px solid;
        }
        .hr-normal{
            border-top: 2px solid;
        }
        .hr-ancho{
            border-top: 4px solid;
        }
    </style>
    <style>
        .dropdown-submenu {
            position: relative;
        }

        .dropdown-submenu>.dropdown-menu {
            top: 0;
            right: 100%;
            margin-top: -6px;
            margin-left: -1px;
            -webkit-border-radius: 0 6px 6px 6px;
            -moz-border-radius: 0 6px 6px;
            border-radius: 0 6px 6px 6px;
        }

        .dropdown-submenu:hover>.dropdown-menu {
            display: block;
        }

        .dropdown-submenu>a:after {
            display: block;
            content: " ";
            float: right;
            width: 0;
            height: 0;
            border-color: transparent;
            border-style: solid;
            border-width: 5px 0 5px 5px;
            border-left-color: #ccc;
            margin-top: 5px;
            margin-right: -10px;
        }

        .dropdown-submenu:hover>a:after {
            border-left-color: #fff;
        }

        .dropdown-submenu.pull-left {
            float: none;
        }

        .dropdown-submenu.pull-left>.dropdown-menu {
            left: -100%;
            margin-left: 10px;
            -webkit-border-radius: 6px 0 6px 6px;
            -moz-border-radius: 6px 0 6px 6px;
            border-radius: 6px 0 6px 6px;
        }
    </style>
        
    <!--Nav tabs-->
    <!--================================-->
    <ul class="nav nav-tabs nav-justified">
        <li class="active">
            <a href="#demo-asd-tab-1" data-toggle="tab">
                <i class="ti ti-pencil-alt"></i> {{trans('paleta.tools_editor')}}
            </a>
        </li>
    </ul>
    <!--================================-->
    <!--End nav tabs-->



    <!-- Tabs Content -->
    <!--================================-->
    <div class="tab-content">

        <!--First tab (Contact list)-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div class="tab-pane fade in active" id="demo-asd-tab-1">
            <!--Family-->
            <div class="list-group bg-trans pad-all">
                <div class="sidebar-nav list-group bg-trans">
                    <ul class="nav nav-list">
                        <li class="nav-header">
                        <button class="btn btn-mint mar-ver btn-block">{{trans("paleta.disenio_title")}}</button>
                        </li>
                        <li class="rows" id="estRows">
                        <div class="lyrow">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success columna">
                                <i class="ti ti-move"></i>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.disenio_columna_12")}}  <button class="btn btn-xs btn-mint" onclick="return bootbox.alert('{{trans("paleta.disenio_columna_12_instruccion")}}')"><i class="ti ti-layout-width-full"></i></button>
                            </div>
                            <div class="view">
                                <div class="row clearfix">
                                    <div class="col-md-12 column">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="lyrow">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <a href="#close" class="opciones btn btn-info btnChange">
                                <i class="ti ti-loop"></i>
                            </a>
                            <span class="drag btn btn-success columna">
                                <i class="ti ti-move"></i>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.disenio_columna_8_4")}}  <button class="btn btn-xs btn-mint"  onclick="return bootbox.alert('{{trans("paleta.disenio_columna_8_4_instruccion")}}')"><i class="ti ti-layout-width-full"></i></button>
                            </div>
                            <div class="view">
                                <div class="row clearfix">
                                    <div class="col-md-4 column changeDiv">
                                    </div>
                                    <div class="col-md-8 column changeDiv">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="lyrow">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success columna">
                                <i class="ti ti-move"></i>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.disenio_columna_6")}}  <button class="btn btn-xs btn-mint"  onclick="return bootbox.alert('{{trans("paleta.disenio_columna_6_instruccion")}}')"><i class="ti ti-layout-column2"></i></button>
                            </div>
                            <div class="view">
                                <div class="row clearfix">
                                    <div class="col-md-6 column"></div>
                                    <div class="col-md-6 column"></div>
                                </div>
                            </div>
                        </div>
                        <div class="lyrow">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success columna">
                                <i class="ti ti-move"></i>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.disenio_columna_4")}} <button class="btn btn-xs btn-mint"  onclick="return bootbox.alert('{{trans("paleta.disenio_columna_4_instruccion")}}')"><i class="ti ti-layout-column3"></i></button>
                            </div>

                            <div class="view">
                                <div class="row clearfix">
                                    <div class="col-md-4 column" ondragover="alert(0);"></div>
                                    <div class="col-md-4 column"></div>
                                    <div class="col-md-4 column"></div>
                                </div>
                            </div>
                        </div>

                        <div class="lyrow">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success columna">
                                <i class="ti ti-move"></i>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.disenio_columna_3")}} <button class="btn btn-xs btn-mint"  onclick="return bootbox.alert('{{trans("paleta.disenio_columna_3_instruccion")}}')"><i class="ti ti-layout-column3"></i></button>
                            </div>
                            <div class="view">
                                <div class="row clearfix">
                                    <div class="col-md-3 column"></div>
                                    <div class="col-md-3 column"></div>
                                    <div class="col-md-3 column"></div>
                                    <div class="col-md-3 column"></div>
                                </div>
                            </div>
                        </div>
                        <div class="lyrow ui-draggable">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success columna" style="display: none;">
                                <i class="ti ti-move"></i>
                            </span>    
                            <div class="preview pull-right">
                                <input type="text" value="" placeholder="3 8 1" class="form-control">
                            </div>
                            <div class="view">
                                <div class="row">
                                </div>
                            </div>
                        </div>
                        </li>
                    </ul>
                    {{-- Sección de paleta: TEXTOS --}}
                    <ul class="nav nav-list">
                        <li class="nav-header">
                            <button class="btn btn-info mar-ver btn-block">{{trans("paleta.textos_title")}}</button>
                        </li>
                        <li class="rows" id="estRows">
                        {{-- TITULO = Etiqueta <H2> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <span class="configuration">
                                <div class="dropdown">
                                    <a id="dLabel" role="button" data-toggle="dropdown" class="btn btn-primary btn-sm dropdown-menu-btn" href="#">
                                        <i class="demo-pli-dot-vertical"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right multi-level" role="menu" aria-labelledby="dropdownMenu">
                                        <li class="dropdown-submenu">
                                            <a tabindex="-1" href="#">{{trans("paleta.tools_color")}}</a>
                                            <ul class="dropdown-menu dropdown-menu-right">
                                                <li class="dropdown-header">{{trans("paleta.tools_color")}}</li>
                                                <li><a href="#" rel="text-primary" class="text-primary nv2">{{trans("paleta.tools_color_negro")}}</a></li>
                                                <li><a href="#" rel="text-success" class="text-success nv2">{{trans("paleta.tools_color_verde")}}</a></li>
                                                <li><a href="#" rel="text-info" class="text-info nv2">{{trans("paleta.tools_color_azul")}}</a></li>
                                                <li><a href="#" rel="text-warning" class="text-warning nv2">{{trans("paleta.tools_color_amarillo")}}</a></li>
                                                <li><a href="#" rel="text-purple" class="text-purple nv2">{{trans("paleta.tools_color_purpura")}}</a></li>
                                                <li><a href="#" rel="text-pink" class="text-pink nv2">{{trans("paleta.tools_color_rosado")}}</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.textos_titulo")}}  <button class="btn btn-xs btn-info"  onclick="return bootbox.alert('{{trans("paleta.textos_titulo_instruccion")}}')"><i class="fa fa-header"></i></button>
                            </div>
                            <div class="view">
                                <h2 contenteditable="true">{{trans("paleta.textos_titulo_contenido")}}</h2>
                            </div>
                        </div>
                        {{-- DIVISOR = Etiqueta <HR> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <span class="configuration">
                                <div class="dropdown">
                                    <a id="dLabel" role="button" data-toggle="dropdown" class="btn btn-primary btn-sm dropdown-menu-btn" href="#">
                                        <i class="demo-pli-dot-vertical"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right multi-level" role="menu" aria-labelledby="dropdownMenu">
                                        <li class="dropdown-submenu">
                                            <a tabindex="-1" href="#">{{trans("paleta.tools_color")}}</a>
                                            <ul class="dropdown-menu dropdown-menu-right">
                                                <li class="dropdown-header">{{trans("paleta.tools_color")}}</li>
                                                <li><a href="#" rel="text-primary" class="text-primary nv2">{{trans("paleta.tools_color_negro")}}</a></li>
                                                <li><a href="#" rel="text-success" class="text-success nv2">{{trans("paleta.tools_color_verde")}}</a></li>
                                                <li><a href="#" rel="text-info" class="text-info nv2">{{trans("paleta.tools_color_azul")}}</a></li>
                                                <li><a href="#" rel="text-warning" class="text-warning nv2">{{trans("paleta.tools_color_amarillo")}}</a></li>
                                                <li><a href="#" rel="text-purple" class="text-purple nv2">{{trans("paleta.tools_color_purpura")}}</a></li>
                                                <li><a href="#" rel="text-pink" class="text-pink nv2">{{trans("paleta.tools_color_rosado")}}</a></li>
                                            </ul>
                                        </li>
                                        <li class="dropdown-submenu">
                                            <a tabindex="-1" href="#">{{trans("paleta.textos_divisor_bordes")}}</a>
                                            <ul class="dropdown-menu dropdown-menu-right">
                                                <li class="dropdown-header">{{trans("paleta.tools_color")}}</li>
                                                <li><a href="#" rel="hr-delgado" class="text-primary nv2">{{trans("paleta.textos_divisor_delgado")}}</a></li>
                                                <li><a href="#" rel="hr-normal" class="text-success nv2">{{trans("paleta.textos_divisor_normal")}}</a></li>
                                                <li><a href="#" rel="hr-ancho" class="text-success nv2">{{trans("paleta.textos_divisor_ancho")}}</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.textos_divisor")}}  <button class="btn btn-xs btn-info"  onclick="return bootbox.alert('{{trans("paleta.textos_divisor_instruccion")}}')"><i class="fa fa-header"></i></button>
                            </div>
                            <div class="view">
                                <hr class="hr-normal">
                            </div>
                        </div>
                        {{-- PARRAFO = Etiqueta <DIV> (Se utilizaba la <P> pero por inconvenientes con el cleanHtml se utiliza un div normal el cual funciona igual) --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <span class="configuration">
                                <div class="dropdown">
                                    <a id="dLabel" role="button" data-toggle="dropdown" class="btn btn-primary btn-sm dropdown-menu-btn" href="#">
                                        <i class="demo-pli-dot-vertical"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right multi-level" role="menu" aria-labelledby="dropdownMenu">
                                        <li><a href="#" class="nv1" rel="interlineado-x2">{{trans("paleta.tools_interlineado")}}</a></li>
                                        <li class="divider">
                                        </li><li class="dropdown-submenu">
                                            <a tabindex="-1" href="#">{{trans("paleta.tools_color")}}</a>
                                            <ul class="dropdown-menu dropdown-menu-right">
                                                <li class="dropdown-header">{{trans("paleta.tools_color")}}</li>
                                                <li><a href="#" rel="text-primary" class="text-primary nv2">{{trans("paleta.tools_color_negro")}}</a></li>
                                                <li><a href="#" rel="text-success" class="text-success nv2">{{trans("paleta.tools_color_verde")}}</a></li>
                                                <li><a href="#" rel="text-info" class="text-info nv2">{{trans("paleta.tools_color_azul")}}</a></li>
                                                <li><a href="#" rel="text-warning" class="text-warning nv2">{{trans("paleta.tools_color_amarillo")}}</a></li>
                                                <li><a href="#" rel="text-purple" class="text-purple nv2">{{trans("paleta.tools_color_purpura")}}</a></li>
                                                <li><a href="#" rel="text-pink" class="text-pink nv2">{{trans("paleta.tools_color_rosado")}}</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.textos_parrafo")}} <button class="btn btn-xs btn-info"  onclick="return bootbox.alert('{{trans("paleta.textos_parrafo_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view editorParrafo">
                                <div class="editor" contenteditable>{!!trans("paleta.textos_parrafo_contenido")!!}</div>
                            </div>
                        </div>
                        {{-- LISTA = Etiqueta <UL> --}}
                        {{-- <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.textos_lista")}} <button class="btn btn-xs btn-info"  onclick="return bootbox.alert('{{trans("paleta.textos_lista_instruccion")}}')"><i class="fa fa-list-ul text-bold"></i></button>
                            </div>
                            <div class="view">
                                <ul contenteditable="true">
                                    <li class="list-item">Lorem ipsum dolor sit amet</li>
                                    <li class="list-item">Consectetur adipiscing elit</li>
                                    <li class="list-item">Integer molestie lorem at massa</li>
                                    <li class="list-item">Facilisis in pretium nisl aliquet</li>
                                    <li class="list-item">Nulla volutpat aliquam velit</li>
                                    <li class="list-item">Faucibus porta lacus fringilla vel</li>
                                    <li class="list-item">Aenean sit amet erat nunc</li>
                                    <li class="list-item">Eget porttitor lorem</li>
                                </ul>
                            </div>
                        </div> --}}
                        {{-- LISTA ORDENADA = Etiqueta <ol> --}}
                        {{-- <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.textos_lista_ordenada")}}  <button class="btn btn-xs btn-info"  onclick="return bootbox.alert('{{trans("paleta.textos_lista_ordenada_instruccion")}}')"><i class="fa fa-list-ol text-bold"></i></button>
                            </div>
                            <div class="view">
                                <ol contenteditable="true">
                                    <li class="list-item">Lorem ipsum dolor sit amet</li>
                                    <li class="list-item">Consectetur adipiscing elit</li>
                                    <li class="list-item">Integer molestie lorem at massa</li>
                                    <li class="list-item">Facilisis in pretium nisl aliquet</li>
                                    <li class="list-item">Nulla volutpat aliquam velit</li>
                                    <li class="list-item">Faucibus porta lacus fringilla vel</li>
                                    <li class="list-item">Aenean sit amet erat nunc</li>
                                    <li class="list-item">Eget porttitor lorem</li>
                                </ol>
                            </div>
                        </div> --}}
                        {{-- DESCRIPCION = Etiqueta <DL> --}}
                        {{-- <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.textos_descripcion")}}  <button class="btn btn-xs btn-info"  onclick="return bootbox.alert('{{trans("paleta.textos_descripcion_instruccion")}}')"><i class="fa fa-align-center text-bold"></i></button>
                            </div>
                            <div class="view">
                                <dl contenteditable="true">
                                    <dt>Description lists</dt>
                                    <dd>A description list is perfect for defining terms.</dd>
                                    <dt>Euismod</dt>
                                    <dd>Vestibulum id ligula porta felis euismod semper eget lacinia odio sem nec elit.</dd>
                                    <dd>Donec id elit non mi porta gravida at eget metus.</dd>
                                    <dt>Malesuada porta</dt>
                                    <dd>Etiam porta sem malesuada magna mollis euismod.</dd>
                                    <dt>Felis euismod semper eget lacinia</dt>
                                    <dd>Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</dd>
                                </dl>
                            </div>
                        </div> --}}
                        {{-- CITA = Etiqueta <blockquote> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.textos_cita")}}  <button class="btn btn-xs btn-info"  onclick="return bootbox.alert('{{trans("paleta.textos_cita_instruccion")}}')"><i class="fa fa-file-text text-bold"></i></button>
                            </div>
                            <div class="view">
                                <blockquote class="blockquote" contenteditable="true">
                                    <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
                                    <footer class="blockquote-footer">Someone famous in <cite title="Source Title">Source Title</cite></footer>
                                </blockquote>
                            </div>
                        </div>
                        </li>
                    </ul>
                    <ul class="nav nav-list">
                        <li class="nav-header">
                            <button class="btn btn-primary mar-ver btn-block">{{trans("paleta.componentes_title")}}</button>
                        </li>
                        <li class="rows" id="estRows">
                        {{-- TABLA = Etiqueta <table> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <span class="opciones">
                                <div class="col-sm-6 table-toolbar-right">
                                    <div class="form-group">
                                        <input type="text" autocomplete="off" class="form-control no-column" placeholder="Filas" style="width:100px;">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" autocomplete="off" class="form-control no-rows" placeholder="Columnas" style="width:100px;">
                                    </div>
                                    <div class="btn-group">
                                        <button class="btn btn-primary tabla-generate"><i class="ti ti-wand"></i></button>
                                    </div>
                                </div>
                            </span>
                            <span class="configuration">
                                <div class="dropdown">
                                    <a id="dLabel" role="button" data-toggle="dropdown" class="btn btn-primary btn-sm dropdown-menu-btn" href="#">
                                        <i class="demo-pli-dot-vertical"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right multi-level" role="menu" aria-labelledby="dropdownMenu">
                                        <li><a href="#" class="nv1" rel="table-striped">{{trans("paleta.componentes_tabla_rayas")}}</a></li>
                                        <li><a href="#" class="nv1" rel="table-bordered">{{trans("paleta.componentes_tabla_bordes")}}</a></li>
                                        <li><a href="#" class="nv1" rel="table-hover">{{trans("paleta.componentes_tabla_seleccion")}}</a></li>
                                        <li><a href="#" class="nv1" rel="table-condensed">{{trans("paleta.componentes_tabla_pequeña")}}</a></li>
                                    </ul>
                                </div>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_tabla")}}  <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_tabla_instruccion")}}')"><i class="fa fa-table"></i></button>
                            </div>
                            <div class="view">
                                <table class="table dynamic-table" contenteditable="true">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Product</th>
                                            <th>Payment Taken</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>TB - Monthly</td>
                                        <td>01/04/2012</td>
                                        <td>Default</td>
                                    </tr>
                                    <tr class="table-active">
                                        <td>1</td>
                                        <td>TB - Monthly</td>
                                        <td>01/04/2012</td>
                                        <td>Approved</td>
                                    </tr>
                                    <tr class="table-success">
                                        <td>2</td>
                                        <td>TB - Monthly</td>
                                        <td>02/04/2012</td>
                                        <td>Declined</td>
                                    </tr>
                                    <tr class="table-warning">
                                        <td>3</td>
                                        <td>TB - Monthly</td>
                                        <td>03/04/2012</td>
                                        <td>Pending</td>
                                    </tr>
                                    <tr class="table-danger">
                                        <td>4</td>
                                        <td>TB - Monthly</td>
                                        <td>04/04/2012</td>
                                        <td>Call in to confirm</td>
                                    </tr>
                                </tbody>
                                </table>
                            </div>
                        </div>
                        {{-- Encabezado = Etiqueta <H1> + <SMALL> --}}
                        {{-- <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <span class="configuration">
                                <div class="dropdown">
                                    <a id="dLabel" role="button" data-toggle="dropdown" class="btn btn-primary btn-sm dropdown-menu-btn" href="#">
                                        <i class="demo-pli-dot-vertical"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right multi-level" role="menu" aria-labelledby="dropdownMenu">
                                        <li class="dropdown-submenu">
                                            <a tabindex="-1" href="#">{{trans("paleta.tools_color")}}</a>
                                            <ul class="dropdown-menu dropdown-menu-right">
                                                <li class="dropdown-header">{{trans("paleta.tools_color")}}</li>
                                                <li><a href="#" rel="text-primary" class="text-primary nv2">{{trans("paleta.tools_color_negro")}}</a></li>
                                                <li><a href="#" rel="text-success" class="text-success nv2">{{trans("paleta.tools_color_verde")}}</a></li>
                                                <li><a href="#" rel="text-info" class="text-info nv2">{{trans("paleta.tools_color_azul")}}</a></li>
                                                <li><a href="#" rel="text-warning" class="text-warning nv2">{{trans("paleta.tools_color_amarillo")}}</a></li>
                                                <li><a href="#" rel="text-purple" class="text-purple nv2">{{trans("paleta.tools_color_purpura")}}</a></li>
                                                <li><a href="#" rel="text-pink" class="text-pink nv2">{{trans("paleta.tools_color_rosado")}}</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_encabezado")}}  <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_encabezado_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view">
                                <h1 contenteditable="true">Titulo! <small>Subtitulo</small></h1>
                                
                            </div>
                        </div> --}}
                        {{-- ALERTA = Etiqueta <DIV.ALERT> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <span class="configuration">
                                <div class="dropdown">
                                    <a id="dLabel" role="button" data-toggle="dropdown" class="btn btn-primary btn-sm dropdown-menu-btn" href="#">
                                        <i class="demo-pli-dot-vertical"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right multi-level" role="menu" aria-labelledby="dropdownMenu">
                                        <li class="dropdown-submenu">
                                            <a tabindex="-1" href="#">{{trans("paleta.tools_color")}}</a>
                                            <ul class="dropdown-menu dropdown-menu-right">
                                                <li class="dropdown-header">{{trans("paleta.tools_color")}}</li>
                                                <li><a href="#" rel="alert-dark" class="text-primary nv2">{{trans("paleta.tools_color_negro")}}</a></li>
                                                <li><a href="#" rel="alert-success" class="text-success nv2">{{trans("paleta.tools_color_verde")}}</a></li>
                                                <li><a href="#" rel="alert-info" class="text-info nv2">{{trans("paleta.tools_color_azul")}}</a></li>
                                                <li><a href="#" rel="alert-warning" class="text-warning nv2">{{trans("paleta.tools_color_amarillo")}}</a></li>
                                                <li><a href="#" rel="alert-purple" class="text-purple nv2">{{trans("paleta.tools_color_purpura")}}</a></li>
                                                <li><a href="#" rel="alert-pink" class="text-pink nv2">{{trans("paleta.tools_color_rosado")}}</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_alerta")}} <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_alerta_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view">
                                <div class="alert alert-success" contenteditable="true">
                                    <strong>Alert!</strong>
                                    Best check yo self, you're not looking too good.
                                </div>
                            </div>
                        </div>
                        
                        {{-- PANEL = Etiqueta <DIV.PANEL> --}}
                        {{-- <div class="lyrow">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success columna">
                                <i class="ti ti-move"></i>
                            </span>
                            <span class="configuration">
                                <div class="btn-group dropdown">
                                    <button class="btn btn-mint dropdown-toggle" data-toggle="dropdown" type="button" aria-expanded="false">
                                        {{trans("paleta.tools_color")}} <i class="dropdown-caret"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-right" style="">
                                        <li class="dropdown-header">{{trans("paleta.tools_color_total")}}</li>
                                        <li><a href="#" rel="panel-colorful panel-dark" class="text-primary">{{trans("paleta.tools_color_negro")}}</a></li>
                                        <li><a href="#" rel="panel-colorful panel-success" class="text-success">{{trans("paleta.tools_color_verde")}}</a></li>
                                        <li><a href="#" rel="panel-colorful panel-info" class="text-info">{{trans("paleta.tools_color_azul")}}</a></li>
                                        <li><a href="#" rel="panel-colorful panel-warning" class="text-warning">{{trans("paleta.tools_color_amarillo")}}</a></li>
                                        <li><a href="#" rel="panel-colorful panel-purple" class="text-purple">{{trans("paleta.tools_color_purpura")}}</a></li>
                                        <li><a href="#" rel="panel-colorful panel-pink" class="text-pink">{{trans("paleta.tools_color_rosado")}}</a></li>
                                        <li class="dropdown-header">{{trans("paleta.tools_color_parcial")}}</li>
                                        <li><a href="#" rel="panel-dark" class="text-primary">{{trans("paleta.tools_color_negro")}}</a></li>
                                        <li><a href="#" rel="panel-success" class="text-success">{{trans("paleta.tools_color_verde")}}</a></li>
                                        <li><a href="#" rel="panel-info" class="text-info">{{trans("paleta.tools_color_azul")}}</a></li>
                                        <li><a href="#" rel="panel-warning" class="text-warning">{{trans("paleta.tools_color_amarillo")}}</a></li>
                                        <li><a href="#" rel="panel-purple" class="text-purple">{{trans("paleta.tools_color_purpura")}}</a></li>
                                        <li><a href="#" rel="panel-pink" class="text-pink">{{trans("paleta.tools_color_rosado")}}</a></li>
                                    </ul>
                                </div>
                                <a class="btn btn-default" href="#" rel="panel-bordered">{{trans("paleta.tools_borde")}}</a>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_panel")}} <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_panel_instruccion")}}')"><i class="ti ti-layout-column3"></i></button>
                            </div>
                            <div class="view">
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <h3 class="panel-title" contenteditable="true">Titulo</h3>
                                    </div>
                                    <div class="panel-body">
                                        <div class="row clearfix">
                                            <div class="col-md-12 column">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> --}}
                        {{-- PANEL CON PESTAÑA = Etiqueta <DIV.PANEL.PANEL-CONTROL> --}}
                        {{-- <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <span class="configuration">
                                <div class="dropdown">
                                    <a id="dLabel" role="button" data-toggle="dropdown" class="btn btn-primary btn-sm dropdown-menu-btn" href="#">
                                        <i class="demo-pli-dot-vertical"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right multi-level" role="menu" aria-labelledby="dropdownMenu">
                                        <li><a class="nv1" href="#" rel="panel-bordered">{{trans("paleta.tools_borde")}}</a></li>
                                        <li class="dropdown-submenu">
                                            <a tabindex="-1" href="#">{{trans("paleta.tools_color")}}</a>
                                            <ul class="dropdown-menu dropdown-menu-right">
                                                <li class="dropdown-header">{{trans("paleta.tools_color")}}</li>
                                                <li><a href="#" rel="panel-dark" class="text-primary nv2">{{trans("paleta.tools_color_negro")}}</a></li>
                                                <li><a href="#" rel="panel-success" class="text-success nv2">{{trans("paleta.tools_color_verde")}}</a></li>
                                                <li><a href="#" rel="panel-info" class="text-info nv2">{{trans("paleta.tools_color_azul")}}</a></li>
                                                <li><a href="#" rel="panel-warning" class="text-warning nv2">{{trans("paleta.tools_color_amarillo")}}</a></li>
                                                <li><a href="#" rel="panel-purple" class="text-purple nv2">{{trans("paleta.tools_color_purpura")}}</a></li>
                                                <li><a href="#" rel="panel-pink" class="text-pink nv2">{{trans("paleta.tools_color_rosado")}}</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_panel_pestaña")}}  <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_panel_pestaña_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view">
                                <div class="panel panel-primary">
                                    <!--Panel heading-->
                                    <div class="panel-heading">
                                        <div class="panel-control">
                                            <ul class="nav nav-tabs" contenteditable="true">
                                                <li class="active"><a href="#demo-tabs-box-1" data-toggle="tab" aria-expanded="true">Primera Sección</a></li>
                                                <li class=""><a href="#demo-tabs-box-2" data-toggle="tab" aria-expanded="false">Seguna Sección</a></li>
                                            </ul>
                                        </div>
                                        <h3 class="panel-title" contenteditable="true">Titulo</h3>
                                    </div>
                        
                                    <!--Panel body-->
                                    <div class="panel-body">
                                        <div class="tab-content">
                                            <div class="tab-pane fade active in summernote" id="demo-tabs-box-1">
                                                <p class="text-main text-semibold">First Tab Content</p>
                                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
                                            </div>
                                            <div class="tab-pane fade" id="demo-tabs-box-2" contenteditable="true">
                                                <p class="text-main text-semibold">Second Tab Content</p>
                                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> --}}
                        {{-- TABLA PRECIO = Etiqueta <muchas> --}}
                        {{-- <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_tabla_precio")}}  <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_tabla_precio_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view">
                                <div class="row pricing">
                                    <!--Personal Plan-->
                                    <!--===================================================-->
                                    <div class="col-sm-4">
                                        <div class="panel">
                                            <div class="panel-body" contenteditable="true">
                                                <p class="pricing-title">Personal</p>
                                                <div class="pricing-price">
                                                    <p class="text-info">
                                                        <span class="text-normal">$19</span>
                                                        <span>.99</span>
                                                    </p>
                                                </div>
                                                <ul class="pricing-list">
                                                    <li><strong>5</strong> Projects</li>
                                                    <li><strong>10</strong> GB Storage</li>
                                                    <li><strong>5</strong> User</li>
                                                    <li><strong>Free</strong> Support</li>
                                                </ul>
                                                <button class="btn btn-block btn-info">Choose</button>
                                            </div>
                                        </div>
                                    </div>
                                    <!--===================================================-->
                                    <!--Premium Plan-->
                                    <!--===================================================-->
                                    <div class="col-sm-4">
                                        <div class="panel">
                                            <div class="panel-body" contenteditable="true">
                                                <p class="pricing-title">Premium</p>
                                                <div class="pricing-price">
                                                    <p class="text-info">
                                                        <span class="text-normal">$39</span>
                                                        <span>.99</span>
                                                    </p>
                                                </div>
                                                <ul class="pricing-list">
                                                    <li><strong>20</strong> Projects</li>
                                                    <li><strong>100</strong> GB Storage</li>
                                                    <li><strong>50</strong> Users</li>
                                                    <li><strong>Free</strong> Support</li>
                                                </ul>
                                                <button class="btn btn-block btn-info">Choose</button>
                                            </div>
                                        </div>
                                    </div>
                                    <!--===================================================-->
                    
                    
                                    <!--Enterprise Plan-->
                                    <!--===================================================-->
                                    <div class="col-sm-4">
                                        <div class="panel">
                                            <div class="panel-body" contenteditable="true">
                                                <p class="pricing-title">Enterprise</p>
                                                <div class="pricing-price">
                                                    <p class="text-info">
                                                        <span class="text-normal">$89</span>
                                                        <span>.99</span>
                                                    </p>
                                                </div>
                                                <ul class="pricing-list">
                                                    <li><strong>Unlimited</strong> Projects</li>
                                                    <li><strong>Unlimited</strong> GB Storage</li>
                                                    <li><strong>Unlimited</strong> Users</li>
                                                    <li><strong>Free</strong> Support</li>
                                                </ul>
                                                <button class="btn btn-block btn-info">Choose</button>
                                            </div>
                                        </div>
                                    </div>
                                    <!--===================================================-->
                    
                    
                                </div>
                            </div>
                        </div> --}}
                        {{-- PDF = Etiqueta <OBJECT> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <a class="opciones btn btn-info pdf-single">
                                <i class="ti ti-link"></i>
                            </a>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_pdf")}}  <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_pdf_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view">
                                <p>
                                    <div class="embed-responsive embed-responsive-4by3">
                                        <object data="{{asset('text.pdf')}}" type="application/pdf">
                                        </object>
                                    </div>
                                </p>
                            </div>
                        </div>
                        {{-- DIVISOR = Etiqueta <IFRAME> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <a class="opciones btn btn-info video-single">
                                <i class="ti ti-link"></i>
                            </a>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_video")}}  <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_video_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view">
                                <div class="embed-responsive embed-responsive-16by9 videoEmbed">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/zpOULjyy-n8?rel=0" allowfullscreen></iframe>
                                </div>
                            </div>
                        </div>
                        {{-- IMAGEN = Etiqueta <IMG> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <a class="opciones btn btn-info img-single">
                                <i class="ti ti-image"></i>
                            </a>
                            <a class="opciones btn btn-purple img-iframe" href="#">
                                <i class="ti ti-cut"></i>
                            </a>
                            <a class="opciones btn btn-purple bayron" data-fancybox="closeClick  : false"  style="display: none;" data-type="iframe" href=""></a>
                            
                            
                            <span class="configuration">
                                <div class="dropdown">
                                    <a id="dLabel" role="button" data-toggle="dropdown" class="btn btn-primary btn-sm dropdown-menu-btn" href="#">
                                        <i class="demo-pli-dot-vertical"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right multi-level" role="menu" aria-labelledby="dropdownMenu">
                                        <li><a href="#" class="nv1" rel="img-center">{{trans("paleta.tools_centrada")}}</a></li>
                                        <li class="divider"></li>
                                        <li class="dropdown-submenu">
                                        <a tabindex="-1" href="#">{{trans("paleta.tools_estilos")}}</a>
                                        <ul class="dropdown-menu dropdown-menu-right">
                                            <li><a href="#" rel="img-rounded" class="text-primary nv2">{{trans("paleta.tools_estilos_bordes_redondeado")}}</a></li>
                                            <li><a href="#" rel="img-circle" class="text-success nv2">{{trans("paleta.tools_estilos_circulo")}}</a></li>
                                            <li><a href="#" rel="img-thumbnail" class="text-info nv2">{{trans("paleta.tools_estilos_bordes_exterior")}}</a></li>
                                        </ul>
                                        </li>
                                        <li>
                                            <a href="#" class="img-info">
                                                <i class="ti-help"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_imagen")}}  <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_imagen_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view">
                                <img class="img-responsive img-center" src="{{asset('img/4-00003.jpg')}}" alt="Image">
                            </div>
                        </div>
                        
                        {{-- IMAGEN CON LINK = Etiqueta <IMG> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <a class="opciones btn btn-info img-single">
                                <i class="ti ti-image"></i>
                            </a>
                            <a class="opciones btn btn-purple img-iframe" href="#">
                                <i class="ti ti-cut"></i>
                            </a>
                            <a class="opciones btn btn-purple bayron" data-fancybox="closeClick  : false"  style="display: none;" data-type="iframe" href=""></a>
                            
                            <a class="opciones btn btn-info img-link" >
                                <i class="ti ti-link"></i>
                            </a>
                            <span class="configuration">
                                <div class="btn-group dropdown">
                                    <button class="btn btn-mint dropdown-toggle" data-toggle="dropdown" type="button" aria-expanded="false">
                                        {{trans("paleta.tools_estilos")}} <i class="dropdown-caret"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-right" style="">
                                        <li class="dropdown-header">{{trans("paleta.tools_estilos")}}</li>
                                        <li><a href="#" rel="img-rounded" class="text-primary">{{trans("paleta.tools_estilos_bordes_redondeado")}}</a></li>
                                        <li><a href="#" rel="img-circle" class="text-success">{{trans("paleta.tools_estilos_circulo")}}</a></li>
                                        <li><a href="#" rel="img-thumbnail" class="text-info">{{trans("paleta.tools_estilos_bordes_exterior")}}</a></li>
                                    </ul>
                                </div>
                                <a class="btn btn-default" rel="img-center">{{trans("paleta.tools_centrada")}}</a>
                            </span>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_imagen_link")}}  <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_imagen_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view">
                                <a href="#" target="_blank" class="image-link-validar">
                                    <img class="img-responsive" src="{{asset('img/4-00003.jpg')}}" alt="Image">
                                </a>
                            </div>
                        </div>
                        {{-- IMAGEN CON TEXTO = Etiqueta <DIV.PANEL.IMG> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <a class="opciones btn btn-info img-single">
                                <i class="ti ti-image"></i>
                            </a>
                            <a class="opciones btn btn-purple img-iframe" href="#">
                                <i class="ti ti-cut"></i>
                            </a>
                            <a class="opciones btn btn-purple bayron" data-fancybox="closeClick  : false"  style="display: none;" data-type="iframe" href=""></a>
                            
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_imagen_texto")}}  <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_imagen_texto_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view">
                                <div class="panel-body bord-btm text-center" contenteditable="true">
                                        <h3>Titulo de la imagen</h3>
                                        <div class="task-img">
                                            <img class="img-responsive img-center" src="{{asset('img/shared-img-2.jpg')}}" alt="Image">
                                        </div>
                                        <p class="pad-btm pad-top">Descripción relacionada a la imagen colocada</p>
                                        <a href="#" class="task-footer">
                                            <span class="text-sm"><i class="ti ti-calendar"></i> 25/05/2018 03:08</span>
                                        </a>
                                </div>
                            </div>
                        </div>
                        {{-- GALERIA = Etiqueta <DIV.CAROUSEL> --}}
                        <div class="box box-element">
                            <a href="#close" class="remove btn btn-danger">
                                <i class="glyphicon-remove glyphicon"></i>
                            </a>
                            <span class="drag btn btn-success">
                                <i class="ti ti-move"></i>
                            </span>
                            <a class="opciones btn btn-info gallery">
                                <i class="ti ti-image"></i>
                            </a>
                            <a class="opciones btn btn-purple gallery-wizard" data-fancybox="closeClick  : false" data-type="iframe" href="{{ url('/galeria-wizard') }}">
                                <i class="ti ti-wand"></i>
                            </a>
                            <div class="preview pull-right">
                                {{trans("paleta.componentes_galeria")}}  <button class="btn btn-xs btn-primary"  onclick="return bootbox.alert('{{trans("paleta.componentes_galeria_instruccion")}}')"><i class="fa fa-paragraph"></i></button>
                            </div>
                            <div class="view">
                                <div id="carousel-example-generic" class="carousel slide galleryCarousel" data-ride="carousel">
                                <!-- Indicators -->
                                <ol class="carousel-indicators">
                                   
                                    
                                </ol>
                                <!-- Wrapper for slides -->
                                <div class="carousel-inner">
                                    <div class="item active">
                                        <img src="{{asset('img/example.jpg')}}">
                                        <div class="carousel-caption">
                                        </div>   
                                    </div>
                                </div>
                                <!-- Controls -->
                                <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                    <span class="glyphicon glyphicon-chevron-left"></span>
                                </a>
                                <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                    <span class="glyphicon glyphicon-chevron-right"></span>
                                </a>
                                </div>
                            </div>
                        </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End first tab (Contact list)-->


    </div>
