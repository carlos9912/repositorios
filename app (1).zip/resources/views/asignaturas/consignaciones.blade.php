

@php

    use App\Models\Estudiante;
    use Illuminate\Support\Arr;
    use Carbon\Carbon;

    $consignacionesPendiente = [];

@endphp

@extends('layouts.administrador')

@section('title', trans('general.title_crear_pagina'))

@section('titulo-pagina')

    <div id="page-title">

        <h1 class="page-header text-overflow">Reportes</h1>

    </div>    

@endsection

@section('breadcum')

    <ol class="breadcrumb">

        <li><a href="#"><i class="demo-pli-home"></i></a></li>

        <li class="active">Administrador Reportes</li>

    </ol>

@endsection

@section('content')
<div class="row">
    <div class="col-lg-9">
        {!!Form::open(['route' => 'sucursal.cuadre-ganancia', 'id'=>'formBuscarEstado', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Sucursal</label>
                        <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" id="codsucursal" name="codsucursal" aria-hidden="true" data-placeholder="Seleccione un sucursal">
                            <optgroup label="Sucursales">
                            <option value=""></option>
                            <!-- foreach(DB::table('sucursals AS e')->leftJoin('rel_sucursal_sucursal AS r','r.codsucursal','=','e.codsucursal')->where('r.codsucursal','<>',$sucursal->codsucursal)->get() as $estudiante) -->
                            @foreach(DB::table('sucursales AS s')->where('bloqueo', '<>', 1)->orderBy('codsucursal')->get() as $sucursal)
                                <option value="{{$sucursal->codsucursal}}" {{$sucursal->codsucursal==request('codsucursal') ? 'selected' : ''}}>SUC-{{str_pad($sucursal->codsucursal, 4, "0",STR_PAD_LEFT)}} {{$sucursal->nombres.' '.$sucursal->ubicacion}}</option>
                            @endforeach
                            </optgroup>
                        </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>RANGO FECHA ESTADO</label>
                        <div class="input-group" id="default-daterange">
                            <input id="daterange" type="text" name="rango_fecha" class="form-control" value="{{request('rango_fecha')}}" placeholder="Especifique una fecha a buscar" autocomplete="false" />
                            <span class="input-group-append">
                            <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-1">
                    <label>Buscar</label>
                    <button type="submit" class="btn btn-primary">Buscar</button>
                </div>
            </div>
        {{Form::close()}}
        <div class="panel panel-body">
            <div class="row">
                <div class="col-sm-12">
                    <div class="table-responsive" id="tableReportes">
                        <table class="table table-vcenter mar-top">
                            <thead>
                                <tr>
                                    <th class="min-w-td">No. Transacción</th>
                                    <th class="min-w-td text-left">Cliente</th>
                                    <th class="min-w-td text-left">Tipo</th>
                                    <th class="text-right">Valor Transacción</th>
                                    <th class="text-right">Soporte</th>
                                    <th class="text-center">Fecha</th>
                                    <th class="text-center">Estado</th>
                                    <th style="width: 10%;"></th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $secuencia = 0;
                                    $valorVentas = 0;
                                    $valorPorcentaje = 0;
                                @endphp
                                @if(count($listConsignaciones)>0)
                                    @foreach($listConsignaciones as $ventas)
                                        <tr class="{{$ventas->estado==2 ? 'table-warning' : ''}}">
                                            <td class="min-w-td">CO-{{$ventas->codmovimiento}}</td>
                                            <td>
                                                {{$ventas->nombres}}
                                                <br><b>SUC-{{str_pad($ventas->codsucursal, 4, "0",STR_PAD_LEFT)}}</b>
                                            </td>
                                            <td class="min-w-td text-left">{{$ventas->tipo==2 ? 'PRESTAMO' : 'CONSIGNACION'}} </td>
                                            <td class="text-right">$ {{number_format($ventas->valor)}} </td>
                                            @php
                                                if($ventas->estado==2){
                                                    $consignacionesPendiente[] = $ventas->valor;
                                                }
                                                $valorVentas+=($ventas->valor);
                                                $valorPorcentaje+=($ventas->valor)/100*1;
                                            @endphp
                                            <td class="text-right">
                                                <a data-fancybox href="{{asset('soportes/'.$ventas->soporte)}}" class="btn btn-xs btn-purple"><i class="fa fa-link"></i></a>
                                            </td>
                                            <td class="text-right">{{Carbon::parse($ventas->fechaRegistro)->format(trans('general.format_datetime'))}}</td>
                                            <td class="text-right" id="movimientoLabel{{$ventas->codmovimiento}}">
                                            @if($ventas->estado==3)
                                                <span class="label label-danger">RECHAZADO</span>
                                            @elseif($ventas->estado==2)
                                                <span class="label label-warning">PENDIENTE</span>
                                            @else
                                                <span class="label label-success">APROBADO</span>
                                            @endif
                                            </td>
                                            <td class="text-center" style="width: 10%;" id="movimientoBtn{{$ventas->codmovimiento}}">
                                                @if($ventas->estado==2)
                                                    <button class="btn btn-success btn-xs" onclick="return aprobar(1,{{$ventas->codmovimiento}});"><i class="fa fa-check"></i></button>
                                                    <button class="btn btn-danger btn-xs" onclick="return aprobar(3,{{$ventas->codmovimiento}});"><i class="fa fa-times"></i></button>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif    
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-3">
        <div class="card border-0 bg-warning text-white mb-3 overflow-hidden">
            <!-- begin card-body -->
            <div class="card-body" style="padding: 1rem !important;">
                <!-- begin row -->
                <div class="row">
                    <!-- begin col-7 -->
                    <div class="col-xl-12">
                        <!-- begin title -->
                        <div class="text-white">
                            <b>CONSIGNACIONES PENDIENTES</b>
                        </div>
                        <!-- end title -->
                        <!-- begin total-sales -->
                        <div class="d-flex mb-1">
                            <h2 class="mb-0 text-white">
                                $ <span data-animation="number" data-value="64559.25">{{number_format(array_sum($consignacionesPendiente))}}</span> ({{count($consignacionesPendiente)}})
                            </h2>
                        </div>
                        <!-- end total-sales -->
                    </div>
                    <!-- end col-7 -->
                </div>
                <!-- end row -->
            </div>
            <!-- end card-body -->
        </div>
    </div>
</div>

@endsection

@section('script')

<script>

$(".default-select2").chosen();
    $('[data-fancybox]').fancybox({

        toolbar  : false,

        smallBtn : true,

        iframe : {

            preload : false

        }

    });

    $('#demo-dp-range .input-daterange').datepicker({

        format: "dd/mm/yyyy",

        todayBtn: "linked",

        language: 'es',

        autoclose: true,

        todayHighlight: true

    });

    var rowSelection = $('table').DataTable({

        "responsive": true,

        "pageLength": 25,

        "aaSorting": [],

        "language": {

            "paginate": {

                "previous": '<i class="demo-psi-arrow-left"></i>',

                "next": '<i class="demo-psi-arrow-right"></i>'

            }

        }

    });

    $('.btn-evidencias').click(function(){

        var codasignatura = $(this).data("codasignatura");

        $("#codasignaturaEvidencias").val(codasignatura);

        $("#tablaEvidencias").html('');

        frameworkApp.setLoadData({

            url: '{{ url("evidencias") }}',

            data: {

                codasignatura: codasignatura,

            },

            id_container_body: false,

            success: function(data) {

                console.log(data);

                $("#tablaEvidencias").html(data.html);

                $("#modalEditar").modal('show');

                //frameworkApp.setToastSuccess(data.mensaje);

            }

        });

    });

    $('.btn-editar').click(function(){

        var codasignatura = $(this).data("codasignatura");

        frameworkApp.setLoadData({

            url: '{{ url("asignatura/guardar-asignatura") }}',

            data: {

                codasignatura: codasignatura,

                nombreasignatura: $("#nombre"+codasignatura).val(),

                lema: $("#lema"+codasignatura).val(),

                ih: $("#ih"+codasignatura).val(),

                coddocente: $("#coddocente"+codasignatura).val(),

                coddocenteaux: $("#coddocenteAux"+codasignatura).val()

            },

            id_container_body: false,

            success: function(data) {

                frameworkApp.setToastSuccess(data.mensaje);

            }

        });

    });

    function recargar(){

        location.reload();

    }

    function aprobar(opcion, codmovimiento){

        var messageConfirm = "";

        if(opcion==1){

            messageConfirm = "¿Esta seguro de <b class='font-weight-bold text-success'>ACEPTAR</b> la consignación?";

        }else if(opcion==3){

            messageConfirm = "¿Esta seguro de <b class='font-weight-bold text-danger'>RECHAZAR</b> la consignación?";

        }

        frameworkApp.setConfirm({

            message: messageConfirm,

            accept: function () {

                frameworkApp.setLoadData({

                    url: '{{ url("consignaciones/procesar") }}',

                    data: {

                        codmovimiento: codmovimiento,

                        estado: opcion,

                    },

                    id_container_body: false,

                    success: function(data) {

                        //frameworkApp.setToastSuccess(data.mensaje);
                        $.gritter.add({title:"Operación realizada con éxito",text:data.mensaje});
                        if(opcion==1){

                            $("#movimientoBtn"+codmovimiento).html('');

                            $("#movimientoLabel"+codmovimiento).html('<span class="label label-success">APROBADO</span>');

                        }else if(opcion==3){

                            $("#movimientoBtn"+codmovimiento).html('');

                            $("#movimientoLabel"+codmovimiento).html('<span class="label label-danger">RECHAZADO</span>');

                        }

                    }

                });

                //form.submit();

            },

            cancelar : function() {

                frameworkApp.setToastError("Operación cancelada");

                return false;

            }

        });

        return false;

    }

</script>

    

@endsection