

@extends('layouts.admin')
@section('title', trans('general.title_crear_pagina'))
@section('nav-bar')
    <li style="display: none;">
        <div class="btn-group mar-top mar-rgt">
            <button class="btn btn-mint" id="edit"><i class="fa fa-edit"></i> {{trans('botones.editar')}}</button>
        </div>
    </li>
    <li>
        <div class="btn-group mar-top mar-rgt">
            <a class="btn btn-info btn-previsualizar" ><i class="fa fa-eye"></i> {{trans('botones.visualizar')}}</a>
        </div>
    </li>
    <li>
        <div class="btn-group mar-top" id="botonAccion">
            @if (!blank($pagina->id_pagina))
                <button class="btn btn-success btn-guardar-rapido"><i class="fa fa-download"></i> {{trans('botones.guardar_rapido')}}</button>
            @else
            <button class="btn btn-success"id="button-download-modal" data-target="#downloadModal" data-toggle="modal" ><i class="fa fa-download"></i> {{trans('botones.guardar')}}</button>
            @endif
        </div>
    </li>
    <li>
        <a href="#" id="paleta" class="aside-toggle">
            <i class="demo-pli-dot-vertical"></i>
        </a>
    </li>  
@endsection
@section('content')
        <input type="hidden" id="imgBackground" name="imgBackground" value="">
        <input type="hidden" id="id_pagina" name="id_pagina" value="0">
        
        <div class="demo ui-sortable" style="min-height: 497px;" id="donwloadSource">
                @if (!blank($pagina->id_pagina))
                    {!!$pagina->pagina_editor!!}
                @else
                <div class="lyrow ui-draggable" style="">
                    
                    <div class="view">
                        <div class="row" style="background-color: transparent !important;">
                            <div class="col-md-9" style="background-color: transparent !important;">
                                <div class="lyrow ui-draggable" style="">
                                    <a href="#close" class="opciones btn btn-danger btnChange" data-valor="-1">
                                        <i class="ti ti-minus"></i>
                                    </a>
                                    <a href="#close" class="opciones btn btn-success btnChange" data-valor="1">
                                        <i class="ti ti-plus"></i>
                                    </a>
                                    <div class="view">
                                        <div class="row clearfix" style="background-color: transparent !important;">
                                            <div class="col-md-6 column changeDiv ui-sortable" data-col="col-md-6" style="background-color: transparent !important;">
                                            </div>
                                            <div class="col-md-6 column changeDiv ui-sortable" data-col="col-md-6" style="background-color: transparent !important;">
                                            </div>
                                        </div>
                                    </div>
                                </div>        
                            </div>
                            <div class="col-md-3" style="background-color: transparent !important;">
                                    <div class="lyrow ui-draggable" style="">
                                        <a href="#close" class="opciones btn btn-info btnChange">
                                            <i class="ti ti-loop"></i>
                                        </a>
                                        <div class="view">
                                            <div class="row clearfix"  style="background-color: transparent !important;">
                                                <div class="col-md-12 column changeDiv ui-sortable"  style="background-color: transparent !important;">
                                                    <div class="text-center">
                                                        <div class="footerTitle" style="margin-bottom: 10px;">
                                                            <h4 style="color:white;">Desarrollado por</h4>
                                                        </div>
                                                        <a href="http://www.cxeducativa.com/" target="_blank">
                                                            <img class="img-rounded border-color-1" src="{{asset('img/footer/ml25.png')}}" alt="Image" > 
                                                            <p style="margin-top: 10px;"><strong style="color:white;">{{trans('general.copyright')}}</strong></p>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> 
                                
                            </div>
                        </div>
                    </div>
                </div>
                @endif
        </div>
        <div id="download-layout">
            <div class="pad-all">
            </div>
        </div>
      

        {{-- MODAL UTILIZADO PARA CAMBIAR EL IFRAME DEL VIDEO POR EL QUE EL USUARIO DECIDA --}}
        <div class="modal fade" id="modalWindow" role="dialog" tabindex="-1" aria-labelledby="modalWindow" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">

                    <!--Modal header-->
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                        <h4 class="modal-title">{{trans('elementos.cambiar_video_title')}}</h4>
                    </div>

                    <!--Modal body-->
                    <div class="modal-body mar-btm">
                        <input type="hidden" id="idVideo" name="idVideo" value="">
                        <p class="text-semibold text-main">{{trans('elementos.cambiar_video_instruccion')}}</p>
                        <textarea id="sourceVideo" placeholder="Pega el texto aquí..." rows="13" class="form-control" style="overflow:auto;resize:none"></textarea>
                        
                    </div>

                    <!--Modal footer-->
                    <div class="modal-footer">
                        <button data-dismiss="modal" class="btn btn-default" type="button">{{trans('botones.cerrar')}}</button>
                        <button class="btn btn-success" onclick="return changeVideo();">{{trans('botones.cambiar')}}</button>
                    </div>
                </div>
            </div>
        </div>
        
        {{-- MODAL UTILIZADO PARA ADMINISTRAR LOS ARCHIVOS (IMAGENES Y PDF) --}}
        <div id="fileModal" class="modal fade in" tabindex="-1">
            <div class="modal-dialog modal-lg mar-top" style="width: 90%; min-height: 500px;">
                <div class="modal-content" style="min-height: 600px;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="idGallery" name="idGallery" value="">
                        <input type="hidden" id="idImg" name="idImg" value="">
                        <input type="hidden" id="idPdf" name="idPdf" value="">
                        <input type="hidden" id="idBtnArchivo" name="idBtnArchivo" value="">
                        <div class="panel">
                            <div class="pad-all file-manager">
                                <div class="fixed-fluid">
                                    <div class="fixed-sm-200 pull-sm-left file-sidebar">
                                        <div class="bord-btm pad-btm">
                                            {{-- <a href="#" class="btn btn-block btn-lg btn-info v-middle" data-dismiss="modal" data-target="#fileUpdateModal" data-toggle="modal">Subir Archivo</a> --}}
                                            <a href="{{ url('/archivo') }}" target="_blank" class="btn btn-block btn-lg btn-info v-middle" onclick="">{{trans('botones.subir_archivo')}}</a>
                                        </div>
                                        <input type="hidden" id="filtroBusqueda" name="filtroBusqueda" value="">
                                        
                                        <p class="pad-hor mar-top text-main text-bold text-sm text-uppercase">{{trans('elementos.galeria')}}</p>
                                        <div class="list-group bg-trans pad-btm bord-btm" id="contentImg">
                                            
                                        </div>
                                        <button class="btn btn-success btn-block" onclick="generarGallery();">{{trans('botones.generar')}}</button>
                                    </div>
                                    <div class="fluid file-panel" id="fileContent">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="modal fade" id="layoutitModal" tabindex="-1" role="dialog" aria-labelledby="layoutitModal" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content"></div>
            </div>
        </div>

        <div style="display: none;" class="modal fade" id="downloadModal" tabindex="-1" onclick="downloadLayoutSrc()" role="dialog" aria-labelledby="downloadModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">{{trans('paginas.pagina_title_guardadar_pagina')}}</h4>
                </div>
                <div class="modal-body">
                        {{Form::open(['route' => 'paginas.guardar-pagina', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarPagina']) }}  
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label class="control-label">{{trans('paginas.pagina_nombre')}}</label>
                                        {!! Form::text('nombre', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label class="control-label">{{trans('paginas.pagina_menu')}}</label>
                                        {!! Form::select("id_menu", $menus, null, ["id"=>"id_menu", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => trans("menus.placeholder_menu_seleccione_padre"), "required" => "required"]) !!}
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label class="control-label">{{trans('paginas.pagina_principal')}}</label>
                                    <div class="radio mar-top">
                                        <input id="principal" type="checkbox" name="principal" value="{{App\Enums\ESiNo::index(App\Enums\ESiNo::Si)->getId()}}">
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row" id="btnCrear">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <button class="btn btn-mint" type="submit">{{trans('botones.guardar')}}</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {{Form::close()}}

                        <div id="download-logged" class="" style="display: none;">
                            <p>
                                <textarea id="textPreview" style="display: none;">
                                </textarea>
                            </p>
                        </div>
                </div>
                </div>
            </div>
        </div>

@endsection
@section('mega-menu')
    <div class="btn-group mar-top mar-rgt">
        <button class="btn btn-default mega-dropdown-toggle " id="botonBackground"><i class="demo-pli-layout-grid"></i></button>
    </div>
    <div class="dropdown-menu mega-dropdown-menu">
        <div class="row">
            <div class="col-sm-4 col-md-3">
            <p class="dropdown-header"><i class="ti ti-wand"></i> {{trans('elementos.seleccionar_fondo')}}</p>
                <div class="row img-gallery">
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/1.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/1.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/2.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/2.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/3.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/3.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/4.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/4.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/5.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/5.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/6.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/6.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/7.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/7.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/8.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/8.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/9.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/9.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/10.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/10.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/11.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/11.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/12.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/12.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/13.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/13.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/14.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/14.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/15.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/15.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="preview-box">
                            <a class="preview" href="#" data-ruta="{{ asset('img/patterns/16.png')}}">
                                <img class="img-responsive img-rounded img-thumbnail" src="{{ asset('img/patterns/16.png')}}" alt="thumbs">
                            </a>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
@endsection
@section('script')
    <script src="{{asset('plugins/editor/js/jquery-ui-1.10.4.custom.js')}}"></script>
    <script src="{{asset('plugins/editor/js/jquery.htmlClean.js')}}"></script>

    <script src="{{asset('plugins/editor/js/scripts.js')}}"></script>
    <script src="{{asset('plugins/WYSIWYG/editor-texto.js')}}"></script>
    <script src="{{asset('plugins/cropperjs/dist/cropper.js')}}"></script>
    <script src="{{asset('plugins/color-picker/spectrum.js')}}"></script>
    <!--=================================================-->
    
    <script type="text/javascript">
            new Switchery(document.getElementById('principal'));
            //Selecciona las imagenes para ir armando la galeria
            function seleccionarGallery(ruta, nombre) { 
                //Se asigna la ruta para insertarla despues en la galeria
                var a = '<div class="row">';
                    a+= '   <div class="col-sm-8">';
                    a+= '       <a href="#" class="list-group-item text-bold pad-no" data-url="'+ruta+'">';
                    //El nombre es el texto a mostrar en la lista
                    a+='            <span class="text-main"><i class="fa fa-file-img"></i> <small>'+nombre+'</small></span>';
                    a+='        </a>';
                    a+='    </div>';
                    a+='    <div class="col-sm-1" style="margin-right: 5px;">';
                    a+='        <a class="grouped_elements btn btn-xs btn-info" href='+ruta+'><i class="fa fa-eye"></i></a>';
                    a+='    </div>';
                    a+='    <div class="col-sm-1 ">';
                    a+='        <a class="btn btn-xs btn-danger eliminar-elemento-galeria"><i class="fa fa-times"></i></a>';
                    a+='    </div>';
                    a+='</div>';
                //    console.log(a);
                $("#contentImg").append(a);
            }
            
            //Genera la galeria a partir de las iamgenes seleccionadas por el usuario
            function generarGallery(){
                //Obtiene el id asignado a la galleria, si es vacio quiere decir que no hay una galeria seleccionada
                var idGallery = $("#idGallery").val();
                if(idGallery=='') {
                    alert('{{trans('archivos.error_seleccione_imagen')}}');
                } else {
                    //Limpia la galeria
                    $('#'+idGallery+' .carousel-inner').html('');
                    $('#'+idGallery+' .carousel-inner').html('<div class="content-gallery" style="display: none;">'+$( "#contentImg" ).html()+'</div>');
                    $('#'+idGallery+' .carousel-indicators').html('');
                    //Itera las imagenes seleccionadas y las va asignando a la galeria en el html correcto
                    $( "#contentImg a.list-group-item" ).each(function( index ) {
                        $('<div class="item"><img src="'+$( this ).data( "url" )+'" class="img-center"><div class="carousel-caption"></div>   </div>').appendTo('#'+idGallery+' .carousel-inner');
                        $('<li data-target="#'+idGallery+'" data-slide-to="'+index+'"></li>').appendTo('#'+idGallery+' .carousel-indicators');
                    });
                    //Selecciona como activa la primera imagen
                    $('#'+idGallery+' .item').first().addClass('active');
                    $('#'+idGallery+' .carousel-indicators > li').first().addClass('active');
                    //Recarga el elemento
                    $('#'+idGallery).carousel();
                    //Oculta el modal
                    $('#fileModal').modal('hide');
                    //Limpia las imagenes seleccionadas por el usuario
                    $( "#contentImg" ).html('');
                }
            }

            //Cambia la imagen del contenedor
            function cambiarImage(ruta){
                //Obtiene el id asignado a la imagen, si es vacio quiere decir que no hay una imagen seleccionada
                var idImg = $("#idImg").val();
                if(idImg==''){
                    alert('{{trans('archivos.error_seleccione_imagen')}}');
                }else{
                    $("#"+idImg).attr("src",ruta);
                    //Oculta el modal
                    $('#fileModal').modal('hide');
                }
            }

            //Cambia el pdf del contenedor
            function cambiarPDF(ruta){
                //Obtiene el id asignado a la imagen, si es vacio quiere decir que no hay una imagen seleccionada
                var idImg = $("#idPdf").val();
                if(idImg==''){
                    alert('{{trans('archivos.error_seleccione_pdf')}}');
                }else{
                    $("#"+idImg).attr("data",ruta);
                    //Oculta el modal
                    $('#fileModal').modal('hide');
                }
            }

            //Cambia el href de un boton añadido por el editor
            function cambiarBtnArchivo(ruta){
                //Obtiene el id asignado a la archivo, si es vacio quiere decir que no hay una archivo seleccionada
                var idbtnArchivo = $("#idBtnArchivo").val();
                if(idbtnArchivo==''){
                    alert('{{trans('archivos.error_seleccione_boton')}}');
                }else{
                    $("#"+idbtnArchivo).attr("href",ruta);
                    //Oculta el modal
                    $('#fileModal').modal('hide');
                }
            }
            function eliminarArchivo(rutaArchivo, miniatura, ruta){
                var loading = frameworkApp.setLoading();
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type:'POST',
                    url: '{{ route("paginas.eliminar-archivo") }}',
                    data: {rutaArchivo: rutaArchivo, rutaMiniatura: miniatura, rutaActual: ruta},
                    success:function(data){
                        if(data.success){
                            obtenerArchivosDirectorios(data.rutaActual);
                        }
                        loading.remove();
                    }
                });
                return false;
            }

            //Consulta los ficheros y los directorios para el fileManager
            function obtenerArchivosDirectorios(ruta) { 
                var loading = frameworkApp.setLoading();
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type:'POST',
                    url: '{{ route("paginas.ficheros") }}',
                    data: {rutaActual: ruta, ext: $("#filtroBusqueda").val()},
                    success:function(data){
                        $("#fileContent").html(data.html);
                        loading.remove();
                    }
                });
                return false;
            };

            $(document).ready(function () {
                
                $(document).mousedown(function(e) {
                    if(e.which == 3)
                    {
                        e.preventDefault();
                        var url = $(e.target).parents('.box').find('.dropdown-menu-btn').click();
                        return false;
                    }
                    //console.log(e.target.parent('.box'));
                    
                    //console.log(url);
                        //alert(0);
                });
                $("a.gallery-wizard").fancybox({
                    closeBtn    : false, // hide close button
                    closeClick  : false, // prevents closing when clicking INSIDE fancybox
                    helpers     : { 
                        // prevents closing when clicking OUTSIDE fancybox
                        overlay : {closeClick: false} 
                    },
                    keys : {
                        // prevents closing when press ESC button
                        close  : null
                    }
                });
                $(document).on('click','.img-info', function(){
                    var img = $(this).parent().parent().parent().parent().parent().find('img');
                    frameworkApp.setToastSuccess("Las dimensiones de la imagen son alto:"+img[0].height+" x ancho:"+img[0].width);
                });
                $(document).on('click','.image-link-validar', function(){
                    if(confirm("{{trans('archivos.imagen_confirmacion_abrir')}}")){
                        location.href = this.$target.attr('href');
                    }
                    return false;
                });
                $(document).on('click','.img-link', function(e){
                    
                     aEtiqueta = $(this).parent().find('.image-link-validar');
                     console.log(aEtiqueta);
                     url = bootbox.prompt({ 
                     title: "{{trans('archivos.imagen_url_ingresar')}}", 
                     callback: function(result){ 
                        
                             if(result!=''){
                                aEtiqueta.attr("href",result);
                             }else{
                                 alert("{{trans('archivos.imagen_url_ingresar_error')}}");
                             }
                         }
                     })
                    return false;
                });
                $('[data-toggle="tooltip"]').tooltip(); 
                $("#full").spectrum({
                    allowEmpty:true,
                    color: "#ECC",
                    showInput: true,
                    containerClassName: "full-spectrum",
                    showInitial: true,
                    showPalette: true,
                    showSelectionPalette: true,
                    showAlpha: true,
                    maxPaletteSize: 10,
                    preferredFormat: "hex",
                    localStorageKey: "spectrum.demo",
                    hide: function (color) {
                        changeColor(color);
                    },

                    palette: [
                        ["rgb(0, 0, 0)", "rgb(67, 67, 67)", "rgb(102, 102, 102)", /*"rgb(153, 153, 153)","rgb(183, 183, 183)",*/
                        "rgb(204, 204, 204)", "rgb(217, 217, 217)", /*"rgb(239, 239, 239)", "rgb(243, 243, 243)",*/ "rgb(255, 255, 255)"],
                        ["rgb(152, 0, 0)", "rgb(255, 0, 0)", "rgb(255, 153, 0)", "rgb(255, 255, 0)", "rgb(0, 255, 0)",
                        "rgb(0, 255, 255)", "rgb(74, 134, 232)", "rgb(0, 0, 255)", "rgb(153, 0, 255)", "rgb(255, 0, 255)"],
                        ["rgb(230, 184, 175)", "rgb(244, 204, 204)", "rgb(252, 229, 205)", "rgb(255, 242, 204)", "rgb(217, 234, 211)",
                        "rgb(208, 224, 227)", "rgb(201, 218, 248)", "rgb(207, 226, 243)", "rgb(217, 210, 233)", "rgb(234, 209, 220)",
                        "rgb(221, 126, 107)", "rgb(234, 153, 153)", "rgb(249, 203, 156)", "rgb(255, 229, 153)", "rgb(182, 215, 168)",
                        "rgb(162, 196, 201)", "rgb(164, 194, 244)", "rgb(159, 197, 232)", "rgb(180, 167, 214)", "rgb(213, 166, 189)",
                        "rgb(204, 65, 37)", "rgb(224, 102, 102)", "rgb(246, 178, 107)", "rgb(255, 217, 102)", "rgb(147, 196, 125)",
                        "rgb(118, 165, 175)", "rgb(109, 158, 235)", "rgb(111, 168, 220)", "rgb(142, 124, 195)", "rgb(194, 123, 160)",
                        "rgb(166, 28, 0)", "rgb(204, 0, 0)", "rgb(230, 145, 56)", "rgb(241, 194, 50)", "rgb(106, 168, 79)",
                        "rgb(69, 129, 142)", "rgb(60, 120, 216)", "rgb(61, 133, 198)", "rgb(103, 78, 167)", "rgb(166, 77, 121)",
                        /*"rgb(133, 32, 12)", "rgb(153, 0, 0)", "rgb(180, 95, 6)", "rgb(191, 144, 0)", "rgb(56, 118, 29)",
                        "rgb(19, 79, 92)", "rgb(17, 85, 204)", "rgb(11, 83, 148)", "rgb(53, 28, 117)", "rgb(116, 27, 71)",*/
                        "rgb(91, 15, 0)", "rgb(102, 0, 0)", "rgb(120, 63, 4)", "rgb(127, 96, 0)", "rgb(39, 78, 19)",
                        "rgb(12, 52, 61)", "rgb(28, 69, 135)", "rgb(7, 55, 99)", "rgb(32, 18, 77)", "rgb(76, 17, 48)"]
                    ]
                });
                $(document).on('click','.btn-guardar-rapido', function(e){
                    downloadLayoutSrc();
                    var loading = frameworkApp.setLoading();  
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type:'POST',
                        url: '{{ url("guardar-pagina") }}',
                        data: {
                            pagina_editor: $("#donwloadSource").html(),
                            pagina_mostrar: $("#textPreview").val(),
                            id_pagina: $("#id_pagina").val(),
                            img_background: $('#imgBackground').val()
                        },
                        success:function(data){
                            $("#fileContent").html(data.html);
                            loading.remove();
                            frameworkApp.setToastSuccess("{{trans('paginas.paginas_guardar_exito')}}");
                        }
                    });
                });
                $(document).on('click','.btn-previsualizar', function(e){
                    downloadLayoutSrc();
                    var loading = frameworkApp.setLoading();  
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type:'POST',
                        url: '{{ url("guardar-pagina") }}',
                        data: {
                            pagina_editor: $("#donwloadSource").html(),
                            pagina_mostrar: $("#textPreview").val(),
                            id_pagina: $("#id_pagina").val(),
                            img_background: $('#imgBackground').val()
                        },
                        success:function(data){
                            $("#fileContent").html(data.html);
                            loading.remove();
                            var a = document.createElement('a');
                            a.target="_blank";
                            a.href="{{ route('paginas.visualizar', $pagina->id_pagina) }}";
                            a.click();
                            //window.location.href= 
                            //bootbox.alert("guardado exitoso");
                            //loading.remove();
                        }
                    });
                });
                $("#agregarPagina").validate({
                    ignore: ":not(.chosen-select):checkbox",
                    submitHandler: function(form) {
                        var loading = frameworkApp.setLoading();
                        downloadLayoutSrc();
                        $.ajax({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            type:'POST',
                            url: '{{ url("guardar-pagina") }}',
                            data: {
                                pagina_editor: $("#donwloadSource").html(),
                                pagina_mostrar: $("#textPreview").val(),
                                id_pagina: $("#id_pagina").val(),
                                id_menu: $("#id_menu").val(),
                                nombre: $("#nombre").val(),
                                activo: $("#activo:checked").val(),
                                principal: $("#principal:checked").val(),
                                img_background: $('#imgBackground').val()
                            },
                            success:function(data){
                                loading.remove();
                                $("#downloadModal").modal('hide');
                                $("#botonAccion").html('<button class="btn btn-success btn-guardar-rapido"><i class="fa fa-download"></i> {{trans('botones.guardar_rapido')}}</button>');
                                //$("#fileContent").html(data.html);
                            }
                        });
                        return false;
                    },
                    rules: {
                        nombre: 'required',
                        id_menu: 'required',
                        url: 'required',
                    },
                    highlight: function (element, errorClass) {
                    $(element).parents('.form-group').addClass('has-feedback has-error');
                    $(element).parents('.form-group').removeClass('has-feedback has-success');
                    },
                    unhighlight: function (element, errorClass) {
                    $(element).parents('.form-group').removeClass('has-feedback has-error');
                    $(element).parents('.form-group').addClass('has-feedback has-success');
                    },
                    errorPlacement: function(error, element) {
                        if(element.parents('.input-group').length > 0) {
                            error.insertAfter(element.parents('.input-group'));
                        } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                            error.insertAfter(element.parents('.form-group').find('.chosen-container'));
                        } else if(element.parents('.radio').find('.chosen-container').length > 0){
                            error.insertAfter(element.parents('.radio').find('.chosen-container'));
                        } else {
                            error.insertAfter(element);
                        }
                    }
                });
                //Cuando se abre el modal recarga los ficheros
                $('#fileModal').on('show.bs.modal', function (e) {
                    obtenerArchivosDirectorios();
                });
                //Se da click en editar para que se carguen los componentes visuales del editor
                $("#edit").click();
                $("#paleta").click();
                
                //Cuando se abre el modal de cambiar video, le asigna el valor al id del video y lo coloca
                //En el id
                
                $(document).on('click','.generar-link', function(){
                    link();
                    // url = bootbox.prompt({ 
                    // title: "What is your name?", 
                    // callback: function(result){ 
                        
                    //         if(result!=''){
                    //             link(result);
                    //         }
                    //     }
                    // })
                });
                $(document).on('click','.generar-btn-pdf', function(){
                    let id = Math.random().toString(36).substring(7);
                    var texto = document.getSelection();
                    if(texto==''){
                        texto="Click aquí";
                    }
                    document.execCommand('insertHTML', false, '<a href="#" id="idArchivo_'+id+'" class="text-bold btn-source-file grouped_elements"><u>'+texto+'</u></a>');
                    
                    $("#filtroBusqueda").val('');
                    $('#fileModal').modal('show');
                    $("#idBtnArchivo").val("idArchivo_" + id);
                    $("#idGallery").val("");
                    $("#idImg").val("");
                    $("#idPdf").val("");
                });

                $(document).on('click','.eliminar-elemento-galeria', function(){
                    rowGaleria = $(this).parent().parent();
                    if(confirm("¿Desea elminar el elemento seleccionado?")){
                        rowGaleria.remove();
                    }
                    // bootbox.confirm({ 
                    //     title: "Desea elminar el elemento?", 
                    //     message: "Desea elminar el elemento?",
                    //     className: 'panel panel-colorful panel-primary',
                    //     callback: function(result){ 
                    //         if(result){
                    //             rowGaleria.remove();
                    //         }
                    //     }
                    // });
                    
                });

                $(document).on('click','.video-single', function(){
                    let id = Math.random().toString(36).substring(7);
                    $('#modalWindow').modal('show');
                    $("#idVideo").val("id_" + id);
                    $(this).parent().find('.videoEmbed').attr("id", "id_" + id);
                });

                $(document).on('click','.pdf-single', function(){
                    let id = Math.random().toString(36).substring(7);
                    $("#filtroBusqueda").val('pdf');
                    $('#fileModal').modal('show');
                    $("#idBtnArchivo").val("");
                    $("#idGallery").val("");
                    $("#idImg").val("");
                    $("#idPdf").val("idPDF_" + id);
                    $(this).parent().find('object').attr("id", "idPDF_" + id);
                });


                $(document).on('click','.list-group-item', function(){

                });
                $(document).on('click','.gallery', function(){
                    let id = Math.random().toString(36).substring(7);
                    //var id = Math.floor((Math.random() * 20) * 1)*(Math.random() * 20);
                    $("#filtroBusqueda").val('img');
                    $('#fileModal').modal('show');
                    $("#idBtnArchivo").val("");
                    $("#idGallery").val("idGallery_" + id);
                    $("#idImg").val("");
                    $("#idPdf").val("");
                    $( "#contentImg" ).html($(this).parent().find('.content-gallery').html());
                    $(this).parent().find('.galleryCarousel').attr("id", "idGallery_" + id);
                    $(this).parent().find('.carousel-control').attr("href", "#idGallery_" + id);
                    
                });

                $(document).on('click','.gallery-wizard', function(){
                    let id = Math.random().toString(36).substring(7);
                    //var id = Math.floor((Math.random() * 20) * 1)*(Math.random() * 20);
                    $("#filtroBusqueda").val('img');
                    //$('#fileModal').modal('show');
                    $("#idBtnArchivo").val("");
                    $("#idGallery").val("idGallery_" + id);
                    $("#idImg").val("");
                    $("#idPdf").val("");
                    $( "#contentImg" ).html($(this).parent().find('.content-gallery').html());
                    $(this).parent().find('.galleryCarousel').attr("id", "idGallery_" + id);
                    $(this).parent().find('.carousel-control').attr("href", "#idGallery_" + id);
                    
                });
                $(document).on('click','.img-single', function(){
                    let id = Math.random().toString(36).substring(7);
                    //var id = Math.floor((Math.random() * 20) * 1)*(Math.random() * 20);
                    $("#filtroBusqueda").val('img');
                    $('#fileModal').modal('show');
                    $("#idBtnArchivo").val("");
                    $("#idGallery").val("");
                    $("#idImg").val("idImg_" + id);
                    $("#idPdf").val("");
                    $(this).parent().find('.img-responsive').attr("id", "idImg_" + id);
                    
                });

                
            });
            $(document).on('click','.btnChange',function(){
                var valor = $(this).data("valor");
                var componentes= $(this).parent().find('.changeDiv');
                var isBreak=false;
                componentes.each(function(){
                    console.log("Iteracion: 1 isBreak"+isBreak);
                    if(!isBreak){
                        col = $(this).data("col");
                        
                        var colNuevo = (parseInt(col.replace("col-md-", ""))+parseInt(valor));
                        if(colNuevo>12){
                            colNuevo=1;
                            $(this).removeClass(col);
                            $(this).parent().append('<div class="col-md-11 column changeDiv ui-sortable" data-col="col-md-11" style="background-color: transparent !important;"></div>');
                            $(this).data("col","col-md-"+colNuevo);
                            $(this).addClass("col-md-"+colNuevo);
                        }else if(colNuevo==0){
                            var confirmar = confirm("Seguro desea eliminar el contenedor?");
                            if(confirmar){
                                $(this).removeClass(col);
                                $(this).remove();
                            }else{
                                isBreak = true;
                            }
                        }else if(parseInt(col.replace("col-md-", ""))==12&&parseInt(valor)==-1){
                            $(this).removeClass(col);
                            $(this).parent().append('<div class="col-md-1 column changeDiv ui-sortable" data-col="col-md-1" style="background-color: transparent !important;"></div>')
                            $(this).data("col","col-md-"+colNuevo);
                            $(this).addClass("col-md-"+colNuevo);
                        }else{
                            $(this).removeClass(col);
                            $(this).data("col","col-md-"+colNuevo);
                            $(this).addClass("col-md-"+colNuevo);
                        }
                        
                        valor = valor*-1;
                    }
                    
                });
                componentes.each(function(){
                    $(this).sortable({
                        connectWith: ".column",
                        handle: ".drag",
                    });
                });
                
            });
        
            $(document).on('click','.btnChangeVideoSource',function(){
                var contador=0;
                var clase = [];
                var contenedor = [];
                $(this).parent().find('.videoEmbed').each(function(){
                    clase[contador] = $(this).attr("src");
                    contador++;
                });
            
            });
 
 


            $(document).on('click','.tabla-generate', function(){
                //var id = Math.floor((Math.random() * 20) + 1);
                //$('#fileModal').modal('show');
                //$("#idGallery").val("idGallery_" + id);
                //console.log($(this).parent().parent().find('.no-column').val());
                //console.log($(this).parent().parent().find('.no-rows').val());
                var div = $(this).parent().parent().parent().parent().find('.view');
                var rows = new Number($(this).parent().parent().find('.no-column').val());
                var cols = new Number($(this).parent().parent().find('.no-rows').val());
                if(rows*cols>0){
                var tr = [];
                mytable = $('<table></table>').attr({class:"table",contenteditable: "true"});
                thead = $('<thead>').appendTo(mytable);
                tbody = $('<tbody>').appendTo(mytable);
                for (var i = 0; i <= rows; i++) {
                    if (i==0) {
                        var row = $('<tr></tr>').appendTo(thead);
                        for (var j = 0; j < cols; j++) {
                            var p= $('<th>Titulo</th>').appendTo(row);
                        }
                    }else {
                        var row = $('<tr></tr>').appendTo(tbody);
                        for (var j = 0; j < cols; j++) {
                            $('<td></td>').text("Texto de celda").appendTo(row);
                        }
                    }
                }
                //console.log(div);
                div.html(mytable);
                $(this).parent().parent().find('.no-column').val('');
                $(this).parent().parent().find('.no-rows').val('');
                }else{
                    alert('{{trans('archivos.error_crear_tablas')}}');
                }
            });



            $(document).on('hidden.bs.modal', function (e) {
                $(e.target).removeData('bs.modal');
            });
            $('body').on('click', '#continue-share-non-logged', function () {
                $('#share-not-logged').hide();
                $('#share-logged').removeClass('hide');
                $('#share-logged').show();
            });
            $('body').on('click', '#continue-download-non-logged', function () {
                $('#download-not-logged').hide();
                $('#download').removeClass('hide');
                $('#download').show();
                $('#downloadhtml').removeClass('hide');
                $('#downloadhtml').show();
                $('#download-logged').removeClass('hide');
                $('#download-logged').show();
            });
            function changeVideo(){
                var comment = $.trim($("#sourceVideo").val());
                if(comment!=""){
                    $('#modalWindow').modal('hide');
                    var idVideo= $("#idVideo").val();
                    $("#"+idVideo).html(comment);
                    $("#sourceVideo").val('')
                }else{
                    alert('{{trans('archivos.error_crear_video')}}');
                }
                
            }
            
            $('#content-container').css('background', 'url("{{asset('tema2/img/footer/footer-bg-1.png')}}")');
            $('.preview').each(function () {
                var options = jQuery.extend({
                    ruta: null
                }, $(this).data());
                $(this).bind('click', function (e) {
                    var preview_background = 'url("'+options.ruta+'")';
                    $('#imgBackground').val(preview_background);
                    $('#content-container').css('background', preview_background);
                    $("#botonBackground").click();
                    return false;
                });
            });
    </script>
    
    <script>
        function nameFunction() {
            $("#refrescarItem").click();
        }
        function nameFunction2(htmlGaleria) {
            console.log(htmlGaleria);
            var idGallery = $("#idGallery").val();
            if(idGallery=='') {
                alert('{{trans('archivos.error_seleccione_imagen')}}');
            } else {
                //Limpia la galeria
                $('#'+idGallery+' .carousel-inner').html('');
                $('#'+idGallery+' .carousel-indicators').html('');
                //Itera las imagenes seleccionadas y las va asignando a la galeria en el html correcto
                //$(htmlGaleria).find('.task-img').each
                var aList = '';
                $(htmlGaleria).find('.task-img').each(function( index ) {
                    aList+= '<div class="row">';
                    aList+= '   <div class="col-sm-8">';
                    aList+= '       <a href="#" class="list-group-item text-bold pad-no" data-url="'+$( this ).data("url")+'">';
                    //El nombre es el texto a mostrar en la lista
                    aList+='            <span class="text-main"><i class="fa fa-file-img"></i> <small>'+$( this ).data("nombre")+'</small></span>';
                    aList+='        </a>';
                    aList+='    </div>';
                    aList+='    <div class="col-sm-1" style="margin-right: 5px;">';
                    aList+='        <a class="grouped_elements btn btn-xs btn-info" href='+$( this ).data("url")+'><i class="fa fa-eye"></i></a>';
                    aList+='    </div>';
                    aList+='    <div class="col-sm-1 ">';
                    aList+='        <a class="btn btn-xs btn-danger eliminar-elemento-galeria"><i class="fa fa-times"></i></a>';
                    aList+='    </div>';
                    aList+='</div>';
                    $('<div class="item"><img src="'+$( this ).data( "url" )+'" class="img-center"><div class="carousel-caption"></div>   </div>').appendTo('#'+idGallery+' .carousel-inner');
                    $('<li data-target="#'+idGallery+'" data-slide-to="'+index+'"></li>').appendTo('#'+idGallery+' .carousel-indicators');
                });
                $('#'+idGallery+' .carousel-inner').append('<div class="content-gallery" style="display: none;">'+aList+'</div>');
                
                //Selecciona como activa la primera imagen
                $('#'+idGallery+' .item').first().addClass('active');
                $('#'+idGallery+' .carousel-indicators > li').first().addClass('active');
                //Recarga el elemento
                $('#'+idGallery).carousel();
                //Oculta el modal
                //$('#fileModal').modal('hide');
                //Limpia las imagenes seleccionadas por el usuario
                //$( "#contentImg" ).html('');
            }
        }

        
    </script>
    <script type="text/javascript">
        $(document).ready(function () {
            $("#donwloadSource").bind("contextmenu",function(){
                //return false;
            });
        });
        </script>
@endsection
@section('style')
    <link  href="{{asset('plugins/cropperjs/dist/cropper.css')}}" rel="stylesheet">
    <link href="{{asset('plugins/editor/css/layoutit.css')}}" rel="stylesheet">
    <link href="{{asset('plugins/color-picker/spectrum.css')}}" rel="stylesheet">
    <style>
        .footerText{
            color: #FFFFFF !important;
        }
        #page-content{
            color: white;
        }
        .btn-facebook-filled, .btn-facebook-filled:active, .btn-facebook-filled:focus {
            color: white;
            background: #4e68a1;
            border: 2px solid #4e68a1;
        }
        .btn-twitter-filled, .btn-twitter-filled:active, .btn-twitter-filled:focus {
            color: white;
            background: #65b5f2;
            border: 2px solid #65b5f2;
        }
        .btn-pinterest-filled, .btn-pinterest-filled:active, .btn-pinterest-filled:focus {
            color: white;
            background: #d2373b;
            border: 2px solid #d2373b;
        }
        
        .resizable {
            resize: both;
            overflow: auto;
        }
        .column{
            min-height: 300px;
        }
        .interlineado-x2{
            line-height: 2;
        }
        .img-center {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        .view {
            padding: 15px;
        }
        .column.ui-droppable-hover {
            background: #38a53a;
        }
        .carousel-inner > .item > img {
            margin: 0 auto;
        }
        
    </style>
@endsection
@section('aside')
    @include('principal.partials.paleta')
@endsection
@section('editor')
    @include('principal.partials.editor')
@endsection