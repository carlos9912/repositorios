

@php

use App\Models\Estudiante;

use Illuminate\Support\Arr;

use Carbon\Carbon;


$dinero = 0;
$totalEnvio = 0;
$totalEnviado = 0;
$totalRetiro = 0;
$saldo = 0;
$enviado = 0;
$pagado = 0;
$iva = 0;
$costo = 0;
$ganancia_envia = 0;
$ganancia_recibe = 0;

@endphp

@extends('layouts.administrador')

@section('title', trans('general.title_crear_pagina'))

@section('titulo-pagina')

<div id="page-title">

    <h1 class="page-header text-overflow">Reportes</h1>

</div>    

@endsection

@section('breadcum')

<ol class="breadcrumb">

    <li><a href="#"><i class="demo-pli-home"></i></a></li>

    <li class="active">Administrador Reportes</li>

</ol>

@endsection

@section('content')

<div class="row">

    <div class="col-lg-3">
        <div class="panel panel-inverse">
            <!-- begin panel-heading -->
            <div class="panel-heading">
                <h4 class="panel-title">REPORTE DETALLADOS DE CAJA AFA INVERSIONES S.A.S</h4>
            </div>
            <!-- end panel-heading -->
            <!-- begin panel-body -->
            <div class="panel-body">
                    {{Form::open(['route' => 'asignaturas.reportes-buscar-total', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarAsignatura']) }}
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Rango de fecha</label>
                                <div class="input-group" id="default-daterange">
                                    <input id="daterange" type="text" autocomplete="false" name="rango_fecha" class="form-control" value="{{request('rango_fecha')}}" placeholder="Especifique una fecha a buscar" />
                                    <span class="input-group-append">
                                    <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Sucursal</label>
                                <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" id="codsucursal" name="codsucursal" aria-hidden="true" data-placeholder="Seleccione un sucursal" required>
                                    <optgroup label="Sucursales">
                                    <option value=""></option>
                                    <!-- foreach(DB::table('sucursals AS e')->leftJoin('rel_sucursal_sucursal AS r','r.codsucursal','=','e.codsucursal')->where('r.codsucursal','<>',$sucursal->codsucursal)->get() as $estudiante) -->
                                    @foreach(DB::table('sucursales AS s')->get() as $sucursal)
                                        <option value="{{$sucursal->codsucursal}}" {{request('codsucursal')==$sucursal->codsucursal ? 'selected' : ''}}>{{$sucursal->nombres.' '.$sucursal->ubicacion}}</option>
                                    @endforeach
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12">
                    
                                
                            <div class="form-group mt-4">
                                <button class="btn btn-primary btn-block" type="submit">Buscar</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- end panel-body -->
        </div>

    </div>
    <div class="col-lg-9">
        

        <div class="panel">
            <div class="panel-heading">
                <h4 class="panel-title">INFORME GENERAL - AFA INVERSIONES S.A.S</h4>
            </div>

            <div class="panel-body" id="tableReportes">

                <div class="row">

                    @if(\Auth::user()->email!=1)
                        <div class="col-sm-12">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <td>Sucursal</td>
                                        <td>Saldo</td>
                                        <td>Mov.</td>
                                        <td>Envios</td>
                                        <td>Retiros</td>
                                        <td>Dinero Movido</td>
                                        <td>Dinero enviado</td>
                                        <td>Dinero pagado</td>
                                        <td>Iva</td>
                                        <td>Costo</td>
                                        <td>Ganancia Envia</td>
                                        <td>Ganancia Paga</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($listDefinitivas as $sucursales)
                                        <tr>
                                            <td>{{($sucursales["nombre"])}}</td>
                                            <td>{{number_format($sucursales["dinero"])}}</td>
                                            <td>{{($sucursales["cant"])}}</td>
                                            <td>{{($sucursales["envios"])}}</td>
                                            <td>{{($sucursales["retiros"])}}</td>
                                            <td>{{number_format($sucursales["saldo"])}}</td>
                                            <td>{{number_format($sucursales["saldo_envios"])}}</td>
                                            <td>{{number_format($sucursales["saldo_retiros"])}}</td>
                                            <td>{{number_format($sucursales["iva"])}}</td>
                                            <td>{{number_format($sucursales["costo"])}}</td>
                                            <td>{{number_format($sucursales["ganancia_e"])}}</td>
                                            <td>{{number_format($sucursales["ganancia_r"])}}</td>
                                            @php 
                                                $dinero+=$sucursales["dinero"];
                                                $totalEnvio+=$sucursales["cant"];
                                                $totalEnviado+=$sucursales["envios"];
                                                $totalRetiro+=$sucursales["retiros"];
                                                $saldo+=$sucursales["saldo"];
                                                $enviado+=$sucursales["saldo_envios"];
                                                $pagado+=$sucursales["saldo_retiros"];
                                                $iva+=$sucursales["iva"];
                                                $costo+=$sucursales["costo"];
                                                $ganancia_envia+=$sucursales["ganancia_e"];
                                                $ganancia_recibe+=$sucursales["ganancia_r"];
                                            @endphp
                                           
                                        </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr class="bg-primary text-white font-weight-bold">
                                        <td>Total</td>
                                        <td>{{number_format($dinero)}}</td>
                                        <td>{{$totalEnvio}}</td>
                                        <td>{{$totalEnviado}}</td>
                                        <td>{{$totalRetiro}}</td>
                                        <td>{{number_format($saldo)}}</td>
                                        <td>{{number_format($enviado)}}</td>
                                        <td>{{number_format($pagado)}}</td>
                                        <td>{{number_format($iva)}}</td>
                                        <td>{{number_format($costo)}}</td>
                                        <td>{{number_format($ganancia_envia)}}</td>
                                        <td>{{number_format($ganancia_recibe)}}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                    @endif

                </div>

            </div>

        </div>

    </div>

</div>

@endsection

@section('script')

<script>

$(".default-select2").chosen();
$('[data-fancybox]').fancybox({

    toolbar  : false,

    smallBtn : true,

    iframe : {

        preload : false

    }

});
$('#daterange').daterangepicker({

    locale: {
      format: 'DD/MM/YYYY'
    },

    todayBtn: "linked",

    language: 'es',

    autoclose: true,

    todayHighlight: true

});

@if(blank(request('rango_fecha')))
$('#daterange').val('');
@endif


$('.btn-revertir').click(function(){
    var btn = $(this);
    bootbox.confirm({
        message: "<br>Esta seguro de revertir el giro?<br>Quedará como destinatario la misma persona que realizó el envío",
        buttons: {
            confirm: {
                label: 'Revertir',
                className: 'btn-success'
            },
            cancel: {
                label: 'No revertir',
                className: 'btn-danger'
            }
        },
        callback: function (result) {
            if(result){
                console.log(btn.data("codgiro"));
                frameworkApp.setLoadData({
                    url: '{{ url("clientes/revertir-giro") }}',
                    data: {
                        codgiro: btn.data("codgiro"),
                    },
                    id_container_body: false,
                    success: function(data) {
                        bootbox.alert("<strong>Transacción exitosa</strong><br>");     
                    }
                });
            }
        }
    });
    
});

$('#demo-dp-range .input-daterange').datepicker({

    format: "dd/mm/yyyy",

    todayBtn: "linked",

    language: 'es',

    autoclose: true,

    todayHighlight: true

});
$("#agregarAsignatura").validate({

ignore: ":not(.chosen-select):checkbox",

submitHandler: function(form) {

    form.submit();

    return false;

},

rules: {

    codsucursal: 'required',

},

highlight: function (element, errorClass) {

  $(element).parent().addClass('has-feedback has-error');

  $(element).parent().removeClass('has-feedback has-success');

},

unhighlight: function (element, errorClass) {

  $(element).parent().removeClass('has-feedback has-error');

  $(element).parent().addClass('has-feedback has-success');

},

errorPlacement: function(error, element) {

    bootbox.alert("Seleccione una sucursal");

}

});

var handleDataTableButtons=function(){"use strict";0!==$("table").length&&$("table").DataTable(
    {
        dom:"Bfrtip",
        buttons:[
            {extend:"copy",className:"btn-sm"},
            {extend:"excel",className:"btn-sm"},
            {extend:"pdf",className:"btn-sm"},
            {extend:"print",className:"btn-sm"}
            ],
            responsive:!0
        
    }
    )},
    TableManageButtons=function(){"use strict";return{init:function(){handleDataTableButtons()}}}();
TableManageButtons.init();
$('.btn-evidencias').click(function(){

    var codasignatura = $(this).data("codasignatura");

    $("#codasignaturaEvidencias").val(codasignatura);

    $("#tablaEvidencias").html('');

    frameworkApp.setLoadData({

        url: '{{ url("evidencias") }}',

        data: {

            codasignatura: codasignatura,

        },

        id_container_body: false,

        success: function(data) {

            console.log(data);

            $("#tablaEvidencias").html(data.html);

            $("#modalEditar").modal('show');

            //frameworkApp.setToastSuccess(data.mensaje);

        }

    });

});

$('.btn-editar').click(function(){

    var codasignatura = $(this).data("codasignatura");

    frameworkApp.setLoadData({

        url: '{{ url("asignatura/guardar-asignatura") }}',

        data: {

            codasignatura: codasignatura,

            nombreasignatura: $("#nombre"+codasignatura).val(),

            lema: $("#lema"+codasignatura).val(),

            ih: $("#ih"+codasignatura).val(),

            coddocente: $("#coddocente"+codasignatura).val(),

            coddocenteaux: $("#coddocenteAux"+codasignatura).val()

        },

        id_container_body: false,

        success: function(data) {

            frameworkApp.setToastSuccess(data.mensaje);

        }

    });

});

function recargar(){

    location.reload();

}

</script>



@endsection