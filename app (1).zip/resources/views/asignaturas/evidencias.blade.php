
@php
    use App\Models\Estudiante;
@endphp

                    <table class="table table-vcenter mar-top" id="tablaEvidenciasA">
                        <thead>
                            <tr>
                                <th class="min-w-td">Nombre Asignatura</th>
                                <th style="width:1%;">¿Activo?</th>
                                <th style="width:1%;">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        @php
                            $secuencia = 0;
                        @endphp
                            @if(count($asignatura->evidencias)>0)
                            @foreach($asignatura->evidencias as $estudiante)
                                @php
                                    $secuencia++;
                                @endphp
                                <tr>
                                    <td><textarea class="form-control" style="width: 100%; resize: none;" id="descripcion{{$estudiante->codlogro}}">{{$estudiante->descripcion}}</textarea></td>
                                    <td class="text-center">
                                        <input id="estado{{$estudiante->codlogro}}" name="estado" value="1" class="magic-checkbox" type="checkbox" {{ ($estudiante->estado == 1) ? 'checked' : ''}}>
                                        <label for="estado{{$estudiante->codlogro}}"> </label>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group">
                                            <a class="btn btn-sm btn-default btn-hover-success demo-psi-pen-5 add-tooltip btn-editar" data-original-title="Editar" data-codevidencia="{{$estudiante->codlogro}}" data-container="body"></a>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            @else
                                <tr>
                                    <td colspan="3" class="text-center">
                                        NO HAY EVIDENCIAS PARA MOSTRAR
                                    </td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                
<script>
    $('.btn-editar').click(function(){
        $("#modalEditar").modal('show');
    })
    $('.btn-evidencias').click(function(){
        var codasignatura = $(this).data("codasignatura");
        $("#codasignaturaEvidencias").val(codasignatura);
    });
    $('#tablaEvidenciasA').DataTable({
        "pageLength": 5
    });
    $('.btn-editar').click(function(){
        var codevidencia = $(this).data("codevidencia");
        frameworkApp.setLoadData({
            url: '{{ url("evidencia/guardar-evidencia") }}',
            data: {
                codevidencia: codevidencia,
                descripcion: $("#descripcion"+codevidencia).val(),
                estado: $("#estado"+codevidencia).prop('checked')
            },
            id_container_body: false,
            success: function(data) {
                frameworkApp.setToastSuccess(data.mensaje);
            }
        });
    });
</script>