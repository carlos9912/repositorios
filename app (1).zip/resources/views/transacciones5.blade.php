@php
	use Carbon\Carbon;
	use App\Enums\EEstadoVinculacion;
	use App\Enums\ETipoDocumento;
	use App\Models\Apertura;
	use App\Models\Empleado;
	use App\Models\Sucursal;
	use App\Models\Horario;
if(\Auth::user()->bloqueo==1){
    echo '<script>window.location = "'.url('/empleado-bloqueo').'";</script>';
}
$date = Carbon::now();

$dia = $date->format('w');
$hora = $date->format('d/m/y H:i');
$sucursal = Sucursal::find(session('sucursal')->codsucursal);

if($sucursal->bloqueo == 1){
    echo '<script>window.location = "'.url('/sucursal-bloqueo').'";</script>';
}
$horario = $sucursal->horarios()->first();
$horario = $sucursal->horarios()->first();
$horario = blank($horario) ? new Horario() : $horario;
$apertura = $sucursal->aperturas()->orderBy('codrel','desc')->first();
$apertura = blank($apertura) ? new Apertura() : $apertura;
$valido = false;
$validar_apertura = !blank($apertura->fecha)&&$date->format('d/m/y')==Carbon::parse($apertura->fecha)->format('d/m/y') ? true : false;
//dd($validar_apertura);
//dd(request());

if($dia==0){
	
}else if($dia==5){

}else{
	if($horario->jornada_continua_lv==1){
		$rangos = explode(' - ', $horario->horario_c_lv);
	}else{
		/*$mañana = explode(' - ', $horario->horario_m_lv);
		$mañanaPrimero = explode(' ', $mañana[0]);
		$mañanaSegundo = explode(" ", $mañana[1]);
		$mañanaPrimeroP = Carbon::parse($mañanaPrimero[0]);
		if($mañanaPrimero[1]=='pm.'){
			$mañanaPrimeroP->addHours(12);
		}
		$mañanaSegundoP = Carbon::parse($mañanaSegundo[0]);
		if($mañanaSegundo[1]=='pm.'){
			$mañanaSegundoP->addHours(12);
		}

		$tarde = explode(' - ', $horario->horario_t_lv);
		$tardePrimero = explode(" ", $tarde[0]);
		$tardeSegundo = explode(" ", $tarde[1]);
		$tardePrimeroP = Carbon::parse($tardePrimero[0]);
		if($tardePrimero[1]=='pm.'){
			$tardePrimeroP->addHours(12);
		}
		$tardeSegundoP = Carbon::parse($tardeSegundo[0]);
		if($tardeSegundo[1]=='pm.'){
			$tardeSegundoP->addHours(12);
		}
		if($hora->min($mañanaPrimeroP->format('H:i'))&&$hora<$mañanaSegundoP->format('H:i')){
			$valido = true;
		}else if($hora>$tardePrimeroP->format('H:i')&&$hora<$tardeSegundoP->format('H:i')){
			$valido = true;
		}*/
	}
}
@endphp
@extends('layouts.administrador') 
@if(!blank($horario))
	@section('content')
		<style>
			.modal-title{
				text-align: center;
			}
			.modal-header button{
				display: none!important;
			}
			.bootbox-input{

			}
		</style>
		<div id="demo-lg-modal" class="modal fade" tabindex="-1">
			<div class="modal-dialog modal-lg" id="form-modal">
			</div>
		</div>
		<div id="detalle-row">
		{{Form::open(['route' => 'sucursal.abrir-caja', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'abrirCaja']) }} 
			<input type="hidden" name="codcaja" value="{{$apertura->estado==1 ? $apertura->codrel : ''}}"> 
			<div class="row">
				<!-- begin col-3 -->
				@if($apertura->estado==1&&$validar_apertura)
				<div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-green">
						<div class="stats-icon"><i class="fa fa-desktop"></i></div>
						<div class="stats-info">
							<h4>CAJA ABIERTA</h4>
							<h4>Una vez haya finalizado operaciones debe realizar el cierre de la caja</h4>	
						</div>
						<div class="stats-link">
							<a class="btn-caja">Cerrar la caja <i class="fa fa-arrow-alt-circle-right"></i></a>
						</div>
					</div>
				</div>
				@elseif($apertura->estado==2&&$validar_apertura)
				<div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-red">
						<div class="stats-icon"><i class="fa fa-desktop"></i></div>
						<div class="stats-info">
							<h4>CAJA CERRADA</h4>
							<h4>La caja del día se encuentra cerra y no es posible realizar mas operaciones con la caja cerrada</h4>	
						</div>
						<div class="stats-link">
							<a href="#modal-without-animation" data-toggle="modal">Ver detalles <i class="fa fa-arrow-alt-circle-right"></i></a>
                            <div class="modal" id="modal-without-animation">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Detalle de cierre</h4>
                                        </div>
                                        <div class="modal-body">
                                            <table class="table text-dark">
                                                <thead>
                                                    <tr>
                                                        <td>Usuario</td>
                                                        <td>Fecha</td>
                                                    </tr>
                                                </thead>
                                                <tbody class="">
													<tr>
														<td class="text-left">
														@php
															$empleado = Empleado::find($apertura->empleado_registra);
															echo $empleado->nombreCompleto();
														@endphp
														</td>
														<td>{{($apertura->fecha)}}</td>
													</tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Cerrar</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
						</div>
					</div>
				</div>
				@else
				<div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-red">
						<div class="stats-icon"><i class="fa fa-desktop"></i></div>
						<div class="stats-info">
							<h4>CAJA CERRADA</h4>
							<h4>Para iniciar operaciones es necesario realizar la apertura de la caja</h4>	
						</div>
						<div class="stats-link">
							<a class="btn-caja">Realizar apertura <i class="fa fa-arrow-alt-circle-right"></i></a>
						</div>
					</div>
				</div>
				@endif
				<!-- end col-3 -->
				<!-- begin col-3 -->
				<div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-orange">
						<div class="stats-icon"><i class="fa fa-dollar-sign"></i></div>
						<div class="stats-info">
							<h4>Saldo a consignar</h4>
							<p style="margin-bottom: -6px;">$ {{number_format($sucursal->saldo)}} </p>	
						</div>
						<div class="stats-link">
							<a href="{{route('sucursal.estado-cuenta',[$sucursal->codsucursal])}}">Ver estado de cuenta <i class="fa fa-arrow-alt-circle-right"></i></a>
						</div>
					</div>
				</div>
				<!-- end col-3 -->
			</div>
		{{Form::close()}}
		</div>
		@if($apertura->estado==1&&$validar_apertura)
		<div class="form-group row" id="giro-contenedor">
			<!-- begin col-6 -->
			<div class="col-lg-4">
				<!-- begin panel -->
				<div class="panel panel-inverse" data-sortable-id="form-stuff-1">
				    
					<!-- begin panel-heading -->
					<div class="panel-heading">
						<h4 class="panel-title">Enviar Giro</h4>
					</div>
					<!-- end panel-heading -->
					<!-- begin panel-body -->
					<div class="panel-body" >
					    @if($sucursal->cupo>=$sucursal->saldo)
						<h4 class="text-green">¿Quien envia?</h4>
						<hr>
						<form>
							<div class="form-group row m-b-15">
								<label class="col-form-label col-md-3">identificación</label>
								<div class="col-md-9">
										<div class="input-group m-b-10">
											<div class="input-group-prepend">
												{!! Form::select("tipo_documento", ETipoDocumento::items(), 1, ['id'=>'f', "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Tipo", "required" => "required"]) !!}
											</div>
											{!! Form::hidden('tk',base_convert(1,10,16),['id'=>'tk'])!!}
											{!! Form::text('identificacion', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'identificacion_envio' ]) !!}
											<div class="input-group-prepend">
												<button class="btn btn-primary btn-buscar" type="button"><i class="fa fa-search"></i></button>
											</div>
										</div>
								</div>
							</div>
						</form>
						<hr>
						<h4 class="text-primary">¿Quien Recibe?</h4>
						<hr>
						<div class="alert alert-danger fade show m-b-10">
							Es necesario indicarle al sistema primero los datos de quien envía
						</div>
						@else
    						<div class="alert alert-danger fade show m-b-10">
                                <h4 class="text-light">Ha sobrepasado cupo disponible, liberar cupo por consignación</h4>
                            </div>
						@endif
					</div>
					<!-- end panel-body -->
				</div>
				<!-- end panel -->
				<!-- begin panel -->
				<div class="panel panel-inverse" data-sortable-id="form-stuff-1">
					<!-- begin panel-heading -->
					<div class="panel-heading">
						<h4 class="panel-title">Recibir Giro</h4>
					</div>
					<!-- end panel-heading -->
					<!-- begin panel-body -->
					<div class="panel-body" >
						<h4 class="text-green">¿Nùmero cedula quien recibe?</h4>
						<hr>
						<form>
							<div class="form-group row m-b-15">
								<label class="col-form-label col-md-3">identificación</label>
								<div class="col-md-9">
										<div class="input-group m-b-10">
											<div class="input-group-prepend">
												{!! Form::select("tipo_documento", ETipoDocumento::items(), 1, ['id'=>'f', "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Tipo", "required" => "required"]) !!}
											</div>
											{!! Form::hidden('tk',base_convert(1,10,16),['id'=>'tk'])!!}
											{!! Form::text('identificacion', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'identificacion_envio_recibe' ]) !!}
											<div class="input-group-prepend">
												<button class="btn btn-primary btn-buscar-recibe" type="button"><i class="fa fa-search"></i></button>
											</div>
										</div>
								</div>
							</div>
						</form>
						
					</div>
					<!-- end panel-body -->
				</div>
				<!-- end panel -->
				
			</div>
			<!-- end col-6 -->
			<!-- begin col-6 -->
			<div class="col-lg-6" id="giro-contenedor-recibe">
			@if(!blank(session('last_m'))&&session('last_m')!=0)
				
				<a data-fancybox="" data-type="iframe" href="{{url('factura')}}?m={{(session('last_m'))}}" class="btn btn-primary btn-factura" style="display: none;">
					Open demo
				</a>
				@php
					session(['last_m' =>  0]);
				@endphp
			@endif
			</div>
			<!-- end col-6 -->
		</div>
		@endif
		
	@endsection
	@section('script')
		<script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>
		<script>
			$('.btn-caja').click(function(){
				bootbox.confirm({
					@if($apertura->estado==1&&$validar_apertura)
					message: "<br>La caja se encuentra abierta<br><br><b>¿Desea cerrar la caja y finalizar operaciones?<br>NO PODRA VOLVER A REALIZAR OPERACIONES UNA VEZ FINALICE!</b>",
					@else
					message: "<br>La caja se encuentra cerrada<br><br><b>¿Desea abrir la caja e iniciar operaciones?</b>",
					@endif
					buttons: {
						cancel: {
							label: 'Cancelar',
							className: 'btn-danger'
						},
						confirm: {
							@if($apertura->estado==1&&$validar_apertura)
							label: 'Cerrar caja',
							@else
							label: 'Abrir caja',
							@endif
							
							className: 'btn-success'
						}
					},
					callback: function (result) {
						if(result){
							$("#abrirCaja").submit();
						}
					}
				});
			});
			$('.btn-factura').click();
			$('.btn-buscar').click(function(){
				$(".loader2").show();
				
				$.ajax({				
						dataType: 'json',
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						type: 'POST',
						url: '{{ url("clientes/buscar") }}',				
						data: {identificacion: $("#identificacion_envio").val(), tk:  $("#tk").val()},
						success: function(data) {
							if(data.identificacion==-1){
								bootbox.confirm({
									message: "<br>El número de identificación no se encuentra en la base de datos<br>¿Desea registrarlo?",
									buttons: {
										confirm: {
											label: 'Registrar',
											className: 'btn-success'
										},
										cancel: {
											label: 'Verificar identificación',
											className: 'btn-danger'
										}
									},
									callback: function (result) {
										if(result){
											var codcliente = $(this).data("codcliente");
											$.ajax({
												url: "{{ url('clientes/consultar-transacciones') }}",
												headers: {
													'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
												},
												type: 'post',
												data: {
													codcliente: codcliente
												},
												success: function(result){
													console.log(0);
													$("#demo-lg-modal").modal("show");
													$('#form-modal').html(result.formulario);
												}
											});
										}
									}
								});
							}else{
								$('#giro-contenedor').html(data.html);
							}
							$(".loader2").hide();
						},
						error: function(obj, typeError, text, data) {
							console.log(obj);
							frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
						},
					});
				
			});
			$('.btn-buscar-recibe').click(function(){
				$(".loader2").show();
				
				$.ajax({				
					dataType: 'json',
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					type: 'POST',
					url: '{{ url("clientes/buscar") }}',				
					data: {identificacion: $("#identificacion_envio_recibe").val(), tk:  $("#tk").val()},
					success: function(data) {
						$(".loader2").hide();
						var codigo_cliente = data.codigo;
						console.log(codigo_cliente);
						if(data.identificacion==-1){
							bootbox.confirm({
								message: "<br>El número de identificación no se encuentra en la base de datos<br>¿Desea registrarlo?",
								buttons: {
									confirm: {
										label: 'Registrar',
										className: 'btn-success'
									},
									cancel: {
										label: 'Verificar identificación',
										className: 'btn-danger'
									}
								},
								callback: function (result) {
									if(result){
										if(result){
											var codcliente = $(this).data("codcliente");
											$.ajax({
												url: "{{ url('clientes/consultar-transacciones') }}",
												headers: {
													'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
												},
												type: 'post',
												data: {
													codcliente: codcliente
												},
												success: function(result){
													console.log(0);
													$("#demo-lg-modal").modal("show");
													$('#form-modal').html(result.formulario);
												}
											});
										}
									}
								}
							});
						}else{
							bootbox.prompt({
					
								buttons: {
									confirm: {
										label: 'Verificar giro',
										className: 'btn-success'
									},
									cancel: {
										label: 'No tengo un código',
										className: 'btn-danger'
									}
								},
								inputType: 'number',
								title: "Ingrese el código enviado por mensaje de texto", 
								locale: 'custom',
								callback: function (result) {
									$(".loader2").show();
										setTimeout(function(){ 
											$.ajax({				
											dataType: 'json',
											headers: {
												'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
											},
											type: 'POST',
											url: '{{ url("clientes/buscar-giro") }}',				
											data: {codcliente: codigo_cliente, codigo:  result},
											success: function(data) {
												console.log(data);
												if(data.existe==1){
													$('#giro-contenedor-recibe').html(data.html);
												}else if(data.existe==0){
													$('#giro-contenedor-recibe').html('');
													frameworkApp.setAlert('Con el código <b>'+result+'</b> el cliente no tiene giros registrado');
												}else if(data.existe==2){
													$('#giro-contenedor-recibe').html('');
													frameworkApp.setAlert('El giro con el código <b>'+result+'</b> ya fue cobrado por parte del cliente');
												}
											},
											error: function(obj, typeError, text, data) {
												console.log(obj);
												frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
											},
										});

										$(".loader2").hide();
									}, 500);
									
								}
							});	
						}
						
					},
					error: function(obj, typeError, text, data) {
						console.log(obj);
						frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
					},
				});
				
			});
		</script>
	@endsection
@else
@section('content')
	
<div class="row">
	<!-- begin col-3 -->
	<div class="col-lg-8">
		<div class="widget widget-stats bg-red">
			<div class="stats-icon"><i class="fa fa-calendar"></i></div>
			<div class="stats-info">
				<h4>No es posible realizar transacciones</h4>
				<p>No dispone de horario para operar.<br>Por favor contacte con el administrador</p>	
			</div>
		</div>
	</div>
</div>
@endsection
	
@endif
