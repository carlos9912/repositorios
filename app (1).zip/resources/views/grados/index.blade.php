
@php
    use App\Models\Curso;
@endphp
@extends('layouts.administrador')
@section('title', trans('general.title_crear_pagina'))
@section('titulo-pagina')
    <div id="page-title">
        <h1 class="page-header text-overflow">Administrador Grados</h1>
    </div>    
@endsection
@section('breadcum')
    <ol class="breadcrumb">
        <li><a href="#"><i class="demo-pli-home"></i></a></li>
        <li class="active">Administrador Estudiantes</li>
    </ol>
@endsection
@section('content')
    
    <div class="row">
		<div class="col-md-12">
			<div class="panel">
            <!--===================================================-->
                <div class="panel-body">
                    <table class="table table-vcenter mar-top">
                        <thead>
                            <tr>
                                <th class="min-w-td">#</th>
                                <th>Full Name</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        @php
                            $secuencia = 0;
                        @endphp
                            @foreach(Curso::where('orden','>',0)->orderBy('orden')->get() as $grado)
                                @php
                                    $secuencia++;
                                @endphp
                                <tr>
                                    <td class="min-w-td">{{$grado->orden}}</td>
                                    <td>
                                        {!! Form::text("nombrecurso", $grado->nombrecurso, ["id"=>"nombrecurso".$grado->codcurso, "class" => "form-control " . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "required" => "required"]) !!}
                                    </td>
                                    <td>
                                        {!! Form::select("director", $listDocentes, $grado->director, ["id"=>"director".$grado->codcurso, "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione Director 1", "required" => "required"]) !!}
                                    </td>
                                    <td>
                                        {!! Form::select("codirector", $listDocentes, $grado->codirector, ["id"=>"codirector".$grado->codcurso, "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione Director 2", "required" => "required"]) !!}
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group">
                                            <div class="btn-group dropdown">
                                                <button class="btn btn-purple dropdown-toggle" data-toggle="dropdown">
                                                    <i class="ti-printer"></i>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a href="#">Action</a></li>
                                                    <li><a href="#">Another action</a></li>
                                                    <li><a href="#">Something else here</a></li>
                                                    <li class="divider"></li>
                                                    <li><a href="#">Separated link</a></li>
                                                </ul>
                                            </div>
                                            <button class="btn btn-mint btn-editar" data-id_grado="{{$grado->codcurso}}"><i class="ti-pencil-alt"></i></button>
                                            <button class="btn btn-primary"><i class="ti-menu-alt"></i></button>
                                            
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modalEditar" role="dialog" tabindex="-1" aria-labelledby="modalWindow" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <!--Modal header-->
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                        <h4 class="modal-title">{{trans('elementos.cambiar_video_title')}}</h4>
                    </div>
                    <!--Modal body-->
                    <div class="modal-body mar-btm">
                        <input type="hidden" id="idVideo" name="idVideo" value="">
                        <p class="text-semibold text-main">{{trans('elementos.cambiar_video_instruccion')}}</p>
                        <textarea id="sourceVideo" placeholder="Pega el texto aquí..." rows="13" class="form-control" style="overflow:auto;resize:none"></textarea>
                    </div>
                    <!--Modal footer-->
                    <div class="modal-footer">
                        <button data-dismiss="modal" class="btn btn-default" type="button">{{trans('botones.cerrar')}}</button>
                        <button class="btn btn-success" onclick="return changeVideo();">{{trans('botones.cambiar')}}</button>
                    </div>
                </div>
            </div>
        </div>
@endsection
@section('script')
<script>
    $(window).on('load', function(){
        var rowSelection = $('table').DataTable({
        "responsive": true,
        "pageLength": 15,
        "language": {
            "paginate": {
                "previous": '<i class="demo-psi-arrow-left"></i>',
                "next": '<i class="demo-psi-arrow-right"></i>'
            }
        }
    });
        $('.btn-editar').click(function(){
            var cod_grado = $(this).data("id_grado");
            frameworkApp.setLoadData({
                url: '{{ url("grados/guardar-grado") }}',
                data: {
                    cod_grado: cod_grado,
                    nombrecurso: $("#nombrecurso"+cod_grado).val(),
                    director: $("#director"+cod_grado).val(),
                    codirector: $("#codirector"+cod_grado).val(),
                },
                id_container_body: false,
                success: function(data) {
                    frameworkApp.setToastSuccess(data.mensaje);
                }
            });
        });
    });
</script>
    <script>
        
        $('.dateranges').daterangepicker({
    		ranges: {
                'Hoy': [moment(), moment()],
                'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Ultimos 7 dias': [moment().subtract(6, 'days'), moment()],
                'Ultimos 30 dias': [moment().subtract(29, 'days'), moment()],
                'Todo este mes': [moment().startOf('month'), moment().endOf('month')],
                'Todo el mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            alwaysShowCalendars: true,
    		locale: {
    	      format: 'DD/MM/YYYY'
    	    },
            
        });
    
    function consultarPagina(idPagina){
        frameworkApp.setLoadData({
            url: '{{ url("paginas/informacion-pagina") }}',
            data: {
                id_pagina: idPagina
            },
            id_container_body: false,
            success: function(data) {
                $("#informacionPagina").html(data.informacionPagina);
                $("#editarModal").modal('show');
            }
        });
    }

    function eliminarPagina(idPagina){
        bootbox.confirm({ 
            title: "{{trans('general.atencion')}}", 
            message: "{{trans('paginas.paginas_confirmacion_eliminar')}}",
            callback: function(result){ 
                if(result){
                    frameworkApp.setLoadData({
                        url: '{{ url("eliminar-pagina") }}',
                        data: {
                            id_pagina: idPagina
                        },
                        id_container_body: false,
                        success: function(data) {
                            frameworkApp.setToastSuccess('{{trans('paginas.paginas_eliminacion_exitosa')}}');
                            //bootbox.alert("{{trans('paginas.paginas_eliminacion_exitosa')}}");
                            $("#tablaPaginas").html(data.tablaPaginas);
                            $('#table-paginas').DataTable({
                                "responsive": true,
                                "language": {
                                    "paginate": {
                                    "previous": '<i class="demo-psi-arrow-left"></i>',
                                    "next": '<i class="demo-psi-arrow-right"></i>'
                                    }
                                }
                            });
                            $('.add-tooltip').tooltip();
                            $('.add-tooltip').on('click', function () {
                                $(this).attr('data-original-title', 'changed tooltip');
                                $('.add-tooltip').tooltip();
                                $(this).mouseover();
                            });
                        }
                    });
                }
            }
        });
        
    }

    
    @if(blank(request()->get('rango_fechas')))
        $("#rango_fechas").val('');
    @endif
    
    </script>
@endsection