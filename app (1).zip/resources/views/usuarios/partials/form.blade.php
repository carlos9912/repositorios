
@php

    use App\Models\Estudiante;
    use Carbon\Carbon;
    use Illuminate\Support\Arr;
    use App\Enums\ETipoDocumento;

    $pendientes = 0;

    $meses = ["01"=>"ENERO", "02" => "FEBRERO", "03" => "MARZO", "04" => "ABRIL", "05" => "MAYO", "06" => "JUNIO", "07" => "JULIO", "08" => "AGOSTO", "09" => "SEPTIEMBRE", "10" => "OCTUBRE", 11 =>"NOVIEMBRE", "12" => "DICIEMBRE"];

    $pendientes = 0;
    $dia_n = '';
    $mes_n = '';
    $anualidad_n = '';
    $dia_e = '';
    $mes_e = '';
    $anualidad_e = '';
    
@endphp

    

    
            <div class="modal-content">
                <div class="modal-body">
                    <!-- begin panel -->
					<div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                            <!-- begin panel-heading -->
                            <div class="panel-heading">
                                <h4 class="panel-title">Creación de Clientes</h4>
                            </div>
                            <!-- end panel-heading -->
                            <!-- begin panel-body -->
                            <div class="panel-body">
                                    {{Form::open(['route' => 'clientes.crear-clientes', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarAsignatura']) }}  
                                        {!! Form::hidden('codcliente', $cliente->codcliente) !!}
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-3">Identificación</label>
                                            <div class="col-md-9">
                                                <div class="input-group m-b-10">
                                                    <div class="input-group-prepend">
                                                        {!! Form::select("tipo_documento", ETipoDocumento::items(), $cliente->tipo_documento, ["id"=>"id_menu_padre", "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Tipo", "required" => "required"]) !!}
                                                    </div>
                                                    {!! Form::text('identificacion', $cliente->identificacion, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-3">Nombres</label>
                                            <div class="col-md-4">
                                                {!! Form::text('nombres', $cliente->nombres, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                            </div>
                                            <label class="col-form-label col-md-1">Apellidos</label>
                                            <div class="col-md-4">
                                                {!! Form::text('apellidos', $cliente->apellidos, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                            </div>
                                        </div>
                                        <div class="form-group row m-b-15">
                                            
                                        </div>
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-3">Celular</label>
                                            <div class="col-md-4">
                                                {!! Form::text('celular', $cliente->celular, ['id'=>'celular','class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off']) !!}
                                            </div>
                                            <label class="col-form-label col-md-1">Confirmar</label>
                                            <div class="col-md-4">
                                                {!! Form::text('celular_confirmar', $cliente->celular, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'correo' ]) !!}
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row m-b-15">
                                            
                                        </div>
                                        
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-3">Dirección</label>
                                            <div class="col-md-9">
                                                {!! Form::text('direccion', $cliente->direccion, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row m-b-15">
                                            
                                        </div>
                                        
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-3">Ocupación</label>
                                            <div class="col-md-9">
                                                <input type="text" class="form-control " value="{{$cliente->ocupacion}}" name="ocupacion" id="start" autocomplete="off"/>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-3">Rango de Ingresos</label>
                                            <div class="col-md-4">
                                                <input type="text" class="form-control " value="{{$cliente->ingresos}}" name="ingresos" id="start" autocomplete="off"/>
                                            </div>
                                            
                                            <label class="col-form-label col-md-1">Empresa</label>
                                            <div class="col-md-4">
                                                <input type="text" class="form-control " value="{{$cliente->empresa}}" name="empresa" id="start" autocomplete="off"/>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row m-b-15">
                                        </div>
                                        <div class="form-group">
                                            <button class="btn btn-primary" type="submit">Guardar Cliente</button>
                                        </div>
                                                
                                    {{Form::close()}}
                            </div>
                            <!-- end panel-body -->
                        </div>
                        <!-- end panel -->
                </div>
            </div>

<script>
    // Prepare to show a date picker linked to three select controls
    function actualizarFechaNac() {
        $('#fecha_nacimiento').val((Number($('#fecha_anualidad_nac').val())) + '/' +
            $('#fecha_mes_nac').val() + '/' + (Number($('#fecha_dia_nac').val())));
        return {};
    }

    // Prepare to show a date picker linked to three select controls
    function actualizarFechaexp() {
        $('#fecha_expedicion').val((Number($('#fecha_anualidad_exp').val())) + '/' +
            $('#fecha_mes_exp').val() + '/' + (Number($('#fecha_dia_exp').val())));
        return {};
    }
    $('.datepicker').datepicker();
    $("#agregarAsignatura").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            form.submit();
            return false;
        },
        rules: {
            ingresos: {
              digits: true  
            },
            nombres: 'required',
            apellidos: 'required',
            tipo_documento: 'required',
            identificacion: 'required',
            direccion: 'required',
            ciudad: 'required',
            departamento: 'required',
            ocupacion: 'required',
            celular: 'required',
            celular_confirmar: {
                equalTo: "#celular"
            },
        },
        highlight: function (element, errorClass) {
          $(element).parent().addClass('has-feedback has-error');
          $(element).parent().removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parent().removeClass('has-feedback has-error');
          $(element).parent().addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.hasClass("no-label")){

            } else if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });

    $(function(){
        $.dobPicker({
            daySelector: '#fecha_dia_nac', /* Required */
            monthSelector: '#fecha_mes_nac', /* Required */
            yearSelector: '#fecha_anualidad_nac', /* Required */
            dayDefault: 'Día', /* Optional */
            monthDefault: 'Mes', /* Optional */
            yearDefault: 'Año', /* Optional */
            minimumAge: 0, /* Optional */
            maximumAge: 100 /* Optional */
        });
        $.dobPicker({
            daySelector: '#fecha_dia_exp', /* Required */
            monthSelector: '#fecha_mes_exp', /* Required */
            yearSelector: '#fecha_anualidad_exp', /* Required */
            dayDefault: 'Día', /* Optional */
            monthDefault: 'Mes', /* Optional */
            yearDefault: 'Año', /* Optional */
            minimumAge: 0, /* Optional */
            maximumAge: 100 /* Optional */
        });
       $("#fecha_dia_nac").change(function(){
            actualizarFechaNac();
        });
       $("#fecha_mes_nac").change(function(){
            actualizarFechaNac();
        }); 
       $("#fecha_anualidad_nac").change(function(){
            actualizarFechaNac();
        });
        $("#fecha_dia_exp").change(function(){
            actualizarFechaexp();
        });
       $("#fecha_mes_exp").change(function(){
            actualizarFechaexp();
        }); 
       $("#fecha_anualidad_exp").change(function(){
            actualizarFechaexp();
        });
       $(".chosen-container").css("width","100%");  
       $("#fecha_anualidad_exp").change();
       $("#fecha_mes_nac").change();
       @if(!blank($cliente->codcliente))
            $("#fecha_dia_nac").val('{{str_pad($dia_n, 2, "0", STR_PAD_LEFT)}}');
            $("#fecha_mes_nac").val('{{str_pad($mes_n, 2, "0", STR_PAD_LEFT)}}');
            $("#fecha_anualidad_nac").val('{{$anualidad_n}}');
            $("#fecha_dia_exp").val('{{str_pad($dia_e, 2, "0", STR_PAD_LEFT)}}');
            $("#fecha_mes_exp").val('{{str_pad($mes_e, 2, "0", STR_PAD_LEFT)}}');
            $("#fecha_anualidad_exp").val('{{$anualidad_e}}');
            $('#fecha_expedicion').val('{{($cliente->fecha_expedicion)}}');
            $('#fecha_nacimiento').val('{{($cliente->fecha_nacimiento)}}');
       @endif
   })

    
</script>
    