


@php





    use App\Models\Estudiante;


    use Carbon\Carbon;


    use Illuminate\Support\Arr;


    use App\Enums\ETipoDocumento;





    $pendientes = 0;





@endphp


@extends('layouts.administrador')


@section('title', 'Clientes')


@section('titulo-pagina')


    <div id="page-title">


        <h1 class="page-header text-overflow">Administrador Clientes</h1>


    </div>    


@endsection


@section('breadcum')


    <ol class="breadcrumb">


        <li><a href="#"><i class="demo-pli-home"></i></a></li>


        <li class="active">Administrador Clientes</li>


    </ol>


@endsection


@section('content')


    <div class="panel panel-inverse">


        <div class="panel-heading ui-sortable-handle">


            <div class="btn-group pull-right">


                <button type="button" class="btn btn-success btn-sm abrir-modal" >Crear Cliente</button>


            </div>


            <h4 class="panel-title">Administrar Clientes</h4>


        </div>


        <div class="panel-body">


            <div class="col-md-12">


                    <div class="panel">


                        <!--===================================================-->


                        <div class="panel-body">


                            <div class="table-responsive">


                                <table class="table table-vcenter mar-top">


                                    <thead>


                                        <tr>


                                            <th class="text-center" style="width: 5%;">Documento</th>


                                            <th class="min-w-td">Nombres</th>


                                            <th class="min-w-td">Apellidos</th>


                                            <th>Dirección</th>


                                            <th>Telefonos</th>


                                            <th>Email</th>


                                            <th></th>


                                        </tr>


                                    </thead>


                                    <tbody>


                                    @php


                                        $secuencia = 0;


                                    @endphp


                                        @foreach(DB::table('clientes')->get() as $estudiante)


                                            @php


                                                $secuencia++;


                                            @endphp


                                            <tr>


                                                <td>


                                                    {{$estudiante->identificacion}}


                                                </td>


                                                <td>


                                                    {{$estudiante->nombres}}


                                                </td>


                                                <td>


                                                    {{$estudiante->apellidos}}


                                                </td>


                                                <td>


                                                    {{$estudiante->direccion}}


                                                </td>


                                                <td>


                                                    {{$estudiante->fijo.' - '.$estudiante->celular}}


                                                </td>


                                                <td class="text-center">


                                                    {{$estudiante->email}}


                                                </td>


                                                <td class="text-center mar-rgt" style="width: 5%;">


                                                    <div class="btn-group">


                                                        <a class="btn btn-sm btn-primary btn-hover-success fa fa-edit text-white abrir-modal" data-codcliente="{{$estudiante->codcliente}}"></a>


                                                        <a class="btn btn-sm btn-danger btn-hover-success fa fa-trash text-white add-tooltip eliminar-cliente" data-codcliente="{{$estudiante->codcliente}}"></a>


                                                        <!-- <a class="btn btn-sm btn-primary btn-hover-success add-tooltip btn-evidencias ti ti-receipt" data-original-title="Registrar Consignación" data-toggle="modal" data-target="#modalFormArchivo" data-codasignatura="{{$estudiante->nombres}}" data-container="body"></a> -->


                                                    </div>


                                                </td>


                                            </tr>


                                        @endforeach


                                        


                                    </tbody>


                                </table>


                            </div>


                        </div>


                    </div>


                </div>


        </div>


    </div>


    





    <div id="demo-lg-modal" class="modal fade" tabindex="-1">


        <div class="modal-dialog modal-lg" id="form-modal">


            


        </div>


    </div>


@endsection


@section('script')


<script>



$(function(){
    $('.abrir-modal').click(function(){
        var codcliente = $(this).data("codcliente");
        $.ajax({
            url: "{{ url('clientes/consultar') }}",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'post',
            data: {
                codcliente: codcliente
            },
            success: function(result){
                console.log(0);
                $("#demo-lg-modal").modal("show");
                $('#form-modal').html(result.formulario);
            }
        });
    });

    $('.eliminar-cliente').click(function(){
        var codcliente = $(this).data("codcliente");
        bootbox.confirm({
            message: '<strong>Mensaje de confirmación:</strong> <br><br>¿Esta seguro de eliminar al cliente?',
            closeButton: false,
            buttons: {
                confirm: {
                    label: 'Aceptar',
                    className: 'btn-success'
                },
                cancel: {
                    label: 'Cancelar',
                    className: 'btn-danger'
                }
            },
            callback: function (result) {
                if (result) {
                    $.ajax({
                        url: "{{ url('clientes/eliminar') }}",
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: 'post',
                        data: {
                            codcliente: codcliente
                        },
                        success: function(result){
                            $.gritter.add({title:"Operación realizada con éxito",text:"El registro fue eliminado con éxito"});
                        }
                    });
                }
            }
        });
    });
    var handleDataTableButtons=function(){"use strict";0!==$("table").length&&$("table").DataTable(
    {
        dom:"Bfrtip",
        buttons:[
            {extend:"copy",className:"btn-sm"},
            {extend:"excel",className:"btn-sm"},
            {extend:"pdf",className:"btn-sm"},
            {extend:"print",className:"btn-sm"}
            ],
            responsive:!0
        
    }
    )},
    TableManageButtons=function(){"use strict";return{init:function(){handleDataTableButtons()}}}();
TableManageButtons.init();
});


   








  


</script>


    


@endsection