<div class="table-responsive">
    <table class="table table-striped table-vcenter" id="table-paginas">
        <thead>
            <tr>
                <th></th>
                <th>{{trans('paginas.pagina_titulo')}}</th>
                <th class="text-center">{{trans('paginas.pagina_estado')}}</th>
                <th class="text-center">{{trans('paginas.pagina_principal')}}</th>
                <th class="text-center">{{trans('paginas.pagina_fecha_creacion')}}</th>
                <th class="text-center">{{trans('paginas.pagina_ultima_modificacion')}}</th>
                <th class="text-center">{{trans('paginas.pagina_acciones')}}</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($listPaginas as $pagina)
                <tr>
                    <td class="text-center">
                            <button class="btn btn-{{$pagina->color}} btn-icon btn-circle">
                                @if($pagina->imagen==App\Enums\EIcono::index(App\Enums\EIcono::No)->getId())
                                    <i class="{{$pagina->class_icon}}"></i>
                                @elseif($pagina->imagen==App\Enums\EIcono::index(App\Enums\EIcono::Si)->getId())
                                    <img src="{{url("/storage/menu/".$pagina->class_icon)}}" alt="">
                                @else

                                @endif
                            </button>
                    </td>
                    <td>
                        {{$pagina->titulo}}
                    </td>
                    <td class="text-center">
                        {!!App\Enums\EEstadoPagina::result($pagina->estado)->getAssistant()!!}
                        
                    </td>
                    <td class="text-center">
                        
                        @if($pagina->principal==App\Enums\EEstadoPagina::index(App\Enums\ESiNo::Si)->getId())
                            <a class="btn btn-success btn-sm"><i class="fa fa-check-circle"></i></a>
                        @else
                            <a class="btn btn-danger btn-sm"><i class="fa fa-times-circle"></i></a>
                        @endif
                    </td>
                    <td class="text-center">
                        <span class="text-muted">{{Carbon\Carbon::parse($pagina->fecha_creacion)->format(trans('general.format_datetime'))}}</span>
                    </td>
                    <td class="text-center">
                            <span class="text-muted">{{blank($pagina->fecha_modificacion) ? trans('paginas.pagina_title_sin_modificacion') : Carbon\Carbon::parse($pagina->fecha_modificacion)->format(trans('general.format_datetime'))}}</span>
                    </td>
                    <td class="min-width">
                        <div class="btn-groups">
                            <a href="{{ route('paginas.editar', $pagina->id_pagina) }}" class="btn btn-icon ti ti-pencil-alt icon-lg add-tooltip" data-original-title="{{trans('paginas.pagina_tooltip_editar_contenido')}}" data-container="body"></a>
                            <a href="#" onclick="return consultarPagina({{$pagina->id_pagina}});" class="btn btn-icon ti-pencil icon-lg add-tooltip" data-original-title="{{trans('paginas.pagina_tooltip_editar_informacion')}}" data-container="body"></a>
                            <a href="{{ route('paginas.navegar', ["menu" => $pagina->id_menu, "nombre" => strtolower(str_replace(" ","-", $pagina->nombremenu))]) }}" class="btn btn-icon ti ti-eye icon-lg add-tooltip" target="_blank" data-original-title="{{trans('paginas.pagina_tooltip_ver_pagina')}}" data-container="body"></a>
                            <a href="#" onclick="return eliminarPagina({{$pagina->id_pagina}});" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="{{trans('paginas.pagina_tooltip_eliminar')}}" data-container="body"></a>
                        </div>
                    </td>
                </tr> 
            @endforeach
        </tbody>
    </table>
</div>