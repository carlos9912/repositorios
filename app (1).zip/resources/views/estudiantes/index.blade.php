
@php
    use App\Models\Estudiante;
@endphp
@extends('layouts.administrador')
@section('title', trans('general.title_crear_pagina'))
@section('titulo-pagina')
    <div id="page-title">
        <h1 class="page-header text-overflow">Administrador Estudiantes</h1>
    </div>    
@endsection
@section('breadcum')
    <ol class="breadcrumb">
        <li><a href="#"><i class="demo-pli-home"></i></a></li>
        <li class="active">Administrador Estudiantes</li>
    </ol>
@endsection
@section('content')
    <div class="row">
        <div class="panel">
            <div class="panel-body">
                <div class="form-inline pad-top">
                    <div class="row">
                        {{Form::open(['route' => 'estudiantes.index-consultar']) }}  
                            <div class="col-md-3">
                                {!! Form::select("codcurso", $listGrados, null, ["id"=>"director", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione Grado"]) !!}
                            </div>     
                            <div class="col-md-1">
                                {{ Form::selectRange('anualidad', \Carbon\Carbon::today()->year,2016,  request('anualidad', \Carbon\Carbon::today()->year),['class'=>'form-control']) }}
                            </div>       
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-info">BUSCAR</button>
                            </div> 
                        {{Form::close()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
		<div class="col-md-12">
			<div class="panel">
            <!--===================================================-->
                <div class="panel-body">
                    <table class="table table-vcenter mar-top">
                        <thead>
                            <tr>
                                <th class="min-w-td">#</th>
                                <th class="min-w-td">User</th>
                                <th>Full Name</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Grado</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        @php
                            $secuencia = 0;
                        @endphp
                            @foreach($listEstudiantes as $estudiante)
                                @php
                                    $secuencia++;
                                @endphp
                                <tr>
                                    <td class="min-w-td">{{$secuencia}}</td>
                                    <td><img src="{{asset('img/fotos/'.$estudiante->img)}}" alt="Profile Picture" class="img-circle img-sm"></td>
                                    <td>{{$estudiante->documento}}</td>
                                    <td><a class="btn-link font-bold" href="#">{{$estudiante->nombres.' '.$estudiante->apellidos}}</a></td>
                                    <td>{{$estudiante->email}}</td>
                                    <td>
                                    @switch($estudiante->estadoCurso)
                                        @case(1)
                                            <span class="label label-success">{{$estudiante->nombrecurso}}</span>
                                        @break
                                        @case(2)
                                            <span class="label label-danger">{{$estudiante->nombrecurso}}</span>
                                        @break
                                        @case(3)
                                            <span class="label label-info">{{$estudiante->nombrecurso}}</span>
                                        @break
                                    @endswitch
                                        
                                    </td>
                                    <td class="text-center">
                                    <div class="btn-group">
                                        <a class="btn btn-sm btn-default btn-hover-success demo-psi-pen-5 add-tooltip btn-editar" href="#" data-original-title="Editar" data-container="body"></a>
                                        <a class="btn btn-sm btn-default btn-hover-warning demo-pli-unlock add-tooltip"  target="_blank" href="{{route('estudiantes.detalle',['codestudiante' =>encrypt($estudiante->codestudiante)])}}"  data-original-title="Ficha Acumulativa" data-container="body"></a>
                                        <a class="btn btn-sm btn-default btn-hover-danger btn-matricular demo-pli-trash add-tooltip" target="_blank" href="{{route('estudiantes.matriculas',['codestudiante' => $estudiante->codestudiante])}}" data-original-title="Delete" data-container="body"></a>
                                    </div>
                                    </td>
                                </tr>
                            @endforeach
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modalEditar" role="dialog" tabindex="-1" aria-labelledby="modalWindow" aria-hidden="true">
    </div>
@endsection
@section('script')
<script>
    $(window).on('load', function(){
        var rowSelection = $('table').DataTable({
        "responsive": true,
        "language": {
            "paginate": {
                "previous": '<i class="demo-psi-arrow-left"></i>',
                "next": '<i class="demo-psi-arrow-right"></i>'
            }
        }
    });
    
    $('.btn-editar').click(function(){
        $("#modalEditar").modal('show');
    })
    $('table').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            rowSelection.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
    });
    function recargar(){
        location.reload();
    }
</script>
    
@endsection