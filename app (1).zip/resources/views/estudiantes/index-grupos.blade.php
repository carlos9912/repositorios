
@php
    use App\Models\Estudiante;
@endphp
@extends('layouts.administrador')
@section('title', trans('general.title_crear_pagina'))
@section('titulo-pagina')
    <div id="page-title">
        <h1 class="page-header text-overflow">Administrador Estudiantes</h1>
    </div>    
@endsection
@section('breadcum')
    <ol class="breadcrumb">
        <li><a href="#"><i class="demo-pli-home"></i></a></li>
        <li class="active">Administrador Estudiantes</li>
    </ol>
@endsection
@section('content')
    <div class="row">
        <div class="panel">
            <div class="panel-body">
                <div class="form-inline pad-top">
                    <div class="row">
                        {{Form::open(['route' => 'estudiantes.index-consultar-grupos']) }}  
                            <div class="col-md-2">
                                {!! Form::select("codcurso", $listGrados, null, ["id"=>"director", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione Grado"]) !!}
                            </div>     
                            <div class="col-md-3">
                            {!! Form::select("codasignatura", $listAsignaturas, null, ["id"=>"director", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Seleccione Asignatura"]) !!}
                            </div>      
                            <div class="col-md-1">
                                {{ Form::selectRange('anualidad', \Carbon\Carbon::today()->year,2016,  request('anualidad', \Carbon\Carbon::today()->year),['class'=>'form-control']) }}
                            </div>       
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-info">BUSCAR</button>
                            </div> 
                        {{Form::close()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
		<div class="col-md-6">
			<div class="panel">
            <!--===================================================-->
                <div class="panel-body">
                    {{Form::open(['route' => 'estudiantes.vincular-grupos']) }} 
                    {{Form::hidden('codasignatura', request('codasignatura')) }}
                    {{Form::hidden('codcurso', request('codcurso')) }}
                    {{Form::hidden('anualidad', request('anualidad')) }}   
                    <button class="btn btn-primary pull-right mar-btm">Vincular estudiantes al grupo</button>
                    <br>
                    <table class="table table-vcenter mar-top">
                        <thead>
                            <tr>
                                <th class="min-w-td">#</th>
                                <th class="min-w-td">User</th>
                                <th>Full Name</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        @php
                            $secuencia = 0;
                        @endphp
                            @foreach($listEstudiantes as $estudiante)
                                @php
                                    $secuencia++;
                                @endphp
                                <tr>
                                    <td class="min-w-td">{{$secuencia}}</td>
                                    <td><img src="{{asset('img/fotos/'.$estudiante->img)}}" alt="Profile Picture" class="img-circle img-sm"></td>
                                    <td>{{$estudiante->documento}}</td>
                                    <td><a class="btn-link font-bold" href="#">{{$estudiante->nombres.' '.$estudiante->apellidos}}</a></td>
                                    <td>{{$estudiante->email}}</td>
                                    <td class="text-center">
                                        <input id="matricular{{$estudiante->codestudiante}}" name="matricular[]" value="{{$estudiante->codestudiante}}" class="magic-checkbox" type="checkbox">
                                        <label for="matricular{{$estudiante->codestudiante}}">Vincular?</label>
                                    </td>
                                </tr>
                            @endforeach
                            
                        </tbody>
                    </table>
                    {{Form::close() }}  
                </div>
            </div>
        </div>
		<div class="col-md-6">
			<div class="panel">
            <!--===================================================-->
                <div class="panel-body">
                    {{Form::open(['route' => 'estudiantes.desvincular-grupos']) }} 
                    {{Form::hidden('codasignatura', request('codasignatura')) }}
                    {{Form::hidden('codcurso', request('codcurso')) }}
                    {{Form::hidden('anualidad', request('anualidad')) }}   
                    <button class="btn btn-danger pull-right mar-btm">Desvincular estudiantes del grupo</button>
                    <br>
                    <table class="table table-vcenter mar-top">
                        <thead>
                            <tr>
                                <th class="min-w-td">#</th>
                                <th class="min-w-td">User</th>
                                <th>Full Name</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        @php
                            $secuencia = 0;
                        @endphp
                            @foreach($listEstudiantesVinculados as $estudiante)
                                @php
                                    $secuencia++;
                                @endphp
                                <tr>
                                    <td class="min-w-td">{{$secuencia}}</td>
                                    <td><img src="{{asset('img/fotos/'.$estudiante->img)}}" alt="Profile Picture" class="img-circle img-sm"></td>
                                    <td>{{$estudiante->documento}}</td>
                                    <td><a class="btn-link font-bold" href="#">{{$estudiante->nombres.' '.$estudiante->apellidos}}</a></td>
                                    <td>{{$estudiante->email}}</td>
                                    <td class="text-center">
                                        <input id="desmatricular{{$estudiante->codestudiante}}" name="desmatricular[]" value="{{$estudiante->codestudiante}}" class="magic-checkbox" type="checkbox">
                                        <label for="desmatricular{{$estudiante->codestudiante}}">Desvincular?</label>
                                    </td>
                                </tr>
                            @endforeach
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modalEditar" role="dialog" tabindex="-1" aria-labelledby="modalWindow" aria-hidden="true">
    </div>
@endsection
@section('script')
<script>
    $(window).on('load', function(){
        var rowSelection = $('table').DataTable({
        "responsive": true,
        "language": {
            "paginate": {
                "previous": '<i class="demo-psi-arrow-left"></i>',
                "next": '<i class="demo-psi-arrow-right"></i>'
            }
        }
    });
    
    $('.btn-editar').click(function(){
        $("#modalEditar").modal('show');
    });
    });
    function recargar(){
        location.reload();
    }
</script>
    
@endsection