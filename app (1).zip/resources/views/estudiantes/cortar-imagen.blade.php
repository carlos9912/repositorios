@extends('layouts.admin')
@section('title', trans('general.title_administrar_archivos'))
@section('content')
  <div class="row">
    <div class="col-sm-10 col-sm-offset-1">
      <div class="panel panel-success bord-all">
        <div class="panel-heading">
          <h3 class="panel-title text-bold">{{trans('archivos.imagen_subir_editar')}}</h3>
        </div>
        <div class="panel-body row" style="min-height: 590px;">
          <div class="col-md-12" >
            <!-- <h3 class="page-header">Demo:</h3> -->
            <div class="img-container">
              <img src="{{ asset($imagen) }}?timestamp={{$numero}}" alt="Picture" id="imgCropper">
            </div>
            <div class="col-md-12 docs-buttons">
                <!-- <h3 class="page-header">Toolbar:</h3> -->
                <div class="btn-group">
                  <button class="btn btn-primary" data-method="setDragMode" data-option="move" type="button" title="Move">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setDragMode", "move")">
                      <span class="fa fa-arrows"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="setDragMode" data-option="crop" type="button" title="Crop">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setDragMode", "crop")">
                      <span class="fa fa-crop"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="zoom" data-option="0.1" type="button" title="Zoom In">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("zoom", 0.1)">
                      <span class="fa fa-search-plus"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="zoom" data-option="-0.1" type="button" title="Zoom Out">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("zoom", -0.1)">
                      <span class="fa fa-search-minus"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="rotate" data-option="-45" type="button" title="Rotate Left">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("rotate", -45)">
                      <span class="fa fa-rotate-left"></span>
                    </span>
                  </button>
                  <button class="btn btn-primary" data-method="rotate" data-option="45" type="button" title="Rotate Right">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("rotate", 45)">
                      <span class="fa fa-rotate-right"></span>
                    </span>
                  </button>
                </div>
                <div class="btn-group btn-group" data-toggle="buttons">
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="1.7777777777777777" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio1" name="aspestRatio" value="1.7777777777777777" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 16 / 9)">
                      16:9
                    </span>
                  </label>
                  <label class="btn btn-primary active" id="aspestRatio2Label" data-method="setAspectRatio" data-option="1.3333333333333333" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio2" name="aspestRatio" value="1.3333333333333333" type="radio" selected>
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 4 / 3)">
                      4:3
                    </span>
                  </label>
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="1" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio3" name="aspestRatio" value="1" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 1 / 1)">
                      1:1
                    </span>
                  </label>
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="0.6666666666666666" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio4" name="aspestRatio" value="0.6666666666666666" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", 2 / 3)">
                      2:3
                    </span>
                  </label>
                  <label class="btn btn-primary" data-method="setAspectRatio" data-option="NaN" title="Set Aspect Ratio">
                    <input class="sr-only" id="aspestRatio5" name="aspestRatio" value="NaN" type="radio">
                    <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("setAspectRatio", NaN)">
                      Free
                    </span>
                  </label>
                </div>
                
                <button type="button" class="btn btn-secondary" style="display: none;" data-method="getData" data-option="" data-target="#putData" id="btnDataCropper">
                  <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="cropper.getData()">
                    Get Data
                  </span>
                </button>
                    {{Form::open(['route' => 'paginas.guardar-imagen-crop', 'id' => 'informacionDocente']) }}
                    {!! Form::hidden('dataCrop', null,['id' => 'putData']) !!}
                    {!! Form::hidden('imagen', $imagen,['id' => 'putData']) !!}
                    {!! Form::close() !!}
                <button class="btn btn-mint" data-method="getCroppedCanvas" type="button">
                  <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper("getCroppedCanvas")">
                      <span class="fa fa-check"></span>
                      
                      {{trans('botones.finalizar')}}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
    </div>
  </div>
  <!-- Show the cropped image in modal -->
  <div class="modal fade docs-cropped" id="getCroppedCanvasModal" aria-hidden="true" aria-labelledby="getCroppedCanvasTitle" role="dialog" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bord-btm">
          <h4 class="modal-title" id="getCroppedCanvasTitle">{{trans('archivos.imagen_terminada')}}</h4>
          <div class="pull-right">
            <button type="button" class="btn btn-danger" data-dismiss="modal">{{trans('botones.seguir_editando')}}</button>
            <a class="btn btn-primary" id="download" href="javascript:void(0);" onclick="return convasToBlob();">{{trans('botones.cortar')}}</a>
          </div>
        </div>
        <div class="modal-body" id="modalBodyCanvas"></div>
        <!-- <div class="modal-footer">
          <button class="btn btn-primary" data-dismiss="modal" type="button">Close</button>
        </div> -->
        
      </div>
      
    </div>
  </div>

  
  {{-- MODAL UTILIZADO PARA ADMINISTRAR LOS ARCHIVOS (IMAGENES Y PDF) --}}
  <div id="fileModal" class="modal fade in" tabindex="-1">
      <div class="modal-dialog modal-lg mar-top" style="width: 90%;">
          <div class="modal-content" style="min-height: 600px;">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
              </div>
              <div class="modal-body">
                  <input type="hidden" id="idGallery" name="idGallery" value="">
                  <input type="hidden" id="idImg" name="idImg" value="">
                  <input type="hidden" id="idPdf" name="idPdf" value="">
                  <input type="hidden" id="idBtnArchivo" name="idBtnArchivo" value="">
                  <div class="panel">
                      <div class="pad-all file-manager">
                          <div class="fixed-fluid">
                              <div class="fluid file-panel" id="fileContent">
                                  
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
@endsection

@section('script')
  <script src="{{asset('plugins/cropperjs/dist/cropper.js')}}"></script>
  <script src="{{asset('plugins/cropperjs/configuracion.js')}}"></script>
  <script src="{{asset('plugins/canvas-blob/js/canvas-to-blob.min.js')}}"></script>

  <script>
    $(document).ready(function () {
        
        $("#aspestRatio5").click();
        $('#getCroppedCanvasModal').on('show.bs.modal', function (e) {
          $("#btnDataCropper").click();
        });
      });
      
      
      
      
      function convasToBlob() {
          var loading = frameworkApp.setLoading();
          $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              dataType: 'json',
              type:'POST',
              url: '{{ url("cortar-imagen-crop") }}',
              data: new FormData($("#informacionDocente")[0]),
              processData: false,
              contentType: false,
              id_container_body: false,
              success: function(data) {
                loading.remove();
                    var ruta=$("#imgCropper").attr("src");
                    ruta = ruta.replace("?timestamp={{$numero}}",'');
                    
                    parent.cambiarImage(ruta+"?timestamp="+Math.random().toString(36).substring(7));
                    //parent.cambiarImage('asasa.jpg');
                    //parent.nameFunction2($("#contentGallery"));
                    parent.jQuery.fancybox.close();
                    //$('#getCroppedCanvasModal').modal('hide');
              },
          });
      }

      
  </script>
@endsection
@section('style')
    <link  href="{{asset('plugins/cropperjs/dist/cropper.css')}}" rel="stylesheet">
    <link  href="{{asset('plugins/cropperjs/configuracion.css')}}" rel="stylesheet">
    <style>
        .img-center {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
@endsection