@php
    use Illuminate\Support\Str;
@endphp

@section('title', Str::title($nombre))
@extends('layouts.app')
@section('informacion')
    <li>{!!$parametro->horario!!}</li>
@endsection
@section('navbar')
    @if (Illuminate\Support\Arr::exists($listMenus,1))
        @foreach ($listMenus[1] as $menuNv1)
            <li class="dropdown singleDrop {{$coloresPlantilla[$menuNv1->color]}}">
                
                @if (Illuminate\Support\Arr::exists($listMenus,$menuNv1->id_menu))
                    <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        <i class="fa {{$menuNv1->class_icon}} bg-{{$coloresPlantilla[$menuNv1->color]}}" aria-hidden="true"></i> <span class="">{{$menuNv1->nombre}}</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-left">
                        @foreach ($listMenus[$menuNv1->id_menu] as $menuNv2)
                            @if(Illuminate\Support\Arr::exists($listMenus,$menuNv2->id_menu))
                            <li class="dropdown dropdown-submenu ">
                                <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa {{$menuNv2->class_icon}}" aria-hidden="true"></i> {{$menuNv2->nombre}}
                                </a>
                                <ul class="dropdown-menu">
                                @foreach ($listMenus[$menuNv2->id_menu] as $menuNv3)
                                    <li class=""><a href="{{(blank($menuNv3->url)) ? route('paginas.navegar', ["menu" => $menuNv3->id_menu, "nombre" => Str::slug($menuNv3->nombre)]) : $menuNv3->url}}" target="{{\App\Enums\ETarget::result($menuNv3->target)->getDescription()}}">{{$menuNv3->nombre}}</a></li>
                                @endforeach
                                </ul>    
                            </li>
                            @else
                                <li class="">
                                    <a href="{{(blank($menuNv2->url)) ? route('paginas.navegar', ["menu" => $menuNv2->id_menu, "nombre" => Str::slug($menuNv2->nombre)]) : $menuNv2->url}}" target="{{\App\Enums\ETarget::result($menuNv2->target)->getDescription()}}">
                                        <i class="fa {{$menuNv2->class_icon}}" aria-hidden="true"></i> {{$menuNv2->nombre}}
                                    </a>    
                                </li>
                            @endif
                        @endforeach
                        
                    </ul>
                @else 
                    <a href="{{(blank($menuNv1->url)) ? route('paginas.navegar', ["menu" => $menuNv1->id_menu, "nombre" => Str::slug($menuNv1->nombre)]) : $menuNv1->url}}" target="{{\App\Enums\ETarget::result($menuNv1->target)->getDescription()}}" role="button" aria-haspopup="true" aria-expanded="false">
                        <i class="fa {{$menuNv1->class_icon}} bg-{{$coloresPlantilla[$menuNv1->color]}}" aria-hidden="true"></i> <span class="">{{$menuNv1->nombre}}</span>
                    </a>
                @endif
            </li>
        @endforeach
    @endif
@endsection
@section('contenido')

@if (blank($pagina->pagina_mostrar))
    @section('galeria')
        <section class="bannercontainer bannercontainerV1"> 
            <div class="fullscreenbanner-container">
                <div class="fullscreenbanner">
                    <ul id="galeriaPpal">
                    <li data-transition="slidedown" data-slotamount="5" data-masterspeed="1000" data-title="Slide 2" data-delay="5000">
                        <img src="{{asset('plantilla/img/home/slider/1539793157.jpg')}}" alt="slidebg1" data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
                        <div class="slider-caption container">
                        <div class="tp-caption rs-caption-1 sft start text-center"
                            data-hoffset="0"
                            data-x="center"
                            data-y="200"
                            data-speed="800"
                            data-start="1000"
                            data-easing="Back.easeInOut"
                            data-endspeed="300">
                            Sell Kids Products
                        </div>
        
                        <div class="tp-caption rs-caption-2 sft text-center"
                            data-hoffset="0"
                            data-x="center"
                            data-y="265"
                            data-speed="1000"
                            data-start="1500"
                            data-easing="Power4.easeOut"
                            data-endspeed="300"
                            data-endeasing="Power1.easeIn"
                            data-captionhidden="off">
                            All ecommerce features are included with KIDZ <br>
                            Build your ecommerce site.
                        </div>
                        </div>
                    </li>
                    <li data-transition="fade" data-slotamount="5" data-masterspeed="700"  data-title="Slide 3">
                        <img src="{{asset('plantilla/img/home/slider/1539794043.jpg')}}" alt="slidebg1" data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
                        <div class="slider-caption container">
                        <div class="tp-caption rs-caption-1 sft start text-right"
                            data-hoffset="0"
                            data-y="200"
                            data-x="right"
                            data-speed="800"
                            data-start="1000"
                            data-easing="Back.easeInOut"
                            data-endspeed="300">
                            Impress Your Clients
                        </div>
        
                        <div class="tp-caption rs-caption-2 sft text-right"
                            data-hoffset="0"
                            data-y="265"
                            data-x="right"
                            data-speed="1000"
                            data-start="1500"
                            data-easing="Power4.easeOut"
                            data-endspeed="300"
                            data-endeasing="Power1.easeIn"
                            data-captionhidden="off">
                            Kidz is created for better user experience in mind.
                        </div>
                        </div>
                    </li>
                    <li data-transition="fade" data-slotamount="5" data-masterspeed="1000" data-title="Slide 2">
                        <img src="{{asset('plantilla/img/home/slider/slider-4.jpg')}}" alt="slidebg1" data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
                        <div class="slider-caption container">
                        <div class="tp-caption rs-caption-1 sft start text-center"
                            data-hoffset="0"
                            data-x="left"
                            data-y="200"
                            data-speed="800"
                            data-start="1000"
                            data-easing="Back.easeInOut"
                            data-endspeed="300">
                            Bright Playful Colors
                        </div>
        
                        <div class="tp-caption rs-caption-2 sft text-center"
                            data-hoffset="0"
                            data-x="left"
                            data-y="265"
                            data-speed="1000"
                            data-start="1500"
                            data-easing="Power4.easeOut"
                            data-endspeed="300"
                            data-endeasing="Power1.easeIn"
                            data-captionhidden="off">
                            Combination of bright and playful colors will help you <br>
                            make users happy.
                        </div>
                        </div>
                    </li>
                    </ul>
                </div>
            </div>
        </section>
    @endsection
@endif
{!!$pagina->pagina_mostrar!!}
@endsection

@section('breadcum')

        @if(count($breadcum)>1)
            <section style="padding: 24px 0 !important;">
                <div class="container" style="padding-top: 5px; ">
                    <ul class="menu-horizontal">
                        @foreach ($breadcum as $paginaBreadcum)
                            <li class="{{$paginaBreadcum->id_pagina==$pagina->id_pagina ? 'active' : 'notactive'}}">
                                <a {{($paginaBreadcum->id_pagina==$pagina->id_pagina) ? '' : 'href='.route('paginas.navegar-pagina', ["pagina" => $paginaBreadcum->id_pagina, "nombre" => $nombre]) }} style="{{$paginaBreadcum->id_pagina==$pagina->id_pagina ? 'color: #e91e63; font-weight: 600;' : ''}}">{{$paginaBreadcum->titulo}}</a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </section>
        @endif
@endsection

@section('scripts')
    <script>
        $(".courseSingleSection").css("background",'{!!$pagina->img_background!!}');
    </script>
@endsection

@section('style')
<style>
    .menu-horizontal {
        position:absolute;
        left:50%;
        display:flex;
        margin:0;
        padding:0;
        transform:translate(-50%,-50%);
    }
    .menu-horizontal li {
        list-style:none;
    }
    .menu-horizontal li a {
        position:relative;
        display:block;
        text-align:center;
        margin:0 25px;
        color:#262626;
        font-size:30x;
        text-transform:uppercase;
        transition:.5s;
        padding:5px 10px;
    }
    .menu-horizontal li.notactive a:hover {
        color:#fff;
        background:#e91e63;
        text-decoration:none;
    }

    .menu-horizontal li.notactive a:hover:before {
        bottom:-12px;
        left:-12px;
        opacity:1;
    }
    .menu-horizontal li.notactive a:hover:after {
        top:-12px;
        right:-12px;
        opacity:1;
    }

</style>
<style>
    .alert-purple {
        background-color: #b269be;
        border-color: transparent;
        border-left: 3px solid #773383;
        color: #fff;
    }
    .alert-pink {
        background-color: #ee87aa;
        border-color: transparent;
        border-left: 3px solid #e62063;
        color: #fff;
    }
    .alert-warning {
        background-color: #f7bb2b;
        border-color: transparent;
        border-left: 3px solid #b07c03;
        color: #fff;
    }
    .alert-info {
        background-color: #37aee3;
        border-color: transparent;
        border-left: 3px solid #116f99;
        color: #fff;
    }
    .alert-success {
        background-color: #9cc56c;
        border-color: transparent;
        border-left: 3px solid #648e33;
        color: #fff;
    }
    .alert-dark {
        background-color: #676f78;
        border-color: transparent;
        border-left: 3px solid #31373e;
        color: #fff;
    }
    .pad-all {
        margin: 15px;    
        padding: 15px;
        border-radius: 10px;
    }
    .img-center {
        display: block;
        margin-left: auto;
        margin-right: auto;
    }
    .pad-all {
        padding: 15px;
        border-radius: 10px;
    }
    .column{
        padding: 15px;
    }
    .bord-all {
        border: 1px solid rgba(200,200,200)!important;
    }
    .bord-btm {
        border-bottom: 1px solid rgba(200,200,200)!important;
    }
    .bord-top {
        border-top: 1px solid rgba(200,200,200)!important;
    }
    .bord-rgt {
        border-right: 1px solid rgba(200,200,200)!important;
    }
    .bord-lft {
        border-left: 1px solid rgba(200,200,200)!important;
    }
    
    .bord-ver {
        border-right: 1px solid rgba(200,200,200)!important;
        border-left: 1px solid rgba(200,200,200)!important;
    }
    .bord-hor {
        border-top: 1px solid rgba(200,200,200)!important;
        border-bottom: 1px solid rgba(200,200,200)!important;
    }
    .text-success-hr{
        border-color: #79af3a !important;
    }
    .text-info-hr{
        border-color: #0391d1 !important;
    }
    .text-primary-hr{
        border-color: #1c3550 !important;
    }
    .text-warning-hr{
        border-color: #db9a00 !important;
    }
    .text-purple-hr{
        border-color: #953ca4 !important;
    }
    .text-pink-hr{
        border-color: #ed417b !important;
    }
    .hr-delgado{
        border-top: 1px solid;
    }
    .hr-normal{
        border-top: 2px solid;
    }
    .hr-ancho{
        border-top: 4px solid;
    }
    .row {
        margin-right: 0px !important;
        margin-left: 0px !important;
    }
</style>
@endsection
@section('footer')
@if(blank($footer))
<div class="row">
    <div class="col-sm-6 col-xs-12">
        <img src="{{asset('img/logo-school-footer.png')}}">
        <br>
        <br>
        <br>
        <div class="footerInfo text-justify">
            <p>Somos una institución educativa dedicada a la formación integral de hombres y mujeres con espíritu de bien, promoviendo el desarrollo de sus capacidades intelectuales, laborales  y potencialidades, fundamentados en principios y valores del respeto a la dignidad humana, vivenciados a través del compromiso personal y social. </p>
            <p>En el año 2020 el Colegio Técnico Industrial José Elías Puyana  se consolidará como la institución educativa oficial abanderada en formación integral, cimentada en principios y valores, en procesos pedagógicos y tecnológicos de alta calidad que formen una persona analítica, crítica, emprendedora, con sentido de pertenencia y espíritu de bien, que contribuya positivamente al desarrollo social, cultural, económico y político del país.</p>
        </div>
    </div>
    <div class="col-sm-3 col-xs-12">
        <div class="footerInfo">
            <ul class="list-unstyled postLink">
                <li>
                <div class="footerInfo">
                    <p style="margin-bottom: 5px;">
                        <strong>Sede A</strong><br>
                        Sede Administrativa<br>
                        Calle 4 No. 11 - 79 Barrio El Centro
                        Telefono: (57-7) 6497555 - 6496795
                    </p>
                </div>
                </li>
                <li>
                <div class="footerInfo">
                    <p style="margin-bottom: 5px;">
                        <strong>Sede B</strong><br>
                        Calle 4A No. 14 - 51 Barrio Altamira
                        Telefono: (57-7) 6752081 - 6826754
                    </p>
                </div>
                </li>
                <li>
                <div class="footerInfo">
                    <p style="margin-bottom: 5px;">
                        <strong>Sede C</strong><br>
                        Calle 34 No. 9E - 91 Barrio La Cumbre
                        Telefono: (57-7) 6582770 - 6582568
                    </p>
                </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="col-sm-3 col-xs-12">
        <div class="footerTitle">
        <h4 class="text-center">Calidad</h4>
        </div>
        <div class="footerInfo">
            <div class="text-center">
            <img src="{{asset('img/footer/ml20.png')}}">
            <img src="{{asset('img/footer/ml19.png')}}">
            <img src="{{asset('img/footer/ml21.png')}}">
            </div>
        <hr>
        <div class="text-center">
            <button type="button" class="btn-social btn-facebook-filled btn-circle"><i class="fa fa-facebook"></i></button>
            <button type="button" class="btn-social btn-twitter-filled btn-circle"><i class="fa fa-twitter"></i></button>
            <button type="button" class="btn-social btn-pinterest-filled btn-circle"><i class="fa fa-pinterest"></i></button>
        </div>
        <hr>
        <div class="text-center">
            <a href="http://www.cxeducativa.com/" target="_blank">
                <img class="img-rounded border-color-1" src="{{asset('img/footer/ml25.png')}}" alt="Image" > 
                <p style="margin-top: 10px;"><strong style="color:white;">{{trans('general.copyright')}}</strong></p>
            </a>
        </div>
        </div>
    </div>
</div>
@else
{!! $footer->pagina_mostrar!!}
@endif
@endsection