

@extends('layouts.administrador')
@section('title', trans('general.administrar_menu_title'))
@section('titulo-pagina')
    <div id="page-title">
        <h1 class="page-header text-overflow">{{trans('menus.menu_plural')}}</h1>
    </div>    
@endsection

@section('breadcum')
    <ol class="breadcrumb">
        <li><a href="#"><i class="demo-pli-home"></i></a></li>
        <li class="active">{{trans('general.administrar_menu_title')}}</li>
    </ol>
@endsection
@section('content')
    <div class="row">
        <div class="col-sm-6">
            <div class="panel">
                <div class="panel-heading">
                    <div class="panel-control mar-top">
                        <div class="input-group-wrap">
                            <a class="opciones btn btn-purple" target="paginaPrincipal" href="{{ url('/') }}">
                                <i class="ti ti-wand"></i> {{trans('menus.menu_previsualizar')}}
                            </a>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="panel-body" id="tablaContenedor">
                            {!!$tablaMenu!!}
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
                <!--Panel with Tabs (Icon)-->
                <!--===================================================-->
                <div class="panel panel-mint" style="min-height: 500px;">
        
                    <!--Panel heading-->
                    <div class="panel-heading">
                        <div class="panel-control">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a data-toggle="tab" href="#demo-tabs2-box-1" aria-expanded="true" id="menuCrear">
                                        <i class="ti ti-plus"></i>
                                    </a>
                                </li>
                                <li class="">
                                    <a data-toggle="tab" href="#demo-tabs2-box-2" aria-expanded="false" id="menuOrdenar">
                                        <i class="demo-pli-laptop icon-lg"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
        
                    <!--Panel Body-->
                    <div class="panel-body">
                        <div class="tab-content">
                            <div id="demo-tabs2-box-1" class="tab-pane fade active in">
                                {{Form::open(['route' => 'menus.crear-menu', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarMenu']) }}  
                                    {!! Form::hidden('id_menu', null, ['id' => 'id_menu' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off' ]) !!}
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="control-label">{{trans('menus.menu_nombre')}}</label>
                                                    {!! Form::text('nombre', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="control-label">{{trans('menus.menu_padre')}}</label>
                                                    {!! Form::select("id_menu_padre", $menus, null, ["id"=>"id_menu_padre", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => trans("menus.placeholder_menu_seleccione_padre"), "required" => "required"]) !!}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            
                                            <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label class="control-label">{{trans('menus.menu_url')}}</label>
                                                        <div class="radio">
                                                            {!! Form::text('url', null, ['class' => 'form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'url' ]) !!}
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="control-label">{{trans('menus.menu_target')}}</label>
                                                    <div class="radio">
                                                        {!! Form::select("target", App\Enums\ETarget::items(), App\Enums\ETarget::index(App\Enums\ETarget::SELF_TG)->getId(), ["id"=>"target", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => trans("menus.placeholder_menu_seleccione_target"),"required" => "required"]) !!}
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-1">
                                                <label class="control-label">{{trans('menus.menu_activo')}}</label>
                                                <div class="radio mar-top">
                                                    <input id="demo-sw-checked" type="checkbox" name="activo" value="{{App\Enums\ESiNo::index(App\Enums\ESiNo::Si)->getId()}}" checked>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="control-label">{{trans('menus.menu_color')}}</label>
                                                {!! Form::hidden('color', 'default', ['id' => 'color' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off' ]) !!}
                                                <div class="radio">
                                                    <div class="btn-group" role="group" aria-label="...">
                                                        <button type="button" class="btn btn-info btn-sm colorSeleccionar" data-clase="btn btn-info btn-circle" data-color="info"><i class="fa fa-circle"></i></button>
                                                        <button type="button" class="btn btn-warning btn-sm colorSeleccionar" data-clase="btn btn-warning btn-circle" data-color="warning"><i class="fa fa-circle"></i></button>
                                                        <button type="button" class="btn btn-success btn-sm colorSeleccionar" data-clase="btn btn-success btn-circle" data-color="success"><i class="fa fa-circle"></i></button>
                                                        <button type="button" class="btn btn-danger btn-sm colorSeleccionar" data-clase="btn btn-danger btn-circle" data-color="danger"><i class="fa fa-circle"></i></button>
                                                        <button type="button" class="btn btn-purple btn-sm colorSeleccionar" data-clase="btn btn-purple btn-circle" data-color="purple"><i class="fa fa-circle"></i></button>
                                                        <button type="button" class="btn btn-pink btn-sm colorSeleccionar" data-clase="btn btn-pink btn-circle" data-color="pink"><i class="fa fa-circle"></i></button>
                                                        <button type="button" class="btn btn-white btn-sm colorSeleccionar" data-clase="btn btn-default btn-circle" data-color="default"><i class="fa fa-circle"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="control-label">{{trans('menus.menu_icono')}}</label>
                                                    <div class="radio">
                                                        {!! Form::select("imagen", App\Enums\EIcono::items(), null, ["class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""),"placeholder" => trans("menus.placeholder_menu_seleccione_icono"), 'id' => 'imagen']) !!}
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">{{trans('menus.menu_recurso')}}</label>
                                                    <div class="radio">
                                                        <div id="divIcono">
                                                            <div class="input-group">
                                                                {!! Form::select("class_icon", $iconos, null, ["id"=>"class_icon", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => trans("menus.placeholder_menu_seleccione_icono")], $opcionIconos) !!}
                                                                <span class="input-group-btn">
                                                                    <button class="btn btn-mint" type="button" data-target="#demo-lg-modal" data-toggle="modal">Ver todos</button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div id="divImagen" style="display: none;">
                                                            {!! Form::file("file", ['id' => "file", 'class' => 'form-control', 'aria-describedby' => 'fileHelp','style'=>'height: auto;']) !!}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 text-center">
                                                <label class="control-label">{{trans('menus.menu_previsualizar')}}</label>
                                                <div class="radio" id="previewIcono">
                                                    <button class="btn btn-default btn-circle" type="button">
                                                        <i class=""></i>
                                                    </button>
                                                    <br>
                                                    <span class="text-dark mar-top"><strong>{{trans('menus.menu_nombre')}}</strong></span>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row" id="btnCrear">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <button class="btn btn-mint" type="submit">{{trans('botones.guardar')}}</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" id="btnEditar" style="display: none;">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <button class="btn btn-primary" type="submit">{{trans('botones.editar')}}</button>
                                                    <button class="btn btn-danger" type="button" onclick="limpiarFormulario()">{{trans('botones.cancelar')}}</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                {{Form::close()}}
                            </div>
                            <div id="demo-tabs2-box-2" class="tab-pane fade">
                                    {{Form::open(['route' => 'menus.crear-menu', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarMenu']) }}  
                                    {!! Form::hidden('id_menu', null, ['id' => 'id_menu' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off' ]) !!}
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="control-label">{{trans('menus.menu')}}</label>
                                                    {!! Form::select("id_menu_ordenar", $menus, null, ["id"=>"id_menu_ordenar", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => trans("menus.placeholder_menu_seleccione"), "required" => "required", "onchange"=>'consultarMenuOrden(this.value);']) !!}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div id="demo-nestable-theme-2" class="dd">
                                                    <ol class="dd-list" id="listaOrdenamiento">
                                                        {{-- @foreach ($listMenus as $menu)
                                                            <li class="dd-item" data-id="{{$menu->id_menu}}">
                                                                <div class="dd-handle dd-outline dd-anim">
                                                                    <div class="media-left">
                                                                        <button class="btn btn-{{$menu->color}} btn-icon btn-circle">
                                                                            @if($menu->imagen==App\Enums\EIcono::index(App\Enums\EIcono::No)->getId())
                                                                                <i class="{{$menu->class_icon}}"></i>
                                                                            @else
                                                                                <img src="http://www.capuchinasarmenia.com/public/img/nav-menu/nav1.png" alt="">
                                                                            @endif
                                                                        </button>
                                                                    </div>
                                                                    <div class="media-body">
                                                                        <div class="text-semibold text-nowrap">{{$menu->nombre}}</div>
                                                                    <small class="text-muted">{{(blank($menu->fecha_modificacion)) ? 'Modificado: '.$menu->fecha_registro : 'Creado: '.$menu->fecha_modificacion }}</small>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        @endforeach --}}
                                                    </ol>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row" id="btnCrear">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <button class="btn btn-mint" type="button" onclick="clickLista();">{{trans('botones.guardar')}}</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                {{Form::close()}}
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
    <div id="demo-lg-modal" class="modal fade" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                    <h4 class="modal-title" id="myLargeModalLabel">{{trans('menus.menu_title_listado_iconos')}}</h4>
                </div>
                <div class="modal-body">
                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-control">
                                <div class="input-group-wrap">
                                    <input type="text" class="form-control buscar mar-top" id="textBuscar" placeholder="Ingrese el texto a buscar">
                                </div>
                            </div>
                            {{trans('menus.menu_tutorial_iconos_seleccionar')}}    
                            
                        </div>
                        <div class="panel-body mar-top">
                            <hr>
                            <div id="iconosLista" class="clearfix demo-icon-list" style="height: 600px; overflow: auto;">
                                @foreach ($opcionIconos as $key => $icono)
                                    <div class="col-sm-6 col-md-3">
                                        <div class="demo-icon" data-icon="{{$key}}">
                                            <i class="fa {{current($icono)}}"></i><span>{{$iconos[$key]}}</span>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
    <script>
        $(window).on('load', function(){
            var rowSelection = $('table').DataTable({
            "responsive": true,
            "bSort" : false,
            "language": {
                "paginate": {
                    "previous": '<i class="demo-psi-arrow-left"></i>',
                    "next": '<i class="demo-psi-arrow-right"></i>'
                }
            }
        });
        $('table').on( 'click', 'tr', function () {
            if ( $(this).hasClass('selected') ) {
                $(this).removeClass('selected');
            }
            else {
                rowSelection.$('tr.selected').removeClass('selected');
                $(this).addClass('selected');
            }
        } );
        });
    </script>
    <script>
    $(function() {
        $(".buscar").keyup(function(){
            var loading = frameworkApp.setLoading();
            var text = $(this).val().toUpperCase();
            $('#iconosLista .col-sm-6').show();
            if(text!=''){
                var tableRow = $("#iconosLista span").filter(function () {
                    var txtCelda = $(this).text().toUpperCase();
                    var n = txtCelda.indexOf(text);
                    return (n!=-1);
                });
                console.log(tableRow);
                $('#iconosLista .col-sm-6').not(tableRow.parents('.col-sm-6')).hide();
            }
            loading.remove();
        });
    });
    $('.colorSeleccionar').on( 'click', function () {
        $("#previewIcono").find('button').attr("class",$(this).data("clase"));
        $("#color").val($(this).data("color"));
    });
    
    $('#class_icon').on('change', function () {
        console.log($(this));
        $("#previewIcono").find('i').attr("class",$(this).find("option:selected" ).data("icon"));
    });
    $('.demo-icon').on('dblclick', function () {
        //alert($(this).data("icon"));
        $('#class_icon').val($(this).data("icon"));
        $('#class_icon').trigger("liszt:updated");
        $('#class_icon').trigger("chosen:updated");
        $("#previewIcono").find('i').attr("class",$('#class_icon').find("option:selected" ).data("icon"));
        $("#demo-lg-modal").modal('hide');
    });
    $('.nombre-menu').on('keyup', function () {
        if($(this).val()!=''){
            $("#previewIcono").find('span').html("<strong>"+$(this).val()+"</strong>");
        }else{
            $("#previewIcono").find('span').html("<strong>Texto</strong>");
        }
    });
    
    $('#imagen').on('change', function () {
        if($(this).val()=={{App\Enums\EIcono::index(App\Enums\EIcono::No)->getId()}}){
            $("#divImagen").hide();
            $("#divIcono").show();
            if($("#class_icon").val()==''){
                $("#previewIcono").find('i').attr("class","");
            }else{
                $("#previewIcono").find('i').attr("class",$("#class_icon").find("option:selected" ).data("icon"));
            }
        }else{
            $("#previewIcono").find('i').attr("class","fa fa-image fa-2x");
            $("#divIcono").hide();
            $("#divImagen").show();
        }
    });
    
    
    
    new Switchery(document.getElementById('demo-sw-checked'));
    $("#agregarMenu").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            var loading = frameworkApp.setLoading();
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                dataType: 'json',
                type:'POST',
                url: '{{ url("menus/crear-menus") }}',
                data: new FormData($("#agregarMenu")[0]),
                processData: false,
                contentType: false,
                id_container_body: false,
                success: function(data) {
                    loading.remove();
                    console.log(data);
                    $('#tablaContenedor').html(data.tablaMenu);
                    frameworkApp.setToastSuccess('{{trans('menus.menus_crear_exito')}}');
                   // bootbox.alert("{{trans('menus.menus_crear_exito')}}");
                    $("#agregarMenu")[0].reset();
                    $('#agregarMenu .chosen').val('');
                    $('#demo-dt-selection').DataTable({
                        "responsive": true,
                        "bSort" : false,
                        "language": {
                            "paginate": {
                            "previous": '<i class="demo-psi-arrow-left"></i>',
                            "next": '<i class="demo-psi-arrow-right"></i>'
                            }
                        }
                    });
                    $("#id_menu_padre").html(data.menus);
                    $("#id_menu_ordenar").html(data.menus);
                    limpiarFormulario();
                    $('.add-tooltip').tooltip();
                    $('.add-tooltip').on('click', function () {
                        $(this).attr('data-original-title', 'changed tooltip');
                        $('.add-tooltip').tooltip();
                        $(this).mouseover();
                    });
                },
                error: function(obj, typeError, text, data) {
                    loading.remove();
                    
                    frameworkApp.setToastError('{{trans('menus.error_transaccion')}}');
                    //bootbox.alert("{{ trans('general.error_transaccion') }}");
                }
            });
            return false;
        },
        rules: {
            nombre: 'required',
            id_menu_padre: 'required',
            class_icon: {
                required: function () {
                    return ((($("#imagen").val()) === ({{App\Enums\EIcono::index(App\Enums\EIcono::No)->getId()}})));
                },
            },
        },
        highlight: function (element, errorClass) {
          $(element).parents('.form-group').addClass('has-feedback has-error');
          $(element).parents('.form-group').removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parents('.form-group').removeClass('has-feedback has-error');
          $(element).parents('.form-group').addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.form-group').find('.chosen-container'));
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });


    function consultarMenu(idMenu){
        frameworkApp.setLoadData({
            url: '{{ url("menus/informacion-menus") }}',
            data: {
                id_menu: idMenu
            },
            id_container_body: false,
            success: function(data) {
                //console.log(data.menus);
                $("#menuCrear").click();
                $("#id_menu").val(data.menus.id_menu);
                $("#nombre").val(data.menus.nombre);
                $("#id_menu_padre").val(data.menus.id_menu_padre);
                $("#url").val(data.menus.url);
                
                $('#demo-sw-checked').trigger('click').attr("checked", data.menus.activo); 

                if (data.menus.activo==true){ 
                     if ($('#demo-sw-checked')[0].checked){
                     }else{
                         $('#demo-sw-checked').trigger('click').attr("checked", "checked"); 
                     }
                 }else{
                     if ($('#demo-sw-checked')[0].checked){
                         $('#demo-sw-checked').trigger('click').removeAttr("checked");
                     }
                 }
                $("#previewIcono").find('span').html("<strong>"+data.menus.nombre+"</strong>");
                $("#target").val(data.menus.target);
                $("#color").val(data.menus.color);
                $("#imagen").val(data.menus.imagen);
                if(data.menus.imagen=={{App\Enums\EIcono::index(App\Enums\Eicono::No)->getId()}}){
                    $("#divImagen").hide();
                    $("#divIcono").show();
                    $("#class_icon").val(data.menus.class_icon);
                    if($("#class_icon").val()==''){
                        $("#previewIcono").find('i').attr("class","");
                    }else{
                        $("#previewIcono").find('i').attr("class",$("#class_icon").find("option:selected" ).data("icon"));
                    }
                }else{
                    $("#previewIcono").find('i').attr("class","fa fa-image fa-2x");
                    $("#divIcono").hide();
                    $("#divImagen").show();
                }
                $("#previewIcono").find('button').attr("class","btn btn-circle btn-"+data.menus.color);
                $('.chosen-select').trigger("chosen:updated");
                $("#btnCrear").hide();
                $("#btnEditar").show();
            }
        });
    }

    function consultarMenuOrden(idMenu){
        if(idMenu!=''){
            frameworkApp.setLoadData({
                url: '{{ url("menus/informacion-menus") }}',
                data: {
                    id_menu: idMenu
                },
                id_container_body: false,
                success: function(data) {
                    $("#menuOrdenar").click();
                    var ddList = '';
                    $.each(data.menusHijos, function(i, item) {
                        ddList+= '<li class="dd-item" data-id="'+item.id_menu+'">';
                        ddList+= '  <div class="dd-handle dd-outline dd-anim">';
                        ddList+= '      <div class="media-left">';
                        ddList+= '          <button class="btn btn-'+item.color+' btn-icon btn-circle">';
                        if(item.imagen=={{App\Enums\EIcono::index(App\Enums\EIcono::No)->getId()}}){
                            ddList+= '          <i class="'+item.class_icon+'"></i>';
                        }else if(item.imagen=={{App\Enums\EIcono::index(App\Enums\EIcono::Si)->getId()}}){
                            ddList+= '          <img src="{{url("/storage/menu/")}}/'+item.class_icon+'" alt="">';
                        }
                        ddList+= '          </button>';
                        ddList+= '      </div>';
                        ddList+= '      <div class="media-body">';
                        ddList+= '          <p class="text-semibold mar-no">'+item.nombre+'</p>';
                        ddList+= '          <small class="text-muted">'+((item.fecha_modificacion!=null) ? 'Modificado: '+item.fecha_modificacion : 'Creado: '+item.fecha_registro )+'</small>';
                        ddList+= '      </div>';
                        ddList+= '  </div>';
                        ddList+= '</li>';
                    });
                    $("#listaOrdenamiento").html(ddList);
                    $("#id_menu_ordenar").val(idMenu);
                    $('.chosen-select').trigger("chosen:updated");
                    $("#menuOrdenar").click();
                }
            });
        }else{
            $("#listaOrdenamiento").html('');
        }
            //$('.dd-list').append(xhtml);
					                        
        
    }

    function clickLista(){
        frameworkApp.setLoadData({
            url: '{{ url("menus/ordenar-menus") }}',
            data: {
                id_menu: $('#id_menu_ordenar').val(),
                lista_ordenada: $('.dd').nestable('serialize')
            },
            id_container_body: false,
            success: function(data) {
                //console.log(data);
                frameworkApp.setToastSuccess(data.notificacion.message);
                //bootbox.alert(data.notificacion.message);
            }
        });
    }
    $('#demo-nestable-theme-2').nestable({group: 11,maxLevels: 1,allowDecrease   : false});
    function limpiarFormulario(){
        $("#id_menu").val('');
        $("#nombre").val('');
        $("#id_menu_padre").val('');
        $("#url").val('');
        $("#target").val('');
        $("#color").val('default');
        $("#imagen").val('');
        $("#class_icon").val('');
        $("#previewIcono").find('button').attr("class","btn btn-circle btn-default");
        $("#previewIcono").find('i').attr("class","");
        $('.chosen-select').trigger("chosen:updated");
        $("#previewIcono").find('span').html("<strong>Texto</strong>");
        $("#btnCrear").show();
        $("#btnEditar").hide();
    }
    </script>
@endsection