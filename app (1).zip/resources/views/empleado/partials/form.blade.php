

@php



    use App\Models\Estudiante;

    use Carbon\Carbon;

    use Illuminate\Support\Arr;

    use App\Enums\ETipoDocumento;

    $meses = ["01"=>"ENERO", "02" => "FEBRERO", "03" => "MARZO", "04" => "ABRIL", "05" => "MAYO", "06" => "JUNIO", "07" => "JULIO", "08" => "AGOSTO", "09" => "SEPTIEMBRE", "10" => "OCTUBRE", 11 =>"NOVIEMBRE", "12" => "DICIEMBRE"];

    $pendientes = 0;
    $dia_n = '';
    $mes_n = '';
    $anualidad_n = '';
    $dia_e = '';
    $mes_e = '';
    $anualidad_e = '';
    if(!blank($empleado->codempleado)){
        $fecha_n = explode('-', $empleado->fecha_nacimiento);
        $fecha_e = explode('-', $empleado->fecha_expedicion);
        $dia_n = $fecha_n[2];
        $mes_n = $fecha_n[1];
        $anualidad_n = $fecha_n[0];
        $dia_e = $fecha_e[2];
        $mes_e = $fecha_e[1];
        $anualidad_e = $fecha_e[0];
    }



@endphp



    



    

            <div class="modal-content">

                <div class="modal-body">

                    <!-- begin panel -->

					<div class="panel panel-inverse" data-sortable-id="form-stuff-1">

                            <!-- begin panel-heading -->

                            <div class="panel-heading">

                                <div class="panel-heading-btn">

                                    <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>

                                    <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>

                                </div>

                                <h4 class="panel-title">Creación / información de empleado</h4>

                            </div>

                            <!-- end panel-heading -->

                            <!-- begin panel-body -->

                            <div class="panel-body">

                                    {{Form::open(['route' => 'empleado.crear-empleado', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarAsignatura']) }}  

                                        {!! Form::hidden('codempleado', $empleado->codempleado) !!}

                                        <div class="form-group row m-b-15">

                                            <label class="col-form-label col-md-3">Identificación</label>

                                            <div class="col-md-9">

                                                <div class="input-group m-b-10">

                                                    <div class="input-group-prepend">

                                                        {!! Form::select("tipo_documento", ETipoDocumento::items(), $empleado->tipo_documento, ["id"=>"id_menu_padre", "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Tipo", "required" => "required"]) !!}

                                                    </div>

                                                    {!! Form::text('identificacion', $empleado->identificacion, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}

                                                </div>

                                            </div>

                                        </div>

                                        <div class="form-group row m-b-15">

                                            <label class="col-form-label col-md-3">Nombres</label>

                                            <div class="col-md-4">

                                                {!! Form::text('nombres', $empleado->nombres, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}

                                            </div>

                                            <label class="col-form-label col-md-1">Apellidos</label>

                                            <div class="col-md-4">

                                                {!! Form::text('apellidos', $empleado->apellidos, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}

                                            </div>

                                        </div>

                                        <div class="form-group row m-b-15">

                                       <label class="col-form-label col-md-3">Departamento </label>

                                       <div class="col-md-4">

                                             {!! Form::text('departamento', $empleado->departamento, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}

                                             </div>
                                             
                                            
                              

                                       <label class="col-form-label col-md-1">municipio </label>

                                       <div class="col-md-4">

                                             {!! Form::text('municipio', $empleado->municipio, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}

                                             </div>
                                             
                                            
                                        <div class="form-group row m-b-15">


                                        </div>

                                        </div>

                                        <div class="form-group row m-b-15">

                                            <label class="col-form-label col-md-3">Fecha expedición identificación</label>

                                            <input type="hidden" class="form-control datepicker" id="fecha_expedicion" name="fecha_expedicion" value="{{Carbon::parse($empleado->fecha_nacimiento)->format('m/d/Y')}}" id="start" autocomplete="off"/>
                                            <div class="col-md-2">
                                                {!! Form::select("dia_exp", [], $dia_e, ["id"=>"fecha_dia_exp", "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "required" => "required"]) !!}
                                            </div>
                                            <div class="col-md-4">
                                                {!! Form::select("mes_exp", [], $mes_e, ["id"=>"fecha_mes_exp", "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "required" => "required"]) !!}
                                            </div>
                                            <div class="col-md-3">
                                                {!! Form::select("anualidad_exp", [], $anualidad_e, ["id"=>"fecha_anualidad_exp", "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "required" => "required"]) !!}
                                            </div>
                                        </div>
                                        

                                        <div class="form-group row m-b-15">
                                            <input type="hidden" class="form-control datepicker" id="fecha_nacimiento" name="fecha_nacimiento" value="{{Carbon::parse($empleado->fecha_nacimiento)->format('m/d/Y')}}" id="start" autocomplete="off"/>
                                            <label class="col-form-label col-md-3">Fecha nacimiento</label>
                                            <div class="col-md-2">
                                                {!! Form::select("dia", [], $dia_n, ["id"=>"fecha_dia_nac", "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "required" => "required"]) !!}
                                            </div>
                                            <div class="col-md-4">
                                                {!! Form::select("mes", [], $mes_n, ["id"=>"fecha_mes_nac", "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "required" => "required"]) !!}
                                            </div>
                                            <div class="col-md-3">
                                                {!! Form::select("anualidad", [], $anualidad_n, ["id"=>"fecha_anualidad_nac", "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "required" => "required"]) !!}
                                            </div>
                                        </div>  

                                        

                                        <div class="form-group row m-b-15">

                                            <label class="col-form-label col-md-3">Celular</label>

                                            <div class="col-md-4">

                                                {!! Form::text('celular', $empleado->celular, ['id'=>'celular','class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off']) !!}

                                            </div>

                                            <label class="col-form-label col-md-1">Confirmar</label>

                                            <div class="col-md-4">

                                                {!! Form::text('celular_confirmar', $empleado->celular, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'correo' ]) !!}

                                            </div>

                                        </div>

                                        

                                        <div class="form-group row m-b-15">

                                            

                                        </div>

                                        

                                        <div class="form-group row m-b-15">

                                            <label class="col-form-label col-md-3">Teléfono Fijo</label>

                                            <div class="col-md-4">

                                                {!! Form::text('fijo', $empleado->fijo, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}

                                            </div>

                                            <label class="col-form-label col-md-1">Email</label>

                                            <div class="col-md-4">

                                                {!! Form::text('email', $empleado->email, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'correo' ]) !!}

                                            </div>

                                        </div>

                                        

                                        <div class="form-group row m-b-15">

                                            <label class="col-form-label col-md-3">Dirección</label>

                                            <div class="col-md-9">

                                                {!! Form::text('direccion', $empleado->direccion, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}

                                            </div>

                                        </div>

                                        

                                        <div class="form-group row m-b-15">

                                            

                                        </div>

                                        

                                        <div class="form-group row m-b-15">

                                            <label class="col-form-label col-md-3">Ocupación</label>

                                            <div class="col-md-9">

                                                <input type="text" class="form-control " value="{{$empleado->ocupacion}}" name="ocupacion" id="start" autocomplete="off"/>

                                            </div>

                                        </div>

                                        

                                        <div class="form-group row m-b-15">

                                            <label class="col-form-label col-md-3">Rango de Ingresos</label> 

                                            <div class="col-md-4">

                                                <input type="text" class="form-control " value="{{$empleado->ingresos}}" name="ingresos" id="start" autocomplete="off"/>

                                            </div>

                                            

                                            <label class="col-form-label col-md-1">Empresa</label>

                                            <div class="col-md-4">

                                                <input type="text" class="form-control " value="{{$empleado->empresa}}" name="empresa" id="start" autocomplete="off"/>

                                            </div>

                                        </div>

                                        

                                        <div class="form-group row m-b-15">

                                        </div>

                                        <div class="form-group">

                                            <button class="btn btn-primary" type="submit">Guardar empleado</button>

                                        </div>

                                                

                                    {{Form::close()}}

                            </div>

                            <!-- end panel-body -->

                        </div>

                        <!-- end panel -->

                </div>

            </div>



<script>


    
    // Prepare to show a date picker linked to three select controls
    function actualizarFechaNac() {
        $('#fecha_nacimiento').val((Number($('#fecha_anualidad_nac').val())) + '/' +
            $('#fecha_mes_nac').val() + '/' + (Number($('#fecha_dia_nac').val())));
        return {};
    }

    // Prepare to show a date picker linked to three select controls
    function actualizarFechaexp() {
        $('#fecha_expedicion').val((Number($('#fecha_anualidad_exp').val())) + '/' +
            $('#fecha_mes_exp').val() + '/' + (Number($('#fecha_dia_exp').val())));
        return {};
    }
    
    
    $('.datepicker').datepicker();

    $("#agregarAsignatura").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            form.submit();
            return false;
        },
        rules: {
            dia_exp: 'required',
            mes_exp: 'required',
            anualidad_exp: 'quired',
            dia: 'required',
            mes: 'required',
            anualidad: 'quired',
            nombres: 'required',
            apellidos: 'required',
            municipio: 'required',
            tipo_documento: 'required',
            identificacion: 'required',
            direccion: 'required',
            ciudad: 'required',
            departamento: 'required',
            fijo: 'required',
            fecha_expedicion: 'required',
            fecha_nacimimento: 'required',
            ocupacion: 'required',
            celular: 'required',
            celular_confirmar: {
                equalTo: "#celular"
            },
        },
        highlight: function (element, errorClass) {
          $(element).parent().addClass('has-feedback has-error');
          $(element).parent().removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parent().removeClass('has-feedback has-error');
          $(element).parent().addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.hasClass("no-label")){

            } else if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });
   
    $(function(){
        $.dobPicker({
            daySelector: '#fecha_dia_nac', /* Required */
            monthSelector: '#fecha_mes_nac', /* Required */
            yearSelector: '#fecha_anualidad_nac', /* Required */
            dayDefault: 'Día', /* Optional */
            monthDefault: 'Mes', /* Optional */
            yearDefault: 'Año', /* Optional */
            minimumAge: 0, /* Optional */
            maximumAge: 100 /* Optional */
        });
        $.dobPicker({
            daySelector: '#fecha_dia_exp', /* Required */
            monthSelector: '#fecha_mes_exp', /* Required */
            yearSelector: '#fecha_anualidad_exp', /* Required */
            dayDefault: 'Día', /* Optional */
            monthDefault: 'Mes', /* Optional */
            yearDefault: 'Año', /* Optional */
            minimumAge: 0, /* Optional */
            maximumAge: 100 /* Optional */
        });
       $("#fecha_dia_nac").change(function(){
            actualizarFechaNac();
        });
       $("#fecha_mes_nac").change(function(){
            actualizarFechaNac();
        }); 
       $("#fecha_anualidad_nac").change(function(){
            actualizarFechaNac();
        });
        $("#fecha_dia_exp").change(function(){
            actualizarFechaexp();
        });
       $("#fecha_mes_exp").change(function(){
            actualizarFechaexp();
        }); 
       $("#fecha_anualidad_exp").change(function(){
            actualizarFechaexp();
        });
       $(".chosen-container").css("width","100%");  
       @if(!blank($empleado->codempleado))
            $("#fecha_dia_nac").val('{{str_pad($dia_n, 2, "0", STR_PAD_LEFT)}}');
            $("#fecha_mes_nac").val('{{str_pad($mes_n, 2, "0", STR_PAD_LEFT)}}');
            $("#fecha_anualidad_nac").val('{{$anualidad_n}}');
            $("#fecha_dia_exp").val('{{str_pad($dia_e, 2, "0", STR_PAD_LEFT)}}');
            $("#fecha_mes_exp").val('{{str_pad($mes_e, 2, "0", STR_PAD_LEFT)}}');
            $("#fecha_anualidad_exp").val('{{$anualidad_e}}');
       @endif
   })

    

</script>

    