



@php







    use App\Models\Estudiante;



    use Carbon\Carbon;



    use Illuminate\Support\Arr;



    use App\Enums\ETipoDocumento;







    $pendientes = 0;







@endphp



@extends('layouts.administrador')



@section('title', 'empleados')



@section('titulo-pagina')



    <div id="page-title">



        <h1 class="page-header text-overflow">Administrador empleados</h1>



    </div>    



@endsection



@section('breadcum')



    <ol class="breadcrumb">



        <li><a href="#"><i class="demo-pli-home"></i></a></li>



        <li class="active">Administrador empleados</li>



    </ol>



@endsection



@section('content')



    <div class="panel panel-inverse">



        <div class="panel-heading ui-sortable-handle">



            <div class="btn-group pull-right">



                <button type="button" class="btn btn-success btn-sm abrir-modal" >Crear empleado</button>



            </div>



            <h4 class="panel-title">Administrar empleados</h4>



        </div>



        <div class="panel-body">



            <div class="col-md-12">



                    <div class="panel">



                        <!--===================================================-->



                        <div class="panel-body">



                            <div class="table-responsive">



                                <table class="table table-vcenter mar-top">



                                    <thead>



                                        <tr>



                                            <th class="text-center" style="width: 5%;">Código</th>
                                            <th class="text-center" style="width: 5%;">Documento</th>



                                            <th class="min-w-td">Nombres</th>



                                            <th class="min-w-td">Apellidos</th>


                                            <th class="min-w-td">departamento</th>


                                            <th class="min-w-td">municipio</th>



                                            <th>Dirección</th>



                                            <th>Telefonos</th>



                                            <th>Email</th>
                                            <th>¿Bloqueo?</th>



                                            <th></th>



                                        </tr>



                                    </thead>



                                    <tbody>



                                    @php



                                        $secuencia = 0;



                                    @endphp



                                        @foreach(DB::table('empleados')->get() as $estudiante)



                                            @php



                                                $secuencia++;



                                            @endphp



                                            <tr>

                                                <td>{{str_pad($estudiante->codempleado, 6, "0", STR_PAD_LEFT)}}</td>



                                                <td>



                                                    {{$estudiante->identificacion}}



                                                </td>



                                                <td>



                                                    {{$estudiante->nombres}}



                                                </td>



                                                <td>



                                                    {{$estudiante->apellidos}}



                                                </td>


                                                <td>



                                                   {{$estudiante->departamento}}



                                                </td>

                                                <td>



                                                   {{$estudiante->municipio}}



                                                </td>

                                                
                                                <td>



                                                    {{$estudiante->direccion}}



                                                </td>



                                                <td>



                                                    {{$estudiante->fijo.' - '.$estudiante->celular}}



                                                </td>



                                                <td class="text-center">



                                                    {{$estudiante->email}}



                                                </td>

                                                <td class="text-center">


                                                    @if($estudiante->bloqueo==1)
                                                        <a class="btn btn-sm btn-danger btn-hover-success fa fa-times-circle text-white bloquear-usuario" data-bloqueo="2" data-codempleado="{{$estudiante->codempleado}}"></a>
                                                    @else
                                                        <a class="btn btn-sm btn-success btn-hover-success fa fa-check text-white bloquear-usuario" data-bloqueo="1" data-codempleado="{{$estudiante->codempleado}}"></a>
                                                    @endif


                                                </td>


                                                <td class="text-center mar-rgt" style="width: 5%;">



                                                    <div class="btn-group">



                                                        <a class="btn btn-sm btn-inverse btn-hover-success fa fa-key text-white resetar-password" data-codempleado="{{$estudiante->codempleado}}"></a>

                                                        <a class="btn btn-sm btn-primary btn-hover-success fa fa-edit text-white abrir-modal" data-codempleado="{{$estudiante->codempleado}}"></a>

                                                        <a class="btn btn-sm btn-danger btn-hover-success fa fa-trash text-white add-tooltip eliminar-empleado" data-codempleado="{{$estudiante->codempleado}}"></a>



                                                        <!-- <a class="btn btn-sm btn-primary btn-hover-success add-tooltip btn-evidencias ti ti-receipt" data-original-title="Registrar Consignación" data-toggle="modal" data-target="#modalFormArchivo" data-codasignatura="{{$estudiante->nombres}}" data-container="body"></a> -->



                                                    </div>



                                                </td>



                                            </tr>



                                        @endforeach

                                        



                                    </tbody>



                                </table>



                            </div>



                        </div>



                    </div>



                </div>



        </div>



    </div>



    







    <div id="demo-lg-modal" class="modal fade" tabindex="-1">



        <div class="modal-dialog modal-lg" id="form-modal">



            



        </div>



    </div>



@endsection



@section('script')



<script>

var handleDataTableButtons=function(){"use strict";0!==$("table").length&&$("table").DataTable(
    {
        dom:"Bfrtip",
        buttons:[
            {extend:"copy",className:"btn-sm"},
            {extend:"excel",className:"btn-sm"},
            {extend:"pdf",className:"btn-sm"},
            {extend:"print",className:"btn-sm"}
            ],
            responsive:!0
        
    }
    )},
    TableManageButtons=function(){"use strict";return{init:function(){handleDataTableButtons()}}}();
TableManageButtons.init();

$('.abrir-modal').click(function(){



    var codempleado = $(this).data("codempleado");



    $.ajax({



        url: "{{ url('empleado/consultar') }}",



        headers: {



            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')



        },



        type: 'post',



        data: {



            codempleado: codempleado



        },



        success: function(result){



            console.log(0);



            $("#demo-lg-modal").modal("show");



            $('#form-modal').html(result.formulario);



        }



    });



});



$('.eliminar-empleado').click(function(){



    var codempleado = $(this).data("codempleado");



    bootbox.confirm({



        message: '<strong>Mensaje de confirmación:</strong> <br><br>¿Esta seguro de eliminar al empleado?',



        closeButton: false,



        buttons: {



            confirm: {



                label: 'Aceptar',



                className: 'btn-success'



            },



            cancel: {



                label: 'Cancelar',



                className: 'btn-danger'



            }



        },



        callback: function (result) {



            if (result) {



                $.ajax({



                    url: "{{ url('empleado/eliminar') }}",



                    headers: {



                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')



                    },



                    type: 'post',



                    data: {



                        codempleado: codempleado



                    },



                    success: function(result){



                        $.gritter.add({title:"Operación realizada con éxito",text:"El registro fue eliminado con éxito"});
                        location.reload();


                    }



                });



            }



        }



    });



    



});

$('.bloquear-usuario').click(function(){
    var codempleado = $(this).data("codempleado");
    var bloqueo = $(this).data("bloqueo");
    bootbox.confirm({
        message: '<strong>Mensaje de confirmación:</strong> <br><br>¿Esta seguro de bloquear al empleado?',
        closeButton: false,
    buttons: {
        confirm: {
           label: 'Aceptar',
            className: 'btn-success'
        },
        cancel: {
            label: 'Cancelar',
            className: 'btn-danger'
        }
    },
    callback: function (result) {
        if (result) {
            $.ajax({
                url: "{{ url('empleado/bloqueo') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'post',
                data: {
                    codempleado: codempleado,
                    bloqueo: bloqueo
                },
                success: function(result){
                    $.gritter.add({title:"Operación realizada con éxito",text:"El empleado fue bloqueado con éxito"});
                   location.reload();
                }
            });
        }
    }
});







});




$('.resetar-password').click(function(){
var codempleado = $(this).data("codempleado");
console.log(codempleado);
bootbox.confirm({
    message: '<strong>Mensaje de confirmación:</strong> <br><br>¿Esta seguro de resetear la contraseña del empleado?',
    closeButton: false,
    buttons: {
        confirm: {
            label: 'Aceptar',
            className: 'btn-success'
        },
        cancel: {
            label: 'Cancelar',
            className: 'btn-danger'
        }
    },
    callback: function (result) {
        $(".loader2").show();
        if (result) {
            $.ajax({
                url: "{{ url('empleado/resetear-password') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'post',
                data: {
                    codempleado: codempleado
                },
                success: function(result){
                    $(".loader2").hide();
                    $.gritter.add({title:"Operación realizada con éxito",text:"La contraseña se actualizó con éxito"});
                }
            });
        }else{
            $(".loader2").hide();
        }
    }
});







});



   











  



</script>



    



@endsection