
<!DOCTYPE html>
<html lang="es">



<!-- Mirrored from www.themeon.net/nifty/v2.9/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 26 Apr 2018 20:15:22 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="http://localhost/gestor-web/public/img/favicon.png">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="nQjtpYHZZEPNhGmymT2dfEfdeEcudoKbarYz6RJW">
    <title>Crear nueva pagina - Gestor web</title>


    <!--STYLESHEET-->
    <!--=================================================-->

    <!--Open Sans Font [ OPTIONAL ]-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>


    <!--Bootstrap Stylesheet [ REQUIRED ]-->
    
    <link href="http://localhost/gestor-web/public/css/bootstrap.min.css" rel="stylesheet">


    <!--Nifty Stylesheet [ REQUIRED ]-->
    <link href="http://localhost/gestor-web/public/css/nifty.min.css" rel="stylesheet">


    <!--Nifty Premium Icon [ DEMONSTRATION ]-->
    <link href="http://localhost/gestor-web/public/css/demo/nifty-demo-icons.min.css" rel="stylesheet">


    <!--=================================================-->





    <!--Demo [ DEMONSTRATION ]-->
    <link href="http://localhost/gestor-web/public/css/demo/nifty-demo.min.css" rel="stylesheet">
    <link href="http://localhost/gestor-web/public/plugins/themify-icons/themify-icons.min.css" rel="stylesheet">
    <link href="http://localhost/gestor-web/public/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!--Summernote [ OPTIONAL ]-->
    <link href="http://localhost/gestor-web/public/plugins/summernote/summernote.min.css" rel="stylesheet">
    <link href="http://localhost/gestor-web/public/plugins/fancybox/jquery.fancybox.min.css" rel="stylesheet">
    <!--DataTables [ OPTIONAL ]-->
    <link href="http://localhost/gestor-web/public/plugins/datatables/media/css/dataTables.bootstrap.css" rel="stylesheet">
	<link href="http://localhost/gestor-web/public/plugins/datatables/extensions/Responsive/css/responsive.dataTables.min.css" rel="stylesheet">
    <!--Chosen [ OPTIONAL ]-->
    <link href="http://localhost/gestor-web/public/plugins/chosen/chosen.min.css" rel="stylesheet">
    <link href="http://localhost/gestor-web/public/plugins/chosen/chosenIcon.css" rel="stylesheet">
    <!--Switchery [ OPTIONAL ]-->
    <link href="http://localhost/gestor-web/public/plugins/switchery/switchery.min.css" rel="stylesheet">
      

</head>

<!--TIPS-->
<!--You may remove all ID or Class names which contain "demo-", they are only used for demonstration. -->
<body style="background-color: #ecf0f5 !important;">
        <div id="container" class="effect aside-float aside-bright mainnav-sm">
            
            <!--NAVBAR-->
            <!--===================================================-->
            <header id="navbar">
                <div id="navbar-container" class="boxed">
    
                    <!--Brand logo & name-->
                    <!--================================-->
                    <div class="navbar-header">
                        <a href="index.html" class="navbar-brand">
                            <img src="img/logo.png" alt="Nifty Logo" class="brand-icon">
                            <div class="brand-title">
                                <span class="brand-text">Nifty</span>
                            </div>
                        </a>
                    </div>
                    <!--================================-->
                    <!--End brand logo & name-->
    
    
                    <!--Navbar Dropdown-->
                    <!--================================-->
                    <div class="navbar-content">
                        <ul class="nav navbar-top-links">
    
                            <!--Navigation toogle button-->
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <li class="tgl-menu-btn">
                                <a class="mainnav-toggle" href="#">
                                    <i class="demo-pli-list-view"></i>
                                </a>
                            </li>
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <!--End Navigation toogle button-->
    
    
    
                            <!--Search-->
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <li>
                                <div class="custom-search-form">
                                    <label class="btn btn-trans" for="search-input" data-toggle="collapse" data-target="#nav-searchbox">
                                        <i class="demo-pli-magnifi-glass"></i>
                                    </label>
                                    <form>
                                        <div class="search-container collapse" id="nav-searchbox">
                                            <input id="search-input" type="text" class="form-control" placeholder="Type for search...">
                                        </div>
                                    </form>
                                </div>
                            </li>
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <!--End Search-->
    
                        </ul>
                        <ul class="nav navbar-top-links">
    
    
                            <!--Mega dropdown-->
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <li class="mega-dropdown">
                                <a href="#" class="mega-dropdown-toggle">
                                    <i class="demo-pli-layout-grid"></i>
                                </a>
                                <div class="dropdown-menu mega-dropdown-menu">
                                    <div class="row">
                                        <div class="col-sm-4 col-md-3">
    
                                            <!--Mega menu list-->
                                            <ul class="list-unstyled">
                                                <li class="dropdown-header"><i class="demo-pli-file icon-lg icon-fw"></i> Pages</li>
                                                <li><a href="#">Profile</a></li>
                                                <li><a href="#">Search Result</a></li>
                                                <li><a href="#">FAQ</a></li>
                                                <li><a href="#">Sreen Lock</a></li>
                                                <li><a href="#">Maintenance</a></li>
                                                <li><a href="#">Invoice</a></li>
                                                <li><a href="#" class="disabled">Disabled</a></li>                                        </ul>
    
                                        </div>
                                        <div class="col-sm-4 col-md-3">
    
                                            <!--Mega menu list-->
                                            <ul class="list-unstyled">
                                                <li class="dropdown-header"><i class="demo-pli-mail icon-lg icon-fw"></i> Mailbox</li>
                                                <li><a href="#"><span class="pull-right label label-danger">Hot</span>Indox</a></li>
                                                <li><a href="#">Read Message</a></li>
                                                <li><a href="#">Compose</a></li>
                                                <li><a href="#">Template</a></li>
                                            </ul>
                                            <p class="pad-top text-main text-sm text-uppercase text-bold"><i class="icon-lg demo-pli-calendar-4 icon-fw"></i>News</p>
                                            <p class="pad-top mar-top bord-top text-sm">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes.</p>
                                        </div>
                                        <div class="col-sm-4 col-md-3">
                                            <!--Mega menu list-->
                                            <ul class="list-unstyled">
                                                <li>
                                                    <a href="#" class="media mar-btm">
                                                        <span class="badge badge-success pull-right">90%</span>
                                                        <div class="media-left">
                                                            <i class="demo-pli-data-settings icon-2x"></i>
                                                        </div>
                                                        <div class="media-body">
                                                            <p class="text-semibold text-main mar-no">Data Backup</p>
                                                            <small class="text-muted">This is the item description</small>
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="media mar-btm">
                                                        <div class="media-left">
                                                            <i class="demo-pli-support icon-2x"></i>
                                                        </div>
                                                        <div class="media-body">
                                                            <p class="text-semibold text-main mar-no">Support</p>
                                                            <small class="text-muted">This is the item description</small>
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="media mar-btm">
                                                        <div class="media-left">
                                                            <i class="demo-pli-computer-secure icon-2x"></i>
                                                        </div>
                                                        <div class="media-body">
                                                            <p class="text-semibold text-main mar-no">Security</p>
                                                            <small class="text-muted">This is the item description</small>
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="media mar-btm">
                                                        <div class="media-left">
                                                            <i class="demo-pli-map-2 icon-2x"></i>
                                                        </div>
                                                        <div class="media-body">
                                                            <p class="text-semibold text-main mar-no">Location</p>
                                                            <small class="text-muted">This is the item description</small>
                                                        </div>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-sm-12 col-md-3">
                                            <p class="dropdown-header"><i class="demo-pli-file-jpg icon-lg icon-fw"></i> Gallery</p>
                                            <div class="row img-gallery">
                                                <div class="col-xs-4">
                                                    <img class="img-responsive" src="img/thumbs/img-1.jpg" alt="thumbs">
                                                </div>
                                                <div class="col-xs-4">
                                                    <img class="img-responsive" src="img/thumbs/img-3.jpg" alt="thumbs">
                                                </div>
                                                <div class="col-xs-4">
                                                    <img class="img-responsive" src="img/thumbs/img-2.jpg" alt="thumbs">
                                                </div>
                                                <div class="col-xs-4">
                                                    <img class="img-responsive" src="img/thumbs/img-4.jpg" alt="thumbs">
                                                </div>
                                                <div class="col-xs-4">
                                                    <img class="img-responsive" src="img/thumbs/img-6.jpg" alt="thumbs">
                                                </div>
                                                <div class="col-xs-4">
                                                    <img class="img-responsive" src="img/thumbs/img-5.jpg" alt="thumbs">
                                                </div>
                                            </div>
                                            <a href="#" class="btn btn-block btn-primary">Browse Gallery</a>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <!--End mega dropdown-->
    
    
    
                            <!--Notification dropdown-->
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <li class="dropdown">
                                <a href="#" data-toggle="dropdown" class="dropdown-toggle">
                                    <i class="demo-pli-bell"></i>
                                    <span class="badge badge-header badge-danger"></span>
                                </a>
    
    
                                <!--Notification dropdown menu-->
                                <div class="dropdown-menu dropdown-menu-md dropdown-menu-right">
                                    <div class="nano scrollable">
                                        <div class="nano-content">
                                            <ul class="head-list">
                                                <li>
                                                    <a href="#" class="media add-tooltip" data-title="Used space : 95%" data-container="body" data-placement="bottom">
                                                        <div class="media-left">
                                                            <i class="demo-pli-data-settings icon-2x text-main"></i>
                                                        </div>
                                                        <div class="media-body">
                                                            <p class="text-nowrap text-main text-semibold">HDD is full</p>
                                                            <div class="progress progress-sm mar-no">
                                                                <div style="width: 95%;" class="progress-bar progress-bar-danger">
                                                                    <span class="sr-only">95% Complete</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="media" href="#">
                                                        <div class="media-left">
                                                            <i class="demo-pli-file-edit icon-2x"></i>
                                                        </div>
                                                        <div class="media-body">
                                                            <p class="mar-no text-nowrap text-main text-semibold">Write a news article</p>
                                                            <small>Last Update 8 hours ago</small>
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="media" href="#">
                                                        <span class="label label-info pull-right">New</span>
                                                        <div class="media-left">
                                                            <i class="demo-pli-speech-bubble-7 icon-2x"></i>
                                                        </div>
                                                        <div class="media-body">
                                                            <p class="mar-no text-nowrap text-main text-semibold">Comment Sorting</p>
                                                            <small>Last Update 8 hours ago</small>
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="media" href="#">
                                                        <div class="media-left">
                                                            <i class="demo-pli-add-user-star icon-2x"></i>
                                                        </div>
                                                        <div class="media-body">
                                                            <p class="mar-no text-nowrap text-main text-semibold">New User Registered</p>
                                                            <small>4 minutes ago</small>
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="media" href="#">
                                                        <div class="media-left">
                                                            <img class="img-circle img-sm" alt="Profile Picture" src="img/profile-photos/9.png">
                                                        </div>
                                                        <div class="media-body">
                                                            <p class="mar-no text-nowrap text-main text-semibold">Lucy sent you a message</p>
                                                            <small>30 minutes ago</small>
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="media" href="#">
                                                        <div class="media-left">
                                                            <img class="img-circle img-sm" alt="Profile Picture" src="img/profile-photos/3.png">
                                                        </div>
                                                        <div class="media-body">
                                                            <p class="mar-no text-nowrap text-main text-semibold">Jackson sent you a message</p>
                                                            <small>40 minutes ago</small>
                                                        </div>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
    
                                    <!--Dropdown footer-->
                                    <div class="pad-all bord-top">
                                        <a href="#" class="btn-link text-main box-block">
                                            <i class="pci-chevron chevron-right pull-right"></i>Show All Notifications
                                        </a>
                                    </div>
                                </div>
                            </li>
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <!--End notifications dropdown-->
    
    
    
                            <!--User dropdown-->
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <li id="dropdown-user" class="dropdown">
                                <a href="#" data-toggle="dropdown" class="dropdown-toggle text-right">
                                    <span class="ic-user pull-right">
                                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                        <!--You can use an image instead of an icon.-->
                                        <!--<img class="img-circle img-user media-object" src="img/profile-photos/1.png" alt="Profile Picture">-->
                                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                        <i class="demo-pli-male"></i>
                                    </span>
                                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                    <!--You can also display a user name in the navbar.-->
                                    <!--<div class="username hidden-xs">Aaron Chavez</div>-->
                                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                </a>
    
    
                                <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right panel-default">
                                    <ul class="head-list">
                                        <li>
                                            <a href="#"><i class="demo-pli-male icon-lg icon-fw"></i> Profile</a>
                                        </li>
                                        <li>
                                            <a href="#"><span class="badge badge-danger pull-right">9</span><i class="demo-pli-mail icon-lg icon-fw"></i> Messages</a>
                                        </li>
                                        <li>
                                            <a href="#"><span class="label label-success pull-right">New</span><i class="demo-pli-gear icon-lg icon-fw"></i> Settings</a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="demo-pli-computer-secure icon-lg icon-fw"></i> Lock screen</a>
                                        </li>
                                        <li>
                                            <a href="pages-login.html"><i class="demo-pli-unlock icon-lg icon-fw"></i> Logout</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <!--End user dropdown-->
     
                            
                            <li>
                                <a href="#" class="aside-toggle">
                                    <i class="demo-pli-dot-vertical"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!--================================-->
                    <!--End Navbar Dropdown-->
    
                </div>
            </header>
            <!--===================================================-->
            <!--END NAVBAR-->
    
            <div class="boxed">
    
                <!--CONTENT CONTAINER-->
                <!--===================================================-->
                <div id="content-container" style="background-color: #254769 !important; height: 165px;">
                    <div id="page-head">
                        
                        <!--Page Title-->
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <div id="page-title">
                                <h1 class="page-header text-overflow">Menus</h1>
                            </div>    
                        
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                        <!--End page title-->
    
    
                        <!--Breadcrumb-->
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                        <ol class="breadcrumb">
                        <li><a href="#"><i class="demo-pli-home"></i></a></li>
                        <li><a href="#">Layouts</a></li>
                        <li class="active">Collapsed Navigation</li>
                        </ol>
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                        <!--End breadcrumb-->
    
                    </div>
    
                    
                    <!--Page content-->
                    <!--===================================================-->
                    <div id="page-content">
                        
                        
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="panel panel-body text-center">
                                        <div class="panel-body" id="tablaContenedor">
                                            <div class="table-responsive">
                                                
                                                <table id="demo-dt-selection" class="table table-striped table-vcenter" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th></th>
                                                            <th>Nombre menu</th>
                                                            <th class="text-center">Estado</th>
                                                            <th class="text-center">Acciones</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn- btn-icon btn-circle">
                                                                                                            <i class="658"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Estudiantes
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-danger">Inactivo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn- btn-icon btn-circle">
                                                                                                            <i class="645"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Directivos
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-danger">Inactivo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn-info btn-icon btn-circle">
                                                                                                            <i class="180"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Docentes
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-danger">Inactivo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn-success btn-icon btn-circle">
                                                                                                            <i class="fa fa-compass"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Dependencias
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-danger">Inactivo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn-danger btn-icon btn-circle">
                                                                                                            <i class="fa fa-forumbee"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Eventos
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-danger">Inactivo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn-danger btn-icon btn-circle">
                                                                                                            <i class="fa fa-forumbee"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Eventos
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-danger">Inactivo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn-danger btn-icon btn-circle">
                                                                                                            <i class="fa fa-forumbee"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Eventos
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-danger">Inactivo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn-danger btn-icon btn-circle">
                                                                                                            <i class="fa fa-forumbee"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Eventos
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-success">Activo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn-purple btn-icon btn-circle">
                                                                                                            <img src="http://www.capuchinasarmenia.com/public/img/nav-menu/nav1.png" alt="">
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Inscripciones
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-success">Activo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn-warning btn-icon btn-circle">
                                                                                                            <i class="fa fa-heartbeat"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Enfermeria
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-success">Activo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn-info btn-icon btn-circle">
                                                                                                            <i class="fa fa-drupal"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Deportes
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-success">Activo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                            <tr>
                                                                <td>
                                                                    <button class="btn btn-dark btn-icon btn-circle">
                                                                                                            <i class="fa fa-trophy"></i>
                                                                                                    </button>
                                                                </td>
                                                                <td class="text-left">
                                                                    Nuevo menu
                                                                </td>
                                                                <td class="text-center">
                                                                                                    <div class="label label-table label-success">Activo</div>
                                                                                            </td>
                                                                <td class="min-width">
                                                                    <div class="btn-groups">
                                                                        <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="View post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body"></a>
                                                                        <a href="#" class="btn btn-icon demo-pli-trash icon-lg add-tooltip" data-original-title="Remove" data-container="body"></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                        <!--Panel with Tabs (Icon)-->
                                        <!--===================================================-->
                                        <div class="panel panel-mint" style="min-height: 500px;">
                                
                                            <!--Panel heading-->
                                            <div class="panel-heading">
                                                <div class="panel-control">
                                                    <ul class="nav nav-tabs">
                                                        <li class="active">
                                                            <a data-toggle="tab" href="#demo-tabs2-box-1" aria-expanded="true">
                                                                <i class="ti ti-plus"></i>
                                                            </a>
                                                        </li>
                                                        <li class="">
                                                            <a data-toggle="tab" href="#demo-tabs2-box-2" aria-expanded="false">
                                                                <i class="demo-pli-laptop icon-lg"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                
                                            <!--Panel Body-->
                                            <div class="panel-body">
                                                <div class="tab-content">
                                                    <div id="demo-tabs2-box-1" class="tab-pane fade active in">
                                                        <form method="POST" action="http://localhost/gestor-web/public/menus/crear-menus" accept-charset="UTF-8" class="validation-wizard wizard-circle" id="agregarMenu"><input name="_token" type="hidden" value="nQjtpYHZZEPNhGmymT2dfEfdeEcudoKbarYz6RJW">  
                                                            <div class="panel-body">
                                                                <div class="row">
                                                                    <div class="col-sm-6">
                                                                        <div class="form-group">
                                                                            <label class="control-label">Nombre menu</label>
                                                                            <input class="nombre-menu form-control" autocomplete="off" name="nombre" type="text">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-6">
                                                                        <div class="form-group">
                                                                            <label class="control-label">Menu padre</label>
                                                                            <select class="form-control chosen-select" required="required" name="id_menu_padre"><option selected="selected" value="">Seleccione menu padre</option><option value="1">MENU PRINCIPAL</option><option value="2">Estudiantes</option><option value="3">Directivos</option><option value="4">Docentes</option><option value="5">Dependencias</option><option value="6">Eventos</option><option value="7">Eventos</option><option value="8">Eventos</option><option value="9">Eventos</option><option value="10">Inscripciones</option><option value="11">Enfermeria</option><option value="12">Deportes</option><option value="13">Nuevo menu</option></select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label class="control-label">Url</label>
                                                                            <div class="radio">
                                                                                <input class="form-control" autocomplete="off" name="url" type="text">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-3">
                                                                        <div class="form-group">
                                                                            <label class="control-label">Target</label>
                                                                            <div class="radio">
                                                                                <select class="form-control chosen-select" required="required" name="target"><option selected="selected" value="">Seleccione target</option><option value="1">_framename</option><option value="2">_parent</option><option value="3">_blank</option><option value="4">_self</option><option value="5">_top</option></select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-1">
                                                                        <label class="control-label">¿Activo?</label>
                                                                        <div class="radio mar-top">
                                                                            <input id="demo-sw-checked" type="checkbox" name="activo" value="1" checked>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <label class="control-label">Color</label>
                                                                        <input id="color" autocomplete="off" name="color" type="hidden">
                                                                        <div class="radio">
                                                                            <div class="btn-group" role="group" aria-label="...">
                                                                                <button type="button" class="btn btn-info colorSeleccionar" data-clase="btn btn-info btn-circle" data-color="info"><i class="fa fa-circle"></i></button>
                                                                                <button type="button" class="btn btn-warning colorSeleccionar" data-clase="btn btn-warning btn-circle" data-color="warning"><i class="fa fa-circle"></i></button>
                                                                                <button type="button" class="btn btn-success colorSeleccionar" data-clase="btn btn-success btn-circle" data-color="success"><i class="fa fa-circle"></i></button>
                                                                                <button type="button" class="btn btn-danger colorSeleccionar" data-clase="btn btn-danger btn-circle" data-color="danger"><i class="fa fa-circle"></i></button>
                                                                                <button type="button" class="btn btn-purple colorSeleccionar" data-clase="btn btn-purple btn-circle" data-color="purple"><i class="fa fa-circle"></i></button>
                                                                                <button type="button" class="btn btn-pink colorSeleccionar" data-clase="btn btn-pink btn-circle" data-color="pink"><i class="fa fa-circle"></i></button>
                                                                                <button type="button" class="btn btn-dark colorSeleccionar" data-clase="btn btn-dark btn-circle" data-color="dark"><i class="fa fa-circle"></i></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="row">
                                                                    <div class="col-md-3">
                                                                        <div class="form-group">
                                                                            <label class="control-label">Icono</label>
                                                                            <div class="radio">
                                                                                <select class="form-control chosen-select" required="required" id="imagen" name="imagen"><option value="1">Imagen</option><option value="2" selected="selected">Icono</option></select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label class="control-label">Recurso</label>
                                                                            <div class="radio">
                                                                                <div id="divIcono">
                                                                                    <div class="input-group">
                                                                                        <select id="class_icon" class="form-control chosen-select" name="class_icon"><option selected="selected" value="">Seleccione icono</option><option value="1" data-icon="fa fa-500px fa-2x">500px</option><option value="2" data-icon="fa fa-adjust fa-2x">Adjust</option><option value="3" data-icon="fa fa-adn fa-2x">Adn</option><option value="4" data-icon="fa fa-align-center fa-2x">Align Center</option><option value="5" data-icon="fa fa-align-justify fa-2x">Align Justify</option><option value="6" data-icon="fa fa-align-left fa-2x">Align Left</option><option value="7" data-icon="fa fa-align-right fa-2x">Align Right</option><option value="8" data-icon="fa fa-amazon fa-2x">Amazon</option><option value="9" data-icon="fa fa-ambulance fa-2x">Ambulance</option><option value="10" data-icon="fa fa-anchor fa-2x">Anchor</option><option value="11" data-icon="fa fa-android fa-2x">Android</option><option value="12" data-icon="fa fa-angellist fa-2x">Angellist</option><option value="13" data-icon="fa fa-angle-double-down fa-2x">Angle Double Down</option><option value="14" data-icon="fa fa-angle-double-left fa-2x">Angle Double Left</option><option value="15" data-icon="fa fa-angle-double-right fa-2x">Angle Double Right</option><option value="16" data-icon="fa fa-angle-double-up fa-2x">Angle Double Up</option><option value="17" data-icon="fa fa-angle-down fa-2x">Angle Down</option><option value="18" data-icon="fa fa-angle-left fa-2x">Angle Left</option><option value="19" data-icon="fa fa-angle-right fa-2x">Angle Right</option><option value="20" data-icon="fa fa-angle-up fa-2x">Angle Up</option><option value="21" data-icon="fa fa-apple fa-2x">Apple</option><option value="22" data-icon="fa fa-archive fa-2x">Archive</option><option value="23" data-icon="fa fa-area-chart fa-2x">Area Chart</option><option value="24" data-icon="fa fa-arrow-circle-down fa-2x">Arrow Circle Down</option><option value="25" data-icon="fa fa-arrow-circle-left fa-2x">Arrow Circle Left</option><option value="26" data-icon="fa fa-arrow-circle-o-down fa-2x">Arrow Circle O Down</option><option value="27" data-icon="fa fa-arrow-circle-o-left fa-2x">Arrow Circle O Left</option><option value="28" data-icon="fa fa-arrow-circle-o-right fa-2x">Arrow Circle O Right</option><option value="29" data-icon="fa fa-arrow-circle-o-up fa-2x">Arrow Circle O Up</option><option value="30" data-icon="fa fa-arrow-circle-right fa-2x">Arrow Circle Right</option><option value="31" data-icon="fa fa-arrow-circle-up fa-2x">Arrow Circle Up</option><option value="32" data-icon="fa fa-arrow-down fa-2x">Arrow Down</option><option value="33" data-icon="fa fa-arrow-left fa-2x">Arrow Left</option><option value="34" data-icon="fa fa-arrow-right fa-2x">Arrow Right</option><option value="35" data-icon="fa fa-arrow-up fa-2x">Arrow Up</option><option value="36" data-icon="fa fa-arrows fa-2x">Arrows</option><option value="37" data-icon="fa fa-arrows-alt fa-2x">Arrows Alt</option><option value="38" data-icon="fa fa-arrows-h fa-2x">Arrows H</option><option value="39" data-icon="fa fa-arrows-v fa-2x">Arrows V</option><option value="40" data-icon="fa fa-asterisk fa-2x">Asterisk</option><option value="41" data-icon="fa fa-at fa-2x">At</option><option value="42" data-icon="fa fa-automobile fa-2x">Automobile</option><option value="43" data-icon="fa fa-backward fa-2x">Backward</option><option value="44" data-icon="fa fa-balance-scale fa-2x">Balance Scale</option><option value="45" data-icon="fa fa-ban fa-2x">Ban</option><option value="46" data-icon="fa fa-bank fa-2x">Bank</option><option value="47" data-icon="fa fa-bar-chart fa-2x">Bar Chart</option><option value="48" data-icon="fa fa-bar-chart-o fa-2x">Bar Chart O</option><option value="49" data-icon="fa fa-barcode fa-2x">Barcode</option><option value="50" data-icon="fa fa-bars fa-2x">Bars</option><option value="51" data-icon="fa fa-battery-0 fa-2x">Battery 0</option><option value="52" data-icon="fa fa-battery-1 fa-2x">Battery 1</option><option value="53" data-icon="fa fa-battery-2 fa-2x">Battery 2</option><option value="54" data-icon="fa fa-battery-3 fa-2x">Battery 3</option><option value="55" data-icon="fa fa-battery-4 fa-2x">Battery 4</option><option value="56" data-icon="fa fa-battery-empty fa-2x">Battery Empty</option><option value="57" data-icon="fa fa-battery-full fa-2x">Battery Full</option><option value="58" data-icon="fa fa-battery-half fa-2x">Battery Half</option><option value="59" data-icon="fa fa-battery-quarter fa-2x">Battery Quarter</option><option value="60" data-icon="fa fa-battery-three-quarters fa-2x">Battery Three Quarters</option><option value="61" data-icon="fa fa-bed fa-2x">Bed</option><option value="62" data-icon="fa fa-beer fa-2x">Beer</option><option value="63" data-icon="fa fa-behance fa-2x">Behance</option><option value="64" data-icon="fa fa-behance-square fa-2x">Behance Square</option><option value="65" data-icon="fa fa-bell fa-2x">Bell</option><option value="66" data-icon="fa fa-bell-o fa-2x">Bell O</option><option value="67" data-icon="fa fa-bell-slash fa-2x">Bell Slash</option><option value="68" data-icon="fa fa-bell-slash-o fa-2x">Bell Slash O</option><option value="69" data-icon="fa fa-bicycle fa-2x">Bicycle</option><option value="70" data-icon="fa fa-binoculars fa-2x">Binoculars</option><option value="71" data-icon="fa fa-birthday-cake fa-2x">Birthday Cake</option><option value="72" data-icon="fa fa-bitbucket fa-2x">Bitbucket</option><option value="73" data-icon="fa fa-bitbucket-square fa-2x">Bitbucket Square</option><option value="74" data-icon="fa fa-bitcoin fa-2x">Bitcoin</option><option value="75" data-icon="fa fa-black-tie fa-2x">Black Tie</option><option value="76" data-icon="fa fa-bluetooth fa-2x">Bluetooth</option><option value="77" data-icon="fa fa-bluetooth-b fa-2x">Bluetooth B</option><option value="78" data-icon="fa fa-bold fa-2x">Bold</option><option value="79" data-icon="fa fa-bolt fa-2x">Bolt</option><option value="80" data-icon="fa fa-bomb fa-2x">Bomb</option><option value="81" data-icon="fa fa-book fa-2x">Book</option><option value="82" data-icon="fa fa-bookmark fa-2x">Bookmark</option><option value="83" data-icon="fa fa-bookmark-o fa-2x">Bookmark O</option><option value="84" data-icon="fa fa-briefcase fa-2x">Briefcase</option><option value="85" data-icon="fa fa-btc fa-2x">Btc</option><option value="86" data-icon="fa fa-bug fa-2x">Bug</option><option value="87" data-icon="fa fa-building fa-2x">Building</option><option value="88" data-icon="fa fa-building-o fa-2x">Building O</option><option value="89" data-icon="fa fa-bullhorn fa-2x">Bullhorn</option><option value="90" data-icon="fa fa-bullseye fa-2x">Bullseye</option><option value="91" data-icon="fa fa-bus fa-2x">Bus</option><option value="92" data-icon="fa fa-buysellads fa-2x">Buysellads</option><option value="93" data-icon="fa fa-cab fa-2x">Cab</option><option value="94" data-icon="fa fa-calculator fa-2x">Calculator</option><option value="95" data-icon="fa fa-calendar fa-2x">Calendar</option><option value="96" data-icon="fa fa-calendar-check-o fa-2x">Calendar Check O</option><option value="97" data-icon="fa fa-calendar-minus-o fa-2x">Calendar Minus O</option><option value="98" data-icon="fa fa-calendar-o fa-2x">Calendar O</option><option value="99" data-icon="fa fa-calendar-plus-o fa-2x">Calendar Plus O</option><option value="100" data-icon="fa fa-calendar-times-o fa-2x">Calendar Times O</option><option value="101" data-icon="fa fa-camera fa-2x">Camera</option><option value="102" data-icon="fa fa-camera-retro fa-2x">Camera Retro</option><option value="103" data-icon="fa fa-car fa-2x">Car</option><option value="104" data-icon="fa fa-caret-down fa-2x">Caret Down</option><option value="105" data-icon="fa fa-caret-left fa-2x">Caret Left</option><option value="106" data-icon="fa fa-caret-right fa-2x">Caret Right</option><option value="107" data-icon="fa fa-caret-square-o-down fa-2x">Caret Square O Down</option><option value="108" data-icon="fa fa-caret-square-o-left fa-2x">Caret Square O Left</option><option value="109" data-icon="fa fa-caret-square-o-right fa-2x">Caret Square O Right</option><option value="110" data-icon="fa fa-caret-square-o-up fa-2x">Caret Square O Up</option><option value="111" data-icon="fa fa-caret-up fa-2x">Caret Up</option><option value="112" data-icon="fa fa-cart-arrow-down fa-2x">Cart Arrow Down</option><option value="113" data-icon="fa fa-cart-plus fa-2x">Cart Plus</option><option value="114" data-icon="fa fa-cc fa-2x">Cc</option><option value="115" data-icon="fa fa-cc-amex fa-2x">Cc Amex</option><option value="116" data-icon="fa fa-cc-diners-club fa-2x">Cc Diners Club</option><option value="117" data-icon="fa fa-cc-discover fa-2x">Cc Discover</option><option value="118" data-icon="fa fa-cc-jcb fa-2x">Cc Jcb</option><option value="119" data-icon="fa fa-cc-mastercard fa-2x">Cc Mastercard</option><option value="120" data-icon="fa fa-cc-paypal fa-2x">Cc Paypal</option><option value="121" data-icon="fa fa-cc-stripe fa-2x">Cc Stripe</option><option value="122" data-icon="fa fa-cc-visa fa-2x">Cc Visa</option><option value="123" data-icon="fa fa-certificate fa-2x">Certificate</option><option value="124" data-icon="fa fa-chain fa-2x">Chain</option><option value="125" data-icon="fa fa-chain-broken fa-2x">Chain Broken</option><option value="126" data-icon="fa fa-check fa-2x">Check</option><option value="127" data-icon="fa fa-check-circle fa-2x">Check Circle</option><option value="128" data-icon="fa fa-check-circle-o fa-2x">Check Circle O</option><option value="129" data-icon="fa fa-check-square fa-2x">Check Square</option><option value="130" data-icon="fa fa-check-square-o fa-2x">Check Square O</option><option value="131" data-icon="fa fa-chevron-circle-down fa-2x">Chevron Circle Down</option><option value="132" data-icon="fa fa-chevron-circle-left fa-2x">Chevron Circle Left</option><option value="133" data-icon="fa fa-chevron-circle-right fa-2x">Chevron Circle Right</option><option value="134" data-icon="fa fa-chevron-circle-up fa-2x">Chevron Circle Up</option><option value="135" data-icon="fa fa-chevron-down fa-2x">Chevron Down</option><option value="136" data-icon="fa fa-chevron-left fa-2x">Chevron Left</option><option value="137" data-icon="fa fa-chevron-right fa-2x">Chevron Right</option><option value="138" data-icon="fa fa-chevron-up fa-2x">Chevron Up</option><option value="139" data-icon="fa fa-child fa-2x">Child</option><option value="140" data-icon="fa fa-chrome fa-2x">Chrome</option><option value="141" data-icon="fa fa-circle fa-2x">Circle</option><option value="142" data-icon="fa fa-circle-o fa-2x">Circle O</option><option value="143" data-icon="fa fa-circle-o-notch fa-2x">Circle O Notch</option><option value="144" data-icon="fa fa-circle-thin fa-2x">Circle Thin</option><option value="145" data-icon="fa fa-clipboard fa-2x">Clipboard</option><option value="146" data-icon="fa fa-clock-o fa-2x">Clock O</option><option value="147" data-icon="fa fa-clone fa-2x">Clone</option><option value="148" data-icon="fa fa-close fa-2x">Close</option><option value="149" data-icon="fa fa-cloud fa-2x">Cloud</option><option value="150" data-icon="fa fa-cloud-download fa-2x">Cloud Download</option><option value="151" data-icon="fa fa-cloud-upload fa-2x">Cloud Upload</option><option value="152" data-icon="fa fa-cny fa-2x">Cny</option><option value="153" data-icon="fa fa-code fa-2x">Code</option><option value="154" data-icon="fa fa-code-fork fa-2x">Code Fork</option><option value="155" data-icon="fa fa-codepen fa-2x">Codepen</option><option value="156" data-icon="fa fa-codiepie fa-2x">Codiepie</option><option value="157" data-icon="fa fa-coffee fa-2x">Coffee</option><option value="158" data-icon="fa fa-cog fa-2x">Cog</option><option value="159" data-icon="fa fa-cogs fa-2x">Cogs</option><option value="160" data-icon="fa fa-columns fa-2x">Columns</option><option value="161" data-icon="fa fa-comment fa-2x">Comment</option><option value="162" data-icon="fa fa-comment-o fa-2x">Comment O</option><option value="163" data-icon="fa fa-commenting fa-2x">Commenting</option><option value="164" data-icon="fa fa-commenting-o fa-2x">Commenting O</option><option value="165" data-icon="fa fa-comments fa-2x">Comments</option><option value="166" data-icon="fa fa-comments-o fa-2x">Comments O</option><option value="167" data-icon="fa fa-compass fa-2x">Compass</option><option value="168" data-icon="fa fa-compress fa-2x">Compress</option><option value="169" data-icon="fa fa-connectdevelop fa-2x">Connectdevelop</option><option value="170" data-icon="fa fa-contao fa-2x">Contao</option><option value="171" data-icon="fa fa-copy fa-2x">Copy</option><option value="172" data-icon="fa fa-copyright fa-2x">Copyright</option><option value="173" data-icon="fa fa-creative-commons fa-2x">Creative Commons</option><option value="174" data-icon="fa fa-credit-card fa-2x">Credit Card</option><option value="175" data-icon="fa fa-credit-card-alt fa-2x">Credit Card Alt</option><option value="176" data-icon="fa fa-crop fa-2x">Crop</option><option value="177" data-icon="fa fa-crosshairs fa-2x">Crosshairs</option><option value="178" data-icon="fa fa-css3 fa-2x">Css3</option><option value="179" data-icon="fa fa-cube fa-2x">Cube</option><option value="180" data-icon="fa fa-cubes fa-2x">Cubes</option><option value="181" data-icon="fa fa-cut fa-2x">Cut</option><option value="182" data-icon="fa fa-cutlery fa-2x">Cutlery</option><option value="183" data-icon="fa fa-dashboard fa-2x">Dashboard</option><option value="184" data-icon="fa fa-dashcube fa-2x">Dashcube</option><option value="185" data-icon="fa fa-database fa-2x">Database</option><option value="186" data-icon="fa fa-dedent fa-2x">Dedent</option><option value="187" data-icon="fa fa-delicious fa-2x">Delicious</option><option value="188" data-icon="fa fa-desktop fa-2x">Desktop</option><option value="189" data-icon="fa fa-deviantart fa-2x">Deviantart</option><option value="190" data-icon="fa fa-diamond fa-2x">Diamond</option><option value="191" data-icon="fa fa-digg fa-2x">Digg</option><option value="192" data-icon="fa fa-dollar fa-2x">Dollar</option><option value="193" data-icon="fa fa-dot-circle-o fa-2x">Dot Circle O</option><option value="194" data-icon="fa fa-download fa-2x">Download</option><option value="195" data-icon="fa fa-dribbble fa-2x">Dribbble</option><option value="196" data-icon="fa fa-dropbox fa-2x">Dropbox</option><option value="197" data-icon="fa fa-drupal fa-2x">Drupal</option><option value="198" data-icon="fa fa-edge fa-2x">Edge</option><option value="199" data-icon="fa fa-edit fa-2x">Edit</option><option value="200" data-icon="fa fa-eject fa-2x">Eject</option><option value="201" data-icon="fa fa-ellipsis-h fa-2x">Ellipsis H</option><option value="202" data-icon="fa fa-ellipsis-v fa-2x">Ellipsis V</option><option value="203" data-icon="fa fa-empire fa-2x">Empire</option><option value="204" data-icon="fa fa-envelope fa-2x">Envelope</option><option value="205" data-icon="fa fa-envelope-o fa-2x">Envelope O</option><option value="206" data-icon="fa fa-envelope-square fa-2x">Envelope Square</option><option value="207" data-icon="fa fa-eraser fa-2x">Eraser</option><option value="208" data-icon="fa fa-eur fa-2x">Eur</option><option value="209" data-icon="fa fa-euro fa-2x">Euro</option><option value="210" data-icon="fa fa-exchange fa-2x">Exchange</option><option value="211" data-icon="fa fa-exclamation fa-2x">Exclamation</option><option value="212" data-icon="fa fa-exclamation-circle fa-2x">Exclamation Circle</option><option value="213" data-icon="fa fa-exclamation-triangle fa-2x">Exclamation Triangle</option><option value="214" data-icon="fa fa-expand fa-2x">Expand</option><option value="215" data-icon="fa fa-expeditedssl fa-2x">Expeditedssl</option><option value="216" data-icon="fa fa-external-link fa-2x">External Link</option><option value="217" data-icon="fa fa-external-link-square fa-2x">External Link Square</option><option value="218" data-icon="fa fa-eye fa-2x">Eye</option><option value="219" data-icon="fa fa-eye-slash fa-2x">Eye Slash</option><option value="220" data-icon="fa fa-eyedropper fa-2x">Eyedropper</option><option value="221" data-icon="fa fa-facebook fa-2x">Facebook</option><option value="222" data-icon="fa fa-facebook-f fa-2x">Facebook F</option><option value="223" data-icon="fa fa-facebook-official fa-2x">Facebook Official</option><option value="224" data-icon="fa fa-facebook-square fa-2x">Facebook Square</option><option value="225" data-icon="fa fa-fast-backward fa-2x">Fast Backward</option><option value="226" data-icon="fa fa-fast-forward fa-2x">Fast Forward</option><option value="227" data-icon="fa fa-fax fa-2x">Fax</option><option value="228" data-icon="fa fa-feed fa-2x">Feed</option><option value="229" data-icon="fa fa-female fa-2x">Female</option><option value="230" data-icon="fa fa-fighter-jet fa-2x">Fighter Jet</option><option value="231" data-icon="fa fa-file fa-2x">File</option><option value="232" data-icon="fa fa-file-archive-o fa-2x">File Archive O</option><option value="233" data-icon="fa fa-file-audio-o fa-2x">File Audio O</option><option value="234" data-icon="fa fa-file-code-o fa-2x">File Code O</option><option value="235" data-icon="fa fa-file-excel-o fa-2x">File Excel O</option><option value="236" data-icon="fa fa-file-image-o fa-2x">File Image O</option><option value="237" data-icon="fa fa-file-movie-o fa-2x">File Movie O</option><option value="238" data-icon="fa fa-file-o fa-2x">File O</option><option value="239" data-icon="fa fa-file-pdf-o fa-2x">File Pdf O</option><option value="240" data-icon="fa fa-file-photo-o fa-2x">File Photo O</option><option value="241" data-icon="fa fa-file-picture-o fa-2x">File Picture O</option><option value="242" data-icon="fa fa-file-powerpoint-o fa-2x">File Powerpoint O</option><option value="243" data-icon="fa fa-file-sound-o fa-2x">File Sound O</option><option value="244" data-icon="fa fa-file-text fa-2x">File Text</option><option value="245" data-icon="fa fa-file-text-o fa-2x">File Text O</option><option value="246" data-icon="fa fa-file-video-o fa-2x">File Video O</option><option value="247" data-icon="fa fa-file-word-o fa-2x">File Word O</option><option value="248" data-icon="fa fa-file-zip-o fa-2x">File Zip O</option><option value="249" data-icon="fa fa-files-o fa-2x">Files O</option><option value="250" data-icon="fa fa-film fa-2x">Film</option><option value="251" data-icon="fa fa-filter fa-2x">Filter</option><option value="252" data-icon="fa fa-fire fa-2x">Fire</option><option value="253" data-icon="fa fa-fire-extinguisher fa-2x">Fire Extinguisher</option><option value="254" data-icon="fa fa-firefox fa-2x">Firefox</option><option value="255" data-icon="fa fa-flag fa-2x">Flag</option><option value="256" data-icon="fa fa-flag-checkered fa-2x">Flag Checkered</option><option value="257" data-icon="fa fa-flag-o fa-2x">Flag O</option><option value="258" data-icon="fa fa-flash fa-2x">Flash</option><option value="259" data-icon="fa fa-flask fa-2x">Flask</option><option value="260" data-icon="fa fa-flickr fa-2x">Flickr</option><option value="261" data-icon="fa fa-floppy-o fa-2x">Floppy O</option><option value="262" data-icon="fa fa-folder fa-2x">Folder</option><option value="263" data-icon="fa fa-folder-o fa-2x">Folder O</option><option value="264" data-icon="fa fa-folder-open fa-2x">Folder Open</option><option value="265" data-icon="fa fa-folder-open-o fa-2x">Folder Open O</option><option value="266" data-icon="fa fa-font fa-2x">Font</option><option value="267" data-icon="fa fa-fonticons fa-2x">Fonticons</option><option value="268" data-icon="fa fa-fort-awesome fa-2x">Fort Awesome</option><option value="269" data-icon="fa fa-forumbee fa-2x">Forumbee</option><option value="270" data-icon="fa fa-forward fa-2x">Forward</option><option value="271" data-icon="fa fa-foursquare fa-2x">Foursquare</option><option value="272" data-icon="fa fa-frown-o fa-2x">Frown O</option><option value="273" data-icon="fa fa-futbol-o fa-2x">Futbol O</option><option value="274" data-icon="fa fa-gamepad fa-2x">Gamepad</option><option value="275" data-icon="fa fa-gavel fa-2x">Gavel</option><option value="276" data-icon="fa fa-gbp fa-2x">Gbp</option><option value="277" data-icon="fa fa-ge fa-2x">Ge</option><option value="278" data-icon="fa fa-gear fa-2x">Gear</option><option value="279" data-icon="fa fa-gears fa-2x">Gears</option><option value="280" data-icon="fa fa-genderless fa-2x">Genderless</option><option value="281" data-icon="fa fa-get-pocket fa-2x">Get Pocket</option><option value="282" data-icon="fa fa-gg fa-2x">Gg</option><option value="283" data-icon="fa fa-gg-circle fa-2x">Gg Circle</option><option value="284" data-icon="fa fa-gift fa-2x">Gift</option><option value="285" data-icon="fa fa-git fa-2x">Git</option><option value="286" data-icon="fa fa-git-square fa-2x">Git Square</option><option value="287" data-icon="fa fa-github fa-2x">Github</option><option value="288" data-icon="fa fa-github-alt fa-2x">Github Alt</option><option value="289" data-icon="fa fa-github-square fa-2x">Github Square</option><option value="290" data-icon="fa fa-gittip fa-2x">Gittip</option><option value="291" data-icon="fa fa-glass fa-2x">Glass</option><option value="292" data-icon="fa fa-globe fa-2x">Globe</option><option value="293" data-icon="fa fa-google fa-2x">Google</option><option value="294" data-icon="fa fa-google-plus fa-2x">Google Plus</option><option value="295" data-icon="fa fa-google-plus-square fa-2x">Google Plus Square</option><option value="296" data-icon="fa fa-google-wallet fa-2x">Google Wallet</option><option value="297" data-icon="fa fa-graduation-cap fa-2x">Graduation Cap</option><option value="298" data-icon="fa fa-gratipay fa-2x">Gratipay</option><option value="299" data-icon="fa fa-group fa-2x">Group</option><option value="300" data-icon="fa fa-h-square fa-2x">H Square</option><option value="301" data-icon="fa fa-hacker-news fa-2x">Hacker News</option><option value="302" data-icon="fa fa-hand-grab-o fa-2x">Hand Grab O</option><option value="303" data-icon="fa fa-hand-lizard-o fa-2x">Hand Lizard O</option><option value="304" data-icon="fa fa-hand-o-down fa-2x">Hand O Down</option><option value="305" data-icon="fa fa-hand-o-left fa-2x">Hand O Left</option><option value="306" data-icon="fa fa-hand-o-right fa-2x">Hand O Right</option><option value="307" data-icon="fa fa-hand-o-up fa-2x">Hand O Up</option><option value="308" data-icon="fa fa-hand-paper-o fa-2x">Hand Paper O</option><option value="309" data-icon="fa fa-hand-peace-o fa-2x">Hand Peace O</option><option value="310" data-icon="fa fa-hand-pointer-o fa-2x">Hand Pointer O</option><option value="311" data-icon="fa fa-hand-rock-o fa-2x">Hand Rock O</option><option value="312" data-icon="fa fa-hand-scissors-o fa-2x">Hand Scissors O</option><option value="313" data-icon="fa fa-hand-spock-o fa-2x">Hand Spock O</option><option value="314" data-icon="fa fa-hand-stop-o fa-2x">Hand Stop O</option><option value="315" data-icon="fa fa-hashtag fa-2x">Hashtag</option><option value="316" data-icon="fa fa-hdd-o fa-2x">Hdd O</option><option value="317" data-icon="fa fa-header fa-2x">Header</option><option value="318" data-icon="fa fa-headphones fa-2x">Headphones</option><option value="319" data-icon="fa fa-heart fa-2x">Heart</option><option value="320" data-icon="fa fa-heart-o fa-2x">Heart O</option><option value="321" data-icon="fa fa-heartbeat fa-2x">Heartbeat</option><option value="322" data-icon="fa fa-history fa-2x">History</option><option value="323" data-icon="fa fa-home fa-2x">Home</option><option value="324" data-icon="fa fa-hospital-o fa-2x">Hospital O</option><option value="325" data-icon="fa fa-hotel fa-2x">Hotel</option><option value="326" data-icon="fa fa-hourglass fa-2x">Hourglass</option><option value="327" data-icon="fa fa-hourglass-1 fa-2x">Hourglass 1</option><option value="328" data-icon="fa fa-hourglass-2 fa-2x">Hourglass 2</option><option value="329" data-icon="fa fa-hourglass-3 fa-2x">Hourglass 3</option><option value="330" data-icon="fa fa-hourglass-end fa-2x">Hourglass End</option><option value="331" data-icon="fa fa-hourglass-half fa-2x">Hourglass Half</option><option value="332" data-icon="fa fa-hourglass-o fa-2x">Hourglass O</option><option value="333" data-icon="fa fa-hourglass-start fa-2x">Hourglass Start</option><option value="334" data-icon="fa fa-houzz fa-2x">Houzz</option><option value="335" data-icon="fa fa-html5 fa-2x">Html5</option><option value="336" data-icon="fa fa-i-cursor fa-2x">I Cursor</option><option value="337" data-icon="fa fa-ils fa-2x">Ils</option><option value="338" data-icon="fa fa-image fa-2x">Image</option><option value="339" data-icon="fa fa-inbox fa-2x">Inbox</option><option value="340" data-icon="fa fa-indent fa-2x">Indent</option><option value="341" data-icon="fa fa-industry fa-2x">Industry</option><option value="342" data-icon="fa fa-info fa-2x">Info</option><option value="343" data-icon="fa fa-info-circle fa-2x">Info Circle</option><option value="344" data-icon="fa fa-inr fa-2x">Inr</option><option value="345" data-icon="fa fa-instagram fa-2x">Instagram</option><option value="346" data-icon="fa fa-institution fa-2x">Institution</option><option value="347" data-icon="fa fa-internet-explorer fa-2x">Internet Explorer</option><option value="348" data-icon="fa fa-intersex fa-2x">Intersex</option><option value="349" data-icon="fa fa-ioxhost fa-2x">Ioxhost</option><option value="350" data-icon="fa fa-italic fa-2x">Italic</option><option value="351" data-icon="fa fa-joomla fa-2x">Joomla</option><option value="352" data-icon="fa fa-jpy fa-2x">Jpy</option><option value="353" data-icon="fa fa-jsfiddle fa-2x">Jsfiddle</option><option value="354" data-icon="fa fa-key fa-2x">Key</option><option value="355" data-icon="fa fa-keyboard-o fa-2x">Keyboard O</option><option value="356" data-icon="fa fa-krw fa-2x">Krw</option><option value="357" data-icon="fa fa-language fa-2x">Language</option><option value="358" data-icon="fa fa-laptop fa-2x">Laptop</option><option value="359" data-icon="fa fa-lastfm fa-2x">Lastfm</option><option value="360" data-icon="fa fa-lastfm-square fa-2x">Lastfm Square</option><option value="361" data-icon="fa fa-leaf fa-2x">Leaf</option><option value="362" data-icon="fa fa-leanpub fa-2x">Leanpub</option><option value="363" data-icon="fa fa-legal fa-2x">Legal</option><option value="364" data-icon="fa fa-lemon-o fa-2x">Lemon O</option><option value="365" data-icon="fa fa-level-down fa-2x">Level Down</option><option value="366" data-icon="fa fa-level-up fa-2x">Level Up</option><option value="367" data-icon="fa fa-life-bouy fa-2x">Life Bouy</option><option value="368" data-icon="fa fa-life-buoy fa-2x">Life Buoy</option><option value="369" data-icon="fa fa-life-ring fa-2x">Life Ring</option><option value="370" data-icon="fa fa-life-saver fa-2x">Life Saver</option><option value="371" data-icon="fa fa-lightbulb-o fa-2x">Lightbulb O</option><option value="372" data-icon="fa fa-line-chart fa-2x">Line Chart</option><option value="373" data-icon="fa fa-link fa-2x">Link</option><option value="374" data-icon="fa fa-linkedin fa-2x">Linkedin</option><option value="375" data-icon="fa fa-linkedin-square fa-2x">Linkedin Square</option><option value="376" data-icon="fa fa-linux fa-2x">Linux</option><option value="377" data-icon="fa fa-list fa-2x">List</option><option value="378" data-icon="fa fa-list-alt fa-2x">List Alt</option><option value="379" data-icon="fa fa-list-ol fa-2x">List Ol</option><option value="380" data-icon="fa fa-list-ul fa-2x">List Ul</option><option value="381" data-icon="fa fa-location-arrow fa-2x">Location Arrow</option><option value="382" data-icon="fa fa-lock fa-2x">Lock</option><option value="383" data-icon="fa fa-long-arrow-down fa-2x">Long Arrow Down</option><option value="384" data-icon="fa fa-long-arrow-left fa-2x">Long Arrow Left</option><option value="385" data-icon="fa fa-long-arrow-right fa-2x">Long Arrow Right</option><option value="386" data-icon="fa fa-long-arrow-up fa-2x">Long Arrow Up</option><option value="387" data-icon="fa fa-magic fa-2x">Magic</option><option value="388" data-icon="fa fa-magnet fa-2x">Magnet</option><option value="389" data-icon="fa fa-mail-forward fa-2x">Mail Forward</option><option value="390" data-icon="fa fa-mail-reply fa-2x">Mail Reply</option><option value="391" data-icon="fa fa-mail-reply-all fa-2x">Mail Reply All</option><option value="392" data-icon="fa fa-male fa-2x">Male</option><option value="393" data-icon="fa fa-map fa-2x">Map</option><option value="394" data-icon="fa fa-map-marker fa-2x">Map Marker</option><option value="395" data-icon="fa fa-map-o fa-2x">Map O</option><option value="396" data-icon="fa fa-map-pin fa-2x">Map Pin</option><option value="397" data-icon="fa fa-map-signs fa-2x">Map Signs</option><option value="398" data-icon="fa fa-mars fa-2x">Mars</option><option value="399" data-icon="fa fa-mars-double fa-2x">Mars Double</option><option value="400" data-icon="fa fa-mars-stroke fa-2x">Mars Stroke</option><option value="401" data-icon="fa fa-mars-stroke-h fa-2x">Mars Stroke H</option><option value="402" data-icon="fa fa-mars-stroke-v fa-2x">Mars Stroke V</option><option value="403" data-icon="fa fa-maxcdn fa-2x">Maxcdn</option><option value="404" data-icon="fa fa-meanpath fa-2x">Meanpath</option><option value="405" data-icon="fa fa-medium fa-2x">Medium</option><option value="406" data-icon="fa fa-medkit fa-2x">Medkit</option><option value="407" data-icon="fa fa-meh-o fa-2x">Meh O</option><option value="408" data-icon="fa fa-mercury fa-2x">Mercury</option><option value="409" data-icon="fa fa-microphone fa-2x">Microphone</option><option value="410" data-icon="fa fa-microphone-slash fa-2x">Microphone Slash</option><option value="411" data-icon="fa fa-minus fa-2x">Minus</option><option value="412" data-icon="fa fa-minus-circle fa-2x">Minus Circle</option><option value="413" data-icon="fa fa-minus-square fa-2x">Minus Square</option><option value="414" data-icon="fa fa-minus-square-o fa-2x">Minus Square O</option><option value="415" data-icon="fa fa-mixcloud fa-2x">Mixcloud</option><option value="416" data-icon="fa fa-mobile fa-2x">Mobile</option><option value="417" data-icon="fa fa-mobile-phone fa-2x">Mobile Phone</option><option value="418" data-icon="fa fa-modx fa-2x">Modx</option><option value="419" data-icon="fa fa-money fa-2x">Money</option><option value="420" data-icon="fa fa-moon-o fa-2x">Moon O</option><option value="421" data-icon="fa fa-mortar-board fa-2x">Mortar Board</option><option value="422" data-icon="fa fa-motorcycle fa-2x">Motorcycle</option><option value="423" data-icon="fa fa-mouse-pointer fa-2x">Mouse Pointer</option><option value="424" data-icon="fa fa-music fa-2x">Music</option><option value="425" data-icon="fa fa-navicon fa-2x">Navicon</option><option value="426" data-icon="fa fa-neuter fa-2x">Neuter</option><option value="427" data-icon="fa fa-newspaper-o fa-2x">Newspaper O</option><option value="428" data-icon="fa fa-object-group fa-2x">Object Group</option><option value="429" data-icon="fa fa-object-ungroup fa-2x">Object Ungroup</option><option value="430" data-icon="fa fa-odnoklassniki fa-2x">Odnoklassniki</option><option value="431" data-icon="fa fa-odnoklassniki-square fa-2x">Odnoklassniki Square</option><option value="432" data-icon="fa fa-opencart fa-2x">Opencart</option><option value="433" data-icon="fa fa-openid fa-2x">Openid</option><option value="434" data-icon="fa fa-opera fa-2x">Opera</option><option value="435" data-icon="fa fa-optin-monster fa-2x">Optin Monster</option><option value="436" data-icon="fa fa-outdent fa-2x">Outdent</option><option value="437" data-icon="fa fa-pagelines fa-2x">Pagelines</option><option value="438" data-icon="fa fa-paint-brush fa-2x">Paint Brush</option><option value="439" data-icon="fa fa-paper-plane fa-2x">Paper Plane</option><option value="440" data-icon="fa fa-paper-plane-o fa-2x">Paper Plane O</option><option value="441" data-icon="fa fa-paperclip fa-2x">Paperclip</option><option value="442" data-icon="fa fa-paragraph fa-2x">Paragraph</option><option value="443" data-icon="fa fa-paste fa-2x">Paste</option><option value="444" data-icon="fa fa-pause fa-2x">Pause</option><option value="445" data-icon="fa fa-pause-circle fa-2x">Pause Circle</option><option value="446" data-icon="fa fa-pause-circle-o fa-2x">Pause Circle O</option><option value="447" data-icon="fa fa-paw fa-2x">Paw</option><option value="448" data-icon="fa fa-paypal fa-2x">Paypal</option><option value="449" data-icon="fa fa-pencil fa-2x">Pencil</option><option value="450" data-icon="fa fa-pencil-square fa-2x">Pencil Square</option><option value="451" data-icon="fa fa-pencil-square-o fa-2x">Pencil Square O</option><option value="452" data-icon="fa fa-percent fa-2x">Percent</option><option value="453" data-icon="fa fa-phone fa-2x">Phone</option><option value="454" data-icon="fa fa-phone-square fa-2x">Phone Square</option><option value="455" data-icon="fa fa-photo fa-2x">Photo</option><option value="456" data-icon="fa fa-picture-o fa-2x">Picture O</option><option value="457" data-icon="fa fa-pie-chart fa-2x">Pie Chart</option><option value="458" data-icon="fa fa-pied-piper fa-2x">Pied Piper</option><option value="459" data-icon="fa fa-pied-piper-alt fa-2x">Pied Piper Alt</option><option value="460" data-icon="fa fa-pinterest fa-2x">Pinterest</option><option value="461" data-icon="fa fa-pinterest-p fa-2x">Pinterest P</option><option value="462" data-icon="fa fa-pinterest-square fa-2x">Pinterest Square</option><option value="463" data-icon="fa fa-plane fa-2x">Plane</option><option value="464" data-icon="fa fa-play fa-2x">Play</option><option value="465" data-icon="fa fa-play-circle fa-2x">Play Circle</option><option value="466" data-icon="fa fa-play-circle-o fa-2x">Play Circle O</option><option value="467" data-icon="fa fa-plug fa-2x">Plug</option><option value="468" data-icon="fa fa-plus fa-2x">Plus</option><option value="469" data-icon="fa fa-plus-circle fa-2x">Plus Circle</option><option value="470" data-icon="fa fa-plus-square fa-2x">Plus Square</option><option value="471" data-icon="fa fa-plus-square-o fa-2x">Plus Square O</option><option value="472" data-icon="fa fa-power-off fa-2x">Power Off</option><option value="473" data-icon="fa fa-print fa-2x">Print</option><option value="474" data-icon="fa fa-product-hunt fa-2x">Product Hunt</option><option value="475" data-icon="fa fa-puzzle-piece fa-2x">Puzzle Piece</option><option value="476" data-icon="fa fa-qq fa-2x">Qq</option><option value="477" data-icon="fa fa-qrcode fa-2x">Qrcode</option><option value="478" data-icon="fa fa-question fa-2x">Question</option><option value="479" data-icon="fa fa-question-circle fa-2x">Question Circle</option><option value="480" data-icon="fa fa-quote-left fa-2x">Quote Left</option><option value="481" data-icon="fa fa-quote-right fa-2x">Quote Right</option><option value="482" data-icon="fa fa-ra fa-2x">Ra</option><option value="483" data-icon="fa fa-random fa-2x">Random</option><option value="484" data-icon="fa fa-rebel fa-2x">Rebel</option><option value="485" data-icon="fa fa-recycle fa-2x">Recycle</option><option value="486" data-icon="fa fa-reddit fa-2x">Reddit</option><option value="487" data-icon="fa fa-reddit-alien fa-2x">Reddit Alien</option><option value="488" data-icon="fa fa-reddit-square fa-2x">Reddit Square</option><option value="489" data-icon="fa fa-refresh fa-2x">Refresh</option><option value="490" data-icon="fa fa-registered fa-2x">Registered</option><option value="491" data-icon="fa fa-remove fa-2x">Remove</option><option value="492" data-icon="fa fa-renren fa-2x">Renren</option><option value="493" data-icon="fa fa-reorder fa-2x">Reorder</option><option value="494" data-icon="fa fa-repeat fa-2x">Repeat</option><option value="495" data-icon="fa fa-reply fa-2x">Reply</option><option value="496" data-icon="fa fa-reply-all fa-2x">Reply All</option><option value="497" data-icon="fa fa-retweet fa-2x">Retweet</option><option value="498" data-icon="fa fa-rmb fa-2x">Rmb</option><option value="499" data-icon="fa fa-road fa-2x">Road</option><option value="500" data-icon="fa fa-rocket fa-2x">Rocket</option><option value="501" data-icon="fa fa-rotate-left fa-2x">Rotate Left</option><option value="502" data-icon="fa fa-rotate-right fa-2x">Rotate Right</option><option value="503" data-icon="fa fa-rouble fa-2x">Rouble</option><option value="504" data-icon="fa fa-rss fa-2x">Rss</option><option value="505" data-icon="fa fa-rss-square fa-2x">Rss Square</option><option value="506" data-icon="fa fa-rub fa-2x">Rub</option><option value="507" data-icon="fa fa-ruble fa-2x">Ruble</option><option value="508" data-icon="fa fa-rupee fa-2x">Rupee</option><option value="509" data-icon="fa fa-safari fa-2x">Safari</option><option value="510" data-icon="fa fa-save fa-2x">Save</option><option value="511" data-icon="fa fa-scissors fa-2x">Scissors</option><option value="512" data-icon="fa fa-scribd fa-2x">Scribd</option><option value="513" data-icon="fa fa-search fa-2x">Search</option><option value="514" data-icon="fa fa-search-minus fa-2x">Search Minus</option><option value="515" data-icon="fa fa-search-plus fa-2x">Search Plus</option><option value="516" data-icon="fa fa-sellsy fa-2x">Sellsy</option><option value="517" data-icon="fa fa-send fa-2x">Send</option><option value="518" data-icon="fa fa-send-o fa-2x">Send O</option><option value="519" data-icon="fa fa-server fa-2x">Server</option><option value="520" data-icon="fa fa-share fa-2x">Share</option><option value="521" data-icon="fa fa-share-alt fa-2x">Share Alt</option><option value="522" data-icon="fa fa-share-alt-square fa-2x">Share Alt Square</option><option value="523" data-icon="fa fa-share-square fa-2x">Share Square</option><option value="524" data-icon="fa fa-share-square-o fa-2x">Share Square O</option><option value="525" data-icon="fa fa-shekel fa-2x">Shekel</option><option value="526" data-icon="fa fa-sheqel fa-2x">Sheqel</option><option value="527" data-icon="fa fa-shield fa-2x">Shield</option><option value="528" data-icon="fa fa-ship fa-2x">Ship</option><option value="529" data-icon="fa fa-shirtsinbulk fa-2x">Shirtsinbulk</option><option value="530" data-icon="fa fa-shopping-bag fa-2x">Shopping Bag</option><option value="531" data-icon="fa fa-shopping-basket fa-2x">Shopping Basket</option><option value="532" data-icon="fa fa-shopping-cart fa-2x">Shopping Cart</option><option value="533" data-icon="fa fa-sign-in fa-2x">Sign In</option><option value="534" data-icon="fa fa-sign-out fa-2x">Sign Out</option><option value="535" data-icon="fa fa-signal fa-2x">Signal</option><option value="536" data-icon="fa fa-simplybuilt fa-2x">Simplybuilt</option><option value="537" data-icon="fa fa-sitemap fa-2x">Sitemap</option><option value="538" data-icon="fa fa-skyatlas fa-2x">Skyatlas</option><option value="539" data-icon="fa fa-skype fa-2x">Skype</option><option value="540" data-icon="fa fa-slack fa-2x">Slack</option><option value="541" data-icon="fa fa-sliders fa-2x">Sliders</option><option value="542" data-icon="fa fa-slideshare fa-2x">Slideshare</option><option value="543" data-icon="fa fa-smile-o fa-2x">Smile O</option><option value="544" data-icon="fa fa-soccer-ball-o fa-2x">Soccer Ball O</option><option value="545" data-icon="fa fa-sort fa-2x">Sort</option><option value="546" data-icon="fa fa-sort-alpha-asc fa-2x">Sort Alpha Asc</option><option value="547" data-icon="fa fa-sort-alpha-desc fa-2x">Sort Alpha Desc</option><option value="548" data-icon="fa fa-sort-amount-asc fa-2x">Sort Amount Asc</option><option value="549" data-icon="fa fa-sort-amount-desc fa-2x">Sort Amount Desc</option><option value="550" data-icon="fa fa-sort-asc fa-2x">Sort Asc</option><option value="551" data-icon="fa fa-sort-desc fa-2x">Sort Desc</option><option value="552" data-icon="fa fa-sort-down fa-2x">Sort Down</option><option value="553" data-icon="fa fa-sort-numeric-asc fa-2x">Sort Numeric Asc</option><option value="554" data-icon="fa fa-sort-numeric-desc fa-2x">Sort Numeric Desc</option><option value="555" data-icon="fa fa-sort-up fa-2x">Sort Up</option><option value="556" data-icon="fa fa-soundcloud fa-2x">Soundcloud</option><option value="557" data-icon="fa fa-space-shuttle fa-2x">Space Shuttle</option><option value="558" data-icon="fa fa-spinner fa-2x">Spinner</option><option value="559" data-icon="fa fa-spoon fa-2x">Spoon</option><option value="560" data-icon="fa fa-spotify fa-2x">Spotify</option><option value="561" data-icon="fa fa-square fa-2x">Square</option><option value="562" data-icon="fa fa-square-o fa-2x">Square O</option><option value="563" data-icon="fa fa-stack-exchange fa-2x">Stack Exchange</option><option value="564" data-icon="fa fa-stack-overflow fa-2x">Stack Overflow</option><option value="565" data-icon="fa fa-star fa-2x">Star</option><option value="566" data-icon="fa fa-star-half fa-2x">Star Half</option><option value="567" data-icon="fa fa-star-half-empty fa-2x">Star Half Empty</option><option value="568" data-icon="fa fa-star-half-full fa-2x">Star Half Full</option><option value="569" data-icon="fa fa-star-half-o fa-2x">Star Half O</option><option value="570" data-icon="fa fa-star-o fa-2x">Star O</option><option value="571" data-icon="fa fa-steam fa-2x">Steam</option><option value="572" data-icon="fa fa-steam-square fa-2x">Steam Square</option><option value="573" data-icon="fa fa-step-backward fa-2x">Step Backward</option><option value="574" data-icon="fa fa-step-forward fa-2x">Step Forward</option><option value="575" data-icon="fa fa-stethoscope fa-2x">Stethoscope</option><option value="576" data-icon="fa fa-sticky-note fa-2x">Sticky Note</option><option value="577" data-icon="fa fa-sticky-note-o fa-2x">Sticky Note O</option><option value="578" data-icon="fa fa-stop fa-2x">Stop</option><option value="579" data-icon="fa fa-stop-circle fa-2x">Stop Circle</option><option value="580" data-icon="fa fa-stop-circle-o fa-2x">Stop Circle O</option><option value="581" data-icon="fa fa-street-view fa-2x">Street View</option><option value="582" data-icon="fa fa-strikethrough fa-2x">Strikethrough</option><option value="583" data-icon="fa fa-stumbleupon fa-2x">Stumbleupon</option><option value="584" data-icon="fa fa-stumbleupon-circle fa-2x">Stumbleupon Circle</option><option value="585" data-icon="fa fa-subscript fa-2x">Subscript</option><option value="586" data-icon="fa fa-subway fa-2x">Subway</option><option value="587" data-icon="fa fa-suitcase fa-2x">Suitcase</option><option value="588" data-icon="fa fa-sun-o fa-2x">Sun O</option><option value="589" data-icon="fa fa-superscript fa-2x">Superscript</option><option value="590" data-icon="fa fa-support fa-2x">Support</option><option value="591" data-icon="fa fa-table fa-2x">Table</option><option value="592" data-icon="fa fa-tablet fa-2x">Tablet</option><option value="593" data-icon="fa fa-tachometer fa-2x">Tachometer</option><option value="594" data-icon="fa fa-tag fa-2x">Tag</option><option value="595" data-icon="fa fa-tags fa-2x">Tags</option><option value="596" data-icon="fa fa-tasks fa-2x">Tasks</option><option value="597" data-icon="fa fa-taxi fa-2x">Taxi</option><option value="598" data-icon="fa fa-television fa-2x">Television</option><option value="599" data-icon="fa fa-tencent-weibo fa-2x">Tencent Weibo</option><option value="600" data-icon="fa fa-terminal fa-2x">Terminal</option><option value="601" data-icon="fa fa-text-height fa-2x">Text Height</option><option value="602" data-icon="fa fa-text-width fa-2x">Text Width</option><option value="603" data-icon="fa fa-th fa-2x">Th</option><option value="604" data-icon="fa fa-th-large fa-2x">Th Large</option><option value="605" data-icon="fa fa-th-list fa-2x">Th List</option><option value="606" data-icon="fa fa-thumb-tack fa-2x">Thumb Tack</option><option value="607" data-icon="fa fa-thumbs-down fa-2x">Thumbs Down</option><option value="608" data-icon="fa fa-thumbs-o-down fa-2x">Thumbs O Down</option><option value="609" data-icon="fa fa-thumbs-o-up fa-2x">Thumbs O Up</option><option value="610" data-icon="fa fa-thumbs-up fa-2x">Thumbs Up</option><option value="611" data-icon="fa fa-ticket fa-2x">Ticket</option><option value="612" data-icon="fa fa-times fa-2x">Times</option><option value="613" data-icon="fa fa-times-circle fa-2x">Times Circle</option><option value="614" data-icon="fa fa-times-circle-o fa-2x">Times Circle O</option><option value="615" data-icon="fa fa-tint fa-2x">Tint</option><option value="616" data-icon="fa fa-toggle-down fa-2x">Toggle Down</option><option value="617" data-icon="fa fa-toggle-left fa-2x">Toggle Left</option><option value="618" data-icon="fa fa-toggle-off fa-2x">Toggle Off</option><option value="619" data-icon="fa fa-toggle-on fa-2x">Toggle On</option><option value="620" data-icon="fa fa-toggle-right fa-2x">Toggle Right</option><option value="621" data-icon="fa fa-toggle-up fa-2x">Toggle Up</option><option value="622" data-icon="fa fa-trademark fa-2x">Trademark</option><option value="623" data-icon="fa fa-train fa-2x">Train</option><option value="624" data-icon="fa fa-transgender fa-2x">Transgender</option><option value="625" data-icon="fa fa-transgender-alt fa-2x">Transgender Alt</option><option value="626" data-icon="fa fa-trash fa-2x">Trash</option><option value="627" data-icon="fa fa-trash-o fa-2x">Trash O</option><option value="628" data-icon="fa fa-tree fa-2x">Tree</option><option value="629" data-icon="fa fa-trello fa-2x">Trello</option><option value="630" data-icon="fa fa-tripadvisor fa-2x">Tripadvisor</option><option value="631" data-icon="fa fa-trophy fa-2x">Trophy</option><option value="632" data-icon="fa fa-truck fa-2x">Truck</option><option value="633" data-icon="fa fa-try fa-2x">Try</option><option value="634" data-icon="fa fa-tty fa-2x">Tty</option><option value="635" data-icon="fa fa-tumblr fa-2x">Tumblr</option><option value="636" data-icon="fa fa-tumblr-square fa-2x">Tumblr Square</option><option value="637" data-icon="fa fa-turkish-lira fa-2x">Turkish Lira</option><option value="638" data-icon="fa fa-tv fa-2x">Tv</option><option value="639" data-icon="fa fa-twitch fa-2x">Twitch</option><option value="640" data-icon="fa fa-twitter fa-2x">Twitter</option><option value="641" data-icon="fa fa-twitter-square fa-2x">Twitter Square</option><option value="642" data-icon="fa fa-umbrella fa-2x">Umbrella</option><option value="643" data-icon="fa fa-underline fa-2x">Underline</option><option value="644" data-icon="fa fa-undo fa-2x">Undo</option><option value="645" data-icon="fa fa-university fa-2x">University</option><option value="646" data-icon="fa fa-unlink fa-2x">Unlink</option><option value="647" data-icon="fa fa-unlock fa-2x">Unlock</option><option value="648" data-icon="fa fa-unlock-alt fa-2x">Unlock Alt</option><option value="649" data-icon="fa fa-unsorted fa-2x">Unsorted</option><option value="650" data-icon="fa fa-upload fa-2x">Upload</option><option value="651" data-icon="fa fa-usb fa-2x">Usb</option><option value="652" data-icon="fa fa-usd fa-2x">Usd</option><option value="653" data-icon="fa fa-user fa-2x">User</option><option value="654" data-icon="fa fa-user-md fa-2x">User Md</option><option value="655" data-icon="fa fa-user-plus fa-2x">User Plus</option><option value="656" data-icon="fa fa-user-secret fa-2x">User Secret</option><option value="657" data-icon="fa fa-user-times fa-2x">User Times</option><option value="658" data-icon="fa fa-users fa-2x">Users</option><option value="659" data-icon="fa fa-venus fa-2x">Venus</option><option value="660" data-icon="fa fa-venus-double fa-2x">Venus Double</option><option value="661" data-icon="fa fa-venus-mars fa-2x">Venus Mars</option><option value="662" data-icon="fa fa-viacoin fa-2x">Viacoin</option><option value="663" data-icon="fa fa-video-camera fa-2x">Video Camera</option><option value="664" data-icon="fa fa-vimeo fa-2x">Vimeo</option><option value="665" data-icon="fa fa-vimeo-square fa-2x">Vimeo Square</option><option value="666" data-icon="fa fa-vine fa-2x">Vine</option><option value="667" data-icon="fa fa-vk fa-2x">Vk</option><option value="668" data-icon="fa fa-volume-down fa-2x">Volume Down</option><option value="669" data-icon="fa fa-volume-off fa-2x">Volume Off</option><option value="670" data-icon="fa fa-volume-up fa-2x">Volume Up</option><option value="671" data-icon="fa fa-warning fa-2x">Warning</option><option value="672" data-icon="fa fa-wechat fa-2x">Wechat</option><option value="673" data-icon="fa fa-weibo fa-2x">Weibo</option><option value="674" data-icon="fa fa-weixin fa-2x">Weixin</option><option value="675" data-icon="fa fa-whatsapp fa-2x">Whatsapp</option><option value="676" data-icon="fa fa-wheelchair fa-2x">Wheelchair</option><option value="677" data-icon="fa fa-wifi fa-2x">Wifi</option><option value="678" data-icon="fa fa-wikipedia-w fa-2x">Wikipedia W</option><option value="679" data-icon="fa fa-windows fa-2x">Windows</option><option value="680" data-icon="fa fa-won fa-2x">Won</option><option value="681" data-icon="fa fa-wordpress fa-2x">Wordpress</option><option value="682" data-icon="fa fa-wrench fa-2x">Wrench</option><option value="683" data-icon="fa fa-xing fa-2x">Xing</option><option value="684" data-icon="fa fa-xing-square fa-2x">Xing Square</option><option value="685" data-icon="fa fa-y-combinator fa-2x">Y Combinator</option><option value="686" data-icon="fa fa-y-combinator-square fa-2x">Y Combinator Square</option><option value="687" data-icon="fa fa-yahoo fa-2x">Yahoo</option><option value="688" data-icon="fa fa-yc fa-2x">Yc</option><option value="689" data-icon="fa fa-yc-square fa-2x">Yc Square</option><option value="690" data-icon="fa fa-yelp fa-2x">Yelp</option><option value="691" data-icon="fa fa-yen fa-2x">Yen</option><option value="692" data-icon="fa fa-youtube fa-2x">Youtube</option><option value="693" data-icon="fa fa-youtube-play fa-2x">Youtube Play</option><option value="694" data-icon="fa fa-youtube-square fa-2x">Youtube Square</option></select>
                                                                                        <span class="input-group-btn">
                                                                                            <button class="btn btn-mint" type="button" data-target="#demo-lg-modal" data-toggle="modal">Ver todos</button>
                                                                                        </span>
                                                                                    </div>
                                                                                </div>
                                                                                <div id="divImagen" style="display: none;">
                                                                                    <input id="file" class="form-control" aria-describedby="fileHelp" style="height: auto;" name="file" type="file">
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-3 text-center">
                                                                        <label class="control-label">Previsualizar</label>
                                                                        <div class="radio" id="previewIcono">
                                                                            <button class="btn btn-default btn-circle" type="button">
                                                                                <i class=""></i>
                                                                            </button>
                                                                            <br>
                                                                            <span class="text-dark mar-top"><strong>Nombre menu</strong></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-sm-6">
                                                                        <div class="form-group">
                                                                            <button class="btn btn-success" type="submit">Guardar</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                    <div id="demo-tabs2-box-2" class="tab-pane fade">
                                                        <div class="media">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div id="demo-lg-modal" class="modal fade" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                                            <h4 class="modal-title" id="myLargeModalLabel">Listado de iconos</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="panel">
                                                <div class="panel-heading">
                                                    Si desea puede seleccionar directamente el icono desde aquí, solo hay que dar doble click    
                                                    <input type="text" class="form-control buscar mar-top" id="textBuscar" placeholder="Ingrese el texto a buscar">
                                                </div>
                                                <div class="panel-body mar-top">
                                                    <hr>
                                                    <div id="iconosLista" class="clearfix demo-icon-list" style="height: 600px; overflow: auto;">
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="1">
                                                                    <i class="fa fa fa-500px fa-2x"></i><span>500px</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="2">
                                                                    <i class="fa fa fa-adjust fa-2x"></i><span>Adjust</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="3">
                                                                    <i class="fa fa fa-adn fa-2x"></i><span>Adn</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="4">
                                                                    <i class="fa fa fa-align-center fa-2x"></i><span>Align Center</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="5">
                                                                    <i class="fa fa fa-align-justify fa-2x"></i><span>Align Justify</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="6">
                                                                    <i class="fa fa fa-align-left fa-2x"></i><span>Align Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="7">
                                                                    <i class="fa fa fa-align-right fa-2x"></i><span>Align Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="8">
                                                                    <i class="fa fa fa-amazon fa-2x"></i><span>Amazon</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="9">
                                                                    <i class="fa fa fa-ambulance fa-2x"></i><span>Ambulance</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="10">
                                                                    <i class="fa fa fa-anchor fa-2x"></i><span>Anchor</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="11">
                                                                    <i class="fa fa fa-android fa-2x"></i><span>Android</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="12">
                                                                    <i class="fa fa fa-angellist fa-2x"></i><span>Angellist</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="13">
                                                                    <i class="fa fa fa-angle-double-down fa-2x"></i><span>Angle Double Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="14">
                                                                    <i class="fa fa fa-angle-double-left fa-2x"></i><span>Angle Double Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="15">
                                                                    <i class="fa fa fa-angle-double-right fa-2x"></i><span>Angle Double Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="16">
                                                                    <i class="fa fa fa-angle-double-up fa-2x"></i><span>Angle Double Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="17">
                                                                    <i class="fa fa fa-angle-down fa-2x"></i><span>Angle Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="18">
                                                                    <i class="fa fa fa-angle-left fa-2x"></i><span>Angle Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="19">
                                                                    <i class="fa fa fa-angle-right fa-2x"></i><span>Angle Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="20">
                                                                    <i class="fa fa fa-angle-up fa-2x"></i><span>Angle Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="21">
                                                                    <i class="fa fa fa-apple fa-2x"></i><span>Apple</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="22">
                                                                    <i class="fa fa fa-archive fa-2x"></i><span>Archive</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="23">
                                                                    <i class="fa fa fa-area-chart fa-2x"></i><span>Area Chart</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="24">
                                                                    <i class="fa fa fa-arrow-circle-down fa-2x"></i><span>Arrow Circle Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="25">
                                                                    <i class="fa fa fa-arrow-circle-left fa-2x"></i><span>Arrow Circle Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="26">
                                                                    <i class="fa fa fa-arrow-circle-o-down fa-2x"></i><span>Arrow Circle O Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="27">
                                                                    <i class="fa fa fa-arrow-circle-o-left fa-2x"></i><span>Arrow Circle O Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="28">
                                                                    <i class="fa fa fa-arrow-circle-o-right fa-2x"></i><span>Arrow Circle O Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="29">
                                                                    <i class="fa fa fa-arrow-circle-o-up fa-2x"></i><span>Arrow Circle O Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="30">
                                                                    <i class="fa fa fa-arrow-circle-right fa-2x"></i><span>Arrow Circle Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="31">
                                                                    <i class="fa fa fa-arrow-circle-up fa-2x"></i><span>Arrow Circle Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="32">
                                                                    <i class="fa fa fa-arrow-down fa-2x"></i><span>Arrow Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="33">
                                                                    <i class="fa fa fa-arrow-left fa-2x"></i><span>Arrow Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="34">
                                                                    <i class="fa fa fa-arrow-right fa-2x"></i><span>Arrow Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="35">
                                                                    <i class="fa fa fa-arrow-up fa-2x"></i><span>Arrow Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="36">
                                                                    <i class="fa fa fa-arrows fa-2x"></i><span>Arrows</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="37">
                                                                    <i class="fa fa fa-arrows-alt fa-2x"></i><span>Arrows Alt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="38">
                                                                    <i class="fa fa fa-arrows-h fa-2x"></i><span>Arrows H</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="39">
                                                                    <i class="fa fa fa-arrows-v fa-2x"></i><span>Arrows V</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="40">
                                                                    <i class="fa fa fa-asterisk fa-2x"></i><span>Asterisk</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="41">
                                                                    <i class="fa fa fa-at fa-2x"></i><span>At</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="42">
                                                                    <i class="fa fa fa-automobile fa-2x"></i><span>Automobile</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="43">
                                                                    <i class="fa fa fa-backward fa-2x"></i><span>Backward</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="44">
                                                                    <i class="fa fa fa-balance-scale fa-2x"></i><span>Balance Scale</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="45">
                                                                    <i class="fa fa fa-ban fa-2x"></i><span>Ban</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="46">
                                                                    <i class="fa fa fa-bank fa-2x"></i><span>Bank</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="47">
                                                                    <i class="fa fa fa-bar-chart fa-2x"></i><span>Bar Chart</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="48">
                                                                    <i class="fa fa fa-bar-chart-o fa-2x"></i><span>Bar Chart O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="49">
                                                                    <i class="fa fa fa-barcode fa-2x"></i><span>Barcode</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="50">
                                                                    <i class="fa fa fa-bars fa-2x"></i><span>Bars</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="51">
                                                                    <i class="fa fa fa-battery-0 fa-2x"></i><span>Battery 0</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="52">
                                                                    <i class="fa fa fa-battery-1 fa-2x"></i><span>Battery 1</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="53">
                                                                    <i class="fa fa fa-battery-2 fa-2x"></i><span>Battery 2</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="54">
                                                                    <i class="fa fa fa-battery-3 fa-2x"></i><span>Battery 3</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="55">
                                                                    <i class="fa fa fa-battery-4 fa-2x"></i><span>Battery 4</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="56">
                                                                    <i class="fa fa fa-battery-empty fa-2x"></i><span>Battery Empty</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="57">
                                                                    <i class="fa fa fa-battery-full fa-2x"></i><span>Battery Full</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="58">
                                                                    <i class="fa fa fa-battery-half fa-2x"></i><span>Battery Half</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="59">
                                                                    <i class="fa fa fa-battery-quarter fa-2x"></i><span>Battery Quarter</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="60">
                                                                    <i class="fa fa fa-battery-three-quarters fa-2x"></i><span>Battery Three Quarters</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="61">
                                                                    <i class="fa fa fa-bed fa-2x"></i><span>Bed</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="62">
                                                                    <i class="fa fa fa-beer fa-2x"></i><span>Beer</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="63">
                                                                    <i class="fa fa fa-behance fa-2x"></i><span>Behance</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="64">
                                                                    <i class="fa fa fa-behance-square fa-2x"></i><span>Behance Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="65">
                                                                    <i class="fa fa fa-bell fa-2x"></i><span>Bell</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="66">
                                                                    <i class="fa fa fa-bell-o fa-2x"></i><span>Bell O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="67">
                                                                    <i class="fa fa fa-bell-slash fa-2x"></i><span>Bell Slash</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="68">
                                                                    <i class="fa fa fa-bell-slash-o fa-2x"></i><span>Bell Slash O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="69">
                                                                    <i class="fa fa fa-bicycle fa-2x"></i><span>Bicycle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="70">
                                                                    <i class="fa fa fa-binoculars fa-2x"></i><span>Binoculars</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="71">
                                                                    <i class="fa fa fa-birthday-cake fa-2x"></i><span>Birthday Cake</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="72">
                                                                    <i class="fa fa fa-bitbucket fa-2x"></i><span>Bitbucket</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="73">
                                                                    <i class="fa fa fa-bitbucket-square fa-2x"></i><span>Bitbucket Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="74">
                                                                    <i class="fa fa fa-bitcoin fa-2x"></i><span>Bitcoin</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="75">
                                                                    <i class="fa fa fa-black-tie fa-2x"></i><span>Black Tie</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="76">
                                                                    <i class="fa fa fa-bluetooth fa-2x"></i><span>Bluetooth</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="77">
                                                                    <i class="fa fa fa-bluetooth-b fa-2x"></i><span>Bluetooth B</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="78">
                                                                    <i class="fa fa fa-bold fa-2x"></i><span>Bold</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="79">
                                                                    <i class="fa fa fa-bolt fa-2x"></i><span>Bolt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="80">
                                                                    <i class="fa fa fa-bomb fa-2x"></i><span>Bomb</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="81">
                                                                    <i class="fa fa fa-book fa-2x"></i><span>Book</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="82">
                                                                    <i class="fa fa fa-bookmark fa-2x"></i><span>Bookmark</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="83">
                                                                    <i class="fa fa fa-bookmark-o fa-2x"></i><span>Bookmark O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="84">
                                                                    <i class="fa fa fa-briefcase fa-2x"></i><span>Briefcase</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="85">
                                                                    <i class="fa fa fa-btc fa-2x"></i><span>Btc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="86">
                                                                    <i class="fa fa fa-bug fa-2x"></i><span>Bug</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="87">
                                                                    <i class="fa fa fa-building fa-2x"></i><span>Building</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="88">
                                                                    <i class="fa fa fa-building-o fa-2x"></i><span>Building O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="89">
                                                                    <i class="fa fa fa-bullhorn fa-2x"></i><span>Bullhorn</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="90">
                                                                    <i class="fa fa fa-bullseye fa-2x"></i><span>Bullseye</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="91">
                                                                    <i class="fa fa fa-bus fa-2x"></i><span>Bus</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="92">
                                                                    <i class="fa fa fa-buysellads fa-2x"></i><span>Buysellads</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="93">
                                                                    <i class="fa fa fa-cab fa-2x"></i><span>Cab</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="94">
                                                                    <i class="fa fa fa-calculator fa-2x"></i><span>Calculator</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="95">
                                                                    <i class="fa fa fa-calendar fa-2x"></i><span>Calendar</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="96">
                                                                    <i class="fa fa fa-calendar-check-o fa-2x"></i><span>Calendar Check O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="97">
                                                                    <i class="fa fa fa-calendar-minus-o fa-2x"></i><span>Calendar Minus O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="98">
                                                                    <i class="fa fa fa-calendar-o fa-2x"></i><span>Calendar O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="99">
                                                                    <i class="fa fa fa-calendar-plus-o fa-2x"></i><span>Calendar Plus O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="100">
                                                                    <i class="fa fa fa-calendar-times-o fa-2x"></i><span>Calendar Times O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="101">
                                                                    <i class="fa fa fa-camera fa-2x"></i><span>Camera</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="102">
                                                                    <i class="fa fa fa-camera-retro fa-2x"></i><span>Camera Retro</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="103">
                                                                    <i class="fa fa fa-car fa-2x"></i><span>Car</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="104">
                                                                    <i class="fa fa fa-caret-down fa-2x"></i><span>Caret Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="105">
                                                                    <i class="fa fa fa-caret-left fa-2x"></i><span>Caret Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="106">
                                                                    <i class="fa fa fa-caret-right fa-2x"></i><span>Caret Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="107">
                                                                    <i class="fa fa fa-caret-square-o-down fa-2x"></i><span>Caret Square O Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="108">
                                                                    <i class="fa fa fa-caret-square-o-left fa-2x"></i><span>Caret Square O Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="109">
                                                                    <i class="fa fa fa-caret-square-o-right fa-2x"></i><span>Caret Square O Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="110">
                                                                    <i class="fa fa fa-caret-square-o-up fa-2x"></i><span>Caret Square O Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="111">
                                                                    <i class="fa fa fa-caret-up fa-2x"></i><span>Caret Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="112">
                                                                    <i class="fa fa fa-cart-arrow-down fa-2x"></i><span>Cart Arrow Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="113">
                                                                    <i class="fa fa fa-cart-plus fa-2x"></i><span>Cart Plus</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="114">
                                                                    <i class="fa fa fa-cc fa-2x"></i><span>Cc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="115">
                                                                    <i class="fa fa fa-cc-amex fa-2x"></i><span>Cc Amex</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="116">
                                                                    <i class="fa fa fa-cc-diners-club fa-2x"></i><span>Cc Diners Club</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="117">
                                                                    <i class="fa fa fa-cc-discover fa-2x"></i><span>Cc Discover</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="118">
                                                                    <i class="fa fa fa-cc-jcb fa-2x"></i><span>Cc Jcb</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="119">
                                                                    <i class="fa fa fa-cc-mastercard fa-2x"></i><span>Cc Mastercard</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="120">
                                                                    <i class="fa fa fa-cc-paypal fa-2x"></i><span>Cc Paypal</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="121">
                                                                    <i class="fa fa fa-cc-stripe fa-2x"></i><span>Cc Stripe</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="122">
                                                                    <i class="fa fa fa-cc-visa fa-2x"></i><span>Cc Visa</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="123">
                                                                    <i class="fa fa fa-certificate fa-2x"></i><span>Certificate</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="124">
                                                                    <i class="fa fa fa-chain fa-2x"></i><span>Chain</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="125">
                                                                    <i class="fa fa fa-chain-broken fa-2x"></i><span>Chain Broken</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="126">
                                                                    <i class="fa fa fa-check fa-2x"></i><span>Check</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="127">
                                                                    <i class="fa fa fa-check-circle fa-2x"></i><span>Check Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="128">
                                                                    <i class="fa fa fa-check-circle-o fa-2x"></i><span>Check Circle O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="129">
                                                                    <i class="fa fa fa-check-square fa-2x"></i><span>Check Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="130">
                                                                    <i class="fa fa fa-check-square-o fa-2x"></i><span>Check Square O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="131">
                                                                    <i class="fa fa fa-chevron-circle-down fa-2x"></i><span>Chevron Circle Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="132">
                                                                    <i class="fa fa fa-chevron-circle-left fa-2x"></i><span>Chevron Circle Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="133">
                                                                    <i class="fa fa fa-chevron-circle-right fa-2x"></i><span>Chevron Circle Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="134">
                                                                    <i class="fa fa fa-chevron-circle-up fa-2x"></i><span>Chevron Circle Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="135">
                                                                    <i class="fa fa fa-chevron-down fa-2x"></i><span>Chevron Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="136">
                                                                    <i class="fa fa fa-chevron-left fa-2x"></i><span>Chevron Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="137">
                                                                    <i class="fa fa fa-chevron-right fa-2x"></i><span>Chevron Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="138">
                                                                    <i class="fa fa fa-chevron-up fa-2x"></i><span>Chevron Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="139">
                                                                    <i class="fa fa fa-child fa-2x"></i><span>Child</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="140">
                                                                    <i class="fa fa fa-chrome fa-2x"></i><span>Chrome</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="141">
                                                                    <i class="fa fa fa-circle fa-2x"></i><span>Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="142">
                                                                    <i class="fa fa fa-circle-o fa-2x"></i><span>Circle O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="143">
                                                                    <i class="fa fa fa-circle-o-notch fa-2x"></i><span>Circle O Notch</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="144">
                                                                    <i class="fa fa fa-circle-thin fa-2x"></i><span>Circle Thin</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="145">
                                                                    <i class="fa fa fa-clipboard fa-2x"></i><span>Clipboard</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="146">
                                                                    <i class="fa fa fa-clock-o fa-2x"></i><span>Clock O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="147">
                                                                    <i class="fa fa fa-clone fa-2x"></i><span>Clone</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="148">
                                                                    <i class="fa fa fa-close fa-2x"></i><span>Close</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="149">
                                                                    <i class="fa fa fa-cloud fa-2x"></i><span>Cloud</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="150">
                                                                    <i class="fa fa fa-cloud-download fa-2x"></i><span>Cloud Download</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="151">
                                                                    <i class="fa fa fa-cloud-upload fa-2x"></i><span>Cloud Upload</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="152">
                                                                    <i class="fa fa fa-cny fa-2x"></i><span>Cny</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="153">
                                                                    <i class="fa fa fa-code fa-2x"></i><span>Code</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="154">
                                                                    <i class="fa fa fa-code-fork fa-2x"></i><span>Code Fork</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="155">
                                                                    <i class="fa fa fa-codepen fa-2x"></i><span>Codepen</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="156">
                                                                    <i class="fa fa fa-codiepie fa-2x"></i><span>Codiepie</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="157">
                                                                    <i class="fa fa fa-coffee fa-2x"></i><span>Coffee</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="158">
                                                                    <i class="fa fa fa-cog fa-2x"></i><span>Cog</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="159">
                                                                    <i class="fa fa fa-cogs fa-2x"></i><span>Cogs</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="160">
                                                                    <i class="fa fa fa-columns fa-2x"></i><span>Columns</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="161">
                                                                    <i class="fa fa fa-comment fa-2x"></i><span>Comment</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="162">
                                                                    <i class="fa fa fa-comment-o fa-2x"></i><span>Comment O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="163">
                                                                    <i class="fa fa fa-commenting fa-2x"></i><span>Commenting</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="164">
                                                                    <i class="fa fa fa-commenting-o fa-2x"></i><span>Commenting O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="165">
                                                                    <i class="fa fa fa-comments fa-2x"></i><span>Comments</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="166">
                                                                    <i class="fa fa fa-comments-o fa-2x"></i><span>Comments O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="167">
                                                                    <i class="fa fa fa-compass fa-2x"></i><span>Compass</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="168">
                                                                    <i class="fa fa fa-compress fa-2x"></i><span>Compress</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="169">
                                                                    <i class="fa fa fa-connectdevelop fa-2x"></i><span>Connectdevelop</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="170">
                                                                    <i class="fa fa fa-contao fa-2x"></i><span>Contao</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="171">
                                                                    <i class="fa fa fa-copy fa-2x"></i><span>Copy</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="172">
                                                                    <i class="fa fa fa-copyright fa-2x"></i><span>Copyright</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="173">
                                                                    <i class="fa fa fa-creative-commons fa-2x"></i><span>Creative Commons</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="174">
                                                                    <i class="fa fa fa-credit-card fa-2x"></i><span>Credit Card</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="175">
                                                                    <i class="fa fa fa-credit-card-alt fa-2x"></i><span>Credit Card Alt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="176">
                                                                    <i class="fa fa fa-crop fa-2x"></i><span>Crop</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="177">
                                                                    <i class="fa fa fa-crosshairs fa-2x"></i><span>Crosshairs</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="178">
                                                                    <i class="fa fa fa-css3 fa-2x"></i><span>Css3</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="179">
                                                                    <i class="fa fa fa-cube fa-2x"></i><span>Cube</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="180">
                                                                    <i class="fa fa fa-cubes fa-2x"></i><span>Cubes</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="181">
                                                                    <i class="fa fa fa-cut fa-2x"></i><span>Cut</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="182">
                                                                    <i class="fa fa fa-cutlery fa-2x"></i><span>Cutlery</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="183">
                                                                    <i class="fa fa fa-dashboard fa-2x"></i><span>Dashboard</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="184">
                                                                    <i class="fa fa fa-dashcube fa-2x"></i><span>Dashcube</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="185">
                                                                    <i class="fa fa fa-database fa-2x"></i><span>Database</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="186">
                                                                    <i class="fa fa fa-dedent fa-2x"></i><span>Dedent</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="187">
                                                                    <i class="fa fa fa-delicious fa-2x"></i><span>Delicious</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="188">
                                                                    <i class="fa fa fa-desktop fa-2x"></i><span>Desktop</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="189">
                                                                    <i class="fa fa fa-deviantart fa-2x"></i><span>Deviantart</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="190">
                                                                    <i class="fa fa fa-diamond fa-2x"></i><span>Diamond</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="191">
                                                                    <i class="fa fa fa-digg fa-2x"></i><span>Digg</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="192">
                                                                    <i class="fa fa fa-dollar fa-2x"></i><span>Dollar</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="193">
                                                                    <i class="fa fa fa-dot-circle-o fa-2x"></i><span>Dot Circle O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="194">
                                                                    <i class="fa fa fa-download fa-2x"></i><span>Download</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="195">
                                                                    <i class="fa fa fa-dribbble fa-2x"></i><span>Dribbble</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="196">
                                                                    <i class="fa fa fa-dropbox fa-2x"></i><span>Dropbox</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="197">
                                                                    <i class="fa fa fa-drupal fa-2x"></i><span>Drupal</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="198">
                                                                    <i class="fa fa fa-edge fa-2x"></i><span>Edge</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="199">
                                                                    <i class="fa fa fa-edit fa-2x"></i><span>Edit</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="200">
                                                                    <i class="fa fa fa-eject fa-2x"></i><span>Eject</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="201">
                                                                    <i class="fa fa fa-ellipsis-h fa-2x"></i><span>Ellipsis H</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="202">
                                                                    <i class="fa fa fa-ellipsis-v fa-2x"></i><span>Ellipsis V</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="203">
                                                                    <i class="fa fa fa-empire fa-2x"></i><span>Empire</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="204">
                                                                    <i class="fa fa fa-envelope fa-2x"></i><span>Envelope</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="205">
                                                                    <i class="fa fa fa-envelope-o fa-2x"></i><span>Envelope O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="206">
                                                                    <i class="fa fa fa-envelope-square fa-2x"></i><span>Envelope Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="207">
                                                                    <i class="fa fa fa-eraser fa-2x"></i><span>Eraser</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="208">
                                                                    <i class="fa fa fa-eur fa-2x"></i><span>Eur</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="209">
                                                                    <i class="fa fa fa-euro fa-2x"></i><span>Euro</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="210">
                                                                    <i class="fa fa fa-exchange fa-2x"></i><span>Exchange</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="211">
                                                                    <i class="fa fa fa-exclamation fa-2x"></i><span>Exclamation</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="212">
                                                                    <i class="fa fa fa-exclamation-circle fa-2x"></i><span>Exclamation Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="213">
                                                                    <i class="fa fa fa-exclamation-triangle fa-2x"></i><span>Exclamation Triangle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="214">
                                                                    <i class="fa fa fa-expand fa-2x"></i><span>Expand</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="215">
                                                                    <i class="fa fa fa-expeditedssl fa-2x"></i><span>Expeditedssl</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="216">
                                                                    <i class="fa fa fa-external-link fa-2x"></i><span>External Link</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="217">
                                                                    <i class="fa fa fa-external-link-square fa-2x"></i><span>External Link Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="218">
                                                                    <i class="fa fa fa-eye fa-2x"></i><span>Eye</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="219">
                                                                    <i class="fa fa fa-eye-slash fa-2x"></i><span>Eye Slash</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="220">
                                                                    <i class="fa fa fa-eyedropper fa-2x"></i><span>Eyedropper</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="221">
                                                                    <i class="fa fa fa-facebook fa-2x"></i><span>Facebook</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="222">
                                                                    <i class="fa fa fa-facebook-f fa-2x"></i><span>Facebook F</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="223">
                                                                    <i class="fa fa fa-facebook-official fa-2x"></i><span>Facebook Official</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="224">
                                                                    <i class="fa fa fa-facebook-square fa-2x"></i><span>Facebook Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="225">
                                                                    <i class="fa fa fa-fast-backward fa-2x"></i><span>Fast Backward</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="226">
                                                                    <i class="fa fa fa-fast-forward fa-2x"></i><span>Fast Forward</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="227">
                                                                    <i class="fa fa fa-fax fa-2x"></i><span>Fax</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="228">
                                                                    <i class="fa fa fa-feed fa-2x"></i><span>Feed</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="229">
                                                                    <i class="fa fa fa-female fa-2x"></i><span>Female</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="230">
                                                                    <i class="fa fa fa-fighter-jet fa-2x"></i><span>Fighter Jet</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="231">
                                                                    <i class="fa fa fa-file fa-2x"></i><span>File</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="232">
                                                                    <i class="fa fa fa-file-archive-o fa-2x"></i><span>File Archive O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="233">
                                                                    <i class="fa fa fa-file-audio-o fa-2x"></i><span>File Audio O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="234">
                                                                    <i class="fa fa fa-file-code-o fa-2x"></i><span>File Code O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="235">
                                                                    <i class="fa fa fa-file-excel-o fa-2x"></i><span>File Excel O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="236">
                                                                    <i class="fa fa fa-file-image-o fa-2x"></i><span>File Image O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="237">
                                                                    <i class="fa fa fa-file-movie-o fa-2x"></i><span>File Movie O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="238">
                                                                    <i class="fa fa fa-file-o fa-2x"></i><span>File O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="239">
                                                                    <i class="fa fa fa-file-pdf-o fa-2x"></i><span>File Pdf O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="240">
                                                                    <i class="fa fa fa-file-photo-o fa-2x"></i><span>File Photo O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="241">
                                                                    <i class="fa fa fa-file-picture-o fa-2x"></i><span>File Picture O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="242">
                                                                    <i class="fa fa fa-file-powerpoint-o fa-2x"></i><span>File Powerpoint O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="243">
                                                                    <i class="fa fa fa-file-sound-o fa-2x"></i><span>File Sound O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="244">
                                                                    <i class="fa fa fa-file-text fa-2x"></i><span>File Text</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="245">
                                                                    <i class="fa fa fa-file-text-o fa-2x"></i><span>File Text O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="246">
                                                                    <i class="fa fa fa-file-video-o fa-2x"></i><span>File Video O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="247">
                                                                    <i class="fa fa fa-file-word-o fa-2x"></i><span>File Word O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="248">
                                                                    <i class="fa fa fa-file-zip-o fa-2x"></i><span>File Zip O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="249">
                                                                    <i class="fa fa fa-files-o fa-2x"></i><span>Files O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="250">
                                                                    <i class="fa fa fa-film fa-2x"></i><span>Film</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="251">
                                                                    <i class="fa fa fa-filter fa-2x"></i><span>Filter</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="252">
                                                                    <i class="fa fa fa-fire fa-2x"></i><span>Fire</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="253">
                                                                    <i class="fa fa fa-fire-extinguisher fa-2x"></i><span>Fire Extinguisher</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="254">
                                                                    <i class="fa fa fa-firefox fa-2x"></i><span>Firefox</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="255">
                                                                    <i class="fa fa fa-flag fa-2x"></i><span>Flag</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="256">
                                                                    <i class="fa fa fa-flag-checkered fa-2x"></i><span>Flag Checkered</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="257">
                                                                    <i class="fa fa fa-flag-o fa-2x"></i><span>Flag O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="258">
                                                                    <i class="fa fa fa-flash fa-2x"></i><span>Flash</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="259">
                                                                    <i class="fa fa fa-flask fa-2x"></i><span>Flask</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="260">
                                                                    <i class="fa fa fa-flickr fa-2x"></i><span>Flickr</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="261">
                                                                    <i class="fa fa fa-floppy-o fa-2x"></i><span>Floppy O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="262">
                                                                    <i class="fa fa fa-folder fa-2x"></i><span>Folder</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="263">
                                                                    <i class="fa fa fa-folder-o fa-2x"></i><span>Folder O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="264">
                                                                    <i class="fa fa fa-folder-open fa-2x"></i><span>Folder Open</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="265">
                                                                    <i class="fa fa fa-folder-open-o fa-2x"></i><span>Folder Open O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="266">
                                                                    <i class="fa fa fa-font fa-2x"></i><span>Font</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="267">
                                                                    <i class="fa fa fa-fonticons fa-2x"></i><span>Fonticons</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="268">
                                                                    <i class="fa fa fa-fort-awesome fa-2x"></i><span>Fort Awesome</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="269">
                                                                    <i class="fa fa fa-forumbee fa-2x"></i><span>Forumbee</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="270">
                                                                    <i class="fa fa fa-forward fa-2x"></i><span>Forward</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="271">
                                                                    <i class="fa fa fa-foursquare fa-2x"></i><span>Foursquare</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="272">
                                                                    <i class="fa fa fa-frown-o fa-2x"></i><span>Frown O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="273">
                                                                    <i class="fa fa fa-futbol-o fa-2x"></i><span>Futbol O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="274">
                                                                    <i class="fa fa fa-gamepad fa-2x"></i><span>Gamepad</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="275">
                                                                    <i class="fa fa fa-gavel fa-2x"></i><span>Gavel</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="276">
                                                                    <i class="fa fa fa-gbp fa-2x"></i><span>Gbp</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="277">
                                                                    <i class="fa fa fa-ge fa-2x"></i><span>Ge</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="278">
                                                                    <i class="fa fa fa-gear fa-2x"></i><span>Gear</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="279">
                                                                    <i class="fa fa fa-gears fa-2x"></i><span>Gears</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="280">
                                                                    <i class="fa fa fa-genderless fa-2x"></i><span>Genderless</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="281">
                                                                    <i class="fa fa fa-get-pocket fa-2x"></i><span>Get Pocket</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="282">
                                                                    <i class="fa fa fa-gg fa-2x"></i><span>Gg</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="283">
                                                                    <i class="fa fa fa-gg-circle fa-2x"></i><span>Gg Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="284">
                                                                    <i class="fa fa fa-gift fa-2x"></i><span>Gift</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="285">
                                                                    <i class="fa fa fa-git fa-2x"></i><span>Git</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="286">
                                                                    <i class="fa fa fa-git-square fa-2x"></i><span>Git Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="287">
                                                                    <i class="fa fa fa-github fa-2x"></i><span>Github</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="288">
                                                                    <i class="fa fa fa-github-alt fa-2x"></i><span>Github Alt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="289">
                                                                    <i class="fa fa fa-github-square fa-2x"></i><span>Github Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="290">
                                                                    <i class="fa fa fa-gittip fa-2x"></i><span>Gittip</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="291">
                                                                    <i class="fa fa fa-glass fa-2x"></i><span>Glass</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="292">
                                                                    <i class="fa fa fa-globe fa-2x"></i><span>Globe</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="293">
                                                                    <i class="fa fa fa-google fa-2x"></i><span>Google</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="294">
                                                                    <i class="fa fa fa-google-plus fa-2x"></i><span>Google Plus</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="295">
                                                                    <i class="fa fa fa-google-plus-square fa-2x"></i><span>Google Plus Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="296">
                                                                    <i class="fa fa fa-google-wallet fa-2x"></i><span>Google Wallet</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="297">
                                                                    <i class="fa fa fa-graduation-cap fa-2x"></i><span>Graduation Cap</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="298">
                                                                    <i class="fa fa fa-gratipay fa-2x"></i><span>Gratipay</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="299">
                                                                    <i class="fa fa fa-group fa-2x"></i><span>Group</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="300">
                                                                    <i class="fa fa fa-h-square fa-2x"></i><span>H Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="301">
                                                                    <i class="fa fa fa-hacker-news fa-2x"></i><span>Hacker News</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="302">
                                                                    <i class="fa fa fa-hand-grab-o fa-2x"></i><span>Hand Grab O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="303">
                                                                    <i class="fa fa fa-hand-lizard-o fa-2x"></i><span>Hand Lizard O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="304">
                                                                    <i class="fa fa fa-hand-o-down fa-2x"></i><span>Hand O Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="305">
                                                                    <i class="fa fa fa-hand-o-left fa-2x"></i><span>Hand O Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="306">
                                                                    <i class="fa fa fa-hand-o-right fa-2x"></i><span>Hand O Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="307">
                                                                    <i class="fa fa fa-hand-o-up fa-2x"></i><span>Hand O Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="308">
                                                                    <i class="fa fa fa-hand-paper-o fa-2x"></i><span>Hand Paper O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="309">
                                                                    <i class="fa fa fa-hand-peace-o fa-2x"></i><span>Hand Peace O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="310">
                                                                    <i class="fa fa fa-hand-pointer-o fa-2x"></i><span>Hand Pointer O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="311">
                                                                    <i class="fa fa fa-hand-rock-o fa-2x"></i><span>Hand Rock O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="312">
                                                                    <i class="fa fa fa-hand-scissors-o fa-2x"></i><span>Hand Scissors O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="313">
                                                                    <i class="fa fa fa-hand-spock-o fa-2x"></i><span>Hand Spock O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="314">
                                                                    <i class="fa fa fa-hand-stop-o fa-2x"></i><span>Hand Stop O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="315">
                                                                    <i class="fa fa fa-hashtag fa-2x"></i><span>Hashtag</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="316">
                                                                    <i class="fa fa fa-hdd-o fa-2x"></i><span>Hdd O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="317">
                                                                    <i class="fa fa fa-header fa-2x"></i><span>Header</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="318">
                                                                    <i class="fa fa fa-headphones fa-2x"></i><span>Headphones</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="319">
                                                                    <i class="fa fa fa-heart fa-2x"></i><span>Heart</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="320">
                                                                    <i class="fa fa fa-heart-o fa-2x"></i><span>Heart O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="321">
                                                                    <i class="fa fa fa-heartbeat fa-2x"></i><span>Heartbeat</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="322">
                                                                    <i class="fa fa fa-history fa-2x"></i><span>History</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="323">
                                                                    <i class="fa fa fa-home fa-2x"></i><span>Home</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="324">
                                                                    <i class="fa fa fa-hospital-o fa-2x"></i><span>Hospital O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="325">
                                                                    <i class="fa fa fa-hotel fa-2x"></i><span>Hotel</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="326">
                                                                    <i class="fa fa fa-hourglass fa-2x"></i><span>Hourglass</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="327">
                                                                    <i class="fa fa fa-hourglass-1 fa-2x"></i><span>Hourglass 1</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="328">
                                                                    <i class="fa fa fa-hourglass-2 fa-2x"></i><span>Hourglass 2</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="329">
                                                                    <i class="fa fa fa-hourglass-3 fa-2x"></i><span>Hourglass 3</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="330">
                                                                    <i class="fa fa fa-hourglass-end fa-2x"></i><span>Hourglass End</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="331">
                                                                    <i class="fa fa fa-hourglass-half fa-2x"></i><span>Hourglass Half</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="332">
                                                                    <i class="fa fa fa-hourglass-o fa-2x"></i><span>Hourglass O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="333">
                                                                    <i class="fa fa fa-hourglass-start fa-2x"></i><span>Hourglass Start</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="334">
                                                                    <i class="fa fa fa-houzz fa-2x"></i><span>Houzz</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="335">
                                                                    <i class="fa fa fa-html5 fa-2x"></i><span>Html5</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="336">
                                                                    <i class="fa fa fa-i-cursor fa-2x"></i><span>I Cursor</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="337">
                                                                    <i class="fa fa fa-ils fa-2x"></i><span>Ils</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="338">
                                                                    <i class="fa fa fa-image fa-2x"></i><span>Image</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="339">
                                                                    <i class="fa fa fa-inbox fa-2x"></i><span>Inbox</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="340">
                                                                    <i class="fa fa fa-indent fa-2x"></i><span>Indent</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="341">
                                                                    <i class="fa fa fa-industry fa-2x"></i><span>Industry</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="342">
                                                                    <i class="fa fa fa-info fa-2x"></i><span>Info</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="343">
                                                                    <i class="fa fa fa-info-circle fa-2x"></i><span>Info Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="344">
                                                                    <i class="fa fa fa-inr fa-2x"></i><span>Inr</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="345">
                                                                    <i class="fa fa fa-instagram fa-2x"></i><span>Instagram</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="346">
                                                                    <i class="fa fa fa-institution fa-2x"></i><span>Institution</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="347">
                                                                    <i class="fa fa fa-internet-explorer fa-2x"></i><span>Internet Explorer</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="348">
                                                                    <i class="fa fa fa-intersex fa-2x"></i><span>Intersex</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="349">
                                                                    <i class="fa fa fa-ioxhost fa-2x"></i><span>Ioxhost</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="350">
                                                                    <i class="fa fa fa-italic fa-2x"></i><span>Italic</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="351">
                                                                    <i class="fa fa fa-joomla fa-2x"></i><span>Joomla</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="352">
                                                                    <i class="fa fa fa-jpy fa-2x"></i><span>Jpy</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="353">
                                                                    <i class="fa fa fa-jsfiddle fa-2x"></i><span>Jsfiddle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="354">
                                                                    <i class="fa fa fa-key fa-2x"></i><span>Key</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="355">
                                                                    <i class="fa fa fa-keyboard-o fa-2x"></i><span>Keyboard O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="356">
                                                                    <i class="fa fa fa-krw fa-2x"></i><span>Krw</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="357">
                                                                    <i class="fa fa fa-language fa-2x"></i><span>Language</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="358">
                                                                    <i class="fa fa fa-laptop fa-2x"></i><span>Laptop</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="359">
                                                                    <i class="fa fa fa-lastfm fa-2x"></i><span>Lastfm</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="360">
                                                                    <i class="fa fa fa-lastfm-square fa-2x"></i><span>Lastfm Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="361">
                                                                    <i class="fa fa fa-leaf fa-2x"></i><span>Leaf</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="362">
                                                                    <i class="fa fa fa-leanpub fa-2x"></i><span>Leanpub</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="363">
                                                                    <i class="fa fa fa-legal fa-2x"></i><span>Legal</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="364">
                                                                    <i class="fa fa fa-lemon-o fa-2x"></i><span>Lemon O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="365">
                                                                    <i class="fa fa fa-level-down fa-2x"></i><span>Level Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="366">
                                                                    <i class="fa fa fa-level-up fa-2x"></i><span>Level Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="367">
                                                                    <i class="fa fa fa-life-bouy fa-2x"></i><span>Life Bouy</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="368">
                                                                    <i class="fa fa fa-life-buoy fa-2x"></i><span>Life Buoy</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="369">
                                                                    <i class="fa fa fa-life-ring fa-2x"></i><span>Life Ring</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="370">
                                                                    <i class="fa fa fa-life-saver fa-2x"></i><span>Life Saver</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="371">
                                                                    <i class="fa fa fa-lightbulb-o fa-2x"></i><span>Lightbulb O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="372">
                                                                    <i class="fa fa fa-line-chart fa-2x"></i><span>Line Chart</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="373">
                                                                    <i class="fa fa fa-link fa-2x"></i><span>Link</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="374">
                                                                    <i class="fa fa fa-linkedin fa-2x"></i><span>Linkedin</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="375">
                                                                    <i class="fa fa fa-linkedin-square fa-2x"></i><span>Linkedin Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="376">
                                                                    <i class="fa fa fa-linux fa-2x"></i><span>Linux</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="377">
                                                                    <i class="fa fa fa-list fa-2x"></i><span>List</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="378">
                                                                    <i class="fa fa fa-list-alt fa-2x"></i><span>List Alt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="379">
                                                                    <i class="fa fa fa-list-ol fa-2x"></i><span>List Ol</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="380">
                                                                    <i class="fa fa fa-list-ul fa-2x"></i><span>List Ul</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="381">
                                                                    <i class="fa fa fa-location-arrow fa-2x"></i><span>Location Arrow</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="382">
                                                                    <i class="fa fa fa-lock fa-2x"></i><span>Lock</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="383">
                                                                    <i class="fa fa fa-long-arrow-down fa-2x"></i><span>Long Arrow Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="384">
                                                                    <i class="fa fa fa-long-arrow-left fa-2x"></i><span>Long Arrow Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="385">
                                                                    <i class="fa fa fa-long-arrow-right fa-2x"></i><span>Long Arrow Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="386">
                                                                    <i class="fa fa fa-long-arrow-up fa-2x"></i><span>Long Arrow Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="387">
                                                                    <i class="fa fa fa-magic fa-2x"></i><span>Magic</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="388">
                                                                    <i class="fa fa fa-magnet fa-2x"></i><span>Magnet</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="389">
                                                                    <i class="fa fa fa-mail-forward fa-2x"></i><span>Mail Forward</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="390">
                                                                    <i class="fa fa fa-mail-reply fa-2x"></i><span>Mail Reply</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="391">
                                                                    <i class="fa fa fa-mail-reply-all fa-2x"></i><span>Mail Reply All</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="392">
                                                                    <i class="fa fa fa-male fa-2x"></i><span>Male</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="393">
                                                                    <i class="fa fa fa-map fa-2x"></i><span>Map</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="394">
                                                                    <i class="fa fa fa-map-marker fa-2x"></i><span>Map Marker</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="395">
                                                                    <i class="fa fa fa-map-o fa-2x"></i><span>Map O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="396">
                                                                    <i class="fa fa fa-map-pin fa-2x"></i><span>Map Pin</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="397">
                                                                    <i class="fa fa fa-map-signs fa-2x"></i><span>Map Signs</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="398">
                                                                    <i class="fa fa fa-mars fa-2x"></i><span>Mars</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="399">
                                                                    <i class="fa fa fa-mars-double fa-2x"></i><span>Mars Double</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="400">
                                                                    <i class="fa fa fa-mars-stroke fa-2x"></i><span>Mars Stroke</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="401">
                                                                    <i class="fa fa fa-mars-stroke-h fa-2x"></i><span>Mars Stroke H</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="402">
                                                                    <i class="fa fa fa-mars-stroke-v fa-2x"></i><span>Mars Stroke V</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="403">
                                                                    <i class="fa fa fa-maxcdn fa-2x"></i><span>Maxcdn</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="404">
                                                                    <i class="fa fa fa-meanpath fa-2x"></i><span>Meanpath</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="405">
                                                                    <i class="fa fa fa-medium fa-2x"></i><span>Medium</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="406">
                                                                    <i class="fa fa fa-medkit fa-2x"></i><span>Medkit</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="407">
                                                                    <i class="fa fa fa-meh-o fa-2x"></i><span>Meh O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="408">
                                                                    <i class="fa fa fa-mercury fa-2x"></i><span>Mercury</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="409">
                                                                    <i class="fa fa fa-microphone fa-2x"></i><span>Microphone</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="410">
                                                                    <i class="fa fa fa-microphone-slash fa-2x"></i><span>Microphone Slash</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="411">
                                                                    <i class="fa fa fa-minus fa-2x"></i><span>Minus</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="412">
                                                                    <i class="fa fa fa-minus-circle fa-2x"></i><span>Minus Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="413">
                                                                    <i class="fa fa fa-minus-square fa-2x"></i><span>Minus Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="414">
                                                                    <i class="fa fa fa-minus-square-o fa-2x"></i><span>Minus Square O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="415">
                                                                    <i class="fa fa fa-mixcloud fa-2x"></i><span>Mixcloud</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="416">
                                                                    <i class="fa fa fa-mobile fa-2x"></i><span>Mobile</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="417">
                                                                    <i class="fa fa fa-mobile-phone fa-2x"></i><span>Mobile Phone</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="418">
                                                                    <i class="fa fa fa-modx fa-2x"></i><span>Modx</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="419">
                                                                    <i class="fa fa fa-money fa-2x"></i><span>Money</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="420">
                                                                    <i class="fa fa fa-moon-o fa-2x"></i><span>Moon O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="421">
                                                                    <i class="fa fa fa-mortar-board fa-2x"></i><span>Mortar Board</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="422">
                                                                    <i class="fa fa fa-motorcycle fa-2x"></i><span>Motorcycle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="423">
                                                                    <i class="fa fa fa-mouse-pointer fa-2x"></i><span>Mouse Pointer</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="424">
                                                                    <i class="fa fa fa-music fa-2x"></i><span>Music</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="425">
                                                                    <i class="fa fa fa-navicon fa-2x"></i><span>Navicon</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="426">
                                                                    <i class="fa fa fa-neuter fa-2x"></i><span>Neuter</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="427">
                                                                    <i class="fa fa fa-newspaper-o fa-2x"></i><span>Newspaper O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="428">
                                                                    <i class="fa fa fa-object-group fa-2x"></i><span>Object Group</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="429">
                                                                    <i class="fa fa fa-object-ungroup fa-2x"></i><span>Object Ungroup</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="430">
                                                                    <i class="fa fa fa-odnoklassniki fa-2x"></i><span>Odnoklassniki</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="431">
                                                                    <i class="fa fa fa-odnoklassniki-square fa-2x"></i><span>Odnoklassniki Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="432">
                                                                    <i class="fa fa fa-opencart fa-2x"></i><span>Opencart</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="433">
                                                                    <i class="fa fa fa-openid fa-2x"></i><span>Openid</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="434">
                                                                    <i class="fa fa fa-opera fa-2x"></i><span>Opera</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="435">
                                                                    <i class="fa fa fa-optin-monster fa-2x"></i><span>Optin Monster</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="436">
                                                                    <i class="fa fa fa-outdent fa-2x"></i><span>Outdent</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="437">
                                                                    <i class="fa fa fa-pagelines fa-2x"></i><span>Pagelines</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="438">
                                                                    <i class="fa fa fa-paint-brush fa-2x"></i><span>Paint Brush</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="439">
                                                                    <i class="fa fa fa-paper-plane fa-2x"></i><span>Paper Plane</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="440">
                                                                    <i class="fa fa fa-paper-plane-o fa-2x"></i><span>Paper Plane O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="441">
                                                                    <i class="fa fa fa-paperclip fa-2x"></i><span>Paperclip</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="442">
                                                                    <i class="fa fa fa-paragraph fa-2x"></i><span>Paragraph</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="443">
                                                                    <i class="fa fa fa-paste fa-2x"></i><span>Paste</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="444">
                                                                    <i class="fa fa fa-pause fa-2x"></i><span>Pause</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="445">
                                                                    <i class="fa fa fa-pause-circle fa-2x"></i><span>Pause Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="446">
                                                                    <i class="fa fa fa-pause-circle-o fa-2x"></i><span>Pause Circle O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="447">
                                                                    <i class="fa fa fa-paw fa-2x"></i><span>Paw</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="448">
                                                                    <i class="fa fa fa-paypal fa-2x"></i><span>Paypal</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="449">
                                                                    <i class="fa fa fa-pencil fa-2x"></i><span>Pencil</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="450">
                                                                    <i class="fa fa fa-pencil-square fa-2x"></i><span>Pencil Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="451">
                                                                    <i class="fa fa fa-pencil-square-o fa-2x"></i><span>Pencil Square O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="452">
                                                                    <i class="fa fa fa-percent fa-2x"></i><span>Percent</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="453">
                                                                    <i class="fa fa fa-phone fa-2x"></i><span>Phone</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="454">
                                                                    <i class="fa fa fa-phone-square fa-2x"></i><span>Phone Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="455">
                                                                    <i class="fa fa fa-photo fa-2x"></i><span>Photo</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="456">
                                                                    <i class="fa fa fa-picture-o fa-2x"></i><span>Picture O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="457">
                                                                    <i class="fa fa fa-pie-chart fa-2x"></i><span>Pie Chart</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="458">
                                                                    <i class="fa fa fa-pied-piper fa-2x"></i><span>Pied Piper</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="459">
                                                                    <i class="fa fa fa-pied-piper-alt fa-2x"></i><span>Pied Piper Alt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="460">
                                                                    <i class="fa fa fa-pinterest fa-2x"></i><span>Pinterest</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="461">
                                                                    <i class="fa fa fa-pinterest-p fa-2x"></i><span>Pinterest P</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="462">
                                                                    <i class="fa fa fa-pinterest-square fa-2x"></i><span>Pinterest Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="463">
                                                                    <i class="fa fa fa-plane fa-2x"></i><span>Plane</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="464">
                                                                    <i class="fa fa fa-play fa-2x"></i><span>Play</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="465">
                                                                    <i class="fa fa fa-play-circle fa-2x"></i><span>Play Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="466">
                                                                    <i class="fa fa fa-play-circle-o fa-2x"></i><span>Play Circle O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="467">
                                                                    <i class="fa fa fa-plug fa-2x"></i><span>Plug</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="468">
                                                                    <i class="fa fa fa-plus fa-2x"></i><span>Plus</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="469">
                                                                    <i class="fa fa fa-plus-circle fa-2x"></i><span>Plus Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="470">
                                                                    <i class="fa fa fa-plus-square fa-2x"></i><span>Plus Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="471">
                                                                    <i class="fa fa fa-plus-square-o fa-2x"></i><span>Plus Square O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="472">
                                                                    <i class="fa fa fa-power-off fa-2x"></i><span>Power Off</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="473">
                                                                    <i class="fa fa fa-print fa-2x"></i><span>Print</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="474">
                                                                    <i class="fa fa fa-product-hunt fa-2x"></i><span>Product Hunt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="475">
                                                                    <i class="fa fa fa-puzzle-piece fa-2x"></i><span>Puzzle Piece</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="476">
                                                                    <i class="fa fa fa-qq fa-2x"></i><span>Qq</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="477">
                                                                    <i class="fa fa fa-qrcode fa-2x"></i><span>Qrcode</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="478">
                                                                    <i class="fa fa fa-question fa-2x"></i><span>Question</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="479">
                                                                    <i class="fa fa fa-question-circle fa-2x"></i><span>Question Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="480">
                                                                    <i class="fa fa fa-quote-left fa-2x"></i><span>Quote Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="481">
                                                                    <i class="fa fa fa-quote-right fa-2x"></i><span>Quote Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="482">
                                                                    <i class="fa fa fa-ra fa-2x"></i><span>Ra</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="483">
                                                                    <i class="fa fa fa-random fa-2x"></i><span>Random</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="484">
                                                                    <i class="fa fa fa-rebel fa-2x"></i><span>Rebel</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="485">
                                                                    <i class="fa fa fa-recycle fa-2x"></i><span>Recycle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="486">
                                                                    <i class="fa fa fa-reddit fa-2x"></i><span>Reddit</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="487">
                                                                    <i class="fa fa fa-reddit-alien fa-2x"></i><span>Reddit Alien</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="488">
                                                                    <i class="fa fa fa-reddit-square fa-2x"></i><span>Reddit Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="489">
                                                                    <i class="fa fa fa-refresh fa-2x"></i><span>Refresh</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="490">
                                                                    <i class="fa fa fa-registered fa-2x"></i><span>Registered</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="491">
                                                                    <i class="fa fa fa-remove fa-2x"></i><span>Remove</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="492">
                                                                    <i class="fa fa fa-renren fa-2x"></i><span>Renren</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="493">
                                                                    <i class="fa fa fa-reorder fa-2x"></i><span>Reorder</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="494">
                                                                    <i class="fa fa fa-repeat fa-2x"></i><span>Repeat</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="495">
                                                                    <i class="fa fa fa-reply fa-2x"></i><span>Reply</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="496">
                                                                    <i class="fa fa fa-reply-all fa-2x"></i><span>Reply All</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="497">
                                                                    <i class="fa fa fa-retweet fa-2x"></i><span>Retweet</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="498">
                                                                    <i class="fa fa fa-rmb fa-2x"></i><span>Rmb</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="499">
                                                                    <i class="fa fa fa-road fa-2x"></i><span>Road</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="500">
                                                                    <i class="fa fa fa-rocket fa-2x"></i><span>Rocket</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="501">
                                                                    <i class="fa fa fa-rotate-left fa-2x"></i><span>Rotate Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="502">
                                                                    <i class="fa fa fa-rotate-right fa-2x"></i><span>Rotate Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="503">
                                                                    <i class="fa fa fa-rouble fa-2x"></i><span>Rouble</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="504">
                                                                    <i class="fa fa fa-rss fa-2x"></i><span>Rss</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="505">
                                                                    <i class="fa fa fa-rss-square fa-2x"></i><span>Rss Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="506">
                                                                    <i class="fa fa fa-rub fa-2x"></i><span>Rub</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="507">
                                                                    <i class="fa fa fa-ruble fa-2x"></i><span>Ruble</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="508">
                                                                    <i class="fa fa fa-rupee fa-2x"></i><span>Rupee</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="509">
                                                                    <i class="fa fa fa-safari fa-2x"></i><span>Safari</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="510">
                                                                    <i class="fa fa fa-save fa-2x"></i><span>Save</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="511">
                                                                    <i class="fa fa fa-scissors fa-2x"></i><span>Scissors</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="512">
                                                                    <i class="fa fa fa-scribd fa-2x"></i><span>Scribd</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="513">
                                                                    <i class="fa fa fa-search fa-2x"></i><span>Search</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="514">
                                                                    <i class="fa fa fa-search-minus fa-2x"></i><span>Search Minus</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="515">
                                                                    <i class="fa fa fa-search-plus fa-2x"></i><span>Search Plus</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="516">
                                                                    <i class="fa fa fa-sellsy fa-2x"></i><span>Sellsy</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="517">
                                                                    <i class="fa fa fa-send fa-2x"></i><span>Send</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="518">
                                                                    <i class="fa fa fa-send-o fa-2x"></i><span>Send O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="519">
                                                                    <i class="fa fa fa-server fa-2x"></i><span>Server</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="520">
                                                                    <i class="fa fa fa-share fa-2x"></i><span>Share</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="521">
                                                                    <i class="fa fa fa-share-alt fa-2x"></i><span>Share Alt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="522">
                                                                    <i class="fa fa fa-share-alt-square fa-2x"></i><span>Share Alt Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="523">
                                                                    <i class="fa fa fa-share-square fa-2x"></i><span>Share Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="524">
                                                                    <i class="fa fa fa-share-square-o fa-2x"></i><span>Share Square O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="525">
                                                                    <i class="fa fa fa-shekel fa-2x"></i><span>Shekel</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="526">
                                                                    <i class="fa fa fa-sheqel fa-2x"></i><span>Sheqel</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="527">
                                                                    <i class="fa fa fa-shield fa-2x"></i><span>Shield</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="528">
                                                                    <i class="fa fa fa-ship fa-2x"></i><span>Ship</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="529">
                                                                    <i class="fa fa fa-shirtsinbulk fa-2x"></i><span>Shirtsinbulk</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="530">
                                                                    <i class="fa fa fa-shopping-bag fa-2x"></i><span>Shopping Bag</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="531">
                                                                    <i class="fa fa fa-shopping-basket fa-2x"></i><span>Shopping Basket</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="532">
                                                                    <i class="fa fa fa-shopping-cart fa-2x"></i><span>Shopping Cart</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="533">
                                                                    <i class="fa fa fa-sign-in fa-2x"></i><span>Sign In</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="534">
                                                                    <i class="fa fa fa-sign-out fa-2x"></i><span>Sign Out</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="535">
                                                                    <i class="fa fa fa-signal fa-2x"></i><span>Signal</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="536">
                                                                    <i class="fa fa fa-simplybuilt fa-2x"></i><span>Simplybuilt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="537">
                                                                    <i class="fa fa fa-sitemap fa-2x"></i><span>Sitemap</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="538">
                                                                    <i class="fa fa fa-skyatlas fa-2x"></i><span>Skyatlas</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="539">
                                                                    <i class="fa fa fa-skype fa-2x"></i><span>Skype</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="540">
                                                                    <i class="fa fa fa-slack fa-2x"></i><span>Slack</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="541">
                                                                    <i class="fa fa fa-sliders fa-2x"></i><span>Sliders</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="542">
                                                                    <i class="fa fa fa-slideshare fa-2x"></i><span>Slideshare</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="543">
                                                                    <i class="fa fa fa-smile-o fa-2x"></i><span>Smile O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="544">
                                                                    <i class="fa fa fa-soccer-ball-o fa-2x"></i><span>Soccer Ball O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="545">
                                                                    <i class="fa fa fa-sort fa-2x"></i><span>Sort</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="546">
                                                                    <i class="fa fa fa-sort-alpha-asc fa-2x"></i><span>Sort Alpha Asc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="547">
                                                                    <i class="fa fa fa-sort-alpha-desc fa-2x"></i><span>Sort Alpha Desc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="548">
                                                                    <i class="fa fa fa-sort-amount-asc fa-2x"></i><span>Sort Amount Asc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="549">
                                                                    <i class="fa fa fa-sort-amount-desc fa-2x"></i><span>Sort Amount Desc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="550">
                                                                    <i class="fa fa fa-sort-asc fa-2x"></i><span>Sort Asc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="551">
                                                                    <i class="fa fa fa-sort-desc fa-2x"></i><span>Sort Desc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="552">
                                                                    <i class="fa fa fa-sort-down fa-2x"></i><span>Sort Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="553">
                                                                    <i class="fa fa fa-sort-numeric-asc fa-2x"></i><span>Sort Numeric Asc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="554">
                                                                    <i class="fa fa fa-sort-numeric-desc fa-2x"></i><span>Sort Numeric Desc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="555">
                                                                    <i class="fa fa fa-sort-up fa-2x"></i><span>Sort Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="556">
                                                                    <i class="fa fa fa-soundcloud fa-2x"></i><span>Soundcloud</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="557">
                                                                    <i class="fa fa fa-space-shuttle fa-2x"></i><span>Space Shuttle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="558">
                                                                    <i class="fa fa fa-spinner fa-2x"></i><span>Spinner</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="559">
                                                                    <i class="fa fa fa-spoon fa-2x"></i><span>Spoon</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="560">
                                                                    <i class="fa fa fa-spotify fa-2x"></i><span>Spotify</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="561">
                                                                    <i class="fa fa fa-square fa-2x"></i><span>Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="562">
                                                                    <i class="fa fa fa-square-o fa-2x"></i><span>Square O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="563">
                                                                    <i class="fa fa fa-stack-exchange fa-2x"></i><span>Stack Exchange</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="564">
                                                                    <i class="fa fa fa-stack-overflow fa-2x"></i><span>Stack Overflow</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="565">
                                                                    <i class="fa fa fa-star fa-2x"></i><span>Star</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="566">
                                                                    <i class="fa fa fa-star-half fa-2x"></i><span>Star Half</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="567">
                                                                    <i class="fa fa fa-star-half-empty fa-2x"></i><span>Star Half Empty</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="568">
                                                                    <i class="fa fa fa-star-half-full fa-2x"></i><span>Star Half Full</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="569">
                                                                    <i class="fa fa fa-star-half-o fa-2x"></i><span>Star Half O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="570">
                                                                    <i class="fa fa fa-star-o fa-2x"></i><span>Star O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="571">
                                                                    <i class="fa fa fa-steam fa-2x"></i><span>Steam</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="572">
                                                                    <i class="fa fa fa-steam-square fa-2x"></i><span>Steam Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="573">
                                                                    <i class="fa fa fa-step-backward fa-2x"></i><span>Step Backward</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="574">
                                                                    <i class="fa fa fa-step-forward fa-2x"></i><span>Step Forward</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="575">
                                                                    <i class="fa fa fa-stethoscope fa-2x"></i><span>Stethoscope</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="576">
                                                                    <i class="fa fa fa-sticky-note fa-2x"></i><span>Sticky Note</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="577">
                                                                    <i class="fa fa fa-sticky-note-o fa-2x"></i><span>Sticky Note O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="578">
                                                                    <i class="fa fa fa-stop fa-2x"></i><span>Stop</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="579">
                                                                    <i class="fa fa fa-stop-circle fa-2x"></i><span>Stop Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="580">
                                                                    <i class="fa fa fa-stop-circle-o fa-2x"></i><span>Stop Circle O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="581">
                                                                    <i class="fa fa fa-street-view fa-2x"></i><span>Street View</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="582">
                                                                    <i class="fa fa fa-strikethrough fa-2x"></i><span>Strikethrough</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="583">
                                                                    <i class="fa fa fa-stumbleupon fa-2x"></i><span>Stumbleupon</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="584">
                                                                    <i class="fa fa fa-stumbleupon-circle fa-2x"></i><span>Stumbleupon Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="585">
                                                                    <i class="fa fa fa-subscript fa-2x"></i><span>Subscript</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="586">
                                                                    <i class="fa fa fa-subway fa-2x"></i><span>Subway</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="587">
                                                                    <i class="fa fa fa-suitcase fa-2x"></i><span>Suitcase</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="588">
                                                                    <i class="fa fa fa-sun-o fa-2x"></i><span>Sun O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="589">
                                                                    <i class="fa fa fa-superscript fa-2x"></i><span>Superscript</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="590">
                                                                    <i class="fa fa fa-support fa-2x"></i><span>Support</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="591">
                                                                    <i class="fa fa fa-table fa-2x"></i><span>Table</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="592">
                                                                    <i class="fa fa fa-tablet fa-2x"></i><span>Tablet</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="593">
                                                                    <i class="fa fa fa-tachometer fa-2x"></i><span>Tachometer</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="594">
                                                                    <i class="fa fa fa-tag fa-2x"></i><span>Tag</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="595">
                                                                    <i class="fa fa fa-tags fa-2x"></i><span>Tags</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="596">
                                                                    <i class="fa fa fa-tasks fa-2x"></i><span>Tasks</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="597">
                                                                    <i class="fa fa fa-taxi fa-2x"></i><span>Taxi</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="598">
                                                                    <i class="fa fa fa-television fa-2x"></i><span>Television</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="599">
                                                                    <i class="fa fa fa-tencent-weibo fa-2x"></i><span>Tencent Weibo</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="600">
                                                                    <i class="fa fa fa-terminal fa-2x"></i><span>Terminal</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="601">
                                                                    <i class="fa fa fa-text-height fa-2x"></i><span>Text Height</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="602">
                                                                    <i class="fa fa fa-text-width fa-2x"></i><span>Text Width</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="603">
                                                                    <i class="fa fa fa-th fa-2x"></i><span>Th</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="604">
                                                                    <i class="fa fa fa-th-large fa-2x"></i><span>Th Large</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="605">
                                                                    <i class="fa fa fa-th-list fa-2x"></i><span>Th List</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="606">
                                                                    <i class="fa fa fa-thumb-tack fa-2x"></i><span>Thumb Tack</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="607">
                                                                    <i class="fa fa fa-thumbs-down fa-2x"></i><span>Thumbs Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="608">
                                                                    <i class="fa fa fa-thumbs-o-down fa-2x"></i><span>Thumbs O Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="609">
                                                                    <i class="fa fa fa-thumbs-o-up fa-2x"></i><span>Thumbs O Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="610">
                                                                    <i class="fa fa fa-thumbs-up fa-2x"></i><span>Thumbs Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="611">
                                                                    <i class="fa fa fa-ticket fa-2x"></i><span>Ticket</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="612">
                                                                    <i class="fa fa fa-times fa-2x"></i><span>Times</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="613">
                                                                    <i class="fa fa fa-times-circle fa-2x"></i><span>Times Circle</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="614">
                                                                    <i class="fa fa fa-times-circle-o fa-2x"></i><span>Times Circle O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="615">
                                                                    <i class="fa fa fa-tint fa-2x"></i><span>Tint</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="616">
                                                                    <i class="fa fa fa-toggle-down fa-2x"></i><span>Toggle Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="617">
                                                                    <i class="fa fa fa-toggle-left fa-2x"></i><span>Toggle Left</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="618">
                                                                    <i class="fa fa fa-toggle-off fa-2x"></i><span>Toggle Off</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="619">
                                                                    <i class="fa fa fa-toggle-on fa-2x"></i><span>Toggle On</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="620">
                                                                    <i class="fa fa fa-toggle-right fa-2x"></i><span>Toggle Right</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="621">
                                                                    <i class="fa fa fa-toggle-up fa-2x"></i><span>Toggle Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="622">
                                                                    <i class="fa fa fa-trademark fa-2x"></i><span>Trademark</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="623">
                                                                    <i class="fa fa fa-train fa-2x"></i><span>Train</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="624">
                                                                    <i class="fa fa fa-transgender fa-2x"></i><span>Transgender</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="625">
                                                                    <i class="fa fa fa-transgender-alt fa-2x"></i><span>Transgender Alt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="626">
                                                                    <i class="fa fa fa-trash fa-2x"></i><span>Trash</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="627">
                                                                    <i class="fa fa fa-trash-o fa-2x"></i><span>Trash O</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="628">
                                                                    <i class="fa fa fa-tree fa-2x"></i><span>Tree</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="629">
                                                                    <i class="fa fa fa-trello fa-2x"></i><span>Trello</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="630">
                                                                    <i class="fa fa fa-tripadvisor fa-2x"></i><span>Tripadvisor</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="631">
                                                                    <i class="fa fa fa-trophy fa-2x"></i><span>Trophy</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="632">
                                                                    <i class="fa fa fa-truck fa-2x"></i><span>Truck</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="633">
                                                                    <i class="fa fa fa-try fa-2x"></i><span>Try</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="634">
                                                                    <i class="fa fa fa-tty fa-2x"></i><span>Tty</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="635">
                                                                    <i class="fa fa fa-tumblr fa-2x"></i><span>Tumblr</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="636">
                                                                    <i class="fa fa fa-tumblr-square fa-2x"></i><span>Tumblr Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="637">
                                                                    <i class="fa fa fa-turkish-lira fa-2x"></i><span>Turkish Lira</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="638">
                                                                    <i class="fa fa fa-tv fa-2x"></i><span>Tv</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="639">
                                                                    <i class="fa fa fa-twitch fa-2x"></i><span>Twitch</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="640">
                                                                    <i class="fa fa fa-twitter fa-2x"></i><span>Twitter</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="641">
                                                                    <i class="fa fa fa-twitter-square fa-2x"></i><span>Twitter Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="642">
                                                                    <i class="fa fa fa-umbrella fa-2x"></i><span>Umbrella</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="643">
                                                                    <i class="fa fa fa-underline fa-2x"></i><span>Underline</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="644">
                                                                    <i class="fa fa fa-undo fa-2x"></i><span>Undo</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="645">
                                                                    <i class="fa fa fa-university fa-2x"></i><span>University</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="646">
                                                                    <i class="fa fa fa-unlink fa-2x"></i><span>Unlink</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="647">
                                                                    <i class="fa fa fa-unlock fa-2x"></i><span>Unlock</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="648">
                                                                    <i class="fa fa fa-unlock-alt fa-2x"></i><span>Unlock Alt</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="649">
                                                                    <i class="fa fa fa-unsorted fa-2x"></i><span>Unsorted</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="650">
                                                                    <i class="fa fa fa-upload fa-2x"></i><span>Upload</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="651">
                                                                    <i class="fa fa fa-usb fa-2x"></i><span>Usb</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="652">
                                                                    <i class="fa fa fa-usd fa-2x"></i><span>Usd</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="653">
                                                                    <i class="fa fa fa-user fa-2x"></i><span>User</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="654">
                                                                    <i class="fa fa fa-user-md fa-2x"></i><span>User Md</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="655">
                                                                    <i class="fa fa fa-user-plus fa-2x"></i><span>User Plus</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="656">
                                                                    <i class="fa fa fa-user-secret fa-2x"></i><span>User Secret</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="657">
                                                                    <i class="fa fa fa-user-times fa-2x"></i><span>User Times</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="658">
                                                                    <i class="fa fa fa-users fa-2x"></i><span>Users</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="659">
                                                                    <i class="fa fa fa-venus fa-2x"></i><span>Venus</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="660">
                                                                    <i class="fa fa fa-venus-double fa-2x"></i><span>Venus Double</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="661">
                                                                    <i class="fa fa fa-venus-mars fa-2x"></i><span>Venus Mars</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="662">
                                                                    <i class="fa fa fa-viacoin fa-2x"></i><span>Viacoin</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="663">
                                                                    <i class="fa fa fa-video-camera fa-2x"></i><span>Video Camera</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="664">
                                                                    <i class="fa fa fa-vimeo fa-2x"></i><span>Vimeo</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="665">
                                                                    <i class="fa fa fa-vimeo-square fa-2x"></i><span>Vimeo Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="666">
                                                                    <i class="fa fa fa-vine fa-2x"></i><span>Vine</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="667">
                                                                    <i class="fa fa fa-vk fa-2x"></i><span>Vk</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="668">
                                                                    <i class="fa fa fa-volume-down fa-2x"></i><span>Volume Down</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="669">
                                                                    <i class="fa fa fa-volume-off fa-2x"></i><span>Volume Off</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="670">
                                                                    <i class="fa fa fa-volume-up fa-2x"></i><span>Volume Up</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="671">
                                                                    <i class="fa fa fa-warning fa-2x"></i><span>Warning</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="672">
                                                                    <i class="fa fa fa-wechat fa-2x"></i><span>Wechat</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="673">
                                                                    <i class="fa fa fa-weibo fa-2x"></i><span>Weibo</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="674">
                                                                    <i class="fa fa fa-weixin fa-2x"></i><span>Weixin</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="675">
                                                                    <i class="fa fa fa-whatsapp fa-2x"></i><span>Whatsapp</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="676">
                                                                    <i class="fa fa fa-wheelchair fa-2x"></i><span>Wheelchair</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="677">
                                                                    <i class="fa fa fa-wifi fa-2x"></i><span>Wifi</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="678">
                                                                    <i class="fa fa fa-wikipedia-w fa-2x"></i><span>Wikipedia W</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="679">
                                                                    <i class="fa fa fa-windows fa-2x"></i><span>Windows</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="680">
                                                                    <i class="fa fa fa-won fa-2x"></i><span>Won</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="681">
                                                                    <i class="fa fa fa-wordpress fa-2x"></i><span>Wordpress</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="682">
                                                                    <i class="fa fa fa-wrench fa-2x"></i><span>Wrench</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="683">
                                                                    <i class="fa fa fa-xing fa-2x"></i><span>Xing</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="684">
                                                                    <i class="fa fa fa-xing-square fa-2x"></i><span>Xing Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="685">
                                                                    <i class="fa fa fa-y-combinator fa-2x"></i><span>Y Combinator</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="686">
                                                                    <i class="fa fa fa-y-combinator-square fa-2x"></i><span>Y Combinator Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="687">
                                                                    <i class="fa fa fa-yahoo fa-2x"></i><span>Yahoo</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="688">
                                                                    <i class="fa fa fa-yc fa-2x"></i><span>Yc</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="689">
                                                                    <i class="fa fa fa-yc-square fa-2x"></i><span>Yc Square</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="690">
                                                                    <i class="fa fa fa-yelp fa-2x"></i><span>Yelp</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="691">
                                                                    <i class="fa fa fa-yen fa-2x"></i><span>Yen</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="692">
                                                                    <i class="fa fa fa-youtube fa-2x"></i><span>Youtube</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="693">
                                                                    <i class="fa fa fa-youtube-play fa-2x"></i><span>Youtube Play</span>
                                                                </div>
                                                            </div>
                                                                                            <div class="col-sm-6 col-md-3">
                                                                <div class="demo-icon" data-icon="694">
                                                                    <i class="fa fa fa-youtube-square fa-2x"></i><span>Youtube Square</span>
                                                                </div>
                                                            </div>
                                                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                    </div>
                    <!--===================================================-->
                    <!--End page content-->
    
                </div>
                <!--===================================================-->
                <!--END CONTENT CONTAINER-->
    
    
                
                <!--ASIDE-->
                <!--===================================================-->
                <aside id="aside-container">
                    <div id="aside">
                        <div class="nano">
                            <div class="nano-content">
                                
                                <!--Nav tabs-->
                                <!--================================-->
                                <ul class="nav nav-tabs nav-justified">
                                    <li class="active">
                                        <a href="#demo-asd-tab-1" data-toggle="tab">
                                            <i class="demo-pli-speech-bubble-7 icon-lg"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#demo-asd-tab-2" data-toggle="tab">
                                            <i class="demo-pli-information icon-lg icon-fw"></i> Report
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#demo-asd-tab-3" data-toggle="tab">
                                            <i class="demo-pli-wrench icon-lg icon-fw"></i> Settings
                                        </a>
                                    </li>
                                </ul>
                                <!--================================-->
                                <!--End nav tabs-->
    
    
    
                                <!-- Tabs Content -->
                                <!--================================-->
                                <div class="tab-content">
    
                                    <!--First tab (Contact list)-->
                                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                    <div class="tab-pane fade in active" id="demo-asd-tab-1">
                                        <p class="pad-all text-main text-sm text-uppercase text-bold">
                                            <span class="pull-right badge badge-warning">3</span> Family
                                        </p>
    
                                        <!--Family-->
                                        <div class="list-group bg-trans">
                                            <a href="#" class="list-group-item">
                                                <div class="media-left pos-rel">
                                                    <img class="img-circle img-xs" src="img/profile-photos/2.png" alt="Profile Picture">
                                                    <i class="badge badge-success badge-stat badge-icon pull-left"></i>
                                                </div>
                                                <div class="media-body">
                                                    <p class="mar-no text-main">Stephen Tran</p>
                                                    <small class="text-muteds">Availabe</small>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <div class="media-left pos-rel">
                                                    <img class="img-circle img-xs" src="img/profile-photos/7.png" alt="Profile Picture">
                                                </div>
                                                <div class="media-body">
                                                    <p class="mar-no text-main">Brittany Meyer</p>
                                                    <small class="text-muteds">I think so</small>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <div class="media-left pos-rel">
                                                    <img class="img-circle img-xs" src="img/profile-photos/1.png" alt="Profile Picture">
                                                    <i class="badge badge-info badge-stat badge-icon pull-left"></i>
                                                </div>
                                                <div class="media-body">
                                                    <p class="mar-no text-main">Jack George</p>
                                                    <small class="text-muteds">Last Seen 2 hours ago</small>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <div class="media-left pos-rel">
                                                    <img class="img-circle img-xs" src="img/profile-photos/4.png" alt="Profile Picture">
                                                </div>
                                                <div class="media-body">
                                                    <p class="mar-no text-main">Donald Brown</p>
                                                    <small class="text-muteds">Lorem ipsum dolor sit amet.</small>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <div class="media-left pos-rel">
                                                    <img class="img-circle img-xs" src="img/profile-photos/8.png" alt="Profile Picture">
                                                    <i class="badge badge-warning badge-stat badge-icon pull-left"></i>
                                                </div>
                                                <div class="media-body">
                                                    <p class="mar-no text-main">Betty Murphy</p>
                                                    <small class="text-muteds">Idle</small>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <div class="media-left pos-rel">
                                                    <img class="img-circle img-xs" src="img/profile-photos/9.png" alt="Profile Picture">
                                                    <i class="badge badge-danger badge-stat badge-icon pull-left"></i>
                                                </div>
                                                <div class="media-body">
                                                    <p class="mar-no text-main">Samantha Reid</p>
                                                    <small class="text-muteds">Offline</small>
                                                </div>
                                            </a>
                                        </div>
    
                                        <hr>
                                        <p class="pad-all text-main text-sm text-uppercase text-bold">
                                            <span class="pull-right badge badge-success">Offline</span> Friends
                                        </p>
    
                                        <!--Works-->
                                        <div class="list-group bg-trans">
                                            <a href="#" class="list-group-item">
                                                <span class="badge badge-purple badge-icon badge-fw pull-left"></span> Joey K. Greyson
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <span class="badge badge-info badge-icon badge-fw pull-left"></span> Andrea Branden
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <span class="badge badge-success badge-icon badge-fw pull-left"></span> Johny Juan
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <span class="badge badge-danger badge-icon badge-fw pull-left"></span> Susan Sun
                                            </a>
                                        </div>
    
    
                                        <hr>
                                        <p class="pad-all text-main text-sm text-uppercase text-bold">News</p>
    
                                        <div class="pad-hor">
                                            <p>Lorem ipsum dolor sit amet, consectetuer
                                                <a data-title="45%" class="add-tooltip text-semibold text-main" href="#">adipiscing elit</a>, sed diam nonummy nibh. Lorem ipsum dolor sit amet.
                                            </p>
                                            <small><em>Last Update : Des 12, 2014</em></small>
                                        </div>
    
    
                                    </div>
                                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                    <!--End first tab (Contact list)-->
    
    
                                    <!--Second tab (Custom layout)-->
                                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                    <div class="tab-pane fade" id="demo-asd-tab-2">
    
                                        <!--Monthly billing-->
                                        <div class="pad-all">
                                            <p class="pad-ver text-main text-sm text-uppercase text-bold">Billing &amp; reports</p>
                                            <p>Get <strong class="text-main">$5.00</strong> off your next bill by making sure your full payment reaches us before August 5, 2018.</p>
                                        </div>
                                        <hr class="new-section-xs">
                                        <div class="pad-all">
                                            <span class="pad-ver text-main text-sm text-uppercase text-bold">Amount Due On</span>
                                            <p class="text-sm">August 17, 2018</p>
                                            <p class="text-2x text-thin text-main">$83.09</p>
                                            <button class="btn btn-block btn-success mar-top">Pay Now</button>
                                        </div>
    
    
                                        <hr>
    
                                        <p class="pad-all text-main text-sm text-uppercase text-bold">Additional Actions</p>
    
                                        <!--Simple Menu-->
                                        <div class="list-group bg-trans">
                                            <a href="#" class="list-group-item"><i class="demo-pli-information icon-lg icon-fw"></i> Service Information</a>
                                            <a href="#" class="list-group-item"><i class="demo-pli-mine icon-lg icon-fw"></i> Usage Profile</a>
                                            <a href="#" class="list-group-item"><span class="label label-info pull-right">New</span><i class="demo-pli-credit-card-2 icon-lg icon-fw"></i> Payment Options</a>
                                            <a href="#" class="list-group-item"><i class="demo-pli-support icon-lg icon-fw"></i> Message Center</a>
                                        </div>
    
    
                                        <hr>
    
                                        <div class="text-center">
                                            <div><i class="demo-pli-old-telephone icon-3x"></i></div>
                                            Questions?
                                            <p class="text-lg text-semibold text-main"> (415) 234-53454 </p>
                                            <small><em>We are here 24/7</em></small>
                                        </div>
                                    </div>
                                    <!--End second tab (Custom layout)-->
                                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    
    
                                    <!--Third tab (Settings)-->
                                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                    <div class="tab-pane fade" id="demo-asd-tab-3">
                                        <ul class="list-group bg-trans">
                                            <li class="pad-top list-header">
                                                <p class="text-main text-sm text-uppercase text-bold mar-no">Account Settings</p>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="pull-right">
                                                    <input class="toggle-switch" id="demo-switch-1" type="checkbox" checked>
                                                    <label for="demo-switch-1"></label>
                                                </div>
                                                <p class="mar-no text-main">Show my personal status</p>
                                                <small class="text-muted">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</small>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="pull-right">
                                                    <input class="toggle-switch" id="demo-switch-2" type="checkbox" checked>
                                                    <label for="demo-switch-2"></label>
                                                </div>
                                                <p class="mar-no text-main">Show offline contact</p>
                                                <small class="text-muted">Aenean commodo ligula eget dolor. Aenean massa.</small>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="pull-right">
                                                    <input class="toggle-switch" id="demo-switch-3" type="checkbox">
                                                    <label for="demo-switch-3"></label>
                                                </div>
                                                <p class="mar-no text-main">Invisible mode </p>
                                                <small class="text-muted">Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </small>
                                            </li>
                                        </ul>
    
    
                                        <hr>
    
                                        <ul class="list-group pad-btm bg-trans">
                                            <li class="list-header"><p class="text-main text-sm text-uppercase text-bold mar-no">Public Settings</p></li>
                                            <li class="list-group-item">
                                                <div class="pull-right">
                                                    <input class="toggle-switch" id="demo-switch-4" type="checkbox" checked>
                                                    <label for="demo-switch-4"></label>
                                                </div>
                                                Online status
                                            </li>
                                            <li class="list-group-item">
                                                <div class="pull-right">
                                                    <input class="toggle-switch" id="demo-switch-5" type="checkbox" checked>
                                                    <label for="demo-switch-5"></label>
                                                </div>
                                                Show offline contact
                                            </li>
                                            <li class="list-group-item">
                                                <div class="pull-right">
                                                    <input class="toggle-switch" id="demo-switch-6" type="checkbox" checked>
                                                    <label for="demo-switch-6"></label>
                                                </div>
                                                Show my device icon
                                            </li>
                                        </ul>
    
    
    
                                        <hr>
    
                                        <p class="pad-hor text-main text-sm text-uppercase text-bold mar-no">Task Progress</p>
                                        <div class="pad-all">
                                            <p class="text-main">Upgrade Progress</p>
                                            <div class="progress progress-sm">
                                                <div class="progress-bar progress-bar-success" style="width: 15%;"><span class="sr-only">15%</span></div>
                                            </div>
                                            <small>15% Completed</small>
                                        </div>
                                        <div class="pad-hor">
                                            <p class="text-main">Database</p>
                                            <div class="progress progress-sm">
                                                <div class="progress-bar progress-bar-danger" style="width: 75%;"><span class="sr-only">75%</span></div>
                                            </div>
                                            <small>17/23 Database</small>
                                        </div>
    
                                    </div>
                                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                    <!--Third tab (Settings)-->
    
                                </div>
                            </div>
                        </div>
                    </div>
                </aside>
                <!--===================================================-->
                <!--END ASIDE-->
    
                
                <!--MAIN NAVIGATION-->
                <!--===================================================-->
                <nav id="mainnav-container">
                    <div id="mainnav">
    
    
                        <!--OPTIONAL : ADD YOUR LOGO TO THE NAVIGATION-->
                        <!--It will only appear on small screen devices.-->
                        <!--================================
                        <div class="mainnav-brand">
                            <a href="index.html" class="brand">
                                <img src="img/logo.png" alt="Nifty Logo" class="brand-icon">
                                <span class="brand-text">Nifty</span>
                            </a>
                            <a href="#" class="mainnav-toggle"><i class="pci-cross pci-circle icon-lg"></i></a>
                        </div>
                        -->
    
    
    
                        <!--Menu-->
                        <!--================================-->
                        <div id="mainnav-menu-wrap">
                            <div class="nano">
                                <div class="nano-content">
    
                                    <!--Profile Widget-->
                                    <!--================================-->
                                    <div id="mainnav-profile" class="mainnav-profile">
                                        <div class="profile-wrap text-center">
                                            <div class="pad-btm">
                                                <img class="img-circle img-md" src="img/profile-photos/1.png" alt="Profile Picture">
                                            </div>
                                            <a href="#profile-nav" class="box-block" data-toggle="collapse" aria-expanded="false">
                                                <span class="pull-right dropdown-toggle">
                                                    <i class="dropdown-caret"></i>
                                                </span>
                                                <p class="mnp-name">Aaron Chavez</p>
                                                <span class="mnp-desc">aaron.cha@themeon.net</span>
                                            </a>
                                        </div>
                                        <div id="profile-nav" class="collapse list-group bg-trans">
                                            <a href="#" class="list-group-item">
                                                <i class="demo-pli-male icon-lg icon-fw"></i> View Profile
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <i class="demo-pli-gear icon-lg icon-fw"></i> Settings
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <i class="demo-pli-information icon-lg icon-fw"></i> Help
                                            </a>
                                            <a href="#" class="list-group-item">
                                                <i class="demo-pli-unlock icon-lg icon-fw"></i> Logout
                                            </a>
                                        </div>
                                    </div>
    
    
                                    <!--Shortcut buttons-->
                                    <!--================================-->
                                    <div id="mainnav-shortcut" class="hidden">
                                        <ul class="list-unstyled shortcut-wrap">
                                            <li class="col-xs-3" data-content="My Profile">
                                                <a class="shortcut-grid" href="#">
                                                    <div class="icon-wrap icon-wrap-sm icon-circle bg-mint">
                                                    <i class="demo-pli-male"></i>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="col-xs-3" data-content="Messages">
                                                <a class="shortcut-grid" href="#">
                                                    <div class="icon-wrap icon-wrap-sm icon-circle bg-warning">
                                                    <i class="demo-pli-speech-bubble-3"></i>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="col-xs-3" data-content="Activity">
                                                <a class="shortcut-grid" href="#">
                                                    <div class="icon-wrap icon-wrap-sm icon-circle bg-success">
                                                    <i class="demo-pli-thunder"></i>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="col-xs-3" data-content="Lock Screen">
                                                <a class="shortcut-grid" href="#">
                                                    <div class="icon-wrap icon-wrap-sm icon-circle bg-purple">
                                                    <i class="demo-pli-lock-2"></i>
                                                    </div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <!--================================-->
                                    <!--End shortcut buttons-->
    
    
                                    <ul id="mainnav-menu" class="list-group">
                            
                                        <!--Category name-->
                                        <li class="list-header">Navigation</li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-home"></i>
                                                <span class="menu-title">Dashboard</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="index.html">Dashboard 1</a></li>
                                                <li><a href="dashboard-2.html">Dashboard 2</a></li>
                                                <li><a href="dashboard-3.html">Dashboard 3</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li class="active-sub">
                                            <a href="#">
                                                <i class="demo-pli-split-vertical-2"></i>
                                                <span class="menu-title">Layouts</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse in">
                                                <li class="active-link"><a href="layouts-collapsed-navigation.html">Collapsed Navigation</a></li>
                                                <li><a href="layouts-offcanvas-navigation.html">Off-Canvas Navigation</a></li>
                                                <li><a href="layouts-offcanvas-slide-in-navigation.html">Slide-in Navigation</a></li>
                                                <li><a href="layouts-offcanvas-revealing-navigation.html">Revealing Navigation</a></li>
                                                <li class="list-divider"></li>
                                                <li><a href="layouts-aside-right-side.html">Aside on the right side</a></li>
                                                <li><a href="layouts-aside-left-side.html">Aside on the left side</a></li>
                                                <li><a href="layouts-aside-dark-theme.html">Dark version of aside</a></li>
                                                <li class="list-divider"></li>
                                                <li><a href="layouts-fixed-navbar.html">Fixed Navbar</a></li>
                                                <li><a href="layouts-fixed-footer.html">Fixed Footer</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="widgets.html">
                                                <i class="demo-pli-gear"></i>
                                                <span class="menu-title">
                                                    Widgets
                                                    <span class="pull-right badge badge-warning">24</span>
                                                </span>
                                            </a>
                                        </li>
                            
                                        <li class="list-divider"></li>
                            
                                        <!--Category name-->
                                        <li class="list-header">Components</li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-boot-2"></i>
                                                <span class="menu-title">UI Elements</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="ui-buttons.html">Buttons</a></li>
                                                <li><a href="ui-panels.html">Panels</a></li>
                                                <li><a href="ui-modals.html">Modals</a></li>
                                                <li><a href="ui-progress-bars.html">Progress bars</a></li>
                                                <li><a href="ui-components.html">Components</a></li>
                                                <li><a href="ui-typography.html">Typography</a></li>
                                                <li><a href="ui-list-group.html">List Group</a></li>
                                                <li><a href="ui-tabs-accordions.html">Tabs &amp; Accordions</a></li>
                                                <li><a href="ui-alerts-tooltips.html">Alerts &amp; Tooltips</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-pen-5"></i>
                                                <span class="menu-title">Forms</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="forms-general.html">General</a></li>
                                                <li><a href="forms-components.html">Advanced Components</a></li>
                                                <li><a href="forms-validation.html">Validation</a></li>
                                                <li><a href="forms-wizard.html">Wizard</a></li>
                                                <li><a href="forms-file-upload.html">File Upload</a></li>
                                                <li><a href="forms-text-editor.html">Text Editor</a></li>
                                                <li><a href="forms-markdown.html">Markdown</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-receipt-4"></i>
                                                <span class="menu-title">Tables</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="tables-static.html">Static Tables</a></li>
                                                <li><a href="tables-bootstrap.html">Bootstrap Tables</a></li>
                                                <li><a href="tables-datatable.html">Data Tables</a></li>
                                                <li><a href="tables-footable.html">Foo Tables</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-bar-chart"></i>
                                                <span class="menu-title">Charts</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="charts-morris-js.html">Morris JS</a></li>
                                                <li><a href="charts-flot-charts.html">Flot Charts</a></li>
                                                <li><a href="charts-easy-pie-charts.html">Easy Pie Charts</a></li>
                                                <li><a href="charts-sparklines.html">Sparklines</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-repair"></i>
                                                <span class="menu-title">Miscellaneous</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="misc-timeline.html">Timeline</a></li>
                                                <li><a href="misc-maps.html">Google Maps</a></li>
                                                <li><a href="xplugins-notifications.html">Notifications<span class="label label-purple pull-right">Improved</span></a></li>
                                                <li><a href="misc-nestable-list.html">Nestable List</a></li>
                                                <li><a href="misc-animate-css.html">CSS Animations</a></li>
                                                <li><a href="misc-css-loaders.html">CSS Loaders</a></li>
                                                <li><a href="misc-spinkit.html">Spinkit</a></li>
                                                <li><a href="misc-tree-view.html">Tree View</a></li>
                                                <li><a href="misc-clipboard.html">Clipboard</a></li>
                                                <li><a href="misc-x-editable.html">X-Editable</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-warning-window"></i>
                                                <span class="menu-title">Grid System</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="grid-bootstrap.html">Bootstrap Grid</a></li>
                                                <li><a href="grid-liquid-fixed.html">Liquid Fixed</a></li>
                                                <li><a href="grid-match-height.html">Match Height</a></li>
                                                <li><a href="grid-masonry.html">Masonry</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <li class="list-divider"></li>
                            
                                        <!--Category name-->
                                        <li class="list-header">More</li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-computer-secure"></i>
                                                <span class="menu-title">App Views</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="app-file-manager.html">File Manager</a></li>
                                                <li><a href="app-users.html">Users</a></li>
                                                <li><a href="app-users-2.html">Users 2</a></li>
                                                <li><a href="app-profile.html">Profile</a></li>
                                                <li><a href="app-calendar.html">Calendar</a></li>
                                                <li><a href="app-taskboard.html">Taskboard</a></li>
                                                <li><a href="app-chat.html">Chat</a></li>
                                                <li><a href="app-contact-us.html">Contact Us</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-speech-bubble-5"></i>
                                                <span class="menu-title">Blog Apps</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="blog.html">Blog</a></li>
                                                <li><a href="blog-list.html">Blog List</a></li>
                                                <li><a href="blog-list-2.html">Blog List 2</a></li>
                                                <li><a href="blog-details.html">Blog Details</a></li>
                                                <li class="list-divider"></li>
                                                <li><a href="blog-manage-posts.html">Manage Posts</a></li>
                                                <li><a href="blog-add-edit-post.html">Add Edit Post</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-mail"></i>
                                                <span class="menu-title">Email</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="mailbox.html">Inbox</a></li>
                                                <li><a href="mailbox-message.html">View Message</a></li>
                                                <li><a href="mailbox-compose.html">Compose Message</a></li>
                                                <li><a href="mailbox-templates.html">Email Templates</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-file-html"></i>
                                                <span class="menu-title">Other Pages</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="pages-blank.html">Blank Page</a></li>
                                                <li><a href="pages-invoice.html">Invoice</a></li>
                                                <li><a href="pages-search-results.html">Search Results</a></li>
                                                <li><a href="pages-faq.html">FAQ</a></li>
                                                <li><a href="pages-pricing.html">Pricing<span class="label label-success pull-right">New</span></a></li>
                                                <li class="list-divider"></li>
                                                <li><a href="pages-404-alt.html">Error 404 alt</a></li>
                                                <li><a href="pages-500-alt.html">Error 500 alt</a></li>
                                                <li class="list-divider"></li>
                                                <li><a href="pages-404.html">Error 404 </a></li>
                                                <li><a href="pages-500.html">Error 500</a></li>
                                                <li><a href="pages-maintenance.html">Maintenance</a></li>
                                                <li><a href="pages-login.html">Login</a></li>
                                                <li><a href="pages-register.html">Register</a></li>
                                                <li><a href="pages-password-reminder.html">Password Reminder</a></li>
                                                <li><a href="pages-lock-screen.html">Lock Screen</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-photo-2"></i>
                                                <span class="menu-title">Gallery</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="gallery-columns.html">Columns</a></li>
                                                <li><a href="gallery-justified.html">Justified</a></li>
                                                <li><a href="gallery-nested.html">Nested</a></li>
                                                <li><a href="gallery-grid.html">Grid</a></li>
                                                <li><a href="gallery-carousel.html">Carousel</a></li>
                                                <li class="list-divider"></li>
                                                <li><a href="gallery-slider.html">Slider</a></li>
                                                <li><a href="gallery-default-theme.html">Default Theme</a></li>
                                                <li><a href="gallery-compact-theme.html">Compact Theme</a></li>
                                                <li><a href="gallery-grid-theme.html">Grid Theme</a></li>
                                                
                                            </ul>
                                        </li>
    
    
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-tactic"></i>
                                                <span class="menu-title">Menu Level</span>
                                                <i class="arrow"></i>
                                            </a>
    
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="#">Second Level Item</a></li>
                                                <li><a href="#">Second Level Item</a></li>
                                                <li><a href="#">Second Level Item</a></li>
                                                <li class="list-divider"></li>
                                                <li>
                                                    <a href="#">Third Level<i class="arrow"></i></a>
    
                                                    <!--Submenu-->
                                                    <ul class="collapse">
                                                        <li><a href="#">Third Level Item</a></li>
                                                        <li><a href="#">Third Level Item</a></li>
                                                        <li><a href="#">Third Level Item</a></li>
                                                        <li><a href="#">Third Level Item</a></li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a href="#">Third Level<i class="arrow"></i></a>
    
                                                    <!--Submenu-->
                                                    <ul class="collapse">
                                                        <li><a href="#">Third Level Item</a></li>
                                                        <li><a href="#">Third Level Item</a></li>
                                                        <li class="list-divider"></li>
                                                        <li><a href="#">Third Level Item</a></li>
                                                        <li><a href="#">Third Level Item</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
    
                            
                                        <li class="list-divider"></li>
                            
                                        <!--Category name-->
                                        <li class="list-header">Extras</li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-happy"></i>
                                                <span class="menu-title">Icons Pack</span>
                                                <i class="arrow"></i>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="icons-ionicons.html">Ion Icons</a></li>
                                                <li><a href="icons-themify.html">Themify</a></li>
                                                <li><a href="icons-font-awesome.html">Font Awesome</a></li>
                                                <li><a href="icons-flagicons.html">Flag Icon CSS</a></li>
                                                <li><a href="icons-weather-icons.html">Weather Icons</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="#">
                                                <i class="demo-pli-medal-2"></i>
                                                <span class="menu-title">
                                                    PREMIUM ICONS
                                                    <span class="label label-danger pull-right">BEST</span>
                                                </span>
                                            </a>
                            
                                            <!--Submenu-->
                                            <ul class="collapse">
                                                <li><a href="premium-line-icons.html">Line Icons Pack</a></li>
                                                <li><a href="premium-solid-icons.html">Solid Icons Pack</a></li>
                                                
                                            </ul>
                                        </li>
                            
                                        <!--Menu list item-->
                                        <li>
                                            <a href="helper-classes.html">
                                                <i class="demo-pli-inbox-full"></i>
                                                <span class="menu-title">Helper Classes</span>
                                            </a>
                                        </li>                                </ul>
    
    
                                    <!--Widget-->
                                    <!--================================-->
                                    <div class="mainnav-widget">
    
                                        <!-- Show the button on collapsed navigation -->
                                        <div class="show-small">
                                            <a href="#" data-toggle="menu-widget" data-target="#demo-wg-server">
                                                <i class="demo-pli-monitor-2"></i>
                                            </a>
                                        </div>
    
                                        <!-- Hide the content on collapsed navigation -->
                                        <div id="demo-wg-server" class="hide-small mainnav-widget-content">
                                            <ul class="list-group">
                                                <li class="list-header pad-no mar-ver">Server Status</li>
                                                <li class="mar-btm">
                                                    <span class="label label-primary pull-right">15%</span>
                                                    <p>CPU Usage</p>
                                                    <div class="progress progress-sm">
                                                        <div class="progress-bar progress-bar-primary" style="width: 15%;">
                                                            <span class="sr-only">15%</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mar-btm">
                                                    <span class="label label-purple pull-right">75%</span>
                                                    <p>Bandwidth</p>
                                                    <div class="progress progress-sm">
                                                        <div class="progress-bar progress-bar-purple" style="width: 75%;">
                                                            <span class="sr-only">75%</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="pad-ver"><a href="#" class="btn btn-success btn-bock">View Details</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!--================================-->
                                    <!--End widget-->
    
                                </div>
                            </div>
                        </div>
                        <!--================================-->
                        <!--End menu-->
    
                    </div>
                </nav>
                <!--===================================================-->
                <!--END MAIN NAVIGATION-->
    
            </div>
    
            
    
            <!-- FOOTER -->
            <!--===================================================-->
            <footer id="footer">
    
                <!-- Visible when footer positions are fixed -->
                <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
                <div class="show-fixed pad-rgt pull-right">
                    You have <a href="#" class="text-main"><span class="badge badge-danger">3</span> pending action.</a>
                </div>
    
    
    
                <!-- Visible when footer positions are static -->
                <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
                <div class="hide-fixed pull-right pad-rgt">
                    14GB of <strong>512GB</strong> Free.
                </div>
    
    
    
                <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
                <!-- Remove the class "show-fixed" and "hide-fixed" to make the content always appears. -->
                <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
    
                <p class="pad-lft">&#0169; 2018 Your Company</p>
    
    
    
            </footer>
            <!--===================================================-->
            <!-- END FOOTER -->
    
    
            <!-- SCROLL PAGE BUTTON -->
            <!--===================================================-->
            <button class="scroll-top btn">
                <i class="pci-chevron chevron-up"></i>
            </button>
            <!--===================================================-->
        </div>
        <!--===================================================-->
        <!-- END OF CONTAINER -->
    
    
        
        
        
        <!--JAVASCRIPT-->
        <!--=================================================-->
    
        <!--jQuery [ REQUIRED ]-->
        <script src="http://localhost/gestor-web/public/js/jquery.min.js"></script>

        
        <!-- jQuery validate JavaScript -->
        <script src="http://localhost/gestor-web/public/plugins/jquery-validate/jquery-validate.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/jquery-validate/additional-methods.min.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/jquery-validate/messages_es.min.js"></script>
    
        <!--BootstrapJS [ RECOMMENDED ]-->
        <script src="http://localhost/gestor-web/public/js/bootstrap.min.js"></script>
    
    
        <!--NiftyJS [ RECOMMENDED ]-->
        <script src="http://localhost/gestor-web/public/js/nifty.min.js"></script>
    
    
    
    
        <!--=================================================-->
        
        <!--Demo script [ DEMONSTRATION ]-->
        <script src="http://localhost/gestor-web/public/js/demo/nifty-demo.min.js"></script>
    
        
        <!--Flot Chart [ OPTIONAL ]-->
        <script src="http://localhost/gestor-web/public/plugins/flot-charts/jquery.flot.min.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/flot-charts/jquery.flot.resize.min.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/flot-charts/jquery.flot.tooltip.min.js"></script>
        <!--Summernote [ OPTIONAL ]-->
        <script src="http://localhost/gestor-web/public/plugins/summernote/summernote.min.js"></script>
    
    
        <!--Sparkline [ OPTIONAL ]-->
        <script src="http://localhost/gestor-web/public/plugins/sparkline/jquery.sparkline.min.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/fancybox/jquery.fancybox.min.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/bootbox/bootbox.min.js"></script>

        <!--DataTables [ OPTIONAL ]-->
        <script src="http://localhost/gestor-web/public/plugins/datatables/media/js/jquery.dataTables.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/datatables/media/js/dataTables.bootstrap.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js"></script>
        <!--Chosen [ OPTIONAL ]-->
        <script src="http://localhost/gestor-web/public/plugins/chosen/chosen.jquery.min.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/chosen/chosenIcon.jquery.js"></script>
        <!--Switchery [ OPTIONAL ]-->
        <script src="http://localhost/gestor-web/public/plugins/switchery/switchery.min.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/framework/framework.js"></script>
        <script src="http://localhost/gestor-web/public/plugins/framework/plugins.js"></script>
        
            <script>

        $(function() {
            $(".buscar").keyup(function(){
                var loading = frameworkApp.setLoading();
                var text = $(this).val().toUpperCase();
                $('#iconosLista .col-sm-6').show();
                if(text!=''){
                    var tableRow = $("#iconosLista span").filter(function () {
                        var txtCelda = $(this).text().toUpperCase();
                        var n = txtCelda.indexOf(text);
                        return (n!=-1);
                    });
                    console.log(tableRow);
                    $('#iconosLista .col-sm-6').not(tableRow.parents('.col-sm-6')).hide();
                }
                loading.remove();
            });
        });
        var rowSelection = $('#demo-dt-selection').DataTable({
        "responsive": true,
        "bSort" : false,
        "language": {
            "paginate": {
              "previous": '<i class="demo-psi-arrow-left"></i>',
              "next": '<i class="demo-psi-arrow-right"></i>'
                }
            }
        });

    $('#demo-dt-selection').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            rowSelection.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
    
    
    $('.colorSeleccionar').on( 'click', function () {
        $("#previewIcono").find('button').attr("class",$(this).data("clase"));
        $("#color").val($(this).data("color"));
    });
    
    $('#class_icon').on('change', function () {
        console.log($(this));
        $("#previewIcono").find('i').attr("class",$(this).find("option:selected" ).data("icon"));
    });
    $('.demo-icon').on('dblclick', function () {
        //alert($(this).data("icon"));
        $('#class_icon').val($(this).data("icon"));
        $('#class_icon').trigger("liszt:updated");
        $('#class_icon').trigger("chosen:updated");
        $("#previewIcono").find('i').attr("class",$('#class_icon').find("option:selected" ).data("icon"));
        $("#demo-lg-modal").modal('hide');
    });
    $('.nombre-menu').on('keyup', function () {
        if($(this).val()!=''){
            $("#previewIcono").find('span').html("<strong>"+$(this).val()+"</strong>");
        }else{
            $("#previewIcono").find('span').html("<strong>Texto</strong>");
        }
    });
    
    $('#imagen').on('change', function () {
        if($(this).val()==2){
            $("#divImagen").hide();
            $("#divIcono").show();
            if($("#class_icon").val()==''){
                $("#previewIcono").find('i').attr("class","");
            }else{
                $("#previewIcono").find('i').attr("class",$("#class_icon").find("option:selected" ).data("icon"));
            }
        }else{
            $("#previewIcono").find('i').attr("class","fa fa-image fa-2x");
            $("#divIcono").hide();
            $("#divImagen").show();
        }
    });
    
    
    // SWITCHERY - CHECKED BY DEFAULT
    // =================================================================
    // Require Switchery
    // http://abpetkov.github.io/switchery/
    // =================================================================
    new Switchery(document.getElementById('demo-sw-checked'));
    $("#agregarMenu").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            var loading = frameworkApp.setLoading();
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                dataType: 'json',
                type:'POST',
                url: 'http://localhost/gestor-web/public/menus/crear-menus',
                data: new FormData($("#agregarMenu")[0]),
                processData: false,
                contentType: false,
                id_container_body: false,
                success: function(data) {
                    loading.remove();
                    $('#tablaContenedor').html(data.tablaMenu);
                    bootbox.alert("¡Menu creado con exito!");
                    $("#agregarMenu")[0].reset();
                    $('#agregarMenu .chosen').val('');
                    $('#demo-dt-selection').DataTable({
                        "responsive": true,
                        "bSort" : false,
                        "language": {
                            "paginate": {
                            "previous": '<i class="demo-psi-arrow-left"></i>',
                            "next": '<i class="demo-psi-arrow-right"></i>'
                            }
                        }
                    });
                },
                error: function(obj, typeError, text, data) {
                    bootbox.alert("general.error_transaccion");
                }
            });
            return false;
        },
        rules: {
            nombre: 'required',
            id_menu_padre: 'required',
            url: 'required',
            class_icon: {
                required: function () {
                    return (($("#imagen").val() == 1) ? false : true);
                },
            },
            file: {
                required: function () {
                    return (($("#imagen").val() == 2) ? false : true);
                },
            },
        },
        highlight: function (element, errorClass) {
          $(element).parents('.form-group').addClass('has-feedback has-error');
          $(element).parents('.form-group').removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parents('.form-group').removeClass('has-feedback has-error');
          $(element).parents('.form-group').addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.form-group').find('.chosen-container'));
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });


    function consultarMenu(idMenu){
        frameworkApp.setLoadData({
            url: 'http://localhost/gestor-web/public/colegios/detalle-movimientos',
            data: {
                id_colegio: options.id_colegio, anualidad: options.anualidad
            },
            id_container_body: false,
            success: function(data) {
                $("#detalleModalBody").html(data.html);
                $("#exampleModal").modal('show');
            }
        });
    }
    </script>
    
        <!--Specify page [ SAMPLE ]-->
        
    
        
    
    </body>
</html>