@extends('layouts.login')
@section('content')
<!-- BEGIN login-brand -->
<!-- END login-brand -->
<h3 class="m-b-20"><span>Afainversiones</span></h3>
<!-- BEGIN login-desc -->
<div class="login-desc m-b-30">
	la oportunidad de crecer juntos
</div>
<!-- END login-desc -->
<!-- BEGIN login-form -->
<form method="post" class="form-horizontal form-material" id="loginForm" action="{{ route('login') }}">
	{{ csrf_field() }}
	<div class="form-group">
		<label>Usuario <span class="text-danger">*</span></label>
		<input type="text" class="form-control{{ $errors->has('username') ? ' is-invalid' : '' }}" name="username" value="{{ old('username') }}" autofocus placeholder="{{ trans('auth.username') }}" autocomplete="off">
		@if ($errors->has('username'))
			<span class="invalid-feedback">
				<strong>{{ $errors->first('username') }}</strong>
			</span>
		@endif
	</div>
	<div class="form-group">
		<label>Contraseña <span class="text-danger">*</span></label>
		<input type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" placeholder="{{ trans('auth.password') }}" autocomplete="off">
		@if ($errors->has('password'))
			<span class="invalid-feedback">
				<strong>{{ $errors->first('password') }}</strong>
			</span>
		@endif
	</div>
	<div class="d-flex align-items-center">
		<button type="submit" class="btn btn-primary width-150 btn-rounded">Iniciar Sesion</button>
	</div>
</form>
<!-- END login-form -->
<div class="login-desc m-t-30">
	¿Desea trabajar con nosotros? Más información <a  href="https://api.whatsapp.com/send?phone=573205624402&text=Me%20interesaría%20trabajar%20con%20ustedes" target="_blank">aquí</a>.
</div>
@endsection
@section('content2')
        <!-- LOGIN FORM -->
		<!--===================================================-->
		<div class="cls-content">
		    <div class="cls-content-sm panel">
		        <div class="panel-body">
		            <div class="mar-ver pad-btm">
                        <h1 class="h3">Wifi Neighbor</h1>
		                <p>{{trans("general.inicio_sesion_subtitle")}}</p>
		            </div>
		            <form method="post" class="form-horizontal form-material" id="loginForm" action="{{ route('login') }}">
                        {{ csrf_field() }}
                        <div class="form-group">
		                    <input type="text" class="form-control{{ $errors->has('username') ? ' is-invalid' : '' }}" name="username" value="{{ old('username') }}" autofocus placeholder="{{ trans('auth.username') }}" autocomplete="off">
                            @if ($errors->has('username'))
                                <span class="invalid-feedback">
                                    <strong>{{ $errors->first('username') }}</strong>
                                </span>
                            @endif
		                </div>
		                <div class="form-group">
                            ccccccccc
                        </div>
                        <hr>
		                <button class="btn btn-primary btn-lg btn-block" type="submit">{{trans("general.inicio_sesion_btn")}}</button>
		            </form>
		        </div>
		
		        <div class="pad-all">
		            <div class="media pad-top bord-top">
		                <div class="media-body text-left text-bold text-main">
                            {{trans("general.copyright")}}
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!--===================================================-->
@endsection