@extends('layouts.blank')
@php
    use App\Enums\ESiNo;
@endphp
@section('content')
    <div class="login-register" >
        <div class="login-box card">
            <div class="card-body">
                {!! Form::model($usuario,['route' => ['usuarios.cambiar-password', $usuario->id_usuario], 'method' => 'PUT', 'id' => 'frmChangePassword']) !!}
                    <h3 class="box-title m-b-20">{{ trans('auth.cambiar_password_tittle') }}</h3>
                    <h6 class="card-subtitle text-justify">@if($usuario->acceso_inicial==ESiNo::index(ESiNo::Si)->getId()){{ trans('auth.cambiar_password_tutorial') }}<hr class="m-t-5 m-b-5">@endif<span class="text-danger m-t-20">{{ trans('auth.password_debil') }}</span><hr class="m-t-5 m-b-5"></h6>
                    <div class="form-group m-t-20">
                        <div class="col-xs-12">
                            <input type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" id="password" placeholder="{{ trans('auth.nueva_password') }}">
                                @if ($errors->has('password'))
                                <span class="invalid-feedback">
                                    <strong>{{ $errors->first('password') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="passwordConfirm" id="passwordConfirm" placeholder="{{ trans('auth.conf_nueva_password') }}">
                             @if ($errors->has('password'))
                                <span class="invalid-feedback">
                                    <strong>{{ $errors->first('password') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group text-center m-t-40">
                        <div class="col-xs-12">
                            <button class="btn btn-info btn-md btn-block text-uppercase waves-effect waves-light" type="submit">{{ trans('auth.cambiar_password_tittle') }}</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection
@section('scripts')
	<script type="text/javascript">
        $(function(){
            	$("#frmChangePassword").validate({
        			errorClass: "text-danger form-error-label",
                    successClass: "text-success", 
                    errorElement : "small",
                    highlight: function (element, errorClass) {
                    	$(element).addClass('is-invalid');
                        $(element).removeClass(errorClass)
                    },
                    unhighlight: function (element, errorClass) {
                    	$(element).removeClass('is-invalid');
                        $(element).removeClass(errorClass)
                    },
        			submitHandler: function(form) {
        				if(validarPassword($("#password").val())){
                            form.submit();
                        }
        			},
                    rules: {
                        password: {required: true, minlength: 8},
                        passwordConfirm: {
                            equalTo: "#password"
                        }
                    },
        			errorPlacement: function(error, element) {
        				if(element.parents('.i-checks').length > 0) {
        					error.insertAfter(element.parents('.i-checks'));
        				}else if(element.parents('.input-group').length > 0) {
        			    	error.insertAfter(element.parents('.input-group'));
        			    } else {
        			        error.insertAfter(element);
        			    }
        			}
        		});
        });
        
    	function validarPassword(pswd){
            if (pswd.match(/[A-z]/) && pswd.match(/\d/) && pswd.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) {
                return true;
            }else{
                frameworkApp.setAlert('{{ trans("auth.password_debil") }}');
                return false;
            }
            
        }
    </script>
@endsection