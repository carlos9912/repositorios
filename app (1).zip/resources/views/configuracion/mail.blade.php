
<h1>{{$nombre}} Bienvenido a AFAInversiones - Giros</h1>
Su cuenta se ha creado de manera exitosa. Su contraseña de acceso es {{$password}}, recuerde realizar el cambio una vez incie sesión por primera vez