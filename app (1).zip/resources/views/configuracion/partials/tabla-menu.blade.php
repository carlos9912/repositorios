<div class="table-responsive">
                            
        <table id="demo-dt-selection" class="table table-striped table-vcenter" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th class="text-center"></th>
                    <th>{{trans('menus.menu_nombre')}}</th>
                    <th class="text-center">{{trans('menus.menu_estado')}}</th>
                    <th class="text-center">{{trans('menus.menu_acciones')}}</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($listMenus as $menu)
                    <tr>
                        <td class="text-center">
                            <button class="btn btn-{{$menu->color}} btn-icon btn-circle">
                                @if($menu->imagen==App\Enums\EIcono::index(App\Enums\EIcono::No)->getId())
                                    <i class="{{$menu->class_icon}}"></i>
                                @elseif($menu->imagen==App\Enums\EIcono::index(App\Enums\EIcono::Si)->getId())
                                    <img src="{{url("/storage/menu/".$menu->class_icon)}}" alt="">
                                @else

                                @endif
                            </button>
                        </td>
                        <td class="text-left">
                            {{$menu->nombre}}
                        </td>
                        <td class="text-center">
                            @if($menu->activo==App\Enums\ESiNo::index(App\Enums\ESiNo::Si)->getId())
                                <div class="label label-table label-success">Activo</div>
                            @else
                                <div class="label label-table label-danger">Inactivo</div>
                            @endif
                        </td>
                        <td class="min-width">
                            <div class="btn-groups">
                                <a href="#" class="btn btn-icon demo-pli-pen-5 icon-lg add-tooltip" data-original-title="Edit Post" data-container="body" onclick="consultarMenu({{$menu->id_menu}})"></a>
                                <a href="#" class="btn btn-icon demo-pli-file-text-image icon-lg add-tooltip" data-original-title="Remove" data-container="body" onclick="consultarMenuOrden({{$menu->id_menu}});"></a>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>