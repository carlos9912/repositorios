
@php

    use App\Models\Estudiante;
    use Carbon\Carbon;
    use Illuminate\Support\Arr;
    use App\Enums\ETipoDocumento;

    $pendientes = 0;
    
@endphp

    

    
            <div class="modal-content">
                <div class="modal-body">
                    <!-- begin panel -->
					<div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                            <!-- begin panel-heading -->
                            <div class="panel-heading">
                                <div class="panel-heading-btn">
                                </div>
                                <h4 class="panel-title">Creación de Tarifas</h4>
                            </div>
                            <!-- end panel-heading -->
                            <!-- begin panel-body -->
                            <div class="panel-body">
                                    {{Form::open(['route' => 'tarifas.crear-tarifa', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarAsignatura']) }}  
                                        {!! Form::hidden('codtarifa', $tarifa->codtarifa) !!}
                                        
                                        <legend class="m-b-15">Monto</legend>
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-2">Valor Inicial</label>
                                            <div class="col-md-4">
                                                {!! Form::text('valor_inicial', $tarifa->valor_inicial, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'valor_inicial' ]) !!}
                                            </div>
                                            <label class="col-form-label col-md-2">Valor Final</label>
                                            <div class="col-md-4">
                                                {!! Form::text('valor_final', $tarifa->valor_final, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'valor_final' ]) !!}
                                            </div>
                                        </div>
                                        
                                        <div class="alert alert-primary fade show m-b-10">
                                            <small>Si el valor es fijo debe especificarlo unicamente en la caja de <b>costo</b> Ej: 3,500
                                            <br>Si el valor es una parte fija y un porcentual del monto debe especificar el <b>costo</b> y el <b>porcentaje</b> correspondiente Ej: $2,00 + 2.5%
                                            <br>Si el valor es un porcentual del monto debe especificar unicamente en la caja de <b>porcentaje</b> Ej: 2.5%</small>
                                        </div>
                                        <hr>
                                        <legend class="m-b-15">Valor Giro</legend>
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-2">Costo Fijo</label>
                                            <div class="col-md-4">
                                                {!! Form::text('costo', $tarifa->costo, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'costo' ]) !!}
                                            </div>
                                            <label class="col-form-label col-md-2">Porcentaje</label>
                                            <div class="col-md-4">
                                                {!! Form::text('porcentaje', $tarifa->porcentaje, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'porcentaje' ]) !!}
                                            </div>
                                        </div>
                                        <legend class="m-b-15">Iva Giro</legend>
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-2">Costo Fijo</label>
                                            <div class="col-md-4">
                                                {!! Form::text('iva_costo', $tarifa->iva_costo, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'costo' ]) !!}
                                            </div>
                                            <label class="col-form-label col-md-2">Porcentaje</label>
                                            <div class="col-md-4">
                                                {!! Form::text('iva_porcentaje', $tarifa->iva_porcentaje, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'porcentaje' ]) !!}
                                            </div>
                                        </div>
                                        <legend class="m-b-15">Ganancia de quien envía el giro?</legend>
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-2">Valor fijo</label>
                                            <div class="col-md-4">
                                                {!! Form::text('costo_envia', $tarifa->costo_envia, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'costo_envia' ]) !!}
                                            </div>
                                            <label class="col-form-label col-md-2">Porcentaje</label>
                                            <div class="col-md-4">
                                                {!! Form::text('porcentaje_envia', $tarifa->porcentaje_envia, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'porcentaje_envia' ]) !!}
                                            </div>
                                        </div>
                                        <legend class="m-b-15">Ganancia de quien paga el giro?</legend>
                                        <div class="form-group row m-b-15">
                                            <label class="col-form-label col-md-2">Valor fijo</label>
                                            <div class="col-md-4">
                                                {!! Form::text('costo_paga', $tarifa->costo_paga, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'costo_paga' ]) !!}
                                            </div>
                                            <label class="col-form-label col-md-2">Porcentaje</label>
                                            <div class="col-md-4">
                                                {!! Form::text('porcentaje_paga', $tarifa->porcentaje_paga, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'porcentaje_paga' ]) !!}
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row m-b-15">
                                        </div>
                                        <div class="form-group">
                                            <button class="btn btn-primary" type="submit">Guardar tarifa</button>
                                        </div>
                                                
                                    {{Form::close()}}
                            </div>
                            <!-- end panel-body -->
                        </div>
                        <!-- end panel -->
                </div>
            </div>

<script>
    
    //$('.datepicker').datepicker();
    $("#agregarAsignatura").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            form.submit();
            return false;
        },
        rules: {
            valor_inicial: {
                required: true,
                number: true,
                min: 5000,
                max: function () { return ($('#valor_final').val()=='') ? 100000000 : Number($('#valor_final').val()) - 1; }
            },
            valor_final: {
                required: true,
                number: true,
                min: function () { return ($('#valor_inicial').val()=='') ? 100000000 : Number($('#valor_inicial').val()) + 1; }
            },
            costo: {
                required: function () { return ($('#porcentaje').val()=='') ? true : false; }

            },
            porcentaje: {
                required: function () { return ($('#costo').val()=='') ? true : false; }

            },
            costo_envia: {
                required: function () { return ($('#porcentaje_envia').val()=='') ? true : false; }

            },
            porcentaje_envia: {
                required: function () { return ($('#costo_envia').val()=='') ? true : false; }

            },
            costo_paga: {
                required: function () { return ($('#porcentaje_paga').val()=='') ? true : false; }

            },
            porcentaje_paga: {
                required: function () { return ($('#costo_paga').val()=='') ? true : false; }

            },
        },
        highlight: function (element, errorClass) {
          $(element).parent().addClass('has-feedback has-error');
          $(element).parent().removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parent().removeClass('has-feedback has-error');
          $(element).parent().addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.hasClass("no-label")){

            } else if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
</script>
    