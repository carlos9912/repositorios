

@extends('layouts.administrador')
@section('title', trans('general.title_crear_pagina'))
@section('titulo-pagina')
    <div id="page-title">
        <h1 class="page-header text-overflow">{{trans('menus.menu_plural')}}</h1>
    </div>    
@endsection
@section('content')
<div class="panel">
    <div class="panel-body">
        <div id="demo-tabs2-box-1" class="tab-pane fade active in">
            {{Form::open(['route' => 'menus.crear-menu', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarMenu']) }}  
                {!! Form::hidden('id_menu', null, ['id' => 'id_menu' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off' ]) !!}
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="control-label">{{trans('configuracion.nombre_principal')}}</label>
                                {!! Form::text('nombre_principal', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="control-label">{{trans('menus.menu_padre')}}</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="control-label">{{trans('menus.menu_target')}}</label>
                                <div class="radio">
                                    {!! Form::select("target", App\Enums\ETarget::items(), null, ["id"=>"target", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => trans("menus.placeholder_menu_seleccione_target"),"required" => "required"]) !!}
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="control-label">{{trans('menus.menu_icono')}}</label>
                                <div class="radio">
                                    {!! Form::select("imagen", ["400"=>400,"350"=>350,"300"=>300], null, ["class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => trans("menus.placeholder_menu_seleccione_altura"), "required" => "required", 'id' => 'imagen']) !!}
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row" id="btnCrear">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <button class="btn btn-mint" type="submit">{{trans('botones.guardar')}}</button>
                            </div>
                        </div>
                    </div>
                    <div class="row" id="btnEditar" style="display: none;">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit">{{trans('botones.editar')}}</button>
                                <button class="btn btn-danger" type="button" onclick="limpiarFormulario()">{{trans('botones.cancelar')}}</button>
                            </div>
                        </div>
                    </div>
                </div>
            {{Form::close()}}
        </div>
    </div>
</div>
@endsection