

@php



use App\Models\Estudiante;

use Carbon\Carbon;

use Illuminate\Support\Arr;

use App\Enums\ETipoDocumento;



$pendientes = 0;



@endphp

@extends('layouts.administrador')

@section('title', 'Tarifas')

@section('breadcum')

<ol class="breadcrumb">

    <li><a href="#"><i class="demo-pli-home"></i></a></li>

    <li class="active">Administrador tarifas</li>

</ol>

@endsection

@section('content')

<div class="panel panel-primary">

    <div class="panel-heading ui-sortable-handle">

        <div class="btn-group pull-right">

            <button type="button" class="btn btn-success btn-sm abrir-modal" >Crear tarifa</button>

        </div>

        <h4 class="panel-title">Administrar Sucursales</h4>

    </div>

    <div class="panel-body">

        <div class="col-md-12">

                <div class="panel">

                    <!--===================================================-->

                    <div class="panel-body">

                        <div class="table-responsive">

                            <table class="table table-vcenter mar-top">

                                <thead>

                                    <tr>

                                        <th class="text-center" style="width: 5%;">Codigo</th>

                                        <th class="min-w-td text-right">Monto</th>

                                        <th class="min-w-td text-right">Valor<br>Giron</th>

                                        <th class="text-right">Iva</th>

                                        <th class="text-right">Ganancia<br>Giros</th>

                                        <th class="text-right">Ganancia<br>Retiros</th>

                                        <th></th>

                                    </tr>

                                </thead>

                                <tbody>

                                @php

                                    $secuencia = 0;

                                @endphp

                                    @foreach(DB::table('tarifas')->orderBy('valor_inicial','asc')->get() as $tarifas)

                                        @php

                                            $secuencia++;

                                        @endphp

                                        <tr id="tr-{{$tarifas->codtarifa}}">

                                            <td>

                                                TAR-{{str_pad($tarifas->codtarifa, 4, "0",STR_PAD_LEFT)}}

                                            </td>

                                            <td class="text-right">

                                                $ {{number_format($tarifas->valor_inicial,0)}} - $ {{number_format($tarifas->valor_final,0)}}

                                            </td>

                                            <td class="text-right">

                                                $ {{number_format($tarifas->costo,0)}} {{$tarifas->porcentaje>0 ? ' + '.$tarifas->porcentaje.'%' : ''}}

                                            </td>

                                            <td class="text-right">

                                                19%

                                            </td>

                                            <td class="text-right">

                                                $ {{number_format($tarifas->costo_envia,0)}} {{$tarifas->porcentaje_envia>0 ? '+'.$tarifas->porcentaje_envia.'%' : ''}}

                                            </td>

                                            <td class="text-right">

                                                $ {{number_format($tarifas->costo_paga,0)}} {{$tarifas->porcentaje_paga>0 ? '+'.$tarifas->porcentaje_paga.'%' : ''}}

                                            </td>

                                            <td class="text-center mar-rgt" style="width: 5%;">

                                                <div class="btn-group">

                                                    <a class="btn btn-sm btn-primary btn-hover-success fa fa-edit text-white abrir-modal" data-codtarifa="{{$tarifas->codtarifa}}"></a>

                                                    <a class="btn btn-sm btn-danger btn-hover-success fa fa-trash text-white add-tooltip eliminar-sucursal" data-codtarifa="{{$tarifas->codtarifa}}"></a>

                                                </div>

                                            </td>

                                        </tr>

                                    @endforeach

                                    

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </div>

    </div>

</div>





<div id="demo-lg-modal" class="modal fade" tabindex="-1">

    <div class="modal-dialog modal-lg" id="form-modal">

        

    </div>

</div>

@endsection

@section('script')

<script>

$(function(){

    
    var handleDataTableButtons=function(){"use strict";0!==$("table").length&&$("table").DataTable(
    {
        "aaSorting": [],
        dom:"Bfrtip",
        buttons:[
            {extend:"copy",className:"btn-sm"},
            {extend:"excel",className:"btn-sm"},
            {extend:"pdf",className:"btn-sm"},
            {extend:"print",className:"btn-sm"}
            ],
            responsive:!0
        
    }
    )},
    TableManageButtons=function(){"use strict";return{init:function(){handleDataTableButtons()}}}();
TableManageButtons.init();

});

$('.abrir-modal').click(function(){

var codtarifa = $(this).data("codtarifa");

$.ajax({

    url: "{{ url('tarifas/consultar-form') }}",

    headers: {

        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

    },

    type: 'post',

    data: {

        codtarifa: codtarifa

    },

    success: function(result){

        console.log(0);

        $("#demo-lg-modal").modal("show");  

        $('#form-modal').html(result.formulario);

    }

});

});

$('.abrir-modal-empleados').click(function(){

var codsucursal = $(this).data("codsucursal");

$.ajax({

    url: "{{ url('sucursal/consultar-empleados') }}",

    headers: {

        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

    },

    type: 'post',

    data: {

        codsucursal: codsucursal

    },

    success: function(result){

        console.log(0);

        $("#demo-lg-modal").modal("show");

        $('#form-modal').html(result.formulario);

    }

});

});

$('.eliminar-sucursal').click(function(){

    var codtarifa = $(this).data("codtarifa");

    var trPadre = $("#tr-"+codtarifa);

    console.log(trPadre);

    bootbox.confirm({

        message: '<strong>Mensaje de confirmación:</strong> <br><br>¿Esta seguro de eliminar la tarifa?',

        closeButton: false,

        buttons: {

            confirm: {

                label: 'Aceptar',

                className: 'btn-success'

            },

            cancel: {

                label: 'Cancelar',

                className: 'btn-danger'

            }

        },

        callback: function (result) {

            if (result) {

                $.ajax({

                    url: "{{ url('tarifas/eliminar') }}",

                    headers: {

                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

                    },

                    type: 'post',

                    data: {

                        codtarifa: codtarifa

                    },

                    success: function(result){

                        $.gritter.add({title:"Operación realizada con éxito",text:"El registro fue eliminado con éxito"});

                        

                        $('table').DataTable().destroy();

                        trPadre.remove();

                        $('table').DataTable({

                            "aaSorting": []

                        });

                    }

                });

            }

        }

    });



});









</script>



@endsection