
<h1>{{$nombre}}, hemos recibido su solicitud</h1><br>
Su nueva contraseña de acceso es {{$password}}, recuerde realizar el cambio una vez incie sesión.