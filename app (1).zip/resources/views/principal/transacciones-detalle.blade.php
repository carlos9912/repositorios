@php
	use Carbon\Carbon;
	use App\Enums\EEstadoVinculacion;
	use App\Enums\ETipoDocumento;
	use App\Models\Apertura;
	use App\Models\Empleado;
	use App\Models\Sucursal;
	use App\Models\Horario;

	$date = Carbon::now();

$dia = $date->format('w');
$hora = $date->format('d/m/y H:i');
$sucursal = Sucursal::find(session('sucursal')->codsucursal);
$horario = $sucursal->horarios()->first();
$horario = $sucursal->horarios()->first();
$horario = blank($horario) ? new Horario() : $horario;
$apertura = $sucursal->aperturas()->orderBy('codrel','desc')->first();
$apertura = blank($apertura) ? new Apertura() : $apertura;
$valido = false;
$validar_apertura = !blank($apertura->fecha)&&$date->format('d/m/y')==Carbon::parse($apertura->fecha)->format('d/m/y') ? true : false;
//dd($validar_apertura);
//dd(request());

if($dia==0){
	
}else if($dia==5){

}else{
	if($horario->jornada_continua_lv==1){
		$rangos = explode(' - ', $horario->horario_c_lv);
	}else{
		/*$mañana = explode(' - ', $horario->horario_m_lv);
		$mañanaPrimero = explode(' ', $mañana[0]);
		$mañanaSegundo = explode(" ", $mañana[1]);
		$mañanaPrimeroP = Carbon::parse($mañanaPrimero[0]);
		if($mañanaPrimero[1]=='pm.'){
			$mañanaPrimeroP->addHours(12);
		}
		$mañanaSegundoP = Carbon::parse($mañanaSegundo[0]);
		if($mañanaSegundo[1]=='pm.'){
			$mañanaSegundoP->addHours(12);
		}

		$tarde = explode(' - ', $horario->horario_t_lv);
		$tardePrimero = explode(" ", $tarde[0]);
		$tardeSegundo = explode(" ", $tarde[1]);
		$tardePrimeroP = Carbon::parse($tardePrimero[0]);
		if($tardePrimero[1]=='pm.'){
			$tardePrimeroP->addHours(12);
		}
		$tardeSegundoP = Carbon::parse($tardeSegundo[0]);
		if($tardeSegundo[1]=='pm.'){
			$tardeSegundoP->addHours(12);
		}
		if($hora->min($mañanaPrimeroP->format('H:i'))&&$hora<$mañanaSegundoP->format('H:i')){
			$valido = true;
		}else if($hora>$tardePrimeroP->format('H:i')&&$hora<$tardeSegundoP->format('H:i')){
			$valido = true;
		}*/
	}
}
@endphp
	@section('content')
		<style>
			.modal-title{
				text-align: center;
			}
			.modal-header button{
				display: none!important;
			}
			.bootbox-input{

			}
		</style>
		
		{{Form::open(['route' => 'sucursal.abrir-caja', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'abrirCaja']) }} 
			<input type="hidden" name="codcaja" value="{{$apertura->estado==1 ? $apertura->codrel : ''}}"> 
			<div class="row">
				<!-- begin col-3 -->
				@if($apertura->estado==1&&$validar_apertura)
				<div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-green">
						<div class="stats-icon"><i class="fa fa-desktop"></i></div>
						<div class="stats-info">
							<h4>CAJA ABIERTA</h4>
							<h4>Una vez haya finalizado operaciones debe realizar el cierre de la caja</h4>	
						</div>
						<div class="stats-link">
							<a class="btn-caja">Cerrar la caja <i class="fa fa-arrow-alt-circle-right"></i></a>
						</div>
					</div>
				</div>
				@elseif($apertura->estado==2&&$validar_apertura)
				<div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-red">
						<div class="stats-icon"><i class="fa fa-desktop"></i></div>
						<div class="stats-info">
							<h4>CAJA CERRADA</h4>
							<h4>La caja del día se encuentra cerra y no es posible realizar mas operaciones con la caja cerrada</h4>	
						</div>
						<div class="stats-link">
							<a href="#modal-without-animation" data-toggle="modal">Ver detalles <i class="fa fa-arrow-alt-circle-right"></i></a>
                            <div class="modal" id="modal-without-animation">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Detalle de cierre</h4>
                                        </div>
                                        <div class="modal-body">
                                            <table class="table text-dark">
                                                <thead>
                                                    <tr>
                                                        <td>Usuario</td>
                                                        <td>Fecha</td>
                                                    </tr>
                                                </thead>
                                                <tbody class="">
													<tr>
														<td class="text-left">
														@php
															$empleado = Empleado::find($apertura->empleado_registra);
															echo $empleado->nombreCompleto();
														@endphp
														</td>
														<td>{{($apertura->fecha)}}</td>
													</tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Cerrar</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
						</div>
					</div>
				</div>
				@else
				<div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-red">
						<div class="stats-icon"><i class="fa fa-desktop"></i></div>
						<div class="stats-info">
							<h4>CAJA CERRADA</h4>
							<h4>Para iniciar operaciones es necesario realizar la apertura de la caja</h4>	
						</div>
						<div class="stats-link">
							<a class="btn-caja">Realizar apertura <i class="fa fa-arrow-alt-circle-right"></i></a>
						</div>
					</div>
				</div>
				@endif
				<!-- end col-3 -->
				<!-- begin col-3 -->
				<div class="col-lg-3 col-md-6">
					<div class="widget widget-stats bg-orange">
						<div class="stats-icon"><i class="fa fa-dollar-sign"></i></div>
						<div class="stats-info">
							<h4>Saldo a consignar</h4>
							<p style="margin-bottom: -6px;">$ {{number_format($sucursal->saldo)}} </p>	
						</div>
						<div class="stats-link">
							<a href="{{route('sucursal.estado-cuenta',[$sucursal->codsucursal])}}">Ver estado de cuenta <i class="fa fa-arrow-alt-circle-right"></i></a>
						</div>
					</div>
				</div>
				<!-- end col-3 -->
			</div>
		{{Form::close()}}
		
		
		<script>
			$('.btn-caja').click(function(){
				bootbox.confirm({
					@if($apertura->estado==1&&$validar_apertura)
					message: "<br>La caja se encuentra abierta<br><br><b>¿Desea cerrar la caja y finalizar operaciones?<br>NO PODRA VOLVER A REALIZAR OPERACIONES UNA VEZ FINALICE!</b>",
					@else
					message: "<br>La caja se encuentra cerrada<br><br><b>¿Desea abrir la caja e iniciar operaciones?</b>",
					@endif
					buttons: {
						cancel: {
							label: 'Cancelar',
							className: 'btn-danger'
						},
						confirm: {
							@if($apertura->estado==1&&$validar_apertura)
							label: 'Cerrar caja',
							@else
							label: 'Abrir caja',
							@endif
							
							className: 'btn-success'
						}
					},
					callback: function (result) {
						if(result){
							$("#abrirCaja").submit();
						}
					}
				});
			});
		</script>

