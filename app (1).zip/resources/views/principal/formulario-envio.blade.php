@php

	use Carbon\Carbon;
	use App\Enums\EEstadoVinculacion;
    use App\Enums\ETipoDocumento;

@endphp

<style>
    .widget-list-item .widget-list-title {
        font-size: 16px;
        line-height: 16px;
        margin: 0;
    }
</style>

    {{Form::open(['route' => 'clientes.enviar-giro', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'agregarAsignatura']) }}  

        {!! Form::hidden('valor_tarifa', 0,['id'=>'valor_tarifa']) !!}
        {!! Form::hidden('valor_cambio', 0,['id'=>'valor_cambio']) !!}
        {!! Form::hidden('valor_giro', 0,['id'=>'valor_giro']) !!}
        {!! Form::hidden('identificacion',$cliente->identificacion)!!}
        
        <div class="row">
            <div class="col-lg-4 p-0" style="border-right: 1px solid black">
                <div class="panel panel-inverse p-0">
                    <div class="panel-heading">
                        Detalle Transacción
                    </div>
                    <div class="panel-body" >
                        <!-- begin panel -->
                        <div id="datos-envia">
                            <div class="widget-list-action">
                                <a class="widget-card widget-card-rounded mb-0" data-id="widget" href="#modal-without-animation" data-toggle="modal">
                                    <div class="widget-card-cover"></div>
                                    <div class="widget-card-content">
                                        <h5 class="f-s-12 text-black-transparent-7" data-id="widget-elm" data-light-class="f-s-12 text-black-transparent-7" data-dark-class="f-s-12 text-white-transparent-7"><b>Información Remitente</b></h5>
                                        <h4 class="m-b-10"><b>{{$cliente->nombreCompleto()}}</b></h4>
                                        <h6 class="m-b-10"><b>Celular: {{$cliente->celular}}</b></h6>
                                        <h6><b></b></h6>
                                    </div>
                                    
                                </a>

                                <div class="modal" id="modal-without-animation">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Historial de giros</h4>
                                            </div>
                                            <div class="modal-body">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <td  class="text-left">Nombres</td>
                                                            <td>Valor</td>
                                                            <td>Fecha</td>
                                                            <td>Estado</td>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach(DB::table('movimientos AS m')->leftjoin('clientes AS cl','cl.codcliente','=','m.codcliente_recibe')->where('m.codcliente_envia','=',$cliente->codcliente)->orderBy('m.fecha_transaccion', 'DESC')->get() as $movimiento)
                                                            <tr>
                                                                <td class="text-left">{{blank($movimiento->codcliente_recibe) ? $movimiento->nombres_recibe.' '.$movimiento->apellidos_recibe : $movimiento->nombres.' '.$movimiento->apellidos}}<br>{{$movimiento->identificacion}} </td>
                                                                <td>$ {{number_format($movimiento->valor,0)}}</td>
                                                                <td>{{$movimiento->fecha_transaccion}}</td>
                                                                <td>
                                                                    @if($movimiento->estado==1)
                                                                        <span class="label label-green">Pagado</span>
                                                                    @elseif($movimiento->estado==2)
                                                                        <span class="label label-warning">Pendiente</span>
                                                                    @elseif($movimiento->estado==3)
                                                                        <span class="label label-danger">Revertido</span>
                                                                    @endif
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="modal-footer">
                                                <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Close</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <hr>
                        <h4 class="text-primary">¿Quien Recibe?</h4>
                        <hr>
                        <div class="form-group row m-b-15">
                            <label class="col-form-label col-md-12">identificación</label>
                            <div class="col-md-12">
                                <div class="input-group m-b-10">
                                    {!! Form::hidden('tka',2,['id'=>'tka'])!!}
                                    {!! Form::text('identificacion_recibe', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'identificacion_envio_recibe' ]) !!}
                                    <div class="input-group-prepend">
                                        <button class="btn btn-primary btn-buscar-recibe" type="button"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @if($tk==2)
                            <div id="datos-recibe">
                            @if(blank($cliente_recibe->codcliente))
                            <div class="form-group row m-b-15">
                                <label class="col-form-label col-md-3">Nombres</label>
                                <div class="col-md-9">
                                    {!! Form::text('nombres', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombres_recibe' ]) !!}
                                </div>
                            </div>
                            <div class="form-group row m-b-15">
                                <label class="col-form-label col-md-3">Apellidos</label>
                                <div class="col-md-9">
                                    {!! Form::text('apellidos', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'apellidos_recibe' ]) !!}
                                </div>
                            </div>
                            <div class="form-group row m-b-15">
                                <label class="col-form-label col-md-3">Celular</label>
                                <div class="col-md-9">
                                    {!! Form::text('celular', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'celular_recibe' ]) !!}
                                </div>
                            </div>
                            @else
                            <a class="widget-card widget-card-rounded mb-0" data-id="widget" href="#modal-without-animation" data-toggle="modal">
                                <div class="widget-card-cover"></div>
                                <div class="widget-card-content">
                                    <h5 class="f-s-12 text-black-transparent-7" data-id="widget-elm" data-light-class="f-s-12 text-black-transparent-7" data-dark-class="f-s-12 text-white-transparent-7"><b>Información Destinatario</b></h5>
                                    <h4 class="m-b-10"><b>{{$cliente_recibe->nombreCompleto()}}</b></h4>
                                    <h6 class="m-b-10"><b>Celular: {{$cliente_recibe->celular}}</b></h6>
                                    <h6><b></b></h6>
                                </div>
                                
                            </a>
                            @endif
                            </div>
                            <hr>
                            
                        @endif
                            
                    </div>
                </div>
            </div>
            @if($tk==2)
            <div class="col-lg-8" style="margin-top: -145px;">
                <div class="panel panel-inverse">
                    <div class="panel-heading">
                        Detalle Transacción
                    </div>
                    <div class="panel-body" >
                        <div class="form-group row">
                            <label class="col-form-label col-md-3">Valor Giro</label>
                            <div class="col-md-9">
                                <div class="input-group m-b-10">
                                    {!! Form::text('valor', null, ['class' => 'nombre-menu form-control numeric' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'valor' ]) !!}
                                    <div class="input-group-prepend">
                                        <span class="input-group-text pt-0" style="text-transform: none !important; background-color: #c2ddf7; color: #1a4772 !important;">
                                            <div class="checkbox checkbox-css">
                                                <input type="checkbox" id="incluirFlete" value="">
                                                <label for="incluirFlete" style="color: #1a4772 !important;"><b>¿Flete incluido?<b></label>
                                            </div>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3">Valor Recibido</label>
                            <div class="col-md-9">
                                {!! Form::text('valor_recibido', null, ['class' => 'nombre-menu form-control numeric' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'valor_recibido' ]) !!}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12" id="resumen-giro">
                                <hr>
                                <div class="note note-primary m-b-15">
                                    <div class="note-icon"><i class="fa fa-dollar-sign"></i></div>
                                    <div class="note-content text-right">
                                        <div class="row">
                                            <div class="col-sm-7">
                                                <h4><b>Valor Enviado</b></h4>
                                            </div>
                                            <div class="col-sm-5">
                                                <h4><span id="h1-valor">$ 0<span></h4>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-7">
                                                <h4><b>Tarifa</b></h4>
                                            </div>
                                            <div class="col-sm-5">
                                                <h4><span id="h1-tarifa">-<span></h4>
                                            </div>
                                        </div>
                                        <hr class="my-1 mb-2">
                                        <div class="row">
                                            <div class="col-sm-7">
                                                <h4><b>Total</b></h4>
                                            </div>
                                            <div class="col-sm-5">
                                                <h2 class="font-weight-bold"><span id="h1-total">-<span></h2>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-7">
                                                <h4><b>Valor Recibido</b></h4>
                                            </div>
                                            <div class="col-sm-5">
                                                <h2 class="font-weight-bold"><span id="h1-recibido">-<span></h2>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-7">
                                                <h4><b>Cambio</b></h4>
                                            </div>
                                            <div class="col-sm-5">
                                                <h2 class="font-weight-bold"><span id="h1-cambio">-<span></h2>
                                            </div>
                                        </div>
                                            
                                    </div>
                                </div>
                                    {{Form::hidden('et-g',2,['id'=>'et-g'])}}
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-10">
                                <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" id="codsucursal" name="codsucursal" aria-hidden="true" data-placeholder="Seleccione una sucursal">
                                    <optgroup label="Sucursales">
                                    <option></option>
                                    <!-- foreach(DB::table('empleados AS e')->leftJoin('rel_empleado_sucursal AS r','r.codempleado','=','e.codempleado')->where('r.codsucursal','<>',$sucursal->codsucursal)->get() as $estudiante) -->
                                    @foreach(DB::table('sucursales AS s')->where('bloqueo', '<>', 1)->get() as $sucursal)
                                        <option value="{{$sucursal->codsucursal}}">{{$sucursal->nombres.' - '.$sucursal->municipio}}</option>
                                    @endforeach
                                    </optgroup>
                                </select>
                            </div>
                            <div class="col-sm-2">
                                <a class="btn btn-primary" href="#modal-sucursales" data-toggle="modal"><i class="fa fa-search"></i></a>
                            
                                <div class="modal" id="modal-sucursales">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Detalles sucursales</h4>
                                            </div>
                                            <div class="modal-body">
                                                <table class="table" id="sucursal">
                                                    <thead>
                                                        <tr>
                                                            <td  class="text-left">Nombres</td>
                                                            <td>Ubicación</td>
                                                            <td>Dirección</td>
                                                            <td>Teléfonos</td>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach(DB::table('sucursales AS m')->where('bloqueo', '<>', 1)->get() as $sucursal)
                                                            <tr>
                                                                <td>
                                                                    {{$sucursal->nombres}}
                                                                </td>
                                                                <td>
                                                                    {{$sucursal->municipio}}
                                                                </td>
                                                                <td>
                                                                    {{$sucursal->direccion}}
                                                                </td>
                                                                <td>
                                                                    {{$sucursal->fijo.' - '.$sucursal->celular}}
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="modal-footer">
                                                <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Close</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="checkbox checkbox-css">
                                    <input type="checkbox" id="cssCheckbox1" value="">
                                    <label for="cssCheckbox1" id="labelIngresos">Es necesario diligenciar el formato de reporte de ingresos para poder enviar el giro</label>
                                </div>
                            </div>
                        </div>
                        <div id="reporte-ingreso" style="display: none;">
                            <hr>
                            <div class="form-group row">
                                <label class="col-form-label col-md-6" for="ocupacion">Ocupación</label>
                                <div class="col-sm-6">
                                    <select name="ocupacion" id="ocupacion" class="form-control">
                                        <option value=""></option>
                                        <option value="Independiente">Independiente</option>
                                        <option value="Empleado">Empleado</option>
                                        <option value="Estudiante">Estudiante</option>
                                        <option value="Ama de casa">Ama de casa</option>
                                        <option value="No ejerce ninguna labor">No ejerce ninguna labor</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-form-label col-md-6" for="origen_ingresos">¿De donde provienen los ingresos?</label>
                                <div class="col-sm-6">
                                    <label></label>
                                    <select name="origen_ingresos" id="origen_ingresos" class="form-control">
                                        <option value=""></option>
                                        <option value="Nomina">Nomina</option>
                                        <option value="Prestamos">Prestamos</option>
                                        <option value="Creditos">Creditos</option>
                                        <option value="Pago de terceros">Pago de terceros</option>
                                        <option value="Otros">Otros</option>
                                    </select>
                                </div>
                            </div>
                        <div>
                    </div>
                </div>
                <div>
                    <hr>
                    <button class="btn btn-success btn-enviar" type="submit">Enviar giro</button>
                </div>
            </div>
        </div>
    {{Form::close()}}

@endif
    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>

   <script>
   
   $("#identificacion_envio_recibe").on('keyup', function (e) {
        if (e.keyCode === 13) {
            console.log(0);
            $(this).parent().find('.btn-buscar-recibe').click();
            //alert($("input[type='radio']:checked").val());
        }
    });
   var tarifa_global = 0;
       var handleDataTableButtons=function(){"use strict";0!==$("table").length&&$("table").DataTable(
    {
        dom:"Bfrtip",
        buttons:[
            {extend:"copy",className:"btn-sm"},
            {extend:"excel",className:"btn-sm"},
            {extend:"pdf",className:"btn-sm"},
            {extend:"print",className:"btn-sm"}
            ],
            responsive:!0
        
    }
    )},
    TableManageButtons=function(){"use strict";return{init:function(){handleDataTableButtons()}}}();
TableManageButtons.init();
    $(".default-select2").chosen();
        $(".chosen-container").css("width","100%");
        $('.btn-buscar').click(function(){
            $(".loader2").show();
            
            $.ajax({				
                    dataType: 'json',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: 'POST',
                    url: '{{ url("clientes/buscar") }}',				
                    data: {identificacion: $("#identificacion_envio").val(), tk: 1},
                    success: function(data) {
                        if(data.identificacion==-1){
                            bootbox.confirm({
                                message: "<br>El número de identificación no se encuentra en la base de datos<br>¿Desea registrarlo?",
                                buttons: {
                                    confirm: {
                                        label: 'Registrar',
                                        className: 'btn-success'
                                    },
                                    cancel: {
                                        label: 'Verificar identificación',
                                        className: 'btn-danger'
                                    }
                                },
                                callback: function (result) {
                                    if(result){
                                        window.location.href = "{{url('clientes')}}";
                                    }
                                }
                            });
                        }else{
                            $('#giro-contenedor').html(data.html);
                        }
                        $(".loader2").hide();
                    },
                    error: function(obj, typeError, text, data) {
                        console.log(obj);
                        frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
                    },
                });
            
        });

        $('.btn-enviar').click(function(){
            if($("#valor").val().replace(/,/gi, '')>2000000&&!$("#cssCheckbox1").prop('checked')&&($("#ocupacion").val()==''||$("#origen_ingresos").val()=='')){
                $("#labelIngresos").css("color","red");
                $("#labelIngresos").css("font-weight","700");
                setTimeout(() => {
                    $("#labelIngresos").css("color","black");
                $("#labelIngresos").css("font-weight","400");
                }, 2000);
            }
        });

        $('.btn-historial').click(function(){
            $(".loader2").show();
            
            $.ajax({				
                    dataType: 'json',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: 'POST',
                    url: '{{ url("clientes/historial") }}',				
                    data: {identificacion: $("#identificacion_envio").val()},
                    success: function(data) {
                        if(data.identificacion==-1){
                            bootbox.confirm({
                                message: "<br>El número de identificación no se encuentra en la base de datos<br>¿Desea registrarlo?",
                                buttons: {
                                    confirm: {
                                        label: 'Registrar',
                                        className: 'btn-success'
                                    },
                                    cancel: {
                                        label: 'Verificar identificación',
                                        className: 'btn-danger'
                                    }
                                },
                                callback: function (result) {
                                    if(result){
                                       var codcliente = $(this).data("codcliente");
                                       $.ajax({
                                           url: "{{ url('clientes/consultar-transacciones') }}",
                                           headers: {
                                               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                           },
                                           type: 'post',
                                           data: {
                                               codcliente: codcliente
                                           },
                                           success: function(result){
                                               console.log(0);
                                               $("#demo-lg-modal").modal("show");
                                               $('#form-modal').html(result.formulario);
                                           }
                                       });
                                   }
                                }
                            });
                        }else{
                            $('#giro-contenedor').html(data.html);
                        }
                        $(".loader2").hide();
                    },
                    error: function(obj, typeError, text, data) {
                        console.log(obj);
                        frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
                    },
                });
            
        });
        // $("#agregarAsignatura").on('submit', function() {
        //     if($('#et-g').val()==2){
        //         alert('Aun falta ingresar información, por favor verifica que todo este correcto e intentalo de nuevo');
        //         return false;
        //     }else{
        //         return confirm('Do you really want to submit the form?');
        //     };
        // });
        $("#agregarAsignatura").validate({
            ignore: ":not(.chosen-select):checkbox",
            submitHandler: function(form) {
                if($("#valor").val().replace(/,/gi, '')>2000000&&!$("#cssCheckbox1").prop('checked')){
                    frameworkApp.setAlert('Debe indicar al sistema que se diligenció el formato de reporte de ingresos para poder continuar');
                }else if(Number($("#valor_cambio").val())<0){
                    frameworkApp.setAlert('El valor recibido no puede ser inferior al valor total');
                }else{
                    var html="";
                    html+='<div class="alert alert-warning fade show m-b-10 text-center">Por favor verifique toda la información antes de realizar el envío</div>'
                    html+='<div class="m-b-10">'+$("#datos-envia").html()+'</div>';
                    html+='<hr>'
                    @if(blank($cliente_recibe->codcliente))
                        html+='<a class="widget-card widget-card-rounded mb-0" data-id="widget" href="#modal-without-animation" data-toggle="modal">';
                        html+='    <div class="widget-card-cover"></div>';
                        html+='    <div class="widget-card-content">';
                        html+='        <h5 class="f-s-12 text-black-transparent-7" data-id="widget-elm" data-light-class="f-s-12 text-black-transparent-7" data-dark-class="f-s-12 text-white-transparent-7"><b>Información Destinatario</b></h5>';
                        html+='        <h4 class="m-b-10"><b>'+$("#nombres_recibe").val()+' '+$("#apellidos_recibe").val()+'</b></h4>';
                        html+='        <h6 class="m-b-10"><b>Celular: '+$("#celular_recibe").val()+'</b></h6>';
                        html+='        <h6><b></b></h6>';
                        html+='    </div>';
                    @else
                        html+='<div class="m-b-10">'+$("#datos-recibe").html()+'</div>';
                    @endif
                    html+='<hr>'+$("#resumen-giro").html();
                    bootbox.confirm({
                        message: html,
                        buttons: {
                            confirm: {
                                label: 'Todo es correcto, enviar!',
                                className: 'btn-success'
                            },
                            cancel: {
                                label: 'Corregir información',
                                className: 'btn-danger'
                            }
                        },
                        callback: function (result) {
                            if(result){
                                $(".loader2").show();
                                $("#valor").val($("#valor_giro").val().replace(/,/gi, ''));
                                $("#valor_recibido").val($("#valor_recibido").val().replace(/,/gi, ''));
                                form.submit();
                            }
                        }
                    });
                //form.submit();
                }
                return false;
            },
            rules: {
                nombres: 'required',
                apellidos: 'required',
                celular: 'required',
                codsucursal: 'required',
                valor: {
                    required: true,
                },
                ocupacion: {
                    required: function(element) {
                        return $("#valor_giro").val() > 2000000;
                    }
                },
                procedencia: {
                    required: function(element) {
                        return $("#valor_giro").val() > 2000000;
                    }
                },
                valor_recibido: {
                   required: true,
                },
            },
            highlight: function (element, errorClass) {
            $(element).parent().addClass('has-feedback has-error');
            $(element).parent().removeClass('has-feedback has-success');
            },
            unhighlight: function (element, errorClass) {
            $(element).parent().removeClass('has-feedback has-error');
            $(element).parent().addClass('has-feedback has-success');
            },
            errorPlacement: function(error, element) {
                if(element.hasClass("no-label")){

                } else if(element.parents('.input-group').length > 0) {
                    error.insertAfter(element.parents('.input-group'));
                } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                    error.parent().insertAfter(element);
                } else if(element.parents('.radio').find('.chosen-container').length > 0){
                    error.insertAfter(element.parents('.radio').find('.chosen-container'));
                } else {
                    error.insertAfter(element);
                }
            }
        });
        $('#valor').keypress(function (e) {
            if (String.fromCharCode(e.keyCode).match(/[^0-9]/g)){
                return false;
            }else if($(this).val().length > 9){
                return false;
            }
        });
        $('#valor_recibido').keypress(function (e) {
            if (String.fromCharCode(e.keyCode).match(/[^0-9]/g)) return false;
        });
       tarifas = [
            @foreach(DB::table('tarifas')->orderBy('valor_inicial','asc')->get() as $tarifas)
               {
                   inicio: {{$tarifas->valor_inicial}},
                   fin: {{$tarifas->valor_final}},
                   costo: {{blank($tarifas->costo) ? 0 : $tarifas->costo}},
                   porcentaje: {{blank($tarifas->porcentaje) ? 0 : $tarifas->porcentaje}}
               },
           @endforeach
           ];
       console.log(tarifas);
        $('#valor_recibido').keyup(function () {
                calcularCambio();
        });
        $('#valor').keyup(function () {
            calcularValorTarifa();
        });

        $(".numeric").on({
            "focus": function(event) {
                $(event.target).select();
            },
            "keyup": function(event) {
                $(event.target).val(function(index, value) {
                return value.replace(/\D/g, "")
                    .replace(/\B(?=(\d{3})+(?!\d)\.?)/g, ",");
                });
            }
        });

        

        $('.btn-buscar-recibe').click(function(){
            $(".loader2").show();
            $.ajax({				
                    dataType: 'json',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: 'POST',
                    url: '{{ url("clientes/buscar-recibe") }}',				
                    data: {codcliente: {{$cliente->codcliente}}, identificacion_recibe: $("#identificacion_envio_recibe").val(), tk:  $("#tka").val()},
                    success: function(data) {
                        
                            $('#giro-contenedor').html(data.html);
                            $('#transaccion-contenedor').html(data.html);
                        
                        $(".loader2").hide();
                    },
                    error: function(obj, typeError, text, data) {
                        console.log(obj);
                        frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
                    },
                });
            
        });

        $("#incluirFlete").change(function(){
            
            calcularValorTarifa();
            calcularCambio();
            
        });
        $("#cssCheckbox1").change(function(){
            if($(this).prop('checked')){
                $("#reporte-ingreso").show();
            }else{
                $("#reporte-ingreso").hide();
            }
        });
        


        function calcularCambio()
        {
            var valor=$("#valor").val().replace(/,/gi, '');
            var valor_recibido=$("#valor_recibido").val().replace(/,/gi, '');
            $('#valor_cambio').val(0);
            if($("#valor_recibido").val().replace(/,/gi, '')!=''){
                if(!$("#incluirFlete").prop("checked")){
                    var tarifa = Number(valor_recibido)-Number(valor)-Number($('#valor_tarifa').val()); 
                }else{
                    var tarifa = Number(valor_recibido)-Number(valor); 
                }
               $("#h1-recibido").text(numeral(valor_recibido).format('0,0'));
               if(valor<=3000000)
               $('#valor_cambio').val(tarifa);
               $("#h1-cambio").text(numeral(tarifa).format('0,0'));
           }else{
                $("#h1-recibido").text('');
                $("#h1-cambio").text('');
           }
        }
        function calcularValorTarifa()
        {
            var valor=$("#valor").val().replace(/,/gi, '');
            $("#valor_giro").val(valor);
            var valor_recibido=$("#valor_recibido").val().replace(/,/gi, '');
            if(valor!=''){
                $('#et-g').val(2);
                var entre = false;
                for(var i=0; i<tarifas.length; i++){
                    if(!$("#incluirFlete").prop("checked")){
                        
                        $("#h1-valor").text(numeral(valor).format('0,0'));
                        if(Number(valor)>=Number(tarifas[i].inicio) && Number(tarifas[i].fin)>=Number(valor)){
                            entre = true;
                            var data= tarifas[i];
                            console.log(tarifas[i]);
                            $('#et-g').val(1);
                            var valor_total = Number(valor);
                            if(data.porcentaje>0){
                                valor_porcentaje = (Number(valor_total)*Number(tarifas[i].porcentaje))/100;
                            }else{
                                valor_porcentaje = 0;
                            }
                            var tarifa = Number(tarifas[i].costo)+Number(valor_porcentaje); 
                            tarifa_global = tarifa;
                            $('#valor_tarifa').val(tarifa);
                            $("#h1-tarifa").text(numeral(tarifa).format('0,0'));
                            $("#h1-total").text(numeral(valor_total+valor_porcentaje+tarifas[i].costo).format('0,0'));
                            return true;
                        }else{
                            $("#h1-tarifa").text('');
                            $("#h1-total").text('');
                        }
                    }else{
                        $('#et-g').val(1);
                        var valor_total = Number(valor);
                        if(tarifas[i].porcentaje>0){
                            valor_porcentaje_inicio = (Number(tarifas[i].inicio)*Number(tarifas[i].porcentaje))/100;
                            valor_porcentaje_final = (Number(tarifas[i].fin)*Number(tarifas[i].porcentaje))/100;
                        }else{
                            valor_porcentaje_inicio = 0;
                            valor_porcentaje_final = 0;
                        }
                        if(Number(valor)>=Number(tarifas[i].inicio+valor_porcentaje_inicio) && Number(tarifas[i].fin+valor_porcentaje_final)>=Number(valor)){
                            console.log(tarifas[i]);
                            entre = true;
                            valorTemp = valor - tarifas[i].costo;
                            var porcentaje = '1.0'+(tarifas[i].porcentaje*10);
                            console.log(porcentaje);
                            valorTemp = valorTemp / (porcentaje);
                            valorTemp = valor - tarifas[i].costo - valorTemp;
                            var tarifa = tarifas[i].costo + valorTemp;
                            tarifa_global = tarifa;
                            $("#h1-valor").text(numeral(valor-tarifa).format('0,0'));
                            var valorN = Number(valor)-Number(tarifa); 
                            //console.log(valorN+'-'+valor+'-'+tarifa); 
                            $("#valor_giro").val((valorN));  
                            $('#valor_tarifa').val(tarifa);
                            $("#h1-tarifa").text(numeral(tarifa).format('0,0'));
                            $("#h1-total").text(numeral(valor_total).format('0,0'));
                            console.log(tarifa);
                        }else{
                            console.log('otra');
                        }
                        
                    }
                    
                }
                if(!entre){
                    tarifa_global = 0;
                    $("#h1-tarifa").text("-");
                    $("#h1-total").text("-");
                }
            }else{
                $("#h1-recibido").text('');
                $("#h1-cambio").text('');
           }
        }
    </script>