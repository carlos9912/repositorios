@php
	use Carbon\Carbon;
	use App\Enums\EEstadoVinculacion;
    use App\Enums\ETipoDocumento;
@endphp
<style>
    .widget-list-item .widget-list-title {
    font-size: 16px;
    line-height: 16px;
    margin: 0;
}
    </style>
{{Form::open(['route' => 'clientes.retirar-giro', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'agregarAsignatura']) }}  
    <input type="hidden" name="codgiro" id="codgiro" value="{{$giro->codmovimiento}}">
        <div class="col-lg-6">
            <!-- begin panel -->
            <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                <!-- begin panel-heading -->
                <div class="panel-heading">
                    <h4 class="panel-title">Información del giro</h4>
                </div>
                <!-- end panel-heading -->
                <!-- begin panel-body -->
                <div class="panel-body" >
                    <div id="datos-envia">
                        <div class="widget-list-action">
                            <a href="#" data-toggle="dropdown" class="text-muted pull-right btn btn-green btn-sm"><i class="fa fa-ellipsis-h f-s-14"></i></a>
                            <ul class="dropdown-menu dropdown-menu-right">
                                <li><a href="#modal-without-animation" data-toggle="modal">Ver historial</a></li>
                                <li><a href="#" class="btn-favoritos">Favoritos</a></li>
                                <li><a href="#">Editar Información</a></li>
                            </ul>
                            <div class="modal" id="modal-without-animation">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Historial de giros</h4>
                                        </div>
                                        <div class="modal-body">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <td  class="text-left">Nombres</td>
                                                        <td>Valor</td>
                                                        <td>Fecha</td>
                                                        <td>Estado</td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach(DB::table('movimientos AS m')->leftjoin('clientes AS cl','cl.codcliente','=','m.codcliente_recibe')->where('m.codcliente_envia','=',$cliente->codcliente)->orderBy('m.fecha_transaccion', 'DESC')->get() as $movimiento)
                                                        <tr>
                                                            <td class="text-left">{{blank($movimiento->codcliente_recibe) ? $movimiento->nombres_recibe.' '.$movimiento->apellidos_recibe : $movimiento->nombres.' '.$movimiento->apellidos}} </td>
                                                            <td>$ {{number_format($movimiento->valor,0)}}</td>
                                                            <td>{{$movimiento->fecha_transaccion}}</td>
                                                            <td>
                                                                @if($movimiento->estado==1)
                                                                    <span class="label label-green">Pagado</span>
                                                                @elseif($movimiento->estado==2)
                                                                    <span class="label label-warning">Pendiente</span>
                                                                @elseif($movimiento->estado==3)
                                                                    <span class="label label-danger">Revertido</span>
                                                                @endif
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Close</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a class="widget-card widget-card-rounded mb-0" data-id="widget" href="#modal-without-animation" data-toggle="modal">
                            <div class="widget-card-cover"></div>
                            <div class="widget-card-content">
                                <h5 class="f-s-12 text-black-transparent-7" data-id="widget-elm" data-light-class="f-s-12 text-black-transparent-7" data-dark-class="f-s-12 text-white-transparent-7"><b>Información Cliente</b></h5>
                                <h4 class="m-b-10"><b>{{$cliente->nombreCompleto()}}</b></h4>
                                <h6 class="m-b-10"><b>Celular: {{$cliente->celular}}</b></h6>
                                <h6><b></b></h6>
                            </div>
                        </a>
                    </div>
                    <hr>
                    <div id="datos-recibe">
                         <a class="widget-card widget-card-rounded mb-0" data-id="widget" href="#modal-without-animation" data-toggle="modal">
                            <div class="widget-card-cover"></div>
                            <div class="widget-card-content">
                                <h5 class="f-s-12 text-black-transparent-7" data-id="widget-elm" data-light-class="f-s-12 text-black-transparent-7" data-dark-class="f-s-12 text-white-transparent-7"><b>Información Remitente</b></h5>
                                <h4 class="m-b-10"><b>{{$cliente_envia->nombreCompleto()}}</b></h4>
                                <h6 class="m-b-10"><b>Celular: {{$cliente_envia->celular}}</b></h6>
                                <h6><b></b></h6>
                            </div>
                            
                        </a>
                    </div>
                    <div class="invoice-price">
						<div class="invoice-price-left text-right" style="width: 25%!important;">
                        Valor a pagar
						</div>
						<div class="invoice-price-right">
							<small>TOTAL</small> <span class="f-w-600">$ {{number_format($giro->valor)}} </span>
						</div>
					</div>
                    <button class="btn btn-primary btn-lg btn-block mt-4 btn-pagar" type="button">Pagar giro</button>
                </div>
            </div>
        </div>
{{Form::close()}}
    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>
    <a data-fancybox="" data-type="iframe" href="{{url('factura-retira')}}?m={{($giro->codgiro)}}" class="btn btn-primary btn-factura-reclamar" style="display: none;">
        Open demo
    </a>
<script>
$('.btn-pagar').click(function(){
    bootbox.confirm({
        message: "<br>Esta a punto de registrar el pago de un giro por valor de <b>$ {{number_format($giro->valor)}}</b> <br>¿Desea continuar?",
        buttons: {
            confirm: {
                label: 'Pagar giro',
                className: 'btn-success'
            },
            cancel: {
                label: 'Verificar identificación',
                className: 'btn-danger'
            }
        },
        callback: function (result) {
            if(result){
                $(".loader2").show();
                $.ajax({				
                    dataType: 'json',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: 'POST',
                    url: '{{ url("clientes/retirar-giro") }}',				
                    data: {txtAjax: true, codgiro: $("#codgiro").val()},
                    success: function(data) {
                        console.log(data);
                        $(".loader2").hide();
                        //frameworkApp.setAlert('Transacción aprobada<br><br>Valor a pagar al cliente <b>{{number_format($giro->valor)}}</b>');
                        bootbox.alert("<strong>Transacción aprobada</strong><br><br><h3>Valor a pagar al cliente <b>{{number_format($giro->valor)}}</h3></b>", function(){ 
                            $('.btn-factura-reclamar').click();
                            $("#giro-contenedor").html(data.formulario);
                            $("#detalle-row").html(data.detalle);
                            $('#transaccion-contenedor').fadeOut("fast",function(){
            					$('#transaccion-contenedor').html('');
            					$('.identificacion-cliente').val('');
            				});
                        });                                
                        
                    },
                    error: function(obj, typeError, text, data) {
                        $(".loader2").hide();
                        console.log(obj);
                        frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
                    },
                });
            }
        }
    });
    
    
    
});
</script>