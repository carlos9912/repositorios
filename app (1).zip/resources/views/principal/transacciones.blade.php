@php

	use Carbon\Carbon;

	use App\Enums\EEstadoVinculacion;

	use App\Enums\ETipoDocumento;
	
	
	use App\Models\Sucursal;
	
	
$sucursal = Sucursal::find(session('sucursal')->codsucursal);
@endphp

<style>

.modal-title{

	text-align: center;

}

.modal-header button{

	display: none!important;

}

.bootbox-input{



}

</style>

	<!-- begin col-6 -->

	<div class="col-lg-4">

		<!-- begin panel -->

		<div class="panel panel-inverse" data-sortable-id="form-stuff-1">

			<!-- begin panel-heading -->

			<div class="panel-heading">

				<h4 class="panel-title">Enviar Giro</h4>

			</div>

			<!-- end panel-heading -->

			<!-- begin panel-body -->

			<div class="panel-body" >
                @if($sucursal->cupo>=$sucursal->saldo)
				<h4 class="text-green">¿Quien envia?</h4>

				<hr>

				<form>

					<div class="form-group row m-b-15">

						<label class="col-form-label col-md-3">identificación</label>

						<div class="col-md-9">

								<div class="input-group m-b-10">

									<div class="input-group-prepend">

										{!! Form::select("tipo_documento", ETipoDocumento::items(), 1, ['id'=>'f', "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Tipo", "required" => "required"]) !!}

									</div>

									{!! Form::hidden('tk',base_convert(1,10,16),['id'=>'tk'])!!}

									{!! Form::text('identificacion', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'identificacion_envio' ]) !!}

									<div class="input-group-prepend">

										<button class="btn btn-primary btn-buscar" type="button"><i class="fa fa-search"></i></button>

									</div>

								</div>

						</div>

					</div>

				</form>

				<hr>

				<h4 class="text-primary">¿Quien Recibe?</h4>

				<hr>

				<div class="alert alert-danger fade show m-b-10">

					Es necesario indicarle al sistema primero los datos de quien envía

				</div>
   
				@else
					<div class="alert alert-danger fade show m-b-10">
                        <h4 class="text-light">Ha sobrepasado cupo disponible, liberar cupo por consignación</h4>
                    </div>
                
				@endif
 
			</div>
           
			<!-- end panel-body -->

		</div>

		<!-- end panel -->

		<!-- begin panel -->

		<div class="panel panel-inverse" data-sortable-id="form-stuff-1">

			<!-- begin panel-heading -->

			<div class="panel-heading">

				<h4 class="panel-title">Recibir Giro</h4>

			</div>

			<!-- end panel-heading -->

			<!-- begin panel-body -->

			<div class="panel-body" >

				<h4 class="text-green">¿Quien envia?</h4>

				<hr>

				<form>

					<div class="form-group row m-b-15">

						<label class="col-form-label col-md-3">identificación</label>

						<div class="col-md-9">

								<div class="input-group m-b-10">

									<div class="input-group-prepend">

										{!! Form::select("tipo_documento", ETipoDocumento::items(), 1, ['id'=>'f', "class" => "form-control chosen-select no-label" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => "Tipo", "required" => "required"]) !!}

									</div>

									{!! Form::hidden('tk',base_convert(1,10,16),['id'=>'tk'])!!}

									{!! Form::text('identificacion', null, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'identificacion_envio_recibe' ]) !!}

									<div class="input-group-prepend">

										<button class="btn btn-primary btn-buscar-recibe" type="button"><i class="fa fa-search"></i></button>

									</div>

								</div>

						</div>

					</div>

				</form>

				<hr>

				<h4 class="text-primary">¿Quien Recibe?</h4>

				<hr>

				<div class="alert alert-danger fade show m-b-10">

					Es necesario indicarle al sistema primero los datos de quien envía

				</div>

				

			</div>

			<!-- end panel-body -->

		</div>

		<!-- end panel -->

		

	</div>

	<div class="col-lg-6" id="giro-contenedor-recibe">

	</div>

	

<script>

	
$('.btn-buscar').click(function(){
				$(".loader2").show();
				
				$.ajax({				
						dataType: 'json',
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						type: 'POST',
						url: '{{ url("clientes/buscar") }}',				
						data: {identificacion: $("#identificacion_envio").val(), tk:  $("#tk").val()},
						success: function(data) {
							if(data.identificacion==-1){
								bootbox.confirm({
									message: "<br>El número de identificación no se encuentra en la base de datos<br>¿Desea registrarlo?",
									buttons: {
										confirm: {
											label: 'Registrar',
											className: 'btn-success'
										},
										cancel: {
											label: 'Verificar identificación',
											className: 'btn-danger'
										}
									},
									callback: function (result) {
										if(result){
											window.location.href = "{{url('clientes')}}";
										}
									}
								});
							}else{
								$('#giro-contenedor').html(data.html);
							}
							$(".loader2").hide();
						},
						error: function(obj, typeError, text, data) {
							console.log(obj);
							frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
						},
					});
				
			});
			$('.btn-buscar-recibe').click(function(){
				$(".loader2").show();
				
				$.ajax({				
					dataType: 'json',
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					type: 'POST',
					url: '{{ url("clientes/buscar") }}',				
					data: {identificacion: $("#identificacion_envio_recibe").val(), tk:  $("#tk").val()},
					success: function(data) {
						$(".loader2").hide();
						var codigo_cliente = data.codigo;
						console.log(codigo_cliente);
						if(data.identificacion==-1){
							bootbox.confirm({
								message: "<br>El número de identificación no se encuentra en la base de datos<br>¿Desea registrarlo?",
								buttons: {
									confirm: {
										label: 'Registrar',
										className: 'btn-success'
									},
									cancel: {
										label: 'Verificar identificación',
										className: 'btn-danger'
									}
								},
								callback: function (result) {
									if(result){
										window.location.href = "{{url('clientes')}}";
									}
								}
							});
						}else{
							bootbox.prompt({
					
								buttons: {
									confirm: {
										label: 'Verificar giro',
										className: 'btn-success'
									},
									cancel: {
										label: 'No tengo un código',
										className: 'btn-danger'
									}
								},
								inputType: 'number',
								title: "Ingrese el código enviado por mensaje de texto", 
								locale: 'custom',
								callback: function (result) {
									$(".loader2").show();
										setTimeout(function(){ 
											$.ajax({				
											dataType: 'json',
											headers: {
												'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
											},
											type: 'POST',
											url: '{{ url("clientes/buscar-giro") }}',				
											data: {codcliente: codigo_cliente, codigo:  result},
											success: function(data) {
												console.log(data);
												if(data.existe==1){
													$('#giro-contenedor-recibe').html(data.html);
												}else if(data.existe==0){
													$('#giro-contenedor-recibe').html('');
													frameworkApp.setAlert('Con el código <b>'+result+'</b> el cliente no tiene giros registrado');
												}else if(data.existe==2){
													$('#giro-contenedor-recibe').html('');
													frameworkApp.setAlert('El giro con el código <b>'+result+'</b> ya fue cobrado por parte del cliente');
												}
											},
											error: function(obj, typeError, text, data) {
												console.log(obj);
												frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
											},
										});

										$(".loader2").hide();
									}, 500);
									
								}
							});	
						}
						
					},
					error: function(obj, typeError, text, data) {
						console.log(obj);
						frameworkApp.setAlert('Se ha producido un error inesperado. Vuelve a intentarlo mas tarde.');
					},
				});
				
			});
</script>
