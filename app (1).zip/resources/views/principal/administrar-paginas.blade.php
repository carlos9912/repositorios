

@extends('layouts.administrador')
@section('title', trans('general.title_crear_pagina'))
@section('titulo-pagina')
    <div id="page-title">
        <h1 class="page-header text-overflow">{{trans('paginas.pagina_title_administrar_pagina')}}</h1>
    </div>    
@endsection
@section('breadcum')
    <ol class="breadcrumb">
        <li><a href="#"><i class="demo-pli-home"></i></a></li>
        <li class="active">{{trans('paginas.pagina_title_administrar_pagina')}}</li>
    </ol>
@endsection
@section('content')
    <div class="row">
        <div class="panel">
            <div class="panel-body">
                <div class="form-inline pad-top">
                    <div class="row">
                        <div class="col-sm-6 table-toolbar-left">
                            {{ Form::open(['route' => 'paginas.administrar', 'method'=>'get']) }}
                                <div class="form-group">
                                    {!! Form::text('rango_fechas', '', ['id' => 'rango_fechas', 'class' => 'dateranges form-control'. ($errors->has('otra_especialidad') ? ' is-invalid' : ''), 'autocomplete' => 'off' ]) !!}
                                </div>
                                <div class="form-group text-left">
                                    {!! Form::select("id_menu", $menus, null, ["id"=>"id_menu", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => trans("menus.placeholder_menu_seleccione")]) !!}
                                </div>
                                <div class="form-group text-left">
                                    {!! Form::select("principal", App\Enums\ESiNo::items(), null, ["id"=>"principal", "class" => "form-control chosen-select" . ($errors->has("id_ubicacion") ? " is-invalid" : ""), "placeholder" => trans("paginas.pagina_principal")]) !!}
                                </div>
                                <div class="btn-group">
                                    <button class="btn btn-primary"><i class="demo-pli-download-from-cloud"></i> {{trans('botones.buscar')}}</button>
                                </div>
                            {{ Form::close()}}
                        </div>
                        <div class="col-sm-6 table-toolbar-right">
                            <a id="demo-btn-addrow" class="btn btn-mint" href="{{ route('paginas.crear') }}"><i class="demo-pli-add"></i> {{trans('paginas.pagina_crear')}}</a>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="panel">
                
            <!--Posts Table-->
            <!--===================================================-->
            <div class="panel-body" id="tablaPaginas">
                {!! $tablaPaginas !!}
            </div>
                    <!--===================================================-->
                    <!--End Posts Table-->
        </div>
    </div>
    <div class="modal fade" id="editarModal" tabindex="-1" role="dialog" aria-labelledby="downloadModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">{{trans('paginas.pagina_title_editar_pagina')}}</h4>
                </div>
                <div class="modal-body" id="informacionPagina">
                    
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script')
<script>
    $(window).on('load', function(){
        var rowSelection = $('table').DataTable({
        "responsive": true,
        "language": {
            "paginate": {
                "previous": '<i class="demo-psi-arrow-left"></i>',
                "next": '<i class="demo-psi-arrow-right"></i>'
            }
        }
    });
    $('table').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            rowSelection.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
    });
</script>
    <script>
        
        $('.dateranges').daterangepicker({
    		ranges: {
                'Hoy': [moment(), moment()],
                'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Ultimos 7 dias': [moment().subtract(6, 'days'), moment()],
                'Ultimos 30 dias': [moment().subtract(29, 'days'), moment()],
                'Todo este mes': [moment().startOf('month'), moment().endOf('month')],
                'Todo el mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            alwaysShowCalendars: true,
    		locale: {
    	      format: 'DD/MM/YYYY'
    	    },
            
        });
    
    function consultarPagina(idPagina){
        frameworkApp.setLoadData({
            url: '{{ url("paginas/informacion-pagina") }}',
            data: {
                id_pagina: idPagina
            },
            id_container_body: false,
            success: function(data) {
                $("#informacionPagina").html(data.informacionPagina);
                $("#editarModal").modal('show');
            }
        });
    }

    function eliminarPagina(idPagina){
        bootbox.confirm({ 
            title: "{{trans('general.atencion')}}", 
            message: "{{trans('paginas.paginas_confirmacion_eliminar')}}",
            callback: function(result){ 
                if(result){
                    frameworkApp.setLoadData({
                        url: '{{ url("eliminar-pagina") }}',
                        data: {
                            id_pagina: idPagina
                        },
                        id_container_body: false,
                        success: function(data) {
                            frameworkApp.setToastSuccess('{{trans('paginas.paginas_eliminacion_exitosa')}}');
                            //bootbox.alert("{{trans('paginas.paginas_eliminacion_exitosa')}}");
                            $("#tablaPaginas").html(data.tablaPaginas);
                            $('#table-paginas').DataTable({
                                "responsive": true,
                                "language": {
                                    "paginate": {
                                    "previous": '<i class="demo-psi-arrow-left"></i>',
                                    "next": '<i class="demo-psi-arrow-right"></i>'
                                    }
                                }
                            });
                            $('.add-tooltip').tooltip();
                            $('.add-tooltip').on('click', function () {
                                $(this).attr('data-original-title', 'changed tooltip');
                                $('.add-tooltip').tooltip();
                                $(this).mouseover();
                            });
                        }
                    });
                }
            }
        });
        
    }

    
    @if(blank(request()->get('rango_fechas')))
        $("#rango_fechas").val('');
    @endif
    
    </script>
@endsection