

@php

    use App\Models\Sucursal;
    use App\Models\Apertura;
    use Carbon\Carbon;
    use Illuminate\Support\Arr;
    use App\Enums\ETipoDocumento;


    

    

    $pendientes = 0;
    
    $rangoFechas = request('rango_fecha');
    if(blank($rangoFechas)){
        $inicio = date('Y-m').'-01 00:00:00';
        $fin = date('Y-m-d').' 23:59:59';
    }else{
        $rangoFechas = explode(' - ',$rangoFechas);
        $inicio = Carbon::parse(str_replace('/','-',$rangoFechas[0]))->format('Y-m-d').' 00:00:00';
        $fin = Carbon::parse(str_replace('/','-',$rangoFechas[1]))->format('Y-m-d').' 23:59:59';
    }
    $listCajas = [];
    foreach(DB::table('rel_sucursal_caja AS r')->whereBetween('r.fecha', [
            $inicio,
            $fin
        ])->get() as $caja){
            $listCajas[$caja->codsucursal][Carbon::parse($caja->fecha)->format('Y-m-d')] = $caja;
        }
    $begin = new DateTime($inicio);
    $end = new DateTime($fin);
    $interval = DateInterval::createFromDateString('1 day');
    $period = new DatePeriod($begin, $interval, $end);
    
@endphp

@extends('layouts.administrador')

@section('title', 'Sucursales')

@section('titulo-pagina')
    <div id="page-title">
        <h1 class="page-header text-overflow">Administrador sucursales</h1>
    </div>    
@endsection

@section('breadcum')

    <ol class="breadcrumb">

        <li><a href="#"><i class="demo-pli-home"></i></a></li>

        <li class="active">Administrador sucursales</li>

    </ol>

@endsection

@section('content')
    <div class="row">
        <div class="col-sm-12">
            <ul class="nav nav-tabs" style="background: #f3f1f1;">
                <li class="nav-item">
                    <a href="#default-tab-1" data-toggle="tab" class="nav-link {{blank($rangoFechas) ? 'active' : ''}}">
                        <span class="d-sm-none">Movimientos </span>
                        <span class="d-sm-block d-none font-weight-bold">Administrar</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#default-tab-2" data-toggle="tab" class="nav-link {{!blank($rangoFechas) ? 'active' : ''}}">
                        <span class="d-sm-none">Tab 2</span>
                        <span class="d-sm-block d-none font-weight-bold">Estados</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#default-tab-3" data-toggle="tab" class="nav-link">
                        <span class="d-sm-none">Cajas</span>
                        <span class="d-sm-block d-none font-weight-bold">Cajas</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#default-tab-5" data-toggle="tab" class="nav-link abrir-modal">
                        <span class="d-sm-none">Crear sucursal</span>
                        <span class="d-sm-block d-none font-weight-bold">Crear sucursal</span>
                    </a>
                </li>
            </ul>
            <div class="tab-content">
                <!-- begin tab-pane -->
                <div class="tab-pane fade {{blank($rangoFechas) ? 'active show' : ''}}" id="default-tab-1">
                    <div class="row">
                        <!-- begin col-6 -->
                        <div class="col-sm-12">
                            <div class="panel panel-inverse">
                                <div class="panel-body p-0">
                                    <div class="col-md-12">
                                            <div class="panel">
                                                <!--===================================================-->
                                                <div class="panel-body">
                                                                                        
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Caja</th>
                                                                    <th class="min-w-td">Nombre sucursal</th>
                                                                    <th class="min-w-td">Dirección  </th>
                                                                    <th>Municipio</th>
                                                                    <th class="min-w-td">DEPARTAMENTO </th>
                                                                    <th>Telefonos</th>
                                                                    <th>Cupo</th>
                                                                    <th></th>
                                                                    <th></th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            @php
                                                                $secuencia = 0;
                                                            @endphp
                                                                @foreach(DB::table('sucursales')->orderBy('codsucursal')->get() as $sucursal)
                                                                    @php
                                                                        $secuencia++;
                                                                        $date = Carbon::now();
                                                                        $sucursal = Sucursal::find($sucursal->codsucursal);
                                                                        $horario = $sucursal->horarios();
                                                                        $apertura = $sucursal->aperturas()->whereBetween('fecha', [
                                                                            Carbon::parse(Carbon::today())->format('Y-m-d').' 00:00:00',
                                                                            Carbon::parse(Carbon::today())->format('Y-m-d').' 23:59:59'
                                                                        ])->first();
                                                                        $apertura = blank($apertura) ? null : $apertura;
                                                                        $validar_apertura = !blank($apertura) && !blank($apertura->fecha)&&$date->format('d/m/y')==Carbon::parse($apertura->fecha)->format('d/m/y') ? true : false;
                                                                    @endphp
                                                                    <tr id="tr-{{$sucursal->codsucursal}}">
                                                                        <td>
                                                                            @if(!blank($apertura) && $apertura->tipo_registro==1&&$apertura->estado==1&&$validar_apertura)
                                                                                <div class="btn-group">
                                                                                    <a class="btn btn-success btn-sm text-white">Abierta</a>
                                                                                </div>
                                                                            @elseif(!blank($apertura) && $apertura->tipo_registro==1&&$apertura->estado==2&&$validar_apertura)
                                                                            <div class="btn-group">
                                                                                    <a class="btn btn-warning btn-sm text-white">Cerrada</a>
                                                                                    <a href="#" data-toggle="dropdown" class="btn btn-warning btn-sm dropdown-toggle"></a>
                                                                                    <div class="dropdown-menu dropdown-menu-right">
                                                                                        <a data-fancybox="" data-type="iframe" href="{{url('sucursal-cierre')}}?m={{base64_encode($sucursal->codsucursal)}}" class="dropdown-item" title="Cierre de Caja">Cierre de caja</a>	
                                                                                        <a data-fancybox="" data-type="iframe" href="{{url('sucursal-consolidado')}}?m={{base64_encode($sucursal->codsucursal)}}&fecha={{$date->format('Y/m/d')}}" class="dropdown-item" title="Cierre de Caja Detallado">Cierre caja día - detallado</a>	
                                                                                    </div>
                                                                                </div>
                                                                            @else
                                                                            
                                                                                <div class="btn-group">
                                                                                    <a class="btn btn-danger btn-sm text-white">Sin abrir</a>
                                                                                </div>
                                                                            @endif
                                                                        </td>
                                                                        <td>
                                                                            {{$sucursal->nombres}}
                                                                            <br><b>SUC-{{str_pad($sucursal->codsucursal, 4, "0",STR_PAD_LEFT)}}</b>
                                                                        </td>
                                                                        <td>
                                                                            {{$sucursal->direccion}}
                                                                            <br>
                                                                            {{$sucursal->barrio}}
                                                                        </td>
                                                                        <td>
                                                                            {{$sucursal->municipio}}
                                                                        </td>
                                                                        <td>
                                                                            {{$sucursal->departamento}}
                                                                        </td>

                                                                        <td>

                                                                            {{$sucursal->fijo.' - '.$sucursal->celular}}

                                                                        </td>


                                                                        <td class="text-right">

                                                                            $ {{number_format($sucursal->cupo)}}

                                                                        </td>
                                                                        <td class="text-center">

                                                                            @if($sucursal->bloqueo==1)
                                                                                <a class="btn btn-icon btn-circle btn-sm btn-danger btn-hover-success fa fa-times-circle text-white bloquear-sucursal" data-bloqueo="2" data-codsucursal="{{$sucursal->codsucursal}}"></a>
                                                                            @else
                                                                                <a class="btn btn-icon btn-circle btn-sm btn-success btn-hover-success fa fa-check text-white bloquear-sucursal" data-bloqueo="1" data-codsucursal="{{$sucursal->codsucursal}}"></a>
                                                                            @endif


                                                                        </td>
                                                                        

                                                                        <td class="text-center mar-rgt" style="width: 5%;">

                                                                            <div class="btn-group">

                                                                                <a class="btn btn-sm btn-success btn-hover-success fa fa-dollar-sign text-white" href="{{route('sucursal.estado-cuenta',[$sucursal->codsucursal])}}"></a>

                                                                                <a class="btn btn-sm btn-info btn-hover-success fa fa-clock text-white abrir-modal-horarios" data-codsucursal="{{$sucursal->codsucursal}}"></a>
                                                                                <a class="btn btn-sm btn-primary btn-hover-success fa fa-edit text-white abrir-modal" data-codsucursal="{{$sucursal->codsucursal}}"></a>

                                                                                <a class="btn btn-sm btn-danger btn-hover-success fa fa-trash text-white add-tooltip eliminar-sucursal" data-codsucursal="{{$sucursal->codsucursal}}"></a>

                                                                                <!-- <a class="btn btn-sm btn-primary btn-hover-success add-tooltip btn-evidencias ti ti-receipt" data-original-title="Registrar Consignación" data-toggle="modal" data-target="#modalFormArchivo" data-codasignatura="{{$sucursal->nombres}}" data-container="body"></a> -->
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade {{!blank($rangoFechas) ? 'active show' : ''}}" id="default-tab-2">
                    {!!Form::open(['route' => 'sucursal.buscar', 'id'=>'formBuscarEstado', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
                    {{Form::hidden('codsucursal', $sucursal->codsucursal)}}
                        <div class="row">
                        
                            <!-- begin col-6 -->
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>RANGO FECHA ESTADO {{request('rango_fecha')}}</label>
                                    <div class="input-group" id="default-daterange">
                                        <input id="daterange" type="text" name="rango_fecha" class="form-control" value="{{request('rango_fecha')}}" placeholder="Especifique una fecha a buscar" autocomplete="false" />
                                        <span class="input-group-append">
                                        <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-1">
                                <label>Sucursales</label>
                                <button type="submit" class="btn btn-primary">Buscar</button>
                            </div>
                        </div>
                    {{Form::close()}}
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="panel panel-inverse">
                                <div class="panel-body p-0">
                                    <div class="col-md-12 p-0">
                                        <div class="panel">
                                            <!--===================================================-->
                                            <div class="panel-body p-0">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th class="min-w-td">Datos sucursal</th>
                                                                <th class="min-w-td">Saldo  </th>
                                                                <th class="min-w-td">Comisión </th>
                                                                <th class="text-center">Enviado</th>
                                                                <th class="text-center">Retirado</th>
                                                                <th class="text-center">Total Giros</th>
                                                                <th class="text-center">Recargas</th>
                                                                <th class="text-center">Consig.</th>
                                                                <th class="text-center">Facturas</th>
                                                                <th></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        @php
                                                            $secuencia = 0;
                                                            $totales = ["saldo"=>0, "comision" =>0, "enviado"=>0, "retirado"=>0, "recargas" => 0, "consignaciones" =>0, "facturas" =>0];
                                                        @endphp
                                                            @foreach(DB::table('sucursales')->orderBy('codsucursal')->get() as $sucursal)
                                                                @php
                                                                    $totales["saldo"]+=$sucursal->saldo;
                                                                    $giros = 0;
                                                                    $secuencia++;
                                                                    $date = Carbon::now();
                                                                    $sucursal = Sucursal::find($sucursal->codsucursal);
                                                                    $horario = $sucursal->horarios();
                                                                    $apertura = $sucursal->aperturas()->whereBetween('fecha', [
                                                                        Carbon::parse(Carbon::today())->format('Y-m-d').' 00:00:00',
                                                                        Carbon::parse(Carbon::today())->format('Y-m-d').' 23:59:59'
                                                                    ])->first();
                                                                    $apertura = blank($apertura) ? null : $apertura;
                                                                    $validar_apertura = !blank($apertura) && !blank($apertura->fecha)&&$date->format('d/m/y')==Carbon::parse($apertura->fecha)->format('d/m/y') ? true : false;
                                                                @endphp
                                                                <tr id="tr-{{$sucursal->codsucursal}}">
                                                                    <td>
                                                                        <a class="text-inverse" target="_self" name="estadocuenta" href="{{route('sucursal.estado-cuenta',[$sucursal->codsucursal])}}"><b>SUC-{{str_pad($sucursal->codsucursal, 4, "0",STR_PAD_LEFT)}}</b> {{$sucursal->nombres}}{!!!blank($sucursal->deposito) ? ' <i class="fa fa-star"></i>' : ''!!}</a>
                                                                        <br>{{$sucursal->direccion}}
                                                                        <br>
                                                                        {{$sucursal->municipio}} - {{$sucursal->departamento}}
                                                                        <br>Cupo: <b class="text-inverse">$ {{number_format($sucursal->cupo)}}</b>
                                                                    </td>
                                                                    <td class="text-right">
                                                                        Saldo: <b class="text-inverse">$ {{number_format($sucursal->saldo)}}</b>
                                                                        <div class="progress" style="height: 10px; font-weight: 700; ">
                                                                            <div class="progress-bar progress-bar-striped progress-bar-animated " role="progressbar" aria-valuenow="{{number_format($sucursal->saldo*100/$sucursal->cupo)}}" aria-valuemin="0" aria-valuemax="100" style="color: black; width: {{number_format($sucursal->saldo*100/$sucursal->cupo)}}%">{{number_format($sucursal->saldo*100/$sucursal->cupo)}}%</div>
                                                                        </div>
                                                                    </td>
                                                                    <td class="text-right">
                                                                        @php
                                                                            $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->whereBetween('r.fecha_movimiento',[
                                                                                $inicio,
                                                                                $fin
                                                                            ])->where('codsucursal','=',$sucursal->codsucursal)->select(DB::raw('SUM(valor_comision) as comision'))->first();
                                                                            $comisionAcumulada = $comisionAcumulada->comision;
                                                                            $totales["comision"]+=$comisionAcumulada;
                                                                        @endphp
                                                                        <b class="text-inverse">$ {{number_format($comisionAcumulada)}}</b>
                                                                    </td>

                                                                    <td class="text-right table-warning">
                                                                        @php
                                                                        
                                                                            $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->join('movimientos as m', 'm.codmovimiento','=','r.codmovimiento')->where('r.estado','=','1')->whereBetween('r.fecha_movimiento',[
                                                                                $inicio,
                                                                                $fin
                                                                            ])->where('r.codsucursal','=',$sucursal->codsucursal)->where('tipo_movimiento','=','1')->select(DB::raw('SUM(r.valor_real) as valor'),DB::raw('SUM(m.valor_tarifa) as valor_tarifa'))->first();
                                                                            $comisionS = $comisionAcumulada->valor + $comisionAcumulada->valor_tarifa;
                                                                            $giros+=$comisionS;
                                                                            $totales["enviado"]+=$comisionS;
                                                                        @endphp
                                                                        <b class="text-inverse">$ {{number_format($comisionS)}}</b>
                                                                        <i class="fas fa-arrow-alt-circle-up text-warning"> </i>

                                                                    </td>

                                                                    <td class="text-right table-warning">
                                                                    
                                                                        @php
                                                                            $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->whereBetween('r.fecha_movimiento',[
                                                                                $inicio,
                                                                                $fin
                                                                            ])->where('codsucursal','=',$sucursal->codsucursal)->where('tipo_movimiento','=','2')->select(DB::raw('SUM(valor_real) as valor'))->first();
                                                                            $comisionAcumulada = $comisionAcumulada->valor;
                                                                            $giros-=$comisionAcumulada;
                                                                            $totales["retirado"]+=$comisionAcumulada;
                                                                        @endphp
                                                                        <b class="text-inverse">$ {{number_format($comisionAcumulada)}}</b>
                                                                        <i class="fas fa-arrow-alt-circle-down text-success"> </i>
                                                                    </td>
                                                                    
                                                                    <td class="text-right table-warning">
                                                                    
                                                                        <b class="text-inverse">$ {{number_format($giros)}}</b>
                                                                        <i class="fas fa-arrow-alt-circle-down text-success"> </i>
                                                                    </td>


                                                                    <td class="text-right table-info">
                                                                        @php
                                                                            $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->whereBetween('r.fecha_movimiento',[
                                                                                $inicio,
                                                                                $fin
                                                                            ])->where('codsucursal','=',$sucursal->codsucursal)->where('tipo_movimiento','=','4')->where('estado','=','1')->select(DB::raw('SUM(valor_real) as valor'))->first();
                                                                            $comisionAcumulada = $comisionAcumulada->valor;
                                                                            $totales["recargas"]+=$comisionAcumulada;
                                                                        @endphp
                                                                        <b class="text-inverse">$ {{number_format($comisionAcumulada)}}</b>
                                                                        <i class="fas fa-arrow-alt-circle-left text-inverse"> </i>

                                                                    </td>

                                                                    <td class="text-right table-success">
                                                                        @php
                                                                            $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->whereBetween('r.fecha_movimiento',[
                                                                                $inicio,
                                                                                $fin
                                                                            ])->where('codsucursal','=',$sucursal->codsucursal)->where('tipo_movimiento','=','3')->where('estado','=','1')->select(DB::raw('SUM(valor_real) as valor'))->first();
                                                                            $comisionAcumulada = $comisionAcumulada->valor;
                                                                            $totales["consignaciones"]+=$comisionAcumulada;
                                                                        @endphp
                                                                        <b class="text-inverse">$ {{number_format($comisionAcumulada)}}</b>
                                                                        <i class="fas fa-arrow-alt-circle-right text-primary"> </i>

                                                                    </td>

                                                                    <td class="text-right table-danger">
                                                                        @php
                                                                            $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->whereBetween('r.fecha_movimiento',[
                                                                                $inicio,
                                                                                $fin
                                                                            ])->where('codsucursal','=',$sucursal->codsucursal)->where('tipo_movimiento','=','5')->where('estado','=','1')->select(DB::raw('SUM(valor_real) as valor'))->first();
                                                                            $comisionAcumulada = $comisionAcumulada->valor;
                                                                            $totales["facturas"]+=$comisionAcumulada;
                                                                        @endphp
                                                                        <b class="text-inverse">$ {{number_format($comisionAcumulada)}}</b>
                                                                        <i class="fas fa-arrow-alt-circle-right text-primary"> </i>

                                                                    </td>
                                                                    

                                                                    <td class="text-center mar-rgt" style="width: 5%;">

                                                                        <div class="btn-group">

                                                                            <a class="btn btn-sm btn-danger fa fa-print text-white add-tooltip" data-fancybox data-type="iframe" data-fancybox data-type="iframe"  data-src="{{url('sucursal-extracto')}}?m={{base64_encode($sucursal->codsucursal)}}" href="javascript:;"></a>

                                                                            <!-- <a class="btn btn-sm btn-primary btn-hover-success add-tooltip btn-evidencias ti ti-receipt" data-original-title="Registrar Consignación" data-toggle="modal" data-target="#modalFormArchivo" data-codasignatura="{{$sucursal->nombres}}" data-container="body"></a> -->
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            @endforeach
                                                            <tr>
                                                                <td class="table-active text-right font-weight-bold text-inverse">Total</td>
                                                                <td class="table-active text-right font-weight-bold text-inverse">$ {{number_format($totales["saldo"])}}</td>
                                                                <td class="table-active text-right font-weight-bold text-inverse">$ {{number_format($totales["comision"])}}</td>
                                                                <td class="table-active text-right font-weight-bold text-inverse">$ {{number_format($totales["enviado"])}}</td>
                                                                <td class="table-active text-right font-weight-bold text-inverse">$ {{number_format($totales["retirado"])}}</td>
                                                                <td class="table-active text-right font-weight-bold text-inverse">$ {{number_format($totales["enviado"]-$totales["retirado"])}}</td>
                                                                <td class="table-active text-right font-weight-bold text-inverse">$ {{number_format($totales["recargas"])}}</td>
                                                                <td class="table-active text-right font-weight-bold text-inverse">$ {{number_format($totales["consignaciones"])}}</td>
                                                                <td class="table-active text-right font-weight-bold text-inverse">$ {{number_format($totales["facturas"])}}</td>
                                                                <td class="table-active text-right font-weight-bold text-inverse"></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade {{!blank($rangoFechas) ? 'active show' : ''}}" id="default-tab-3">
                    {!!Form::open(['route' => 'sucursal.buscar', 'id'=>'formBuscarEstado', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
                    {{Form::hidden('codsucursal', $sucursal->codsucursal)}}
                        <div class="row">
                        
                            <!-- begin col-6 -->
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>RANGO FECHA ESTADO {{request('rango_fecha')}}</label>
                                    <div class="input-group" id="default-daterange">
                                        <input id="daterange2" type="text" name="rango_fecha" class="form-control" value="{{request('rango_fecha')}}" placeholder="Especifique una fecha a buscar" autocomplete="false" />
                                        <span class="input-group-append">
                                        <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-1">
                                <label>Sucursales</label>
                                <button type="submit" class="btn btn-primary">Buscar</button>
                            </div>
                        </div>
                    {{Form::close()}}
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="panel panel-inverse">
                                <div class="panel-body p-0">
                                    <div class="col-md-12 p-0">
                                        <div class="panel">
                                            <!--===================================================-->
                                            <div class="panel-body p-0">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th class="min-w-td">Datos sucursal</th>
                                                                @foreach($period as $dt)
                                                                    <th class="text-center">{{$dt->format('m-d')}}</th>
                                                                @endforeach
                                                                <th>Resumen</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        @php
                                                            $secuencia = 0;
                                                            $totales = ["saldo"=>0, "comision" =>0, "enviado"=>0, "retirado"=>0, "recargas" => 0, "consignaciones" =>0, "facturas" =>0];
                                                        @endphp
                                                            @foreach(DB::table('sucursales')->orderBy('codsucursal')->get() as $sucursal)
                                                                @php
                                                                    $listCantidad = [0 => 0, 1 => 0];
                                                                    $totales["saldo"]+=$sucursal->saldo;
                                                                    $giros = 0;
                                                                    $secuencia++;
                                                                    $date = Carbon::now();
                                                                    $sucursal = Sucursal::find($sucursal->codsucursal);
                                                                    $horario = $sucursal->horarios();
                                                                    $apertura = $sucursal->aperturas()->whereBetween('fecha', [
                                                                        Carbon::parse(Carbon::today())->format('Y-m-d').' 00:00:00',
                                                                        Carbon::parse(Carbon::today())->format('Y-m-d').' 23:59:59'
                                                                    ])->first();
                                                                    $apertura = blank($apertura) ? null : $apertura;
                                                                    $validar_apertura = !blank($apertura) && !blank($apertura->fecha)&&$date->format('d/m/y')==Carbon::parse($apertura->fecha)->format('d/m/y') ? true : false;
                                                                @endphp
                                                                <tr id="tr-{{$sucursal->codsucursal}}">
                                                                    <td style="min-width: 200px;">
                                                                        <a class="text-inverse" target="_self" name="estadocuenta" href="{{route('sucursal.estado-cuenta',[$sucursal->codsucursal])}}"><b>SUC-{{str_pad($sucursal->codsucursal, 4, "0",STR_PAD_LEFT)}}</b> {{$sucursal->nombres}}</a>
                                                                        <br>{{$sucursal->direccion}}
                                                                        <br>
                                                                        {{$sucursal->municipio}} - {{$sucursal->departamento}}
                                                                        <br>Cupo: <b class="text-inverse">$ {{number_format($sucursal->cupo)}}</b>
                                                                        <br>Saldo: <b class="text-inverse">$ {{number_format($sucursal->saldo)}}</b> {{number_format($sucursal->saldo*100/$sucursal->cupo)}}%
                                                                    </td>
                                                                    @foreach($period as $dt)
                                                                        <td class="text-center" style="min-width: 50px;">
                                                                            @if(Arr::exists($listCajas, $sucursal->codsucursal) && Arr::exists($listCajas[$sucursal->codsucursal], $dt->format('Y-m-d')))
                                                                                @php
                                                                                    $listCantidad[0]++;
                                                                                @endphp
                                                                                <i class="fa fa-unlock text-success" data-toggle="tooltip" data-placement="top" title="{{$listCajas[$sucursal->codsucursal][$dt->format('Y-m-d')]->fecha}}"></i>
                                                                                <i class="fa fa-lock {{blank($listCajas[$sucursal->codsucursal][$dt->format('Y-m-d')]->fecha_cierre) ? 'text-danger' : 'text-success'}}" data-toggle="tooltip" data-placement="top" title="{{$listCajas[$sucursal->codsucursal][$dt->format('Y-m-d')]->fecha_cierre}}"></i>
                                                                            @else
                                                                                <i class="fa fa-times-circle text-danger"></i>
                                                                                @php
                                                                                    $listCantidad[1]++;
                                                                                @endphp
                                                                            @endif
                                                                        </td>
                                                                    @endforeach
                                                                    <td class="text-right">
                                                                        <i class="fa fa-unlock text-success" ></i> {{$listCantidad[0]}}
                                                                        <br><i class="fa fa-times-circle text-danger"></i> {{$listCantidad[1]}}
                                                                    </td>

                                                                    
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="demo-lg-modal" class="modal fade" tabindex="-1">
                <div class="modal-dialog modal-lg" id="form-modal" style="max-width: 90%;">
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')

<script>
    
    $(document).ready(function() {
        
        $('.btn-jornada').change(function(){
            if($(this).prop('checked')){
                $(this).parents('.jornada-contenedor').find(".jornada-normal").hide();
                $(this).parents('.jornada-contenedor').find(".jornada-continua").show();
            }else{
                $(this).parents('.jornada-contenedor').find(".jornada-normal").show();
                $(this).parents('.jornada-contenedor').find(".jornada-continua").hide();
            }
        });

        $('.bloquear-sucursal').click(function(){
            var codsucursal = $(this).data("codsucursal");
            var bloqueo = $(this).data("bloqueo");
            bootbox.confirm({
                message: '<strong>Mensaje de confirmación:</strong> <br><br>¿Esta seguro de bloquear la sucursal?',
                closeButton: false,
                buttons: {
                    confirm: {
                    label: 'Aceptar',
                        className: 'btn-success'
                    },
                    cancel: {
                        label: 'Cancelar',
                        className: 'btn-danger'
                    }
                },
                callback: function (result) {
                    if (result) {
                        $.ajax({
                            url: "{{ url('sucursal/bloqueo') }}",
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            type: 'post',
                            data: {
                                codsucursal: codsucursal,
                                bloqueo: bloqueo
                            },
                            success: function(result){
                                $.gritter.add({title:"Operación realizada con éxito",text:"La sucursal fue bloqueada con éxito"});
                            location.reload();
                            }
                        });
                    }
                }
            });
        });

        $('.abrir-modal').click(function(){
            var codsucursal = $(this).data("codsucursal");
            $.ajax({
                url: "{{ url('sucursal/consultar') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'post',
                data: {
                    codsucursal: codsucursal
                },
                success: function(result){
                    console.log(0);
                    $("#demo-lg-modal").modal("show");
                    $('#form-modal').html(result.formulario);
                }
            });
        });

        $('.abrir-modal-empleados').click(function(){
            var codsucursal = $(this).data("codsucursal");
            $.ajax({
                url: "{{ url('sucursal/consultar-empleados') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'post',
                data: {
                    codsucursal: codsucursal
                },
                success: function(result){
                    console.log(0);
                    $("#demo-lg-modal").modal("show");
                    $('#form-modal').html(result.formulario);
                }
            });
        });

        $('.abrir-modal-horarios').click(function(){
            var codsucursal = $(this).data("codsucursal");
            $.ajax({
                url: "{{ url('sucursal/consultar-horarios') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'post',
                data: {
                    codsucursal: codsucursal
                },
                success: function(result){
                    console.log(0);
                    $("#demo-lg-modal").modal("show");
                    $('#form-modal').html(result.formulario);
                }
            });
        });

        $('.eliminar-sucursal').click(function(){
            var codsucursal = $(this).data("codsucursal");
            var trPadre = $("#tr-"+codsucursal);
            bootbox.confirm({
                message: '<strong>Mensaje de confirmación:</strong> <br><br>¿Esta seguro de eliminar al sucursal?',
                closeButton: false,
                buttons: {
                    confirm: {
                        label: 'Aceptar',
                        className: 'btn-success'
                    },
                    cancel: {
                        label: 'Cancelar',
                        className: 'btn-danger'
                    }
                },
                callback: function (result) {
                    if (result) {
                        $.ajax({
                            url: "{{ url('sucursal/eliminar') }}",
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            type: 'post',
                            data: {
                                codsucursal: codsucursal
                            },
                            success: function(result){
                                $.gritter.add({title:"Operación realizada con éxito",text:"El registro fue eliminado con éxito"});
                                $('table').DataTable().destroy();
                                trPadre.remove();
                                $('table').DataTable({
                                    "aaSorting": []
                                });
                            }
                        });
                    }
                }
            });
        });
        var handleDataTableButtons=function(){"use strict";0!==$("table").length&&$("table").DataTable(
        {
            dom:"Bfrtip",
            "pageLength": 50,
            "aLengthMenu" : [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "bSort": false, 
            "aaSorting": [[0]], 
            buttons:[
                {extend:"copy",className:"btn-sm"},
                {extend:"excel",className:"btn-sm"},
                {extend:"pdf",className:"btn-sm"},
                {extend:"print",className:"btn-sm"}
                ],
                responsive:!0
        }
        )},
        TableManageButtons=function(){"use strict";return{init:function(){handleDataTableButtons()}}}();
        TableManageButtons.init();
    });
    var start = moment().startOf('month');
    var end = moment().endOf('month');
    function cb(start, end) {
        console.log(start.format('DD/MM/YYYY') + ' - ' + end.format('DD/MM/YYYY'));
        @if(blank(request('rango_fecha')))
            $('#daterange').val(start.format('DD/MM/YYYY') + ' - ' + end.format('DD/MM/YYYY'));
            $('#daterange2').val(start.format('DD/MM/YYYY') + ' - ' + end.format('DD/MM/YYYY'));
        @endif
    }
    $('#daterange').daterangepicker({
        locale: {
        format: 'DD/MM/YYYY'
        },
        todayBtn: "linked",
        language: 'es',
        autoclose: true,
        ranges: {
            'Hoy': [moment(), moment()],
            'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Ultimos 7 días': [moment().subtract(6, 'days'), moment()],
            'Ultimos 30 días': [moment().subtract(29, 'days'), moment()],
            'Este mes': [moment().startOf('month'), moment().endOf('month')],
            'El mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },

        todayHighlight: true
    }, cb(start, end));
    $('#daterange2').daterangepicker({
        locale: {
        format: 'DD/MM/YYYY'
        },
        todayBtn: "linked",
        language: 'es',
        autoclose: true,
        ranges: {
            'Hoy': [moment(), moment()],
            'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Ultimos 7 días': [moment().subtract(6, 'days'), moment()],
            'Ultimos 30 días': [moment().subtract(29, 'days'), moment()],
            'Este mes': [moment().startOf('month'), moment().endOf('month')],
            'El mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },

        todayHighlight: true
    }, cb(start, end));
</script>

    

@endsection