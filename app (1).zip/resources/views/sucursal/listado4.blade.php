

@php



    use App\Models\Sucursal;

    use App\Models\Apertura;

    use Carbon\Carbon;

    use Illuminate\Support\Arr;

    use App\Enums\ETipoDocumento;



    $pendientes = 0;

    DB::table('empleados AS e')->whereNotIn('e.codempleado',function($query){
                                                                $query->select('codempleado')->from('rel_empleado_sucursal');
                                                                })->get()

@endphp

@extends('layouts.administrador')

@section('title', 'Sucursales')

@section('titulo-pagina')

    <div id="page-title">

        <h1 class="page-header text-overflow">Administrador sucursales</h1>

    </div>    

@endsection

@section('breadcum')

    <ol class="breadcrumb">

        <li><a href="#"><i class="demo-pli-home"></i></a></li>

        <li class="active">Administrador sucursales</li>

    </ol>

@endsection

@section('content')

    <div class="panel panel-inverse">

        <div class="panel-heading ui-sortable-handle">

            

            <h4 class="panel-title">PUNTOS GIROS AFA</h4>

        </div>

        <div class="panel-body">

            <div class="col-md-12">

                    <div class="panel">

                        <!--===================================================-->

                       <div class="panel-body">

                            <div class="table-responsive">

                                <table class="table table-vcenter mar-top" id="data-table-default">

                                    <thead>

                                        <tr>



                                            <th class="min-w-td">Nombre sucursal</th>

                                            <th class="min-w-td">municipio </th>

                                            <th class="min-w-td">DEPARTAMENTO </th>
                       
                                            <th class="min-w-td">barrio </th> 

                                            <th class="min-w-td">direccion </th> 



                                        </tr>

                                    </thead>

                                    <tbody>

                                    @php

                                        $secuencia = 0;

                                    @endphp

                                        @foreach(DB::table('sucursales')->get() as $sucursal)

                                            @php

                                                $secuencia++;

                                                $date = Carbon::now();

                                                $sucursal = Sucursal::find($sucursal->codsucursal);

                                                $horario = $sucursal->horarios();

                                                $apertura = $sucursal->aperturas()->where('estado','=',1)->first();

                                                $apertura = blank($apertura) ? new Apertura() : $apertura;

                                                $validar_apertura = !blank($apertura->fecha)&&$date->format('d/m/y')==Carbon::parse($apertura->fecha)->format('d/m/y') ? true : false;

                                            @endphp

                                            <tr id="tr-{{$sucursal->codsucursal}}">


                                                <td>

                                                    {{$sucursal->nombres}}

                                                </td>
                                                
                                                  <td>

                                                    {{$sucursal->departamento}}

                                                </td>

                                                <td>

                                                    {{$sucursal->municipio}}

                                                </td>
                                              

                                  
                                                 <td>

                                                    {{$sucursal->barrio}}

                                                </td>
                                                
                                                <td>

                                                    {{$sucursal->direccion}}

                                                </td>
                                          




                                            </tr>

                                        @endforeach

                                        

                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>

                </div>

        </div>

    </div>

    <div id="demo-lg-modal" class="modal fade" tabindex="-1">

        <div class="modal-dialog modal-lg" id="form-modal">

            

        </div>

    </div>

@endsection

@section('script')

<script>


   





  

</script>

    

@endsection