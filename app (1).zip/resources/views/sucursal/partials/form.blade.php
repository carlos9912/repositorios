


@php



    use App\Models\Estudiante;
    use Carbon\Carbon;
    use Illuminate\Support\Arr;
    use App\Enums\ETipoDocumento;
    use App\Enums\EDocumentoSucursal;



    $pendientes = 0;
    $listEmpleados = $sucursal->empleados;

    

@endphp



<style>
.btn-file input[type=file] {
    position: absolute;
    top: 0;
    right: 0;
    min-width: 100%;
    min-height: 100%;
    font-size: 100px;
    text-align: right;
    filter: alpha(opacity=0);
    opacity: 0;
    outline: none;   
    cursor: inherit;
    display: block;
}
</style>    



    

            <div class="modal-content">

                <div class="modal-body">

                    <!-- begin panel -->

					<div class="panel panel-inverse" data-sortable-id="form-stuff-1">

                            <!-- begin panel-heading -->

                            <div class="panel-heading">

                                <div class="panel-heading-btn">

                                </div>

                                <h4 class="panel-title">Creación / información de Sucursales</h4>

                            </div>

                            <!-- end panel-heading -->

                            <!-- begin panel-body -->

                            <div class="panel-body">

                                    {{Form::open(['route' => 'sucursal.crear-sucursal', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarAsignatura', 'enctype'=>'multipart/form-data']) }}  
                                        {!! Form::hidden('codsucursal', $sucursal->codsucursal) !!}
                                        <div class="row">
                                            <div class="col-sm-4" style="border: 1px solid #e2e7eb; padding: 30px; border-bottom-left-radius: 20px; border-top-left-radius: 20px;">
                                                <legend>Datos Básicos</legend>
                                                <div class="row mt-3">
                                                    <div class="col-sm-12">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Nombre del Establecimiento</label>
                                                            {!! Form::text('nombres', $sucursal->nombres, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Municipio</label>
                                                            {!! Form::text('municipio', $sucursal->municipio, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Departamento</label>
                                                            <input type="text" class="form-control" name="departamento" value="{{$sucursal->departamento}}" id="start" autocomplete="off"/>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Celular</label>
                                                            {!! Form::text('celular', $sucursal->celular, ['id'=>'celular','class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off']) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Cupo</label>
                                                            <input type="text" class="form-control " value="{{$sucursal->cupo}}" name="cupo" autocomplete="off"/>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Teléfono Fijo</label>
                                                            {!! Form::text('fijo', $sucursal->fijo, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Correo Electronico</label>
                                                            {!! Form::text('email', $sucursal->email, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'correo' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Dirección</label>
                                                            {!! Form::text('direccion', $sucursal->direccion, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Barrio</label>
                                                            <input type="text" class="form-control " value="{{$sucursal->barrio}}" name="barrio" autocomplete="off"/>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Latitud</label>
                                                            <input type="text" class="form-control " value="{{$sucursal->latitud}}" name="latitud" autocomplete="off"/>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Longitud</label>
                                                            <input type="text" class="form-control " value="{{$sucursal->longitud}}" name="longitud" autocomplete="off"/>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Nit</label>
                                                            <input type="text" class="form-control " value="{{$sucursal->nit}}" name="nit" autocomplete="off"/>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Deposito</label>
                                                            <input type="number" class="form-control " value="{{$sucursal->deposito}}" name="deposito" autocomplete="off"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-3" style="border: 1px solid #e2e7eb; padding: 30px;">
                                                <legend>Datos / Información Representante Legal</legend>
                                                <div class="row mt-3">
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Nombres</label>
                                                            {!! Form::text('nombres_representante', $sucursal->nombres_representante, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Apellidos</label>
                                                            {!! Form::text('apellidos_representante', $sucursal->apellidos_representante, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Cédula</label>
                                                            {!! Form::text('cedula_representante', $sucursal->cedula_representante, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Dirección</label>
                                                            {!! Form::text('direccion_representante', $sucursal->direccion_representante, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Celular</label>
                                                            {!! Form::text('celular_representante', $sucursal->celular_representante, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Email</label>
                                                            {!! Form::text('email_representante', $sucursal->email_representante, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                </div>
                                                <legend>Datos Bancarios</legend>
                                                <div class="row mt-3">
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Tipo Cuenta</label>
                                                            <select class="form-control" name="tipo_cuenta_sucursal">
                                                                <option value="">Seleccione Tipo</option>
                                                                <option value="1" {{$sucursal->tipo_cuenta_sucursal==1 ? "selected" : ""}}>Ahorro</option>
                                                                <option value="2" {{$sucursal->tipo_cuenta_sucursal==2 ? "selected" : ""}}>Corriente</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">Banco</label>
                                                            <select class="form-control" name="banco_sucursal">
                                                                <option value="">Seleccione banco</option>
                                                                <option value="Banco Agrario" {{$sucursal->banco_sucursal=="Banco Agrario" ? "selected" : ""}}>Banco Agrario</option>
                                                                <option value="Bancolombia" {{$sucursal->banco_sucursal=="Bancolombia" ? "selected" : ""}}>Bancolombia</option>
                                                                <option value="Banco de bogota" {{$sucursal->banco_sucursal=="Banco de bogota" ? "selected" : ""}}>Banco de Bogota</option>
                                                                <option value="Davivienda" {{$sucursal->banco_sucursal=="Davivienda" ? "selected" : ""}}>Davivienda</option>
                                                                <option value="Banco Caja Social" {{$sucursal->banco_sucursal=="Banco Caja Social" ? "selected" : ""}}>Banco Caja Social</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <div class="form-group">
                                                            <label for="nombre" style="text-transform: none !important;">No.Cuenta</label>
                                                            {!! Form::text('cuenta_sucursal', $sucursal->cuenta_sucursal, ['class' => 'nombre-menu form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'nombre' ]) !!}
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <div class="row">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-3" style="border: 1px solid #e2e7eb; padding: 30px;  border-bottom-right-radius: 20px; border-top-right-radius: 20px;">
                                                <legend>Documentos</legend>
                                                <div class="row mt-3">
                                                    @foreach(EDocumentoSucursal::data() as $documento)
                                                        @if(Arr::exists($documentos, $documento->getId()))
                                                        <div class="col-sm-6 text-center mb-3" style="border: 1px solid #e2e7eb; border-radius: 10px;">
                                                            <label for=""><small><strong>{{$documento->getDescription()}}</strong></small> </label>
                                                            <br>
                                                            <a class="btn btn-circle mb-3 btn-primary" data-fancybox="" href="{{asset('/documentacion/'.$documentos[$documento->getId()]->ruta)}}">
                                                                <i class="fa fa-search text-white"></i>
                                                            </a>
                                                        </div>
                                                        @else
                                                        <div class="col-sm-6 text-center mb-3" style="border: 1px solid #e2e7eb; border-radius: 10px;">
                                                            <label for=""><small><strong>{{$documento->getDescription()}}</strong></small> </label>
                                                            <br>
                                                            <button class="btn btn-file btn-circle mb-3 btn-danger">
                                                                <i class="fa fa-upload"></i>
                                                                <input type="file" name="documentos[{{$documento->getId()}}]" id="" class="form-control">
                                                            </button>
                                                        </div>
                                                        @endif
                                                        
                                                    @endforeach
                                                </div>
                                            </div>
                                            <div class="col-sm-2">
                                                @if(!blank($sucursal->codsucursal))
                                                    
                                                        <hr>
                                                        
                                                        <div class="widget-list widget-list-rounded m-b-30" data-id="widget">
                                                            <!-- begin widget-list-item -->
                                                            @foreach($listEmpleados as $empleado)
                                                            <div class="widget-list-item">
                                                                <div class="widget-list-media">
                                                                    @if($empleado->cargo==1)
                                                                        <img src="img/icon/admin-icon.png" alt="" class="img-fluid">
                                                                    @else
                                                                        <img src="img/icon/user-icon.png" alt="" class="img-fluid">
                                                                    @endif
                                                                </div>
                                                                <div class="widget-list-content">
                                                                    <h4 class="widget-list-title">{{$empleado->nombres.' '.$empleado->apellidos}}</h4>
                                                                    <p class="widget-list-desc">{{$empleado->identificacion}}</p>
                                                                    <p class="widget-list-desc">LS:</p>
                                                                </div>
                                                                <div class="widget-list-action">
                                                                    <a href="#" data-toggle="dropdown" class="text-muted pull-right"><i class="fa fa-ellipsis-h f-s-14"></i></a>
                                                                    <div class="dropdown-menu dropdown-menu-right">
                                                                        <a href="#" class="dropdown-item">Option 1</a>
                                                                        <a href="#" class="dropdown-item">Option 2</a>
                                                                        <a href="#" class="dropdown-item">Option 3</a>
                                                                        <div class="dropdown-divider"></div>
                                                                        <a href="#" class="dropdown-item">Option 4</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            @endforeach
                                                            <!-- end widget-list-item -->
                                                        </div>
                                                        @if(count($listEmpleados)==0)
                                                            <h5 class="text-center">No hay empleados registrados</h5>
                                                            <hr class="mt-0 mr-0 ml-0 mb-2">
                                                            <p class="text-justify">
                                                                Para añadir un nuevo empleado, seleccione el empleado de la lista de abajo
                                                            </p>
                                                            <hr>
                                                            <div class="form-group row">
                                                                <label class="col-md-4 col-form-label">Empleado</label>
                                                                <div class="col-md-8">
                                                                    <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" id="codempleado" name="codempleado" aria-hidden="true" data-placeholder="Seleccione un empleado">
                                                                        <optgroup label="Empleados">
                                                                        <option></option>
                                                                        <!-- foreach(DB::table('empleados AS e')->leftJoin('rel_empleado_sucursal AS r','r.codempleado','=','e.codempleado')->where('r.codsucursal','<>',$sucursal->codsucursal)->get() as $estudiante) -->
                                                                        @foreach(DB::table('empleados AS e')->whereNotIn('e.codempleado',function($query){
                                                                                $query->select('codempleado')->from('rel_empleado_sucursal');
                                                                                })->get() as $empleado)
                                                                            <option value="{{$empleado->codempleado}}">{{$empleado->nombres.' '.$empleado->apellidos}}</option>
                                                                        @endforeach
                                                                        </optgroup>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-md-4 col-form-label">Cargo</label>
                                                                <div class="col-md-8">
                                                                    <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" aria-hidden="true" id="cargo" name="cargo" data-placeholder="Seleccione un cargo">
                                                                        <optgroup label="Empleados">
                                                                            <option></option>
                                                                            <option value="1">Administrador</option>
                                                                            <option value="2">Cajero</option>
                                                                        </optgroup>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row m-b-15">
                                                            </div>
                                                            <div class="form-group">
                                                                <button class="btn btn-primary btn-vincular" type="button">Vincular Empleado</button>
                                                            </div>
                                                        @endif
                                                @endif
                                            </div>
                                        </div>

                                        <div class="form-group" style="margin-top: 15px;">
                                            <button class="btn btn-primary" type="submit">Guardar sucursal</button>
                                        </div>

                                                

                                    {{Form::close()}}

                            </div>

                            <!-- end panel-body -->

                        </div>

                        <!-- end panel -->

                </div>

            </div>



<script>

    

    //$('.datepicker').datepicker();

    $("#agregarAsignatura").validate({

        ignore: ":not(.chosen-select):checkbox",

        submitHandler: function(form) {
            $(".loader2").show();
            form.submit();

            return false;

        },

        rules: {

            nombres: 'required',

            apellidos: 'required',

            tipo_documento: 'required',

            identificacion: 'required',

            direccion: 'required',

            ciudad: 'required',

            departamento: 'required',

            fijo: 'required',

            fecha_expedicion: 'required',

            fecha_nacimimento: 'required',

            ocupacion: 'required',

            celular: 'required'

        },

        highlight: function (element, errorClass) {

          $(element).parent().addClass('has-feedback has-error');

          $(element).parent().removeClass('has-feedback has-success');

        },

        unhighlight: function (element, errorClass) {

          $(element).parent().removeClass('has-feedback has-error');

          $(element).parent().addClass('has-feedback has-success');

        },

        errorPlacement: function(error, element) {

            if(element.hasClass("no-label")){



            } else if(element.parents('.input-group').length > 0) {

                error.insertAfter(element.parents('.input-group'));

            } else if(element.parents('.form-group').find('.chosen-container').length > 0){

                

            } else if(element.parents('.radio').find('.chosen-container').length > 0){

                error.insertAfter(element.parents('.radio').find('.chosen-container'));

            } else {

                error.insertAfter(element);

            }

        }

    });

    

</script>

    