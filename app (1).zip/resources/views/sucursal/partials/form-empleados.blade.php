

@php



    use App\Models\Estudiante;
    use Carbon\Carbon;
    use Illuminate\Support\Arr;
    use App\Enums\ETipoDocumento;
    $pendientes = 0;
    $listEmpleados = $sucursal->empleados;

@endphp



    

    

            <div class="modal-content">
                <div class="modal-body">
                    <!-- begin panel -->
					<div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                            <!-- begin panel-heading -->
                            <div class="panel-heading">
                                <div class="panel-heading-btn">
                                </div>
                                <h4 class="panel-title">Empleados de Sucursales</h4>
                            </div>
                            <!-- end panel-heading -->
                            <!-- begin panel-body -->
                            <div class="panel-body">
                                    {{Form::open(['route' => 'sucursal.vincular-empleado', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarEmpleado']) }}  
                                        {!! Form::hidden('codsucursal', $sucursal->codsucursal) !!}
                                        <h4 class="text-center">{{$sucursal->nombres}}</h4>
                                        <hr>
                                        @if(count($listEmpleados)>0)
                                            <table class="table table-bordered widget-table widget-table-rounded" data-id="widget">
                    							<thead>
                    								<tr>
                    									<th width="1%">Cargo</th>
                    									<th>Nombre</th>
                    									<th>Estado</th>
                    									<th>Ultima Sesion</th>
                    									<th ccc>...</th>
                    								</tr>
                    							</thead>
                    							<tbody>
                                                @foreach($listEmpleados as $empleado)
                    								<tr>
                    									<td>
                                                            @if($empleado->cargo==1)
                                                                <img src="img/icon/admin-icon.png" alt="" class="img-fluid">
                                                            @else
                                                                <img src="img/icon/user-icon.png" alt="" class="img-fluid">
                                                            @endif
                    									</td>
                    									<td>
                    										<h4 class="widget-table-title">{{$empleado->nombres.' '.$empleado->apellidos}}</h4>
                    										<p class="widget-table-desc m-b-15">{{$empleado->identificacion}}</p>
                    									</td>
                    									<td class="text-nowrap">
                    									@if($empleado->estado==1)
                                                        <span class="label label-green">Activo</span>
                                                        @else
                                                        <span class="label label-danger">Inactivo</span>
                                                        @endif
                                                        </td>
                    									<td>
                    									-
                                                        </td>
                    									<td class="text-center">
                    										<a href="#" class="btn btn-inverse btn-sm" data-id="widget-elm" data-light-class="btn btn-inverse btn-sm" data-dark-class="btn btn-default btn-sm width-80 rounded-corner">Editar</a>
                    									</td>
                    								</tr>                           
                                                @endforeach
                    							</tbody>
                    						</table>
                                            <hr>
                                            <div class="panel panel-info" data-sortable-id="ui-general-1">
                                                <!-- begin panel-heading -->
                                                <div class="panel-heading">
                                                    <h4 class="panel-title"
                                                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-plus-circle"></i> Añadir nuevo empleado</a>
                                                    </h4>
                                                </div>
                                                <!-- end panel-heading -->
                                                <!-- begin panel-body -->
                                                <div class="panel-body" style="display: none;">
                                                    <div class="form-group row">
                                                        <label class="col-md-4 col-form-label">Empleado</label>
                                                        <div class="col-md-8">
                                                            <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" id="codempleado" name="codempleado" aria-hidden="true" data-placeholder="Seleccione un empleado">
                                                                <optgroup label="Empleados">
                                                                <option></option>
                                                                <!-- foreach(DB::table('empleados AS e')->leftJoin('rel_empleado_sucursal AS r','r.codempleado','=','e.codempleado')->where('r.codsucursal','<>',$sucursal->codsucursal)->get() as $estudiante) -->
                                                                @foreach(DB::table('empleados AS e')->whereNotIn('e.codempleado',function($query){
                                                                $query->select('codempleado')->from('rel_empleado_sucursal');
                                                                })->get() as $empleado)
                                                                    <option value="{{$empleado->codempleado}}">{{$empleado->nombres.' '.$empleado->apellidos}}</option>
                                                                @endforeach
                                                                </optgroup>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-md-4 col-form-label">Cargo</label>
                                                        <div class="col-md-8">
                                                            <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" aria-hidden="true" id="cargo" name="cargo" data-placeholder="Seleccione un cargo">
                                                                <optgroup label="Empleados">
                                                                    <option></option>
                                                                    <option value="1">Administrador</option>
                                                                    <option value="2">Cajero</option>
                                                                </optgroup>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row m-b-15">
                                                    </div>
                                                    <div class="form-group">
                                                        <button class="btn btn-primary btn-vincular" type="button">Vincular Empleado</button>
                                                    </div>
                                                </div>
                                                <!-- end panel-body -->
                                            </div>
                                            <!-- end panel -->
                                        @else
                                            <div class="note note-danger m-b-15">
                                                <div class="note-icon"><i class="fa fa-lightbulb"></i></div>
                                                <div class="note-content text-center">
                                                    <h4><b>No hay empleados asociados a esta sucursal!</b></h4>
                                                    <p>
                                                        Para añadir un nuevo empleado, seleccione el empleado de la lista de abajo
                                                    </p>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label">Empleado</label>
                                                <div class="col-md-8">
                                                    <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" id="codempleado" name="codempleado" aria-hidden="true" data-placeholder="Seleccione un empleado">
                                                        <optgroup label="Empleados">
                                                        <option></option>
                                                        <!-- foreach(DB::table('empleados AS e')->leftJoin('rel_empleado_sucursal AS r','r.codempleado','=','e.codempleado')->where('r.codsucursal','<>',$sucursal->codsucursal)->get() as $estudiante) -->
                                                        @foreach(DB::table('empleados AS e')->whereNotIn('e.codempleado',function($query){
                                                                $query->select('codempleado')->from('rel_empleado_sucursal');
                                                                })->get() as $empleado)
                                                            <option value="{{$empleado->codempleado}}">{{$empleado->nombres.' '.$empleado->apellidos}}</option>
                                                        @endforeach
                                                        </optgroup>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label">Cargo</label>
                                                <div class="col-md-8">
                                                    <select class="default-select2 form-control select2-hidden-accessible" tabindex="-1" aria-hidden="true" id="cargo" name="cargo" data-placeholder="Seleccione un cargo">
                                                        <optgroup label="Empleados">
                                                            <option></option>
                                                            <option value="1">Administrador</option>
                                                            <option value="2">Cajero</option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row m-b-15">
                                            </div>
                                            <div class="form-group">
                                                <button class="btn btn-primary btn-vincular" type="button">Vincular Empleado</button>
                                            </div>
                                        @endif
                                    {{Form::close()}}
                            </div>
                            <!-- end panel-body -->
                        </div>
                        <!-- end panel -->
                </div>
            </div>
<script>
    $(".btn-vincular").click(function(){
        $.ajax({
            url: "{{ url('sucursal/vincular-empleado') }}",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'post',
            data: {
                codsucursal: {{$sucursal->codsucursal}},
                codempleado: $("#codempleado").val(),
                cargo: $("#cargo").val()
            },
            success: function(result){
                console.log(0);
                //$("#demo-lg-modal").modal("show");
                $('#form-modal').html(result.formulario);
            }
        });
    });
    $(".default-select2").chosen();
    $(".chosen-container").css("width","100%");
    //$('.datepicker').datepicker();
    $("#agregarEmpleado").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            form.submit();
            return false;
        },
        rules: {
            nombres: 'required',
            apellidos: 'required',
            tipo_documento: 'required',
            identificacion: 'required',
            direccion: 'required',
            ciudad: 'required',
            departamento: 'required',
            fijo: 'required',
            fecha_expedicion: 'required',
            fecha_nacimimento: 'required',
            ocupacion: 'required',
            celular: 'required'
        },
        highlight: function (element, errorClass) {
          $(element).parent().addClass('has-feedback has-error');
          $(element).parent().removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parent().removeClass('has-feedback has-error');
          $(element).parent().addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.hasClass("no-label")){
            } else if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
</script>
    