
@php

    use App\Models\Estudiante;
    use App\Models\Horario;
    use Carbon\Carbon;
    use Illuminate\Support\Arr;
    use App\Enums\ETipoDocumento;

    $pendientes = 0;
    $horario = $sucursal->horarios()->first();
    $horario = blank($horario) ? new Horario() : $horario;
@endphp

    
            <div class="modal-content">
                <div class="modal-body">
                    <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                        {{Form::open(['route' => 'sucursal.asignar-horario', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarAsignatura']) }}  
                            {!! Form::hidden('codsucursal', $sucursal->codsucursal) !!}
                            {!! Form::hidden('codhorario', $horario->codhorario) !!}
                            <!-- end panel-heading -->
                            <!-- begin panel-body -->
                            <div class="panel-body">
                                <div class="card">
                                    <div class="card-header bg-black text-white pointer-cursor">
                                        Horario de Lunes a Viernes
                                    </div>
                                    <div>
                                        <div class="card-body py-2">
                                            <div class="jornada-contenedor">
                                                <div class="form-group row">
                                                    <div class="col-md-5">
                                                        <div class="checkbox checkbox-css">
                                                            <input type="checkbox" name="jornada_continua_lv" id="jornada_continua_lv"  class="btn-jornada" value="1" {{$horario->jornada_continua_lv==1 ? 'checked' : ''}}>
                                                            <label for="jornada_continua_lv">Jornada Continua?</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-7 text-right">
                                                        <button class="btn btn-sm btn-danger btn-limpiar" type="button"><i class="fa fa-trash"></i></button>
                                                    </div>
                                                </div>
                                                <hr>
                                                <div class="form-group row m-b-15 jornada-normal" style="{{$horario->jornada_continua_lv==1 ? 'display: none;' : ''}}" >
                                                    <label class="col-md-4 col-form-label">Horario Mañana</label>
                                                    <div class="col-md-8">
                                                        <div class="input-group input-daterange">
                                                            <input type="text" class="form-control datepicker" name="horario_m_lv" placeholder="Seleccione el horario" value="{{$horario->horario_m_lv}}" data-value="{{$horario->horario_m_lv}}"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group row m-b-15 jornada-normal" style="{{$horario->jornada_continua_lv==1 ? 'display: none; ' : ''}}" >
                                                    <label class="col-md-4 col-form-label">Horario Tarde</label>
                                                    <div class="col-md-8">
                                                        <div class="input-group input-daterange">
                                                            <input type="text" class="form-control datepicker" name="horario_t_lv" placeholder="Seleccione el horario" value="{{$horario->horario_t_lv}}" data-value="{{$horario->horario_t_lv}}"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group row m-b-15 jornada-continua" style="{{$horario->jornada_continua_lv!=1 ? 'display: none;' : ''}}" >
                                                    <label class="col-md-4 col-form-label">Horario del Día</label>
                                                    <div class="col-md-8">
                                                        <div class="input-group input-daterange">
                                                            <input type="text" class="form-control datepicker" name="horario_c_lv" placeholder="Seleccione el horario" value="{{$horario->horario_c_lv}}" data-value="{{$horario->horario_c_lv}}"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="accordion" class="card-accordion">
                                    <!-- begin card -->
                                    
                                    <!-- end card -->
                                    <!-- begin card -->
                                    <div class="card">
                                        <div class="card-header bg-black text-white pointer-cursor collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false">
                                            Horario sábados
                                        </div>
                                        <div id="collapseTwo" class="collapse show" data-parent="#accordion" style="">
                                            <div class="card-body py-2">
                                                <div class="jornada-contenedor">
                                                    <div class="form-group row">
                                                        <div class="col-md-5">
                                                            <div class="checkbox checkbox-css">
                                                                <input type="checkbox" name="jornada_continua_s" id="jornada_continua_s" class="btn-jornada" value="1" value="1" {{$horario->jornada_continua_s==1 ? 'checked' : ''}}>
                                                                <label for="jornada_continua_s">Jornada Continua?</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-7 text-right">
                                                            <button class="btn btn-sm btn-danger btn-limpiar" type="button"><i class="fa fa-trash"></i></button>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <div class="form-group row m-b-15 jornada-normal" style="{{$horario->jornada_continua_s==1 ? 'display: none;' : ''}}">
                                                        <label class="col-md-4 col-form-label">Horario Mañana</label>
                                                        <div class="col-md-8">
                                                            <div class="input-group input-daterange">
                                                                <input type="text" class="form-control datepicker" name="horario_m_s" placeholder="Seleccione el horario" value="{{$horario->horario_m_s}}" data-value="{{$horario->horario_m_s}}"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row m-b-15 jornada-normal" style="{{$horario->jornada_continua_s==1 ? 'display: none; ' : ''}}">
                                                        <label class="col-md-4 col-form-label">Horario Tarde</label>
                                                        <div class="col-md-8">
                                                            <div class="input-group input-daterange">
                                                                <input type="text" class="form-control datepicker" name="horario_t_s" placeholder="Seleccione el horario" value="{{$horario->horario_t_s}}" data-value="{{$horario->horario_t_s}}"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row m-b-15 jornada-continua" style="{{$horario->jornada_continua_s!=1 ? 'display: none;' : ''}}" >
                                                        <label class="col-md-4 col-form-label">Horario del Día</label>
                                                        <div class="col-md-8">
                                                            <div class="input-group input-daterange">
                                                                <input type="text" class="form-control datepicker" name="horario_c_s" placeholder="Seleccione el horario" value="{{$horario->horario_c_s}}" data-value="{{$horario->horario_c_s}}"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end card -->
                                    <!-- begin card -->
                                    <div class="card">
                                        <div class="card-header bg-black text-white pointer-cursor collapsed" data-toggle="collapse" data-target="#collapseThree">
                                            Horarios domingos
                                        </div>
                                        <div id="collapseThree" class="collapse show" data-parent="#accordion">
                                            <div class="card-body py-2">
                                                <div class="jornada-contenedor">
                                                    <div class="form-group row">
                                                        <div class="col-md-5">
                                                            <div class="checkbox checkbox-css">
                                                                <input type="checkbox" name="jornada_continua_d" id="jornada_continua_d" class="btn-jornada" value="1" {{$horario->jornada_continua_d==1 ? 'checked' : ''}}>
                                                                <label for="jornada_continua_d">Jornada Continua?</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-7 text-right">
                                                            <button class="btn btn-sm btn-danger btn-limpiar" type="button"><i class="fa fa-trash"></i></button>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <div class="form-group row m-b-15 jornada-normal" style="{{$horario->jornada_continua_d==1 ? 'display: none;' : ''}}">
                                                        <label class="col-md-4 col-form-label">Horario Mañana</label>
                                                        <div class="col-md-8">
                                                            <div class="input-group input-daterange">
                                                                <input type="text" class="form-control datepicker" name="horario_m_d" placeholder="Seleccione el horario" value="{{$horario->horario_m_d}}" data-value="{{$horario->horario_m_d}}"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row m-b-15 jornada-normal" style="{{$horario->jornada_continua_d==1 ? 'display: none; ' : ''}}">
                                                        <label class="col-md-4 col-form-label">Horario Tarde</label>
                                                        <div class="col-md-8">
                                                            <div class="input-group input-daterange">
                                                                <input type="text" class="form-control datepicker" name="horario_t_d" placeholder="Seleccione el horario" value="{{$horario->horario_t_d}}" data-value="{{$horario->horario_t_d}}"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row m-b-15 jornada-continua" style="{{$horario->jornada_continua_d!=1 ? 'display: none;' : ''}}" >
                                                        <label class="col-md-4 col-form-label">Horario del Día</label>
                                                        <div class="col-md-8">
                                                            <div class="input-group input-daterange">
                                                                <input type="text" class="form-control datepicker" name="horario_c_d" placeholder="Seleccione el horario" value="{{$horario->horario_c_d}}"/data-value="{{$horario->horario_c_d}}">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end card -->
                                    
                                </div>
                                        
                                        
                                        
                                        
                                        <div class="form-group row m-b-15">
                                        </div>
                                        <div class="form-group">
                                            <button class="btn btn-primary" type="submit">Guardar sucursal</button>
                                        </div>
                                             
                            </div>
                            <!-- end panel-body -->
                        {{Form::close()}}
                    </div>
                </div>
            </div>

            <script src="color/assets/plugins/bootstrap-daterangepicker/moment.js"></script>
	<script src="{{asset('color/assets/plugins/bootstrap-daterangepicker/daterangepicker.js')}}"></script>
<script>
$(function(){
    $('.btn-jornada').change(function(){
    if($(this).prop('checked')){
        $(this).parents('.jornada-contenedor').find(".jornada-normal").hide();
        $(this).parents('.jornada-contenedor').find(".jornada-continua").show();
    }else{
        $(this).parents('.jornada-contenedor').find(".jornada-normal").show();
        $(this).parents('.jornada-contenedor').find(".jornada-continua").hide();
    }
});
$('.btn-limpiar').click(function(){
    $(this).closest('.card-body').find('input').val('');
});
    $('.datepicker').daterangepicker({
        timePicker: true,
        timePicker24Hour: false,
        timePickerIncrement: 1,
        timePickerSeconds: false,
        locale: {
            format: 'h:mm a.'
        }
    }).on('show.daterangepicker', function (ev, picker) {
        picker.container.find(".calendar-table").hide();
    });
    $('.datepicker').each(function(){
        if($(this).data('value')==''){
            $(this).val('');
        }
    })
})
    $(".btn-vincular").click(function(){
        $.ajax({
            url: "{{ url('sucursal/vincular-empleado') }}",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'post',
            data: {
                codsucursal: {{$sucursal->codsucursal}},
                codempleado: $("#codempleado").val(),
                cargo: $("#cargo").val()
            },
            success: function(result){
                console.log(0);
                //$("#demo-lg-modal").modal("show");
                $('#form-modal').html(result.formulario);
            }
        });
    });
    $(".default-select2").chosen();
    $(".chosen-container").css("width","100%");
    //$('.datepicker').datepicker();
    $("#agregarAsignatura").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            $.ajax({
            url: "{{ url('sucursal/asignar-horario') }}",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'post',
            data: $("#agregarAsignatura").serialize(),
            success: function(result){
                console.log(0);
                //$("#demo-lg-modal").modal("show");
                $.gritter.add({title:"Operación realizada con éxito",text:"El horario fue registrado con éxito"});
                $('#form-modal').html(result.formulario);
            }
        });
            return false;
        },
        rules: {
            
            horario_m_lv: {
                required: function () { return !$('#jornada_continua_lv').prop('checked'); }
            },
            horario_t_lv: {
                required: function () { return !$('#jornada_continua_lv').prop('checked'); }
            },
            horario_c_lv: {
                required: function () { return $('#jornada_continua_lv').prop('checked'); }
            },

            horario_c_s: {
                required: function () { return $('#jornada_continua_s').prop('checked'); }
            },
            
            horario_c_d: {
                required: function () { return $('#jornada_continua_d').prop('checked'); }
            }
        },
        highlight: function (element, errorClass) {
          $(element).parent().addClass('has-feedback has-error');
          $(element).parent().removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
          $(element).parent().removeClass('has-feedback has-error');
          $(element).parent().addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.hasClass("no-label")){

            } else if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
</script>
    