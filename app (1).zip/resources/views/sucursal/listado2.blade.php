

@php



    use App\Models\Sucursal;

    use App\Models\Apertura;

    use Carbon\Carbon;

    use Illuminate\Support\Arr;

    use App\Enums\ETipoDocumento;



    $pendientes = 0;

    DB::table('empleados AS e')->whereNotIn('e.codempleado',function($query){
                                                                $query->select('codempleado')->from('rel_empleado_sucursal');
                                                                })->get();
    $cantSucursales = DB::table('sucursales')->select(DB::raw('COUNT(*) as cantidad'))->first();
    $cantSucursales = $cantSucursales->cantidad;
    $ListSucursales = [];
    foreach(DB::table('sucursales')->orderBy("departamento")->get() as $sucursal){
        $ListSucursales[($sucursal->departamento)][($sucursal->municipio)][] = $sucursal;
        
    }
@endphp

@extends('layouts.administrador')

@section('title', 'Sucursales')

@section('titulo-pagina')

    <div id="page-title">

        <h1 class="page-header text-overflow">Administrador sucursales</h1>

    </div>    

@endsection

@section('breadcum')

    <ol class="breadcrumb">

        <li><a href="#"><i class="demo-pli-home"></i></a></li>

        <li class="active">Administrador sucursales</li>

    </ol>

@endsection

@section('content')
<div class="row">
    <div class="col-xl-4 col-lg-6">
		<!-- begin card -->
		<div class="card border-0 bg-dark text-white mb-3">
			<!-- begin card-body -->
			<div class="card-body">
				<!-- begin title -->
				<div class="mb-3 text-grey">
					<b>Nuevos puntos</b>
				</div>
				<!-- end title -->
				@foreach(DB::table('sucursales')->orderBy('codsucursal','desc')->limit(3)->get() as $suc)
				<!-- begin row -->
				<div class="row align-items-center p-b-1">
					<!-- begin col-4 -->
					
					<!-- end col-4 -->
					<!-- begin col-8 -->
					<div class="col-8">
						<div class="m-b-2 text-truncate">
						    <b>SUC-{{str_pad($suc->codsucursal, 4, "0",STR_PAD_LEFT)}}</b>
                            {{$suc->nombres}}
						</div>
						<div class="text-grey m-b-2 f-s-11">{{$suc->direccion}} {{$suc->barrio}}</div>
						<div class="text-grey m-b-2 f-s-11">{{$suc->municipio}}, {{$suc->departamento}}</div>
					</div>
					<!-- end col-8 -->
				</div>
				<!-- end row -->
				<hr class="bg-white-transparent-2 m-t-20 m-b-20">
				@endforeach
			</div>
			<!-- end card-body -->
		</div>
		<!-- end card -->
		<div class="card border-0 bg-dark text-white text-truncate mb-3">
			<!-- begin card-body -->
			<div class="card-body">
				<!-- begin title -->
				<div class="mb-3 text-grey">
					<b class="mb-3">Total de sucursales</b> 
				</div>
				<!-- end title -->
				<!-- begin store-session -->
				<div class="d-flex align-items-center mb-1">
					<h2 class="text-white mb-0"><span data-animation="number" data-value="70719">{{$cantSucursales}}</span></h2>
					<div class="ml-auto" style="position: relative;">
						<div id="store-session-sparkline" style="min-height: 28px;"><div id="apexchartsyze8kiu8" class="apexcharts-canvas apexchartsyze8kiu8 light" style="width: 160px; height: 28px;"><svg id="SvgjsSvg1068" width="160" height="28" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG1070" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs1069"><clipPath id="gridRectMaskyze8kiu8"><rect id="SvgjsRect1075" width="163" height="31" x="-1.5" y="-1.5" rx="0" ry="0" fill="#ffffff" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect></clipPath><clipPath id="gridRectMarkerMaskyze8kiu8"><rect id="SvgjsRect1076" width="162" height="30" x="-1" y="-1" rx="0" ry="0" fill="#ffffff" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect></clipPath><linearGradient id="SvgjsLinearGradient1082" x1="0" y1="1" x2="1" y2="1"><stop id="SvgjsStop1083" stop-opacity="1" stop-color="#00acac" offset="0"></stop><stop id="SvgjsStop1084" stop-opacity="1" stop-color="#348fe2" offset="0.5"></stop><stop id="SvgjsStop1085" stop-opacity="1" stop-color="#5ac8fa" offset="1"></stop></linearGradient></defs><line id="SvgjsLine1074" x1="0" y1="0" x2="0" y2="28" stroke="#b6b6b6" stroke-dasharray="3" class="apexcharts-xcrosshairs" x="0" y="0" width="1" height="28" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line><g id="SvgjsG1087" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG1088" class="apexcharts-xaxis-texts-g" transform="translate(0, 1.875)"></g></g><g id="SvgjsG1091" class="apexcharts-grid"><line id="SvgjsLine1093" x1="0" y1="28" x2="160" y2="28" stroke="transparent" stroke-dasharray="0"></line><line id="SvgjsLine1092" x1="0" y1="1" x2="0" y2="28" stroke="transparent" stroke-dasharray="0"></line></g><g id="SvgjsG1078" class="apexcharts-line-series apexcharts-plot-series"><g id="SvgjsG1079" class="apexcharts-series" seriesName="seriesx1" data:longestSeries="true" rel="1" data:realIndex="0"><path id="SvgjsPath1086" d="M0 11.158000000000001C9.333333333333334 11.158000000000001 17.333333333333336 9.124499999999998 26.666666666666668 9.124499999999998C36 9.124499999999998 44 23.4115 53.333333333333336 23.4115C62.66666666666667 23.4115 70.66666666666667 25.081 80 25.081C89.33333333333333 25.081 97.33333333333334 15.358000000000004 106.66666666666667 15.358000000000004C116 15.358000000000004 124.00000000000001 9.800000000000004 133.33333333333334 9.800000000000004C142.66666666666669 9.800000000000004 150.66666666666669 1.5504999999999995 160 1.5504999999999995C160 1.5504999999999995 160 1.5504999999999995 160 1.5504999999999995 " fill="none" fill-opacity="1" stroke="url(#SvgjsLinearGradient1082)" stroke-opacity="1" stroke-linecap="butt" stroke-width="3" stroke-dasharray="0" class="apexcharts-line" index="0" clip-path="url(#gridRectMaskyze8kiu8)" pathTo="M 0 11.158000000000001C 9.333333333333334 11.158000000000001 17.333333333333336 9.124499999999998 26.666666666666668 9.124499999999998C 36 9.124499999999998 44 23.4115 53.333333333333336 23.4115C 62.66666666666667 23.4115 70.66666666666667 25.081 80 25.081C 89.33333333333333 25.081 97.33333333333334 15.358000000000004 106.66666666666667 15.358000000000004C 116 15.358000000000004 124.00000000000001 9.800000000000004 133.33333333333334 9.800000000000004C 142.66666666666669 9.800000000000004 150.66666666666669 1.5504999999999995 160 1.5504999999999995" pathFrom="M -1 49L -1 49L 26.666666666666668 49L 53.333333333333336 49L 80 49L 106.66666666666667 49L 133.33333333333334 49L 160 49"></path><g id="SvgjsG1080" class="apexcharts-series-markers-wrap"><g class="apexcharts-series-markers"><circle id="SvgjsCircle1099" r="0" cx="0" cy="0" class="apexcharts-marker w99yak2ank no-pointer-events" stroke="#ffffff" fill="#008ffb" fill-opacity="1" stroke-width="2" stroke-opacity="0.9" default-marker-size="0"></circle></g></g><g id="SvgjsG1081" class="apexcharts-datalabels"></g></g></g><line id="SvgjsLine1094" x1="0" y1="0" x2="160" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine1095" x1="0" y1="0" x2="160" y2="0" stroke-dasharray="0" stroke-width="0" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG1096" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG1097" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG1098" class="apexcharts-point-annotations"></g></g><rect id="SvgjsRect1073" width="0" height="0" x="0" y="0" rx="0" ry="0" fill="#fefefe" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect><g id="SvgjsG1089" class="apexcharts-yaxis" rel="0" transform="translate(-21, 0)"><g id="SvgjsG1090" class="apexcharts-yaxis-texts-g"></g></g></svg><div class="apexcharts-legend"></div><div class="apexcharts-tooltip dark"><div class="apexcharts-tooltip-series-group"><span class="apexcharts-tooltip-marker" style="background-color: rgb(0, 143, 251);"></span><div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-label"></span><span class="apexcharts-tooltip-text-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div></div></div></div>
					<div class="resize-triggers"><div class="expand-trigger"><div style="width: 161px; height: 29px;"></div></div><div class="contract-trigger"></div></div></div>
				</div>
				<!-- end store-session -->
				<!-- begin percentage -->
				<div class="mb-4 text-grey">
					<i class="fa fa-caret-up"></i> <span data-animation="number" data-value="9.5">17.5</span>% en comparación a la semana anterior
				</div>
				<!-- end percentage -->
				<!-- begin info-row -->
				<div class="d-flex mb-2">
					<div class="d-flex align-items-center">
						<i class="fa fa-circle text-teal f-s-8 mr-2"></i>
						Sucursales pendiente de aprobación
					</div>
					<div class="d-flex align-items-center ml-auto">
						<div class="width-50 text-right pl-2 f-w-600"><span data-animation="number" data-value="53210">26</span></div>
					</div>
				</div>
				<!-- end info-row -->
				<!-- begin info-row -->
				<div class="d-flex mb-2">
					<div class="d-flex align-items-center">
						<i class="fa fa-circle text-blue f-s-8 mr-2"></i>
						Sucursales con documentos pendientes
					</div>
					<div class="d-flex align-items-center ml-auto">
						<div class="width-50 text-right pl-2 f-w-600"><span data-animation="number" data-value="11959">12</span></div>
					</div>
				</div>
				<!-- end info-row -->
				<!-- begin info-row -->
				<div class="d-flex">
					<div class="d-flex align-items-center">
						<i class="fa fa-circle text-aqua f-s-8 mr-2"></i>
						TOTAL DE PUNTOS PENDIENTES POR HABILITAR
					</div>
					<div class="d-flex align-items-center ml-auto">
						<div class="width-50 text-right pl-2 f-w-600"><span data-animation="number" data-value="5545">38</span></div>
					</div>
				</div>
				<!-- end info-row -->
			</div>
			<!-- end card-body -->
		</div>
	</div>
    <div class="col-sm-8">
        <div class="panel panel-inverse">
            <div class="panel-heading ui-sortable-handle">
                <h4 class="panel-title">Información de Puntos - GIROS AFA</h4>
            </div>
            <div class="panel-body">
                <div class="panel">
                            <!--===================================================-->
                   <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-vcenter mar-top" id="data-table-default">
                                <thead>
                                    <tr>
                                        <th class="min-w-td">Nombre sucursal</th>
                                        <th class="min-w-td">direccion </th> 
                                        <th class="min-w-td">municipio </th>
                                        <th class="min-w-td">DEPARTAMENTO </th>
                                    </tr>
                                </thead>
                                <tbody>
                                @php
                                    $secuencia = -1;
                                    $departamentoAnterior = "";
                                    $colores = array("table-active", "table-info", "table-success", "table-warning");
                                @endphp
                                    @foreach(DB::table('sucursales')->orderByRaw("departamento asc, municipio ASC")->get() as $sucursal)
                                        @php
                                            if(strtoupper($sucursal->departamento)!=strtoupper($departamentoAnterior)){
                                                $secuencia++;
                                                $departamentoAnterior = strtoupper($sucursal->departamento);
                                            }
                                            if($secuencia>3){
                                                $secuencia = 0;
                                            }
                                            
                                            
                                            $date = Carbon::now();
                                            $sucursal = Sucursal::find($sucursal->codsucursal);
                                            $horario = $sucursal->horarios();
                                            $apertura = $sucursal->aperturas()->where('estado','=',1)->first();
                                            $apertura = blank($apertura) ? new Apertura() : $apertura;
                                            $validar_apertura = !blank($apertura->fecha)&&$date->format('d/m/y')==Carbon::parse($apertura->fecha)->format('d/m/y') ? true : false;
                                        @endphp

                                        <tr id="tr-{{$sucursal->codsucursal}}">
                                            <td>
                                                <b>SUC-{{str_pad($sucursal->codsucursal, 4, "0",STR_PAD_LEFT)}}</b>
                                                <br>{{$sucursal->nombres}}
                                            </td>
                                            <td>
                                                {{$sucursal->direccion}}
                                                <br>{{$sucursal->barrio}}
                                            </td>
                                            <td>
                                                {{$sucursal->municipio}}
                                            </td>
                                            <td class="{{$colores[$secuencia]}}">
                                                <b>{{$sucursal->departamento}}</b>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    

    <div id="demo-lg-modal" class="modal fade" tabindex="-1">

        <div class="modal-dialog modal-lg" id="form-modal">

            

        </div>

    </div>

@endsection

@section('script')

<script>

var handleDataTableButtons=function(){"use strict";0!==$("table").length&&$("table").DataTable(
        {
            "pageLength": 50,
            "aLengthMenu" : [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "bSort": false, 
            "aaSorting": [[0]], 
            buttons:[
                {extend:"copy",className:"btn-sm"},
                {extend:"excel",className:"btn-sm"},
                {extend:"pdf",className:"btn-sm"},
                {extend:"print",className:"btn-sm"}
                ],
                responsive:!0
        }
        )},
        TableManageButtons=function(){"use strict";return{init:function(){handleDataTableButtons()}}}();
        TableManageButtons.init();
        $('#data-table-default_length').find("select").css("width","100%");





  

</script>

    

@endsection