Hola <i>{{ $demo->receiver }}</i>,
<p>Se ha registrado un nuevo pago de factura en la plataforma de www.afainversiones.com</p>
 
<p><u>Detalles del pago</u></p>
<br>
<div>
<p><b>Convenio:</b>&nbsp;{{ $demo->demo_one }}</p>
<p><b>Valor:</b>&nbsp;{{ $demo->demo_two }}</p>
<br>
<p><b>Sucursal:</b>&nbsp;{{ $demo->demo_tree }}</p>
</div>
 
</div>
 
Se recuerda que tiene 24 horas maximo para registrar este pago,
<br/>
<br/>
<i>{{ $demo->sender }}</i>