

@php

    use App\Models\Sucursal;
    use App\Models\Apertura;
    use App\Models\Convenio;
    use Carbon\Carbon;
    use Illuminate\Support\Arr;
    use App\Enums\ETipoDocumento;

    $pendientes = 0;
    DB::table('empleados AS e')->whereNotIn('e.codempleado',function($query){
                                                                $query->select('codempleado')->from('rel_empleado_sucursal');
                                                                })->get()

@endphp

@extends('layouts.administrador')

@section('title', 'Sucursales')

@section('titulo-pagina')

    <div id="page-title">

        <h1 class="page-header text-overflow">Administrador sucursales</h1>

    </div>    

@endsection

@section('breadcum')

    <ol class="breadcrumb">

        <li><a href="#"><i class="demo-pli-home"></i></a></li>

        <li class="active">Administrador sucursales</li>

    </ol>

@endsection

@section('content')

<div class="row">
    <div class="col-sm-6">
        <div class="panel panel-inverse">
            <div class="panel-heading">
                Convenios
                <a href="#" class="btn btn-sm btn-primary btn-edit" data-codconvenio=""><i class="fa fa-edit"></i></a>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-vcenter mar-top" id="data-table-default">
                        <thead>
                            <tr>
                                <th>CODIGO</th>
                                <th></th>
                                <th class="min-w-td">NOMBRE</th>
                                <th class="min-w-td">ESTADO</th>
                                <th class="min-w-td">...</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach(DB::table('convenios')->orderBy('codconvenio','desc')->get() as $convenio)
                                <tr>
                                    <td>CON-{{$convenio->codconvenio}}</td>
                                    <td>
                                        <img src="img/convenios/{{$convenio->img}}" class="img-fluid" style="width: 50px" alt="">
                                    </td>
                                    <td>
                                        <b>{{$convenio->nombre}}</b>
                                        <br>
                                        <p style="font-size: 90%;">{{$convenio->descripcion}}</p>
                                    </td> 
                                    <td>{{$convenio->estado==1 ? 'Activo' : 'Inactivo'}}</td> 
                                    <td>
                                        <a href="#" class="btn btn-sm btn-primary btn-edit" data-codconvenio="{{$convenio->codconvenio}}"><i class="fa fa-edit"></i></a>
                                    </td>                                   
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6" id="editContenedor">
        <div class="row">
            @foreach(Convenio::all() as $convenio)
                <div class="col-sm-2 mb-4">
                    <a data-toggle="tooltip" data-placement="top" title="{{$convenio->nombre}}">
                        <img src="{{asset('img/convenios/'.$convenio->img)}}" alt="" class="img-fluid img-thumbnail" style="    border-radius: 50%;">
                    </a>
                    
                </div>
            @endforeach
        </div>                                                        
    </div>
</div>

@endsection

@section('script')

    <script>
    
            $(".chosen-select").chosen();
            $(function(){
                $(".btn-edit").click(function(){
                    var codconvenio = $(this).data("codconvenio");
                    $.ajax({
                        url: "{{ url('convenios/consultar') }}",
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: 'post',
                        data: {
                            codconvenio: codconvenio
                        },
                        success: function(result){
                            console.log(0);
                            $('#editContenedor').html(result.formulario);
                        }
                    });
                });
            });
    </script>

@endsection