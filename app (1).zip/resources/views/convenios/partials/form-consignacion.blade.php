
<style>
.is-invalid.checkbox.checkbox-css label:before {
    background: rgba(255,91,87,.5);
}
.checkbox.checkbox-css input:checked+label:before {
    background: #348fe2;
    border-color: #348fe2;
}
</style>
<div class="row">
    <div class="col-sm-5">
        <div class="panel panel-success">
            <div class="panel-heading">
                Detalle pago
            </div>
            <div class="panel-body px-1" style="text-transform: none !important;">
                @if($convenio->tiene_campos==2)
                    <h5>NRO CUENTA: <br><br><b>{{$consignacion->numero_cuenta}}</b></h5>
                
                    <h5>TIPO CUENTA: <br><br><b>{{$consignacion->tipo_cuenta==2 ? 'AHORROS' : 'CORRIENTE'}}</b></h5>
                    
                    <h5>ENTIDAD: <br><br><b>{{$convenio->nombre}}</b></h5>
                    
                    <h5>RECIBE: <br><br><b>{{$consignacion->nombre_recibe}}</b></h5>
                    
                    <h5>IDENTIFICACION: <br><br><b>{{$consignacion->identificacion_recibe}}</b></h5>
                    
                    <h5>TELEFONO: <br><br><b>{{$convenio->telefono_recibe}}</b></h5>
                @else
                    
                    <h5>ENTIDAD: <br><br><b>{{$convenio->nombre}}</b></h5>
                    
                    <h5>NRO CONVENIO: <br><br><b>{{$consignacion->numero_cuenta}}</b></h5>
                
                    
                    <h5>REFERENCIA: <br><br><b>{{$consignacion->identificacion_recibe}}</b></h5>
                    
                @endif
                

                
                <br>
                <!-- begin card -->
                <div class="card border-0 bg-dark text-white text-truncate mb-3">
                    <!-- begin card-body -->
                    <div class="card-body">
                        <!-- begin title -->
                        <div class="mb-3 text-grey">
                            <b class="mb-3">Valor
                            
                            </b> 
                            <span class="ml-2"><i class="fa fa-info-circle" data-toggle="popover" data-trigger="hover" data-title="Conversion Rate" data-placement="top" data-content="Percentage of sessions that resulted in orders from total number of sessions." data-original-title="" title=""></i></span>
                        </div>
                        <!-- end title -->
                        <!-- begin conversion-rate -->
                        <div class="d-flex align-items-center mb-1">
                            <h2 class="text-white mb-0">$ <span data-animation="number" data-value="2.19">{{number_format($consignacion->valor)}}</span></h2>
                            <div class="ml-auto">
                                <div id="conversion-rate-sparkline"></div>
                            </div>
                        </div>
                        <!-- end conversion-rate -->
                    </div>
                    <!-- end card-body -->
                </div>
                <!-- end card -->
            </div>
        </div>
    </div>
    <div class="col-sm-7">
        <div class="panel panel-mint">
            <div class="panel-body">
                {!!Form::open(['route' => 'consignacion.registrar_consignacion', 'id'=>'formRegistrarPago', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
                    {{Form::hidden('codconsignacion', $consignacion->codconsignacion)}}
                    <div class="form-group">
                        <label class="control-label">Valor</label>
                        <input class="nombre-menu form-control numeric" autocomplete="off" id="valorConsignacion" name="valor" type="text">
                    </div>
                    <div class="form-group">
                        <label class="control-label" for="observaciones">Observación</label>
                        <textarea name="observaciones" id="observaciones" cols="30" rows="10" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Soporte</label>
                        <input class="nombre-menu form-control" autocomplete="off" id="soporte" name="soporte" type="file">
                    </div>
                    <div class="form-group">
                        <div class="checkbox checkbox-css is-invalid">
                            <input type="checkbox" id="reversar_pago" name="reversar_pago" value="1"/>
                            <label for="reversar_pago">¿DESEA REVERSAR EL PAGO?</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary">REGISTRAR</button>
                    </div>
                {{Form::close()}}
            </div>
        </div>
    </div>
</div>


<script>
$("#formRegistrarPago").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            if(!$("#reversar_pago").prop('checked')){
                if($("#valorConsignacion").val().replace(/,/gi, '')!={{$consignacion->valor}}){
                    frameworkApp.setAlert('Debe indicar el mismo valor que se encuentra registrado. $ {{number_format($consignacion->valor)}}');
                }else{
                    bootbox.confirm({
                        message: '¿Esta seguro de registrar el pago por $ {{number_format($consignacion->valor)}}?',
                        buttons: {
                            confirm: {
                                label: 'Si, registrar pago!',
                                className: 'btn-success'
                            },
                            cancel: {
                                label: 'No estoy seguro',
                                className: 'btn-danger'
                            }
                        },
                        callback: function (result) {
                            if(result){
                                $(".loader2").show();
                                form.submit();
                            }
                        }
                    });
                }
            }else{
                bootbox.confirm({
                    message: '¿Esta seguro de reversar este pago y realizar la devolución del dinero al punto?<br><br>Esta operación no podrá ser revertida, por favor verifique antes de enviarla',
                    buttons: {
                        confirm: {
                            label: 'Si, reversar pago!',
                            className: 'btn-success'
                        },
                        cancel: {
                            label: 'No estoy seguro',
                            className: 'btn-danger'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $(".loader2").show();
                            form.submit();
                        }
                    }
                });
            }
        },
        rules: {
            valor: {
                required: function(element) {
                    return !$("#reversar_pago").prop('checked');
                }
            },
            soporte: {
                required: function(element) {
                        return !$("#reversar_pago").prop('checked');
                    }
            },
            observaciones: {
                required: function(element) {
                        return $("#reversar_pago").prop('checked');
                    },
                    minlength: 10
            },
        },
        highlight: function (element, errorClass) {
            $(element).parents('.input-group').addClass('has-feedback has-error');
            $(element).parents('.input-group').removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
            $(element).parents('.input-group').removeClass('has-feedback has-error');
            $(element).parents('.input-group').addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });
</script>