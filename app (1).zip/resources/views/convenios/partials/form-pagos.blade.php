@php
    $costo = 0; 
    foreach(DB::table('tarifas_v')->orderBy('valor_inicial','asc')->get() as $tarifas){
        $valorDivisa = $tarifas->costo;
    }
    $valor = $pagos->valor/$valorDivisa;
    $arrayBancos = [
        6 => "Banco bicentenario",
        10 => "Banco de venezuela S.A.C.A",
        14 => "Banco mercantil",
        26 => "Banco occidental de descuento",
        24 => "Banco provincial BBVA",
        20 => "Banesco",
        1 => "Interbancario-100% Banco",
        2 => "Interbancario-Bancamiga",
        3 => "Interbancario-BanCaribe C.A",
        4 => "Interbancario-Banco activo",
        5 => "Interbancario-Banco agrícola de venezuela",
        7 => "Interbancario-Banco caroní C.A",
        8 => "Interbancario-Banco de comercio ex",
        9 => "Interbancario-Banco de exportación",
        28 => "Interbancario-Banco del Sur",
        11 => "Interbancario-Banco del tesoro",
        12 => "Interbancario-Banco exterior C.A",
        13 => "Interbancario-Banco internacional de desarrollo",
        15 => "Interbancario-Banco nacional de crédito",
        16 => "Interbancario-Banco plaza",
        17 => "Interbancario-Banco sofitasa",
        19 => "Interbancario-Bancrecer",
        21 => "Interbancario-Banfanb",
        22 => "Interbancario-Bangente",
        23 => "Interbancario-Banplus",
        25 => "Interbancario-BFC banco fondo común",
        27 => "Interbancario-Citibank N.A",
        29 => "Interbancario-Instituto municipal de crédito popular",
        30 => "Interbancario-Mi banco",
        31 => "Interbancario-Novo Banco S.A",
        18 => "Interbancario-Venezolano de crédito",
      ];
@endphp
<style>
.is-invalid.checkbox.checkbox-css label:before {
    background: rgba(255,91,87,.5);
}
.checkbox.checkbox-css input:checked+label:before {
    background: #348fe2;
    border-color: #348fe2;
}
</style>
<div class="row">
    <div class="col-sm-5">
        <div class="panel panel-success">
            <div class="panel-heading">
                Detalle pagos
            </div>
            <div class="panel-body px-1" style="text-transform: none !important;">
                <h5>CONVENIO: <br><br><b>{{$convenio->nombre}}</b></h5>
                @if($convenio->tiene_campos==2)
                    @foreach(json_decode($pagos->campos_js) as $nombre => $valor)
                        <h5>{{$nombre}}: {{$nombre=='banco' ? $arrayBancos[$valor] : $valor}}</h5>
                    @endforeach
                @else
                    @php
                        $arrCampos = json_decode($pagos->campos_js);
                        echo "<h5> Nro Convenio: ".$arrCampos["numero_cuenta"]."<h5>";
                        echo "<h5> Referencia: ".$arrCampos["identificacion_recibe"]."<h5>";
                        
                    @endphp
                @endif
                <br>
                <!-- begin card -->
                <div class="card border-0 bg-dark text-white text-truncate mb-3">
                    <!-- begin card-body -->
                    <div class="card-body">
                        <!-- begin title -->
                        <div class="mb-3 text-grey">
                            <b class="mb-3">Valor
                            
                            </b> 
                            <span class="ml-2"><i class="fa fa-info-circle" data-toggle="popover" data-trigger="hover" data-title="Conversion Rate" data-placement="top" data-content="Percentage of sessions that resulted in orders from total number of sessions." data-original-title="" title=""></i></span>
                        </div>
                        <!-- end title -->
                        <!-- begin conversion-rate -->
                        <div class="d-flex align-items-center mb-1">
                            <h2 class="text-white mb-0">$ <span data-animation="number" data-value="2.19">{{number_format($pagos->valor)}}</span></h2>
                            <div class="ml-auto">
                                <div id="conversion-rate-sparkline"></div>
                            </div>
                        </div>
                        <!-- end conversion-rate -->
                    </div>
                    <!-- end card-body -->
                </div>
                <!-- end card -->
            </div>
        </div>
    </div>
    <div class="col-sm-7">
        <div class="panel panel-mint">
            <div class="panel-body">
                {!!Form::open(['route' => 'pagos.registrar_pagos', 'id'=>'formRegistrarPago', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
                    {{Form::hidden('codpago', $pagos->codpago)}}
                    <div class="form-group">
                        <label class="control-label">Valor</label>
                        <input class="nombre-menu form-control numeric" autocomplete="off" id="valorConsignacion" name="valor" type="text">
                    </div>
                    <div class="form-group">
                        <label class="control-label" for="observaciones">Observación</label>
                        <textarea name="observaciones" id="observaciones" cols="30" rows="10" class="form-control" {{$pagos->codconvenio==0 ? 'readonly' : '' }}>{{$pagos->codconvenio==0 ? '$ '.($valor) : '' }}</textarea>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Soporte</label>
                        <input class="nombre-menu form-control" autocomplete="off" id="soporte" name="soporte" type="file">
                    </div>
                    <div class="form-group">
                        <div class="checkbox checkbox-css is-invalid">
                            <input type="checkbox" id="reversar_pago" name="reversar_pago" value="1"/>
                            <label for="reversar_pago">¿DESEA REVERSAR EL PAGO?</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary">REGISTRAR</button>
                    </div>
                {{Form::close()}}
            </div>
        </div>
    </div>
</div>


<script>
$("#formRegistrarPago").validate({
        ignore: ":not(.chosen-select):checkbox",
        submitHandler: function(form) {
            if(!$("#reversar_pago").prop('checked')){
                if($("#valorConsignacion").val().replace(/,/gi, '')!={{$pagos->valor}}){
                    frameworkApp.setAlert('Debe indicar el mismo valor que se encuentra registrado. $ {{number_format($pagos->valor)}}');
                }else{
                    bootbox.confirm({
                        message: '¿Esta seguro de registrar el pago por $ {{number_format($pagos->valor)}}?',
                        buttons: {
                            confirm: {
                                label: 'Si, registrar pago!',
                                className: 'btn-success'
                            },
                            cancel: {
                                label: 'No estoy seguro',
                                className: 'btn-danger'
                            }
                        },
                        callback: function (result) {
                            if(result){
                                $(".loader2").show();
                                form.submit();
                            }
                        }
                    });
                }
            }else{
                bootbox.confirm({
                    message: '¿Esta seguro de reversar este pago y realizar la devolución del dinero al punto?<br><br>Esta operación no podrá ser revertida, por favor verifique antes de enviarla',
                    buttons: {
                        confirm: {
                            label: 'Si, reversar pago!',
                            className: 'btn-success'
                        },
                        cancel: {
                            label: 'No estoy seguro',
                            className: 'btn-danger'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $(".loader2").show();
                            form.submit();
                        }
                    }
                });
            }
        },
        rules: {
            valor: {
                required: function(element) {
                    return !$("#reversar_pago").prop('checked');
                }
            },
            soporte: {
                required: function(element) {
                        return !$("#reversar_pago").prop('checked');
                    }
            },
            observaciones: {
                required: function(element) {
                        return $("#reversar_pago").prop('checked');
                    },
                    minlength: 5
            },
        },
        highlight: function (element, errorClass) {
            $(element).parents('.input-group').addClass('has-feedback has-error');
            $(element).parents('.input-group').removeClass('has-feedback has-success');
        },
        unhighlight: function (element, errorClass) {
            $(element).parents('.input-group').removeClass('has-feedback has-error');
            $(element).parents('.input-group').addClass('has-feedback has-success');
        },
        errorPlacement: function(error, element) {
            if(element.parents('.input-group').length > 0) {
                error.insertAfter(element.parents('.input-group'));
            } else if(element.parents('.form-group').find('.chosen-container').length > 0){
                
            } else if(element.parents('.radio').find('.chosen-container').length > 0){
                error.insertAfter(element.parents('.radio').find('.chosen-container'));
            } else {
                error.insertAfter(element);
            }
        }
    });
</script>