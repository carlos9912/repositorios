<div class="panel panel-inverse">
    <!-- begin panel-heading -->
    <div class="panel-heading">
        <h4 class="panel-title">Default Style</h4>
    </div>
    <!-- end panel-heading -->
    <!-- begin panel-body -->
    <div class="panel-body">
        {{Form::open(['route' => 'convenios.crear-convenio', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarCampo', 'enctype'=>'multipart/form-data']) }}  
        <div class="row">
            <div class="col-sm-12">
                {!! Form::hidden('codconvenio', $convenio->codconvenio) !!}
                <fieldset>
                    <legend class="m-b-15">Convenio</legend>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nombre</label>
                        <input type="text" name="nombre"  id="nombre" class="form-control" placeholder="Enter email" value="{{$convenio->nombre}}"/>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Descripción</label>
                        <textarea class="form-control" name="descripcion"  id="descripcion" placeholder="Password">{{$convenio->descripcion}}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Categoria</label>
                        <select class="chosen-select form-control select2-hidden-accessible" tabindex="-1" id="codcategoria" name="codcategoria" aria-hidden="true" data-placeholder="Seleccione una categoría">
                            <optgroup label="Categorías">
                            <option></option>
                            <!-- foreach(DB::table('empleados AS e')->leftJoin('rel_empleado_sucursal AS r','r.codempleado','=','e.codempleado')->where('r.codsucursal','<>',$sucursal->codsucursal)->get() as $estudiante) -->
                            @foreach(DB::table('categorias AS e')->get() as $categoria)
                                <option value="{{$categoria->id_categoria}}" {{$convenio->codcategoria==$categoria->id_categoria ? 'selected' : ''}}>{{$categoria->nombre}}</option>
                            @endforeach
                            </optgroup>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Imagen</label>
                        <input type="file" class="form-control" name="img" id="img" placeholder="Enter email" />
                        <small>Si no desea cambiar la imagen, no seleccione ninguna</small>
                    </div>
                    <hr>
                    
                </fieldset>
            </div>
            <div class="col-sm-12">
                <legend>Campos del convenio</legend>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th class="text-center" style="width: 1%;">Estado</th>
                            <th class="text-center" style="width: 1%;">¿Obligatorio?</th>
                            <th class="text-center" style="width: 1%;">¿Númerico?</th>
                            <th class="text-center" style="width: 1%;">Longitud</th>
                            <th class="text-center" style="width: 1%;">...</th>
                        </tr>
                    </thead>
                    @php
                        $listCampos = [];
                    @endphp
                    @foreach($convenio->bancos as $campo)
                        @php
                            $listCampos[] = $campo->codbanco;
                        @endphp
                        <tr>
                            <td>
                                {{($campo->nombre)}}
                            </td>
                            <td class="text-center">
                                {!!($campo->estado==1 ? '<button class="btn btn-xs btn-success btn-circle"><i class="fa fa-check"></i></button>' : '<button class="btn btn-xs btn-danger btn-circle"><i class="fa fa-times-circle"></i></button>')!!}
                            </td>
                            <td class="text-center">
                                {!!($campo->obligatorio==1 ? '<button class="btn btn-xs btn-success btn-circle"><i class="fa fa-check"></i></button>' : '<button class="btn btn-xs btn-danger btn-circle"><i class="fa fa-times-circle"></i></button>')!!}
                            </td>
                            <td class="text-center">
                                {!!($campo->numerico==1 ? '<button class="btn btn-xs btn-success btn-circle"><i class="fa fa-check"></i></button>' : '<button class="btn btn-xs btn-danger btn-circle"><i class="fa fa-times-circle"></i></button>')!!}
                            </td>
                            <td class="text-center" >
                                {!!($campo->cantidad)!!}
                            </td>
                            <td class="text-center" >
                                <button class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></button>
                            </td>
                        </tr>
                    @endforeach
                </table>
                <div class="row">
                    <div class="col-sm-12">
                        <legend>Añadir Campo</legend>
                    </div>
                    <div class="col-sm-4">
                        <select class="chosen-select form-control select2-hidden-accessible" tabindex="-1" id="codbanco" name="codbanco" aria-hidden="true" data-placeholder="Seleccione un campo">
                            <optgroup label="Categorías">
                            <option></option>
                            <!-- foreach(DB::table('empleados AS e')->leftJoin('rel_empleado_sucursal AS r','r.codempleado','=','e.codempleado')->where('r.codsucursal','<>',$sucursal->codsucursal)->get() as $estudiante) -->
                            @foreach(DB::table('banco_datos AS e')->whereNotIn('codbanco',$listCampos)->get() as $categoria)
                                <option value="{{$categoria->codbanco}}">{{$categoria->nombre}}</option>
                            @endforeach
                            </optgroup>
                        </select>
                    </div>
                    <div class="col-sm-2">
                        <div class="checkbox checkbox-css">
                            <input type="checkbox" name="estado_campo" id="estado_campo" value="1" checked>
                            <label for="estado_campo">¿Estado?</label>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="checkbox checkbox-css">
                            <input type="checkbox" name="obligatorio_campo" id="obligatorio_campo" value="1">
                            <label for="obligatorio_campo" checked>¿Obligatorio?</label>
                        </div>
                    </div>
                    <div class="col-sm-2 text-center">
                        <div class="checkbox checkbox-css">
                            <input type="checkbox" name="numerico_campo" id="numerico_campo" value="1">
                            <label for="numerico_campo">¿Númerico?</label>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <input type="text" name="longitud_campo"  id="longitud_campo" class="form-control" placeholder="Longitud" />
                    </div>
                    <div class="col-sm-12 mt-2 text-right">
                        <button class="btn btn-sm btn-success btn-save" type="button"><i class="fa fa-save"></i></button>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 mt-5">
                <button type="button" class="btn btn-sm btn-primary m-r-5  btn-save">Guardar</button>
                <button type="button" class="btn btn-sm btn-default">Cancelar</button>
            </div>
        </div>

        </form>
    </div>
    <!-- end panel-body -->
</div>
<!-- end panel -->  

<script>

    $(".chosen-select").chosen();
    $('.btn-save').click(function(){
        //$(".loader2").show();
        var codconvenio = $(this).data("codconvenio");
        $.ajax({
            url: "{{ route('convenios.crear-convenio') }}",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'post',
            dataType: 'json',
            data: new FormData($("#agregarCampo")[0]),
            
            processData: false,

            contentType: false,

            id_container_body: false,
            success: function(result){
                console.log(result);
                $(".loader2").hide();
                $.ajax({
                    url: "{{ url('convenios/consultar') }}",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: 'post',
                    data: {
                        codconvenio: {{blank($convenio->codconvenio) ? 'null' : $convenio->codconvenio}}
                    },
                    success: function(result){
                        console.log(0);
                        $('#editContenedor').html(result.formulario);
                        $(".loader2").hide();
                        if({{blank($convenio->codconvenio) ? 'null' : $convenio->codconvenio}}!='null'){
                            $.ajax({
                                url: "{{ url('convenios/consultar') }}",
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                type: 'post',
                                data: {
                                    codconvenio: {{blank($convenio->codconvenio) ? 'null' : $convenio->codconvenio}}
                                },
                                success: function(result){
                                    console.log(0);
                                    $('#editContenedor').html(result.formulario);
                                }
                            });
                        }
                    }
                });
            }
        });
    });
</script>