


@php
    use App\Enums\EDocumentoSucursal;
    use App\Models\Pagos;
    use App\Models\Convenio;
    use Illuminate\Support\Arr;
    use Carbon\Carbon;
    $pendientes = 0;
    $comisionAcumulada = DB::table('rel_sucursal_movimiento AS r')->where('estado_pago','=','1')->where('codsucursal','=',$sucursal->codsucursal)->select(DB::raw('SUM(valor_comision) as comision'))->first();
    $comisionAcumulada = $comisionAcumulada->comision;
    $sucursal->tipo_cuenta = $sucursal->tipo_cuenta_sucursal==1 ? 'Ahorros' : 'Corriente';
    $listTarifas = [];
    foreach(DB::table('tarifas_convenios AS t')->get() as $tarifa){
        $listTarifas[$tarifa->codtarifa] = $tarifa;
    }
@endphp
@php
    $pagosPendientes = 0;
    $vlrPagosPendientes = 0;
    $pagosRealizados = 0;
    $vlrPagosRealizados = 0;
    $pagosReversados = 0;
    $vlrPagosReversados = 0;

    $valorGanancia = 0;
    $valorEnvio = 0;
    $valorRetiro = 0;
    $valorVentas = 0;
    $valorPorcentaje = 0;
    $valorConsignaciones = 0;
    $valorRecargas = 0;
    $valorServicios = 0;
    $codsucursal = NULL;
    $rangoFechas = request('rango_fecha');
    if(blank($rangoFechas)){
        $inicio = date('Y-m-d').' 00:00:00';
        $fin = date('Y-m-d').' 23:59:59';
    }else{
        $rangoFechas = explode(' - ',$rangoFechas);
        $inicio = Carbon::parse(str_replace('/','-',$rangoFechas[0]))->format('Y-m-d').' 00:00:00';
        $fin = Carbon::parse(str_replace('/','-',$rangoFechas[1]))->format('Y-m-d').' 23:59:59';
    }
@endphp

@extends('layouts.administrador')
@section('title', trans('general.title_crear_pagina'))
@section('titulo-pagina')
<div id="page-title">
    <h1 class="page-header text-overflow">Reportes</h1>
</div>    
@endsection
@section('breadcum')
<ol class="breadcrumb">
    <li><a href="#"><i class="demo-pli-home"></i></a></li>
    <li class="active">Administrador Reportes</li>
</ol>
@endsection
@section('content')
<div class="row">
    <div class="col-lg-8">
        {!!Form::open(['route' => 'otros.otros-consultar', 'id'=>'formBuscarEstado', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
            {{Form::hidden('codsucursal', $sucursal->codsucursal)}}
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>RANGO FECHA ESTADO</label>
                        <div class="input-group" id="default-daterange">
                            <input id="daterange" type="text" name="rango_fecha" class="form-control" value="{{request('rango_fecha')}}" placeholder="Especifique una fecha a buscar" autocomplete="false" />
                            <span class="input-group-append">
                            <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-1">
                    <label>...</label>
                    <button type="submit" class="btn btn-primary">Buscar</button>
                </div>
            </div>
        {{Form::close()}}
        
        <!-- begin nav-tabs -->
        <ul class="nav nav-tabs" style="background: #f3f1f1;">
            <li class="nav-item">
                <a href="#default-tab-1" data-toggle="tab" class="nav-link active">
                    <span class="d-sm-none">Movimientos </span>
                    <span class="d-sm-block d-none font-weight-bold">Pendientes</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#default-tab-2" data-toggle="tab" class="nav-link">
                    <span class="d-sm-none">Tab 2</span>
                    <span class="d-sm-block d-none font-weight-bold">Pagados</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#default-tab-3" data-toggle="tab" class="nav-link">
                    <span class="d-sm-none">Tab 2</span>
                    <span class="d-sm-block d-none font-weight-bold">Reversados</span>
                </a>
            </li>
            
        </ul>
        <!-- end nav-tabs -->
        <!-- begin tab-content -->
        <div class="tab-content">
            <!-- begin tab-pane -->
            
            <div class="tab-pane fade active show" id="default-tab-1">
                <div class="panel panel-body">
                    <div class="panel-body" id="tableReportes">
                        <div class="row">
                            @if(\Auth::user()->email!=1)
                                <div class="col-sm-12">
                                    <table class="table table-vcenter mar-top" id="data-table-buttons">
                                        <thead>
                                            <tr>
                                                <th class="min-w-td">No. FV</th>
                                                <th class="min-w-td text-left">Convenio</th>
                                                <th class="min-w-td text-center">Valor</th>
                                                <th class="text-center">Fecha</th>
                                                <th style="width: 22%;">Sucursal</th>
                                                <th>Días</th>
                                                <th style="width: 12%;">¿Pagar?</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach(DB::table('pagos AS p')->join('convenios as c', 'c.codconvenio','=','p.codconvenio')->join('sucursales as s', 's.codsucursal', '=', 'p.codsucursal')->where('estado_pago','<>',1)->where('p.tipo','=',1)->where('p.estado', '=', 1)->orderBy('fecha')->orderBy('fecha')->select('p.*','c.*','s.nombres as nombresucursal','s.municipio', 's.departamento')->get() as $pago)
                                                @php
                                                    $pagosPendientes++;
                                                    $vlrPagosPendientes+=$pago->valor;
                                                @endphp
                                                <tr>
                                                    <td>{{'P-'.str_pad($pago->codpago, 4, "0", STR_PAD_LEFT)}}</td>
                                                    <td>{{$pago->nombre}}</td>
                                                    <td class="text-right">$ {{number_format($pago->valor)}}</td>
                                                    <td>{{Carbon::parse($pago->fecha)->format(trans('general.format_datetime'))}}</td>
                                                    <td>
                                                        <b>{{$pago->nombresucursal}}</b><br>
                                                        {{$pago->municipio}} - {{$pago->departamento}}
                                                    </td>
                                                    <td>
                                                        {!!Carbon::parse($pago->fecha)->diffInDays(Carbon::now())==0 ? Carbon::parse($pago->fecha)->diffInHours(Carbon::now()).' Hrs': '<b class="text-danger">'.Carbon::parse($pago->fecha)->diffInDays(Carbon::now()).' Día(s)</b>'!!}
                                                        
                                                    </td>
                                                    <td>
                                                        <a class="btn btn-primary btn-sm btn-pagar fa fa-cloud-download-alt text-white" data-codpago="{{$pago->codpago}}"></a>
                                                        <a data-fancybox data-type="iframe" class="btn btn-green btn-sm fa fa-search" data-src="https://giros-bam.com/factura?codpago={{base64_encode($pago->codpago)}}"  href="javascript:;">
                                                            <i class="ti ti-printer"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @endforeach   
                                        </tbody>
                                    </table>
                                    <hr>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <!-- end tab-pane -->
            <!-- begin tab-pane -->
            <div class="tab-pane fade" id="default-tab-2">
                <div class="panel panel-body">
                    <div class="panel-body" id="tableReportes">
                        <div class="row">
                            @if(\Auth::user()->email!=1)
                                <div class="col-sm-12">
                                    <table class="table table-vcenter mar-top" id="tablaDatatable">
                                        <thead>
                                            <tr>
                                                <th class="min-w-td">No. FV</th>
                                                <th class="min-w-td text-left">Convenio</th>
                                                <th class="min-w-td text-center">Valor</th>
                                                <th class="text-center">Fecha</th>
                                                <th>Fecha Pago</th>
                                                <th>Sucursal</th>
                                                <th>...</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach(DB::table('pagos AS p')->join('convenios as c', 'c.codconvenio','=','p.codconvenio')->join('sucursales as s', 's.codsucursal', '=', 'p.codsucursal')->where('tipo','=',1)->where('estado_pago','=',1)->whereBetween('fecha_pago',[
                                                $inicio,
                                                $fin
                                            ])->orderBy('fecha_pago','desc')->select('p.*','c.*','s.nombres as nombresucursal','s.municipio', 's.departamento')->get() as $pago)
                                                @php
                                                    $pagosRealizados++;
                                                    $vlrPagosRealizados+=$pago->valor;
                                                @endphp
                                                <tr>
                                                    <td>{{'P-'.str_pad($pago->codpago, 4, "0", STR_PAD_LEFT)}}</td>
                                                    <td>{{$pago->nombre}}</td>
                                                    <td class="text-right">$ {{number_format($pago->valor)}}</td>
                                                    <td>{{Carbon::parse($pago->fecha)->format(trans('general.format_datetime'))}}</td>
                                                    <td><a data-fancybox href="{{asset('soportes/'.$pago->soporte)}}">{{Carbon::parse($pago->fecha_pago)->format(trans('general.format_datetime'))}}</a></td>
                                                    <td>
                                                        {{$pago->nombresucursal}}<br>
                                                        {{$pago->municipio}} - {{$pago->departamento}}
                                                    </td>
                                                    <td>
                                                        <a data-fancybox data-type="iframe" class="btn btn-green btn-sm fa fa-search" data-src="https://giros-bam.com/factura?codpago={{base64_encode($pago->codpago)}}"  href="javascript:;">
                                                            <i class="ti ti-printer"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @endforeach   
                                        </tbody>
                                    </table>
                                    <hr>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <!-- end tab-pane -->
            <!-- begin tab-pane -->
            <div class="tab-pane fade" id="default-tab-3">
                <div class="panel panel-body">
                    <div class="panel-body" id="tableReportes">
                        <div class="row">
                            @if(\Auth::user()->email!=1)
                                <div class="col-sm-12">
                                    <table class="table table-vcenter mar-top" id="tablaDatatable">
                                        <thead>
                                            <tr>
                                                <th class="min-w-td">No. FV</th>
                                                <th class="min-w-td text-left">Convenio</th>
                                                <th class="min-w-td text-center">Valor</th>
                                                <th class="text-center">Fecha</th>
                                                <th>Fecha Pago</th>
                                                <th>Sucursal</th>
                                                <th>...</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach(DB::table('pagos AS p')->join('convenios as c', 'c.codconvenio','=','p.codconvenio')->join('sucursales as s', 's.codsucursal', '=', 'p.codsucursal')->where('tipo','=',1)->where('estado_pago','=',2)->where('p.estado','=',2)->whereBetween('fecha_pago',[
                                                $inicio,
                                                $fin
                                            ])->orderBy('fecha_pago','desc')->select('p.*','c.*','s.nombres as nombresucursal','s.municipio', 's.departamento')->get() as $pago)
                                                @php
                                                    $pagosReversados++;
                                                    $vlrPagosReversados+=$pago->valor;
                                                @endphp
                                                <tr>
                                                    <td>{{'P-'.str_pad($pago->codpago, 4, "0", STR_PAD_LEFT)}}</td>
                                                    <td>{{$pago->nombre}}</td>
                                                    <td class="text-right">$ {{number_format($pago->valor)}}</td>
                                                    <td>{{Carbon::parse($pago->fecha)->format(trans('general.format_datetime'))}}</td>
                                                    <td>
                                                        {{Carbon::parse($pago->fecha_pago)->format(trans('general.format_datetime'))}}<br>
                                                        <b>Motivo: {{$pago->observaciones}}</b>
                                                    </td>
                                                    <td>
                                                        {{$pago->nombresucursal}}<br>
                                                        {{$pago->municipio}} - {{$pago->departamento}}
                                                    </td>
                                                    <td>
                                                        <a data-fancybox data-type="iframe" class="btn btn-green btn-sm fa fa-search" data-src="https://giros-bam.com/factura?codpago={{base64_encode($pago->codpago)}}" href="javascript:;">
                                                            <i class="ti ti-printer"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @endforeach   
                                        </tbody>
                                    </table>
                                    <hr>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <!-- end tab-pane -->
        </div>
        <!-- end tab-content -->

    </div>
    <div class="col-lg-4">
        <div class="row">
            <div class="col-lg-12">
                <div class="widget widget-stats bg-warning">
                    <div class="stats-icon"><i class="fas fa-exclamation-triangle"></i></div>
                    <div class="stats-info">
                        <h4>OTROS PENDIENTES</h4>
                        <p id="valor-iva">$ {{number_format($vlrPagosPendientes)}} ({{$pagosPendientes}}) </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="widget widget-stats bg-green">
                    <div class="stats-icon"><i class="fas fa-check-square"></i></div>
                    <div class="stats-info">
                        <h4>OTROS REALIZADOS</h4>
                        <p id="valor-iva">$ {{number_format($vlrPagosRealizados)}} ({{$pagosRealizados}}) </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="widget widget-stats bg-red">
                    <div class="stats-icon"><i class="fas fa-times-circle"></i></div>
                    <div class="stats-info">
                        <h4>OTROS REVERSADOS</h4>
                        <p id="valor-iva">$ {{number_format($vlrPagosReversados)}} ({{$pagosReversados}}) </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card bg-danger m-b-30">
				<div class="card-body">
    				<div class="xp-widget-box">
    					<div class="float-left">
    					<h4 class="xp-counter text-white">
    					|
    					@foreach(DB::table('tarifas_v')->orderBy('valor_inicial','asc')->get() as $tarifas)
    						$ {{($tarifas->costo)}} |
    					@endforeach
    					</h4>
    					<p class="mb-0 text-white">Tasa del día</p>                        
    					</div>
    					<div class="float-right">
    					<div class="xp-widget-icon xp-widget-icon-bg bg-white">
    						<i class="mdi mdi-account-multiple font-30 text-danger"></i>
    					</div>
    					</div>
    					<div class="clearfix"></div>
    				</div>
				</div>
			</div>
			</div>
        </div>  
    </div>
    <div class="col-sm-12">
    

    </div>


</div>



<div class="modal fade" id="modalFormPagar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="panel-title">Realizar pago</h3>
            </div>
            <div class="modal-body" id="editContenedor">
            </div>
        </div>
    </div>
</div>
{!!Form::open(['route' => 'sucursal.comisiones', 'id'=>'pagarComision', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
    {{Form::hidden('codsucursal', $sucursal->codsucursal)}}
{{Form::close()}}
@endsection

@section('script')

<script>

    $(".numeric").on({
        "focus": function(event) {
            $(event.target).select();
        },
        "keyup": function(event) {
            $(event.target).val(function(index, value) {
            return value.replace(/\D/g, "")
                .replace(/\B(?=(\d{3})+(?!\d)\.?)/g, ",");
            });
        }
    });
    $(function(){
        @if(!blank(request('mensaje')))
            $.gritter.add({title:"Operación realizada con éxito",text:"El pago se realizó correctamente"});
       //     alert('{{request('mensaje')}}');
        @endif
        $(".btn-pagar").click(function(){
            $(".loader2").show();
                var codpago = $(this).data("codpago");
                console.log(codpago);
                $.ajax({
                    url: "{{ url('pagos/consultar') }}",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: 'post',
                    data: {
                        codpago: codpago
                    },
                    success: function(result){
                        console.log(0);
                        $(".loader2").hide();
                        $('#editContenedor').html(result.formulario);
                        $("#modalFormPagar").modal('show');
                    }
                });
        });
        $('#daterange').daterangepicker({
            locale: {
            format: 'DD/MM/YYYY'
            },

            todayBtn: "linked",

            language: 'es',

            autoclose: true,
            ranges: {
                'Hoy': [moment(), moment()],
                'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Ultimos 7 días': [moment().subtract(6, 'days'), moment()],
                'Ultimos 30 días': [moment().subtract(29, 'days'), moment()],
                'Este mes': [moment().startOf('month'), moment().endOf('month')],
                'El mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },

            todayHighlight: true
        });
        $('table').css("width","100%");
    })
    $('.btn-factura').click(function(){
        $(this).attr("href", '{{url('sucursal-consolidado')}}?m={{base64_encode($sucursal->codsucursal)}}&fecha='+(Number($('#fecha_anualidad_nac').val())) + '/' +
            $('#fecha_mes_nac').val() + '/' + (Number($('#fecha_dia_nac').val())))
    });
    
    //$('.dataTables_filter').hide();
    $('[data-fancybox]').fancybox({
        toolbar  : false,
        smallBtn : true,
        iframe : {
            preload : false
        }
    });

    $('#demo-dp-range .input-daterange').datepicker({
        format: "dd/mm/yyyy",
        todayBtn: "linked",
        language: 'es',
        autoclose: true,
        todayHighlight: true
    });
    
    
   

    function recargar(){
        location.reload();
    }
    var handleDataTableButtons = function() {
        "use strict";
        
        if ($('#data-table-buttons').length !== 0) {
            $('#data-table-buttons').DataTable({
                dom: '<"row"<"col-sm-5"B><"col-sm-7"fr>>t<"row"<"col-sm-5"i><"col-sm-7"p>>',
                buttons: [
                    { extend: 'copy', className: 'btn-sm' },
                    { extend: 'csv', className: 'btn-sm' },
                    { extend: 'excel', className: 'btn-sm' },
                    { extend: 'pdf', className: 'btn-sm' },
                    { extend: 'print', className: 'btn-sm' }
                ],
                "bSort": false, 
            "aaSorting": [[0]], 
                responsive: true
            });
        }
    };

    var TableManageButtons = function () {
        "use strict";
        return {
            //main function
            init: function () {
                handleDataTableButtons();
            }
        };
    }();

    $(document).ready(function() {
        TableManageButtons.init();
    });

</script>



@endsection


