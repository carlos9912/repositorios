


@php

use App\Models\Convenio;
use App\Models\Sucursal;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use App\Enums\ETipoDocumento;
use App\Enums\EDocumentoSucursal;


$sucursal = Sucursal::find(session('sucursal')->codsucursal);

@endphp


<!-- begin row -->
<div class="row">
<!-- begin col-6 -->
<div class="col-xl-6 px-0">
    <!-- begin card -->
    <div class="card border-0 bg-dark text-white mb-3 overflow-hidden">
        <!-- begin card-body -->
        <div class="card-body">
            <!-- begin row -->
            <div class="row">
                <!-- begin col-5 -->
                <div class="col-xl-5 col-lg-4 align-items-center d-flex justify-content-center">
                    <img src="img/convenios/{{$convenio->img}}" width="230px" class="d-none d-lg-block img-fluid" />
                </div>
                <!-- end col-5 -->
                <!-- begin col-7 -->
                <div class="col-xl-7 col-lg-8">
                    <!-- begin title -->
                    <div class="mb-3 text-grey">
                        <b>DESCRIPCIÓN DEL CONVENIO</b>
                       
                    </div>
                    <!-- end title -->
                    <!-- begin total-sales -->
                    <div class="mb-1">
                        <h3 class="mb-0 text-white">{{$convenio->nombre}}</h3>
                        <div class="ml-auto mt-n1 mb-n1"><div id="total-sales-sparkline"></div></div>
                    </div>
                    <!-- end total-sales -->
                    <!-- begin percentage -->
                    <div class="mb-3 text-grey" style="text-transform: none;">
                        <i class="fa fa-question-circle"></i> {{$convenio->descripcion}}
                    </div>
                    <!-- end percentage -->
                    <hr class="bg-white-transparent-2" />
                    <!-- begin row -->
                    <div class="row text-truncate">
                        <!-- begin col-6 -->
                        <div class="col-6">
                            <div class="f-s-12 text-grey">Minimo</div>
                            <div class="f-s-18 m-b-5 f-w-600 p-b-1">$<span data-animation="number" data-value="41.20">{{number_format($convenio->minimo)}}</span></div>
                            <div class="progress progress-xs rounded-lg bg-dark-darker m-b-5">
                                <div class="progress-bar progress-bar-striped rounded-right bg-teal" data-animation="width" data-value="55%" style="width: 0%"></div>
                            </div>
                        </div>
                        <!-- end col-6 -->
                        <!-- begin col-6 -->
                        <div class="col-6">
                            <div class="f-s-12 text-grey">Máximo</div>
                            <div class="f-s-18 m-b-5 f-w-600 p-b-1">$<span data-animation="number" data-value="41.20">{{number_format($convenio->maximo)}}</span></div>
                            <div class="progress progress-xs rounded-lg bg-dark-darker m-b-5">
                                <div class="progress-bar progress-bar-striped rounded-right" data-animation="width" data-value="55%" style="width: 0%"></div>
                            </div>
                        </div>
                        <!-- end col-6 -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- end col-7 -->
            </div>
            <!-- end row -->
        </div>
        <!-- end card-body -->
    </div>
    <!-- end card -->
</div>
<div class="col-xl-6 px-0 ppal" id="ppal">
    
        @if($convenio->codcategoria==3)
            {{Form::open(['route' => 'clientes.enviar-giro-banco', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'agregarAsignatura', 'target'=> "_blank"]) }}  
                {!! Form::hidden('valor_tarifa', 0,['id'=>'valor_tarifa']) !!}
                {!! Form::hidden('codtarifa', 0,['id'=>'codtarifa']) !!}
                {!! Form::hidden('valor_cambio', 0,['id'=>'valor_cambio']) !!}
                {!! Form::hidden('valor_giro', 0,['id'=>'valor_giro']) !!}
                {!! Form::hidden('codconvenio', $convenio->codconvenio,['id'=>'codconvenio']) !!}
                <div class="row">
                    @if($convenio->tiene_campos==2)
                        <div class="col-sm-12">
                            <h5>Datos Envía</h5>
                            <hr class="mt-0">
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Teléfono Envía</label>
                                <input type="text" name="telefono_envia" id="telefono_envia" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <hr class="mt-0">
                            <h5>Datos Destino</h5>
                            <hr>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Número de cuenta</label>
                                <div class="input-group m-b-10">
                                    <div class="input-group-prepend">
                                        <select id="tipo_cuenta" class="form-control chosen-select no-label" required="required" name="tipo_cuenta">
                                        <option selected="selected" value="">Tipo</option><option value="2">Ahorros</option><option value="3">Corriente</option>
                                        </select>
                                    </div>
                                    <input type="text" name="numero_cuenta" id="numero_cuenta" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Identificación Destino</label>
                                <input type="text" name="identificacion_recibe" id="identificacion_recibe" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Teléfono Destino</label>
                                <input type="text" name="telefono_recibe" id="telefono_recibe" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Nombre Completo Destino</label>
                                <input type="text" name="nombre_recibe" id="nombre_recibe" class="form-control" required>
                            </div>
                        </div>
                    @else
                        <div class="col-sm-12">
                            <h5>Datos Envía</h5>
                            <hr class="mt-0">
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Teléfono Envía</label>
                                <input type="text" name="telefono_envia" id="telefono_envia" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <hr class="mt-0">
                            <h5>Datos Destino</h5>
                            <hr>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Número de convenio</label>
                                <input type="text" name="numero_cuenta" id="numero_cuenta" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Referencia</label>
                                <input type="text" name="identificacion_recibe" id="identificacion_recibe" class="form-control" required>
                            </div>
                        </div>
                    @endif
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="">Valor</label>
                            <input type="text" class="form-control numeric" id="valor" name="valor" required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="">Valor Recibido</label>
                            <input type="text" class="form-control numeric" id="valor_recibido" name="valor_recibido" required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="checkbox checkbox-css">
                            <input type="checkbox" id="incluirFlete" value="">
                            <label for="incluirFlete" style="color: #1a4772 !important;"><b>¿Flete incluido?</b></label>
                        </div>
                    </div>
                    <div class="col-md-12 px-0" id="resumen-giro">
                        <hr>
                        <div class="note note-primary m-b-15">
                            <div class="note-icon"><i class="fa fa-dollar-sign"></i></div>
                            <div class="note-content text-right ml-0">
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4><b>Valor</b></h4>
                                    </div>
                                    <div class="col-sm-5">
                                        <h4><span id="h1-valor">$ 0<span></h4>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4><b>Tarifa</b></h4>
                                    </div>
                                    <div class="col-sm-5">
                                        <h4><span id="h1-tarifa">-<span></h4>
                                    </div>
                                </div>
                                <hr class="my-1 mb-2">
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4><b>Total</b></h4>
                                    </div>
                                    <div class="col-sm-5">
                                        <h2 class="font-weight-bold"><span id="h1-total">-<span></h2>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4><b>Recibido</b></h4>
                                    </div>
                                    <div class="col-sm-5">
                                        <h2 class="font-weight-bold"><span id="h1-recibido">-<span></h2>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4><b>Cambio</b></h4>
                                    </div>
                                    <div class="col-sm-5">
                                        <h2 class="font-weight-bold"><span id="h1-cambio">-<span></h2>
                                    </div>
                                </div>
                                    
                            </div>
                        </div>
                            {{Form::hidden('et-g',2,['id'=>'et-g'])}}
                    </div>
                    <div class="col-sm-12">
                        <button type="submit" class="btn btn-primary">Enviar</button>
                    </div>
                </div>
            
            {{Form::close()}}
        @elseif($convenio->codcategoria==4)
            {{Form::open(['route' => 'clientes.enviar-giro-banco', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'agregarAsignatura', 'target'=> "_blank"]) }}  
                {!! Form::hidden('valor_tarifa', 0,['id'=>'valor_tarifa']) !!}
                {!! Form::hidden('codtarifa', 0,['id'=>'codtarifa']) !!}
                {!! Form::hidden('valor_cambio', 0,['id'=>'valor_cambio']) !!}
                {!! Form::hidden('valor_giro', 0,['id'=>'valor_giro']) !!}
                {!! Form::hidden('codconvenio', $convenio->codconvenio,['id'=>'codconvenio']) !!}
                <div class="row">
                <div class="col-sm-12">
                    @foreach($campos as $cp)
                        @if($cp->codbanco==7)
                        <div class="form-group">
                            <label for="">{{$cp->nombre}}</label>
                            <div class="input-group m-b-10">
                                <div class="input-group-prepend">
                                    <select id="tipo_cuenta" class="form-control chosen-select no-label" required="required" name="tipo_cuenta">
                                    <option selected="selected" value="">Tipo</option><option value="2">Ahorros</option><option value="3">Corriente</option>
                                    </select>
                                </div>
                                <input type="{{$cp->numerico==1 ? 'number' : 'text'}}" name="field_{{$cp->codbanco}}" class="form-control" {{$cp->obligatorio==1 ? 'required' : ''}}>
                            </div>
                        </div>
                        @elseif($cp->codbanco==10)
                        <div class="form-group">
                            <label for="">{{$cp->nombre}}</label>
                            <select id="field_{{$cp->codbanco}}" class="form-control chosen-select no-label" required="required" name="field_{{$cp->codbanco}}">
                                <option selected="selected" value="">Tipo</option><option value="TI">TARJETA IDENTIDAD</option><option value="CC">CEDULA DE CIUDADANIA</option><option value="CE">CEDULA DE EXTRANJERIA</option>
                            </select>
                        </div>
                        @else
                            @if(blank($cp->img))
                            <div class="form-group">
                                <label for="">{{$cp->nombre}}</label>
                                <input type="{{$cp->numerico==1 ? 'number' : 'text'}}" class="form-control" id="field_{{$cp->codbanco}}" name="field_{{$cp->codbanco}}" autocomplete="off" {{$cp->obligatorio==1 ? 'required' : ''}} >
                            </div>
                            @else
                                <div class="form-group">
                                    <label for="">{{$cp->nombre}}</label>
                                    <div class="input-group m-b-10">
                                        <input type="{{$cp->numerico==1 ? 'number' : 'text'}}" class="form-control" id="field_{{$cp->codbanco}}" name="field_{{$cp->codbanco}}" autocomplete="off" {{$cp->obligatorio==1 ? 'required' : ''}}>
                                        <div class="input-group-prepend">
                                            <a class="btn btn-inverse fa fa-question-circle text-white" data-fancybox="" href="{{asset('img/convenios/ayuda/'.$cp->img)}}"></a>
                                        </div>
                                    </div>
                                </div>
                            @endif
                        @endif
                    @endforeach
                </div>    
                
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="">Valor</label>
                            <input type="text" class="form-control numeric" id="valor" name="valor" required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="">Valor Recibido</label>
                            <input type="text" class="form-control numeric" id="valor_recibido" name="valor_recibido" required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="checkbox checkbox-css">
                            <input type="checkbox" id="incluirFlete" value="">
                            <label for="incluirFlete" style="color: #1a4772 !important;"><b>¿Flete incluido?</b></label>
                        </div>
                    </div>
                    <div class="col-md-12 px-0" id="resumen-giro">
                        <hr>
                        <div class="note note-primary m-b-15">
                            <div class="note-icon"><i class="fa fa-dollar-sign"></i></div>
                            <div class="note-content text-right ml-0">
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4><b>Valor</b></h4>
                                    </div>
                                    <div class="col-sm-5">
                                        <h4><span id="h1-valor">$ 0<span></h4>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4><b>Tarifa</b></h4>
                                    </div>
                                    <div class="col-sm-5">
                                        <h4><span id="h1-tarifa">-<span></h4>
                                    </div>
                                </div>
                                <hr class="my-1 mb-2">
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4><b>Total</b></h4>
                                    </div>
                                    <div class="col-sm-5">
                                        <h2 class="font-weight-bold"><span id="h1-total">-<span></h2>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4><b>Recibido</b></h4>
                                    </div>
                                    <div class="col-sm-5">
                                        <h2 class="font-weight-bold"><span id="h1-recibido">-<span></h2>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4><b>Cambio</b></h4>
                                    </div>
                                    <div class="col-sm-5">
                                        <h2 class="font-weight-bold"><span id="h1-cambio">-<span></h2>
                                    </div>
                                </div>
                                    
                            </div>
                        </div>
                            {{Form::hidden('et-g',2,['id'=>'et-g'])}}
                    </div>
                    <div class="col-sm-12">
                        <button type="submit" class="btn btn-primary">Enviar</button>
                    </div>
                </div>
            
            {{Form::close()}}
        @else
            {{Form::open(['route' => 'clientes.pagar-convenio', 'class' => 'form-horizontal wizard-circle col-sm-12', 'id' => 'agregarAsignatura', 'target'=> "_blank"]) }}
            {!! Form::hidden('valor_cambio', 0,['id'=>'valor_cambio']) !!}
            {!! Form::hidden('valor_giro', 0,['id'=>'valor_giro']) !!}
            {!! Form::hidden('codconvenio', $convenio->codconvenio,['id'=>'codconvenio']) !!}  
            <div class="card border-0">
                <div class="card-header f-w-600 text-center">
                    Datos convenios
                </div>
                <div class="card-body">
                    @foreach($campos as $cp)
                        @if($cp->codbanco==7)
                        <div class="form-group">
                            <label for="">{{$cp->nombre}}</label>
                            <div class="input-group m-b-10">
                                <div class="input-group-prepend">
                                    <select id="tipo_cuenta" class="form-control chosen-select no-label" required="required" name="tipo_cuenta">
                                    <option selected="selected" value="">Tipo</option><option value="2">Ahorros</option><option value="3">Corriente</option>
                                    </select>
                                </div>
                                <input type="{{$cp->numerico==1 ? 'number' : 'text'}}" name="field_{{$cp->codbanco}}" class="form-control" {{$cp->obligatorio==1 ? 'required' : ''}}>
                            </div>
                        </div>
                        @elseif($cp->codbanco==10)
                        <div class="form-group">
                            <label for="">{{$cp->nombre}}</label>
                            <select id="field_{{$cp->codbanco}}" class="form-control chosen-select no-label" required="required" name="field_{{$cp->codbanco}}">
                                <option selected="selected" value="">Tipo</option><option value="TI">TARJETA IDENTIDAD</option><option value="CC">CEDULA DE CIUDADANIA</option><option value="CE">CEDULA DE EXTRANJERIA</option>
                            </select>
                        </div>
                        @else
                            @if(blank($cp->img))
                            <div class="form-group">
                                <label for="">{{$cp->nombre}}</label>
                                <input type="{{$cp->numerico==1 ? 'number' : 'text'}}" class="form-control" id="field_{{$cp->codbanco}}" name="field_{{$cp->codbanco}}" autocomplete="off" {{$cp->obligatorio==1 ? 'required' : ''}} >
                            </div>
                            @else
                                <div class="form-group">
                                    <label for="">{{$cp->nombre}}</label>
                                    <div class="input-group m-b-10">
                                        <input type="{{$cp->numerico==1 ? 'number' : 'text'}}" class="form-control" id="field_{{$cp->codbanco}}" name="field_{{$cp->codbanco}}" autocomplete="off" {{$cp->obligatorio==1 ? 'required' : ''}}>
                                        <div class="input-group-prepend">
                                            <a class="btn btn-inverse fa fa-question-circle text-white" data-fancybox="" href="{{asset('img/convenios/ayuda/'.$cp->img)}}"></a>
                                        </div>
                                    </div>
                                </div>
                            @endif
                        @endif
                    @endforeach
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Valor</label>
                                <input type="text" class="form-control numeric" name="valor_convenio" id="valor_convenio" autocomplete="off" {{1==1 ? 'required' : ''}}>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Confirmar Valor</label>
                                <input type="text" class="form-control numeric" name="confirmar_valor" autocomplete="off" {{1==1 ? 'required' : ''}}>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-success" type="submit">Enviar</button>
                </div>
                <div class="card-footer f-w-600">
                
                </div>
            </div>
            <!-- end card -->   
            {{Form::close()}}
        @endif
</div>
<!-- end col-6 -->
</div>
<a data-fancybox="" data-type="iframe" href="#" class="btn btn-primary btn-factura" style="display: none;">
Open demo
</a>
<script>
if($(window).width()>1400){
    //console.log(0);
    $('#ppal').css("margin-top","-350px");
}else{
    //console.log(1);
    $('#ppal').css("margin-top","-300px");
}
$("input").on('keyup', function (e) {


String.fromCharCode((96 <= e.keyCode && e.keyCode <= 105) ? e.keyCode-48 : e.keyCode)
    if (e.keyCode === 13) {
        $(this).parent().find('.btn-buscar-recibe').click();
        //alert($("input[type='radio']:checked").val());
    }else{
        return false;
    }
});
// $(document).on("contextmenu", function (e) {        
//     e.preventDefault();
// });
$(document).keydown(function (event) {
    //console.log(event.keyCode);
    if (event.keyCode == 123) { // Prevent F12
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
        return false;
    }else if(event.keyCode == 116) { // Prevent F12
        return false;
    }
});
tarifas = [
    @if($convenio->codcategoria==3)
        @foreach(DB::table('tarifas_convenios')->where('grupo','=',$sucursal->tarifa_consignacion)->orderBy('valor_inicial','asc')->get() as $tarifas)
            {
                codtarifa: {{$tarifas->codtarifa}},
                inicio: {{$tarifas->valor_inicial}},
                fin: {{$tarifas->valor_final}},
                costo: {{blank($tarifas->costo) ? 0 : $tarifas->costo}},
                porcentaje: {{blank($tarifas->porcentaje) ? 0 : $tarifas->porcentaje}}
            },
        @endforeach
    @elseif($convenio->codcategoria==4)
        @foreach(DB::table('tarifas_tarjetas')->where('grupo','=',$sucursal->tarifa_consignacion)->orderBy('valor_inicial','asc')->get() as $tarifas)
            {
                codtarifa: {{$tarifas->codtarifa}},
                inicio: {{$tarifas->valor_inicial}},
                fin: {{$tarifas->valor_final}},
                costo: {{blank($tarifas->costo) ? 0 : $tarifas->costo}},
                porcentaje: {{blank($tarifas->porcentaje) ? 0 : $tarifas->porcentaje}}
            },
        @endforeach
    @endif
];
$("#agregarAsignatura").validate({
    ignore: ":not(.chosen-select):checkbox",
    submitHandler: function(form) {
        @if($convenio->codcategoria==3)
        
            if($("#valor").val().replace(/,/gi, '')>{{$convenio->maximo}}||$("#valor").val().replace(/,/gi, '')<{{$convenio->minimo}}){
                frameworkApp.setAlert('El valor a consignar debe estar entre $ {{number_format($convenio->minimo)}} y $ {{number_format($convenio->maximo)}}');
            }else if(Number($("#valor_cambio").val())<0){
                frameworkApp.setAlert('El valor recibido no puede ser inferior al valor total');
            }else{
                tipocuenta = $("#tipo_cuenta").val()==2 ? 'Ahorros' : 'Corriente';
                var html="";
                html+='<div class="alert alert-warning fade show m-b-10 text-center">Por favor verifique toda la información antes de realizar el envío</div>'
                html+='<div class="h4 m-b-10">Detalle Transacción</div>';
                html+='<div class="h4 m-b-10">Cuenta: <b>'+tipocuenta+' / '+$("#numero_cuenta").val()+'</b></div>';
                html+='<div class="h4 m-b-10"><b>'+$("#nombre_recibe").val()+'</b></div>';
                html+='<div class="h4 m-b-10">CC <b>'+$("#identificacion_recibe").val()+'</b></div>';
                html+='<div class="h4 m-b-10">Telefono <b>'+$("#telefono_recibe").val()+'</b></div><br>';

                html+='<div class="h4 m-b-10">Envia: <b>'+$("#nombre_envia").val()+'</b></div>';
                html+='<div class="h4 m-b-10">CC <b>'+$("#identificacion_envia").val()+'</b></div>';
                html+='<div class="h4 m-b-10">Telefono <b>'+$("#telefono_envia").val()+'</b></div>';
                html+='<div class="alert alert-danger fade show m-b-10 text-center font-weight-bold" style="color: #fff; background: #ff5b57; border-color: #ff5b57;">RECUERDE QUE SU CONSIGNACIÓN SE VERÁ REFLEJADA EN HORARIO BANCARIO</div>';
                html+='<hr>'+$("#resumen-giro").html();
                bootbox.confirm({
                    message: html,
                    buttons: {
                        confirm: {
                            label: 'Todo es correcto, enviar!',
                            className: 'btn-success'
                        },
                        cancel: {
                            label: 'Corregir información',
                            className: 'btn-danger'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $(".loader2").show();
                            $("#valor").val($("#valor_giro").val().replace(/,/gi, ''));
                            $("#valor_recibido").val($("#valor_recibido").val().replace(/,/gi, ''));
                            //form.submit();
                            $.ajax({
                                url: "{{ route('clientes.enviar-giro-banco') }}",
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                type: 'post',
                                data: $('#agregarAsignatura').serialize(),
                                success: function(result){
                                    console.log(result);
                                    $('.btn-factura').attr('href','{{url('factura-consignacion')}}?codconsignacion='+result.codconsignacion);

                                    $('.btn-factura').click();
                                    $(".loader2").hide();
                                    $('.btn-factura').attr('href','#');
                                    $("#categoria").val('');
                                    $('#categoria').trigger("chosen:updated");
                                    $("#convenio").val('');
                                    $('#convenio').trigger("chosen:updated");
                                    $('#categoria').change();
                                    $("#saldoSucursal").html("SALDO A CONSIGNAR: $"+result.saldo);
                                }
                            });
                        }
                    }
                });
            //form.submit();
            }
        @elseif($convenio->codcategoria==4)
            if($("#valor").val().replace(/,/gi, '')>{{$convenio->maximo}}||$("#valor").val().replace(/,/gi, '')<{{$convenio->minimo}}){
                frameworkApp.setAlert('El valor a consignar debe estar entre $ {{number_format($convenio->minimo)}} y $ {{number_format($convenio->maximo)}}');
            }else if(Number($("#valor_cambio").val())<0){
                frameworkApp.setAlert('El valor recibido no puede ser inferior al valor total');
            }else{
                var html="";
                html+='<div class="alert alert-warning fade show m-b-10 text-center">Por favor verifique toda la información antes de realizar el envío</div><br>'
                @foreach($campos as $cp)
                    html+='<h4>{{$cp->nombre}}: '+$("#field_{{$cp->codbanco}}").val()+'</h4>';
                @endforeach
                html+='<hr>'
                
                html+='<div class="alert alert-danger fade show m-b-10 text-center font-weight-bold" style="color: #fff; background: #ff5b57; border-color: #ff5b57;">RECUERDE QUE SU CONSIGNACIÓN SE VERÁ REFLEJADA EN HORARIO BANCARIO</div>';
                html+='<hr>'+$("#resumen-giro").html();
                bootbox.confirm({
                    message: html,
                    buttons: {
                        confirm: {
                            label: 'Todo es correcto, enviar!',
                            className: 'btn-success'
                        },
                        cancel: {
                            label: 'Corregir información',
                            className: 'btn-danger'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            if(1==1){
                            $(".loader2").show();
                            $("#valor").val($("#valor_giro").val().replace(/,/gi, ''));
                            $("#valor_recibido").val($("#valor_recibido").val().replace(/,/gi, ''));
                            //form.submit();
                            $.ajax({
                                url: "{{ route('clientes.pagar-convenio') }}",
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                type: 'post',
                                data: $('#agregarAsignatura').serialize(),
                                success: function(result){
                                    console.log(result);
                                    $('.btn-factura').attr('href','{{url('factura-pago')}}?codpago='+result.codpago);

                                    $('.btn-factura').click();
                                    $(".loader2").hide();
                                    $('.btn-factura').attr('href','#');
                                    $("#categoria").val('');
                                    $('#categoria').trigger("chosen:updated");
                                    $("#convenio").val('');
                                    $('#convenio').trigger("chosen:updated");
                                    $('#categoria').change();
                                    $("#saldoSucursal").html("SALDO A CONSIGNAR: $"+result.saldo);
                                }
                            });
                            }else{
                                $("#valor_convenio").val($("#valor_convenio").val().replace(/,/gi, ''));
                                form.submit();
                            }
                        }
                    }
                });
            }
            
            
        @else
            if($("#valor_convenio").val().replace(/,/gi, '')>500000){
                frameworkApp.setAlert('El valor recibido no puede ser superior a $ 500,000');
            }else{
                var html="";
                html+='<div class="alert alert-warning fade show m-b-10 text-center">Por favor verifique toda la información antes de realizar el envío</div><br>'
                @foreach($campos as $cp)
                    html+='<h4>{{$cp->nombre}}: '+$("#field_{{$cp->codbanco}}").val()+'</h4>';
                @endforeach
                html+='<hr>'
                
                html+='<h4>Valor: $ '+$("#valor_convenio").val()+'</h4>';
                html+='<br><div class="alert alert-danger fade show m-b-10 text-center font-weight-bold" style="color: #fff; background: #ff5b57; border-color: #ff5b57;">RECUERDE QUE EL PAGO QUEDARÁ REGISTRADO EN UN PLAZO MÁXIMO DE 24 HORAS. <br>NO RECAUDE FACTURAS VENCIDAS, NI DE PAGO INMEDIATO</div><br>'
                bootbox.confirm({
                    message: html,
                    buttons: {
                        confirm: {
                            label: 'Todo es correcto, enviar!',
                            className: 'btn-success'
                        },
                        cancel: {
                            label: 'Corregir información',
                            className: 'btn-danger'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            if(1==1){
                            $(".loader2").show();
                            $("#valor_convenio").val($("#valor_convenio").val().replace(/,/gi, ''));
                            //form.submit();
                            $.ajax({
                                url: "{{ route('clientes.pagar-convenio') }}",
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                type: 'post',
                                data: $('#agregarAsignatura').serialize(),
                                success: function(result){
                                    console.log(result);
                                    $('.btn-factura').attr('href','{{url('factura-pago')}}?codpago='+result.codpago);

                                    $('.btn-factura').click();
                                    $(".loader2").hide();
                                    $('.btn-factura').attr('href','#');
                                    $("#categoria").val('');
                                    $('#categoria').trigger("chosen:updated");
                                    $("#convenio").val('');
                                    $('#convenio').trigger("chosen:updated");
                                    $('#categoria').change();
                                    $("#saldoSucursal").html("SALDO A CONSIGNAR: $"+result.saldo);
                                }
                            });
                            }else{
                                $("#valor_convenio").val($("#valor_convenio").val().replace(/,/gi, ''));
                                form.submit();
                            }
                        }
                    }
                });
            }
            
        @endif
        return false;
    },
    rules: {
        confirmar_valor: {
            equalTo: "#valor_convenio"
        },
        
        
    },
    highlight: function (element, errorClass) {
    $(element).parent().addClass('has-feedback has-error');
    $(element).parent().removeClass('has-feedback has-success');
    },
    unhighlight: function (element, errorClass) {
    $(element).parent().removeClass('has-feedback has-error');
    $(element).parent().addClass('has-feedback has-success');
    },
    errorPlacement: function(error, element) {
        if(element.hasClass("no-label")){

        } else if(element.parents('.input-group').length > 0) {
            error.insertAfter(element.parents('.input-group'));
        } else if(element.parents('.form-group').find('.chosen-container').length > 0){
            error.parent().insertAfter(element);
        } else if(element.parents('.radio').find('.chosen-container').length > 0){
            error.insertAfter(element.parents('.radio').find('.chosen-container'));
        } else {
            error.insertAfter(element);
        }
    }
});

$('#valor_recibido').keyup(function () {
    calcularCambio();
});
$('#valor').keyup(function () {
    calcularValorTarifa();
});
$("#incluirFlete").change(function(){
            
        calcularValorTarifa();
        calcularCambio();
        
    });

$(".numeric").on({
    "focus": function(event) {
        $(event.target).select();
    },
    "keyup": function(event) {
        $(event.target).val(function(index, value) {
        return value.replace(/\D/g, "")
            .replace(/\B(?=(\d{3})+(?!\d)\.?)/g, ",");
        });
    }
});
function calcularCambio()
        {
            var valor=$("#valor").val().replace(/,/gi, '');
            var valor_recibido=$("#valor_recibido").val().replace(/,/gi, '');
            $('#valor_cambio').val(0);
            if($("#valor_recibido").val().replace(/,/gi, '')!=''){
                if(!$("#incluirFlete").prop("checked")){
                    var tarifa = Number(valor_recibido)-Number(valor)-Number($('#valor_tarifa').val()); 
                }else{
                    var tarifa = Number(valor_recibido)-Number(valor); 
                }
               $("#h1-recibido").text(numeral(valor_recibido).format('0,0'));
               if(valor<=3000000)
               $('#valor_cambio').val(tarifa);
               $("#h1-cambio").text(numeral(tarifa).format('0,0'));
           }else{
                $("#h1-recibido").text('');
                $("#h1-cambio").text('');
           }
        }
function calcularValorTarifa()
{
    var valor=$("#valor").val().replace(/,/gi, '');
    $("#valor_giro").val(valor);
    var valor_recibido=$("#valor_recibido").val().replace(/,/gi, '');
    if(valor!=''){
        $('#et-g').val(2);
        var entre = false;
        for(var i=0; i<tarifas.length; i++){
            if(!$("#incluirFlete").prop("checked")){
                
                $("#h1-valor").text(numeral(valor).format('0,0'));
                if(Number(valor)>=Number(tarifas[i].inicio) && Number(tarifas[i].fin)>=Number(valor)){
                    entre = true;
                    var data= tarifas[i];
                    console.log(tarifas[i]);
                    $('#et-g').val(1);
                    var valor_total = Number(valor);
                    if(data.porcentaje>0){
                        valor_porcentaje = (Number(valor_total)*Number(tarifas[i].porcentaje))/100;
                    }else{
                        valor_porcentaje = 0;
                    }
                    var tarifa = Number(tarifas[i].costo)+Number(valor_porcentaje); 
                    tarifa_global = tarifa;
                    $('#valor_tarifa').val(tarifa);
                    $('#codtarifa').val(tarifas[i].codtarifa);
                    $("#h1-tarifa").text(numeral(tarifa).format('0,0'));
                    $("#h1-total").text(numeral(valor_total+valor_porcentaje+tarifas[i].costo).format('0,0'));
                    return true;
                }else{
                    $("#h1-tarifa").text('');
                    $("#h1-total").text('');
                }
            }else{
                $('#et-g').val(1);
                var valor_total = Number(valor);
                if(tarifas[i].porcentaje>0){
                    valor_porcentaje_inicio = (Number(tarifas[i].inicio)*Number(tarifas[i].porcentaje))/100;
                    valor_porcentaje_final = (Number(tarifas[i].fin)*Number(tarifas[i].porcentaje))/100;
                }else{
                    valor_porcentaje_inicio = 0;
                    valor_porcentaje_final = 0;
                }
                if(Number(valor)>=Number(tarifas[i].inicio+valor_porcentaje_inicio) && Number(tarifas[i].fin+valor_porcentaje_final)>=Number(valor)){
                    console.log(tarifas[i]);
                    entre = true;
                    valorTemp = valor - tarifas[i].costo;
                    var porcentaje = '1.0'+(tarifas[i].porcentaje*10);
                    console.log(porcentaje);
                    valorTemp = valorTemp / (porcentaje);
                    valorTemp = valor - tarifas[i].costo - valorTemp;
                    var tarifa = tarifas[i].costo + valorTemp;
                    tarifa_global = tarifa;
                    $("#h1-valor").text(numeral(valor-tarifa).format('0,0'));
                    var valorN = Number(valor)-Number(tarifa); 
                    //console.log(valorN+'-'+valor+'-'+tarifa); 
                    $("#valor_giro").val((valorN));  
                    $('#valor_tarifa').val(tarifa);
                    $('#codtarifa').val(tarifas[i].codtarifa);
                    $("#h1-tarifa").text(numeral(tarifa).format('0,0'));
                    $("#h1-total").text(numeral(valor_total).format('0,0'));
                    console.log(tarifa);
                }else{
                    console.log('otra');
                }
                
            }
            
        }
        if(!entre){
            tarifa_global = 0;
            $("#h1-tarifa").text("-");
            $("#h1-total").text("-");
        }
    }else{
        $("#h1-recibido").text('');
        $("#h1-cambio").text('');
    }
}
</script>