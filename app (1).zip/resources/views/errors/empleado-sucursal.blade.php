@extends('layouts.blank')





@section('title', 'Page Not Found')





@section('content')

<div class="error">
    <div class="error-code m-b-10">404</div>
    <div class="error-content">
        <div class="error-message">Aún no se ha asignado una sucursal, contacte con AFA Inversiones</div>
        <br>
        <div>
            <a href="{{url("/")}}" class="btn btn-success p-l-20 p-r-20">Ir al inicio</a>
        </div>
    </div>
</div>
@endsection