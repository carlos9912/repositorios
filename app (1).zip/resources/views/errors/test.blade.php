@php

    use App\Models\Cliente;
    $cliente = new Cliente();

@endphp
@extends('layouts.blank')

@section('title', 'Page Not Found')

@section('content')
    <div class="row" style="padding-right: 5%; padding-left: 5%; padding-top: 40px;">
        <div class="col-sm-1"></div>
        <div class="col-sm-10">
            {{Form::open(['route' => 'mensaje', 'method' => 'POST', 'class' => 'validation-wizard wizard-circle', 'id' => 'agregarAsignatura']) }}  
                <div class="form-group">
                    <label for="exampleInputEmail1">Número de télefono</label>
                    <input type="text" name="celular" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Ingresa numero de celular">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Mensaje</label>
                    <textarea name="mensaje" class="form-control"></textarea>
                  </div>
                  <button type="submit" class="btn btn-primary">Enviar</button>
                        
            {{Form::close()}}
        </div>
    </div>

    
@endsection
