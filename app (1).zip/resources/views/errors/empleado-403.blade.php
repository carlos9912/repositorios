@extends('layouts.blank')





@section('title', 'Page Not Found')





@section('content')

<div class="error">
    <div class="error-code m-b-10">419</div>
    <div class="error-content">
        <div class="error-message">¡Acceso denegado!</div>
        <br>
        
        <br>
        <div>
            <a href="{{url("/")}}" class="btn btn-success p-l-20 p-r-20">Ir al inicio</a>
        </div>
    </div>
</div>
@endsection