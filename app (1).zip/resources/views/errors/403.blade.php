@extends('layouts.blank')

@section('title', 'Page Not Found')

@section('content')
    <div class="row" style="padding-right: 5%; padding-left: 5%;">
        <div class="col-sm-1"></div>
        <div class="col-sm-10 text-center">
            <img src="{{ asset('img/403-p.png') }}" class="img-responsive">
        </div>
    </div>

    
@endsection
