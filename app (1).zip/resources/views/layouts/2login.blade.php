<!DOCTYPE html>

<html lang="{{ app()->getLocale() }}">





<!-- Mirrored from www.themeon.net/nifty/v2.9/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 26 Apr 2018 20:16:40 GMT -->

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">



    <title>{{ config('app.name', 'Laravel') }}</title>





    <!--STYLESHEET-->

    <!--=================================================-->

    <!-- ================== BEGIN BASE CSS STYLE ================== -->

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>

    <link href='https://fonts.googleapis.com/css?family=Dosis:400,300,600,700' rel='stylesheet' type='text/css'>

    <link href="{{asset('color/assets/plugins/jquery-ui/jquery-ui.min.css')}}" rel="stylesheet" />

    <link href="{{asset('color/assets/plugins/bootstrap/4.1.3/css/bootstrap.min.css')}}" rel="stylesheet" />

    <link href="{{asset('color/assets/plugins/animate/animate.min.css')}}" rel="stylesheet" />

    <link href="{{asset('color/assets/css/default/style.min.css')}}" rel="stylesheet" />

    <link href="{{asset('color/assets/css/default/style-responsive.min.css')}}" rel="stylesheet" />

    <link href="{{asset('color/assets/css/default/theme/default.css')}}" rel="stylesheet" id="theme" />

    <!-- ================== END BASE CSS STYLE ================== -->



    <!-- ================== BEGIN BASE JS ================== -->

    <script src="{{asset('color/assets/plugins/pace/pace.min.js')}}"></script>

    <!-- ================== END BASE JS ================== -->

    

    

    <!--=================================================



    REQUIRED

    You must include this in your project.





    RECOMMENDED

    This category must be included but you may modify which plugins or components which should be included in your project.





    OPTIONAL

    Optional plugins. You may choose whether to include it in your project or not.





    DEMONSTRATION

    This is to be removed, used for demonstration purposes only. This category must not be included in your project.





    SAMPLE

    Some script samples which explain how to initialize plugins or components. This category should not be included in your project.





    Detailed information and more samples can be found in the document.



    =================================================-->

        

</head>



<!--TIPS-->

<!--You may remove all ID or Class names which contain "demo-", they are only used for demonstration. -->



<body class="pace-top bg-white">

    <!-- begin #page-loader -->

	<div id="page-loader" class="fade show"><span class="spinner"></span></div>

	<!-- end #page-loader -->

    <div id="page-container" class="fade">

        

        @yield('content')



    </div>

    <!--JAVASCRIPT-->

    <!--=================================================-->



    <!--jQuery [ REQUIRED ]-->

    <script src="{{asset('color/assets/plugins/jquery/jquery-3.3.1.min.js')}}"></script>

    <script src="{{asset('color/assets/plugins/jquery-ui/jquery-ui.min.js')}}"></script>

	<script src="{{asset('color/assets/plugins/bootstrap/4.1.3/js/bootstrap.bundle.min.js')}}"></script>

	<!--[if lt IE 9]>

		<script src="../assets/crossbrowserjs/html5shiv.js')}}"></script>

		<script src="../assets/crossbrowserjs/respond.min.js')}}"></script>

		<script src="../assets/crossbrowserjs/excanvas.min.js')}}"></script>

	<![endif]-->

	<script src="{{asset('color/assets/plugins/slimscroll/jquery.slimscroll.min.js')}}"></script>

	<script src="{{asset('color/assets/plugins/js-cookie/js.cookie.js')}}"></script>

	<script src="{{asset('color/assets/js/theme/default.min.js')}}"></script>

	<script src="{{asset('color/assets/js/apps.min.js')}}"></script>

    <script>

        $(document).ready(function() {

            App.init();

        });
        

    </script>



</body>



</html>