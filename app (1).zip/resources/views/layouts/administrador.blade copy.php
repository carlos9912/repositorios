<!DOCTYPE html>
<html lang="en">
@php
	use App\Models\Sucursal;
	use App\Models\Empleado;
	if(!blank(Auth::user()->codempleado)){
		$empleado = Empleado::find(Auth::user()->codempleado);
	}

@endphp

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Favicon icon -->

    <title>Giros - AFAInversiones</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
	
	<!-- ================== BEGIN BASE CSS STYLE ================== -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/jquery-ui/jquery-ui.min.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/bootstrap/4.1.3/css/bootstrap.min.css')}}" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link href="{{asset('color/assets/plugins/animate/animate.min.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/css/default/style.min.css')}}" rel="stylesheet" />	
	<link href="{{asset('color/assets/css/default/style-responsive.min.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/css/default/theme/default.css')}}" rel="stylesheet" id="theme" />
	<link href="{{asset('color/assets/plugins/dataT/dataTables.bootstrap4.min.css')}}" rel="stylesheet" />
	
	<link href="{{asset('color/assets/plugins/bootstrap-daterangepicker/daterangepicker.css')}}" rel="stylesheet" />
	<link href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css" rel="stylesheet"/>
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="{{asset('color/assets/plugins/jquery-jvectormap/jquery-jvectormap.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.css')}}" rel="stylesheet" />
	
	<link href="{{asset('color/assets/plugins/gritter/css/jquery.gritter.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/chosen/chosen.min.css')}}" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="{{asset('color/assets/plugins/pace/pace.min.js')}}"></script>
	<link href="{{asset('color/assets/plugins/jstree/dist/themes/default/style.min.css')}}" rel="stylesheet" />
	<!-- ================== END BASE JS ================== -->
	<style>
	    #content{
	         text-transform: uppercase;
	    }
		legend {
			font-size: 1rem;
			font-weight: 700;
		}
    	.dt-button{
			display: inline-block;
			margin-bottom: 0;
			font-weight: 400;
			text-align: center;
			white-space: nowrap;
			vertical-align: middle;
			-ms-touch-action: manipulation;
			touch-action: manipulation;
			cursor: pointer;
			background-image: none;
			border: 1px solid transparent;
			padding: 6px 12px;
			font-size: 12px;
			line-height: 1.42857143;
			border-radius: 4px;
			-webkit-user-select: none;
			-moz-user-select: none;
			-ms-user-select: none;
			user-select: none;
			color: #fff;
			background: #348fe2;
			border-color: #348fe2;
    	}
		.loader {
			position: absolute;
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			z-index: 99;
			background: 50% 50% no-repeat rgb(249,249,249);
		}
		.loader-container {
			height: 200px;
			
			top:0;
			bottom: 0;
			right: 0;

			margin: 270px;
			text-align: center;
		}
		.loader2 {
			position: absolute;
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			z-index: 9999999;
			background: 50% 50% no-repeat rgb(249,249,249,0.4);
		}
		.loader-container2 {
			height: 200px;
			
			top:0;
			bottom: 0;
			right: 0;

			margin: 270px;
			text-align: center;
		}
		.glyphicon-refresh-animate {
			-animation: spin .7s infinite linear;
			-webkit-animation: spin2 .7s infinite linear;
		}

		@-webkit-keyframes spin2 {
			from { -webkit-transform: rotate(0deg);}
			to { -webkit-transform: rotate(360deg);}
		}

		@keyframes spin {
			from { transform: scale(1) rotate(0deg);}
			to { transform: scale(1) rotate(360deg);}
		}
	</style>
</head>
<body>
	<!-- begin #page-loader -->
	<div id="page-loader" class="fade show"><span class="spinner"></span></div>
	<!-- end #page-loader -->
	
	<!-- begin #page-container -->
	<div id="page-container" class="fade page-sidebar-fixed page-header-fixed">
		<div id="loader" class='loader'>
			<div class='loader-container'>
				<img class="img-responsive" src="{{ asset('img/cargando.gif') }}" style="margin: 0 auto;">
			</div>
		</div>
		<div id="loader2" class='loader2' style="display:none;">
			<div class='loader-container2'>
				<img class="img-responsive" src="{{ asset('img/cargando.gif') }}" style="margin: 0 auto;">
			</div>	
		</div>
		<!-- begin #header -->
		<div id="header" class="header navbar-default">
			<!-- begin navbar-header -->
			<div class="navbar-header">
				<a href="{{url('/')}}" class="navbar-brand"><span class="navbar-logo"></span> <b>AFA</b> Giros</a>
				<button type="button" class="navbar-toggle" data-click="sidebar-toggled">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<!-- end navbar-header -->
			
			<!-- begin header-nav -->
			<ul class="navbar-nav navbar-right">
				<li class="dropdown navbar-user">
					<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
						<img src="color/assets/img/user/user-13.jpg" alt="" /> 
						<span class="d-none d-md-inline">{{Auth::user()->nombres.' '.Auth::user()->apellidos}}</span> <b class="caret"></b>
					</a>
					<div class="dropdown-menu dropdown-menu-right">
						<a href="#" class="dropdown-item" data-toggle="modal" data-target="#modal-message"> 
								<i class="demo-pli-male icon-lg icon-fw"></i> Cambiar Password
						</a>
						<a href="{{route('logout')}}" class="dropdown-item">
								<i class="demo-pli-unlock icon-lg icon-fw"></i> Salir
						</a>
						</div>
				</li>
			</ul>
			<!-- end header navigation right -->
		</div>
		<!-- end #header -->
		
		<!-- begin #sidebar -->
		<div id="sidebar" class="sidebar">
			<!-- begin sidebar scrollbar -->
			<div data-scrollbar="true" data-height="100%">
				<!-- begin sidebar user -->
				<ul class="nav">
					<li class="nav-profile">
						<a href="javascript:;" data-toggle="nav-profile">
							<div class="cover with-shadow"></div>
							<div class="image">
								<img src="color/assets/img/user/user-13.jpg" alt="" />
							</div>
							<div class="info">
								<b class="caret pull-right"></b>
								@if(!blank(Auth::user()->codempleado))
									{{strtoupper($empleado->nombreCompleto())}}
									<small>Cajero</small>
								@else
									{{Auth::user()->nombres.' '.Auth::user()->apellidos}}
									<small>Administrador</small>
								@endif
							</div>
						</a>
					</li>
					<li>
						<ul class="nav nav-profile">
							<li>
								<a href="#" class="dropdown-item" data-toggle="modal" data-target="#modal-message">
										<i class="demo-pli-male icon-lg icon-fw"></i> Cambiar Password
								</a>
							</li>
							<li>
								<a href="{{route('logout')}}" class="dropdown-item">
										<i class="demo-pli-unlock icon-lg icon-fw"></i> Salir
								</a>
							</li>
						</ul>
					</li>
				</ul>
				<!-- end sidebar user -->
				<!-- begin sidebar nav -->
				<ul class="nav">
					<li class="nav-header">Navegación</li>
					<li class="has-sub active">
						<a href="{{url('/')}}">
							<i class="fa fa-th-large"></i>
							<span>Inicio</span>
						</a>
					</li>
				
					@if(!blank(\Auth::user()->codempleado)&&\Auth::user()->perfil!=2)
						<li class="has-sub">
							<a href="{{url('transacciones')}}">
								<i class="fa fa-columns"></i> 	
								<span>Transacciones</span>
							</a>
						</li>
						
						@php
							$sucursal = Sucursal::find(session('sucursal')->codsucursal);
						@endphp
						<li class="has-sub">
							<a href="{{route('sucursal.estado-cuenta',[$sucursal->codsucursal])}}">
								
								<i class="fa fa-home"></i> 
								<span>Estado de cuenta</span>
							</a>
						</li>
						
						

						<li class="has-sub">
						<li><a href="{{url('sucursal-consultar')}}">
						<i class="fab fa-autoprefixer"></i> 
						<span>Puntos Giros Afa</span>
						</a>
						</li>
							
						
						<li class="has-sub">
							<a href="javascript:;">
								<b class="caret"></b>
								<i class="fa fa-comment-dots"></i> 
								<span>Soporte Tecnico</span>
							</a>
							<ul class="sub-menu">
								<li><a href="https://api.whatsapp.com/send?phone=573205624402" target="_blank">Whatsapp</a></li>
								<li><a href="https://www.facebook.com/GIROS-AFA-910681189277027/" target="_blank">Facebook info</a></li>
							
							</ul>
						</li>
					@elseif(\Auth::user()->perfil==2)
						<li class="has-sub">
							<a href="{{url('pagos')}}">
								<i class="fa fa-cart-arrow-down"></i> 
								<span>Pagos</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="{{url('consignaciones-giros')}}">
								<i class="fa fa-cart-arrow-down"></i> 
								<span>Consignaciones</span>
							</a>
						</li>
					@else
					
						<li class="has-sub">
							<a href="javascript:;">
								<b class="caret"></b>
								<i class="fa fa-home"></i> 
								<span>Sucursales</span>
							</a>
							<ul class="sub-menu">
								<li><a href="{{url('sucursal')}}">Sucursales</a></li>
								<li><a href="{{url('sucursal-recargas')}}">Sucursales Recargas</a></li>
								<li><a href="{{url('consignaciones')}}">Compensaciones</a></li>
							</ul>
						</li>
						<li class="has-sub">
							<a href="{{url('clientes')}}">
								<i class="fa fa-users"></i> 
								<span>Clientes</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="{{url('empleado')}}">
								<i class="fa fa-users"></i> 
								<span>Empleados</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="{{url('convenios')}}">
								<i class="fa fa-object-group"></i> 
								<span>Convenios</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="{{url('pagos')}}">
								<i class="fa fa-cart-arrow-down"></i> 
								<span>Pagos</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="{{url('consignaciones-giros')}}">
								<i class="fa fa-cart-arrow-down"></i> 
								<span>Consignaciones</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="{{url('otros')}}">
								<i class="fa fa-cart-arrow-down"></i> 
								<span>Otros</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="{{url('tarifas')}}">
								<i class="fa fa-dollar-sign"></i> 
								<span>Tarifas</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="javascript:;">
								<b class="caret"></b>
								<i class="fa fa-chart-pie"></i> 
								<span>Reportes</span>
							</a>
							<ul class="sub-menu">
								<li><a href="{{url('reportes')}}">Reporte de giros</a></li>
								<li><a href="{{url('reportes-estadisticos')}}">Reportes estadisticos</a></li>
								<li><a href="{{url('reportes-recargas')}}">Reportes recargas</a></li>
								<li><a href="{{url('reportes-detalle')}}">Reporte detallado de cajas</a></li>
								<li><a href="{{url('reportes-total')}}">Reporte general</a></li>
							</ul>
						</li>
						<li class="has-sub">
							<a href="javascript:;">
								<b class="caret"></b>
								<i class="fa fa-comment-dots"></i> 
								<span>Soporte Tecnico</span>
							</a>
							<ul class="sub-menu">
								<li><a href="https://api.whatsapp.com/send?phone=573205624402" target="_blank">Whatsapp</a></li>
								<li><a href="https://www.facebook.com/GIROS-AFA-910681189277027/" target="_blank">Facebook info</a></li>
							
							</ul>
						</li>
					
					@endif
					
					<li class="has-sub" style="background-color: #00acac;">
						<a href="#" onclick='$("#modal-calcular").modal("show");'>
							<i class="fa fa-th-large"></i>
							<span style="color: #fff; font-weight: 700;">Calcular Tarifa Giro</span>
						</a>
					</li>
					<!-- begin sidebar minify button -->
					<li><a href="javascript:;" id="navbarButton" class="sidebar-minify-btn" data-click="sidebar-minify"><i class="fa fa-angle-double-left"></i></a></li>
					<!-- end sidebar minify button -->
				</ul>
				<!-- end sidebar nav -->
			</div>
			<!-- end sidebar scrollbar -->
		</div>
		<div class="sidebar-bg"></div>
		<!-- end #sidebar -->
		
		<!-- begin #content -->
		<div id="content" class="content">
			<!-- begin breadcrumb -->
			
			<!-- end breadcrumb -->
			<!-- begin page-header -->
			<!-- end page-header -->
			
			@yield('content')
			
		</div>
		<div class="modal modal-message fade" id="modal-message" aria-hidden="true" style="display: none;">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Cambiar Constraseña</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>
					<div class="modal-body">
					{{Form::open(['route' => 'sucursal.vincular-empleado', 'class' => 'validation-wizard wizard-circle', 'id' => 'cambiarPassword']) }} 
						<p>Introduce tu nueva contraseña</p>
						<input type="password" class="form-control" name="passwordNueva" id="passwordNueva" autocomplete="off">
						<input type="password" class="form-control" name="passwordNuevaConfirmar" autocomplete="off">
						<button class="btn btn-primary mt-4" type="submit">Cambiar Contraseña</button>
					{{Form::close()}}
					</div>
					<div class="modal-footer">
						<a href="javascript:;" class="btn btn-white" data-dismiss="modal">Cerrar</a>
					</div>
				</div>
			</div>
		</div>
		<div class="modal modal-message fade" id="modal-calcular" aria-hidden="true" style="display: none;">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body" style="width: 40%;">
						<div class="panel panel-inverse">
							<div class="panel-heading">
								Calcular valor giro
							</div>
							<div class="panel-body" >
								<div class="form-group row">
									<label class="col-form-label col-md-3">Valor Giro</label>
									<div class="col-md-9">
										<div class="input-group m-b-10">
											{!! Form::text('valor_p', null, ['class' => 'nombre-menu form-control numeric' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'valor_p' ]) !!}
											<div class="input-group-prepend">
												<span class="input-group-text pt-0" style="text-transform: none !important; background-color: #c2ddf7; color: #1a4772 !important;">
													<div class="checkbox checkbox-css">
														<input type="checkbox" id="incluirFleteP" value="">
														<label for="incluirFleteP" style="color: #1a4772 !important;"><b>¿Flete incluido?<b></label>
													</div>
												</span>
											</div>
										</div>
									</div>
								</div>
								
								<div class="form-group row">
									<div class="col-md-12" id="resumen-giro">
										<hr>
										<div class="note note-primary m-b-15">
											<div class="note-icon"><i class="fa fa-dollar-sign"></i></div>
											<div class="note-content text-right">
												<div class="row">
													<div class="col-sm-7">
														<h4><b>Valor Enviado</b></h4>
													</div>
													<div class="col-sm-5">
														<h4><span id="h1-valor-p">$ 0<span></h4>
													</div>
												</div>
												<div class="row">
													<div class="col-sm-7">
														<h4><b>Tarifa</b></h4>
													</div>
													<div class="col-sm-5">
														<h4><span id="h1-tarifa-p">-<span></h4>
													</div>
												</div>
												<hr class="my-1 mb-2">
												<div class="row">
													<div class="col-sm-7">
														<h4><b>Total</b></h4>
													</div>
													<div class="col-sm-5">
														<h2 class="font-weight-bold"><span id="h1-total-p">-<span></h2>
													</div>
												</div>
												
											</div>
										</div>
											{{Form::hidden('et-g',2,['id'=>'et-g'])}}
									</div>
								</div>
								<hr>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<a href="javascript:;" class="btn btn-white" data-dismiss="modal">Cerrar</a>
					</div>
				</div>
			</div>
		</div>
		<!-- end #content -->
		
		<!-- end theme-panel -->
		
		<!-- begin scroll to top btn -->
		<a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
		<!-- end scroll to top btn -->
	</div>
	<!-- end page container -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="{{ asset('color/assets/plugins/jquery/jquery-3.3.1.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/jquery-ui/jquery-ui.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/bootstrap/4.1.3/js/bootstrap.bundle.min.js')}}"></script>
	<!--[if lt IE 9]>
		<script src="color/assets/crossbrowserjs/html5shiv.js"></script>
		<script src="color/assets/crossbrowserjs/respond.min.js"></script>
		<script src="color/assets/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	<script src="{{ asset('color/assets/plugins/slimscroll/jquery.slimscroll.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/js-cookie/js.cookie.js')}}"></script>
	<script src="{{ asset('color/assets/js/theme/default.min.js')}}"></script>
	<script src="{{ asset('color/assets/js/apps.min.js')}}"></script>
	<!-- ================== END BASE JS ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="{{ asset('color/assets/plugins/masked-input/masked-input.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/gritter/js/jquery.gritter.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.time.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.resize.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.pie.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/sparkline/jquery.sparkline.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/jquery-jvectormap/jquery-jvectormap.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/jquery-jvectormap/jquery-jvectormap-world-mill-en.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')}}"></script>
	<script src="{{ asset('color/assets/js/demo/dashboard.min.js')}}"></script>

	<!--Sparkline [ OPTIONAL ]-->
	<script src="{{ asset('plugins/sparkline/jquery.sparkline.min.js')}}"></script>
	<script src="{{ asset('plugins/fancybox/jquery.fancybox.min.js') }}"></script>
	<script src="{{ asset('plugins/bootbox/bootbox.min.js') }}"></script>

	<!--DataTables [ OPTIONAL ]-->
	<script src="{{ asset('color/assets/plugins/select2/dist/js/select2.min.js')}}"></script>
	<script src="{{ asset('plugins/framework/framework.js') }}"></script>

	
    <!-- jQuery validate JavaScript -->
    <script src="{{ asset('plugins/jquery-validate/jquery-validate.js') }}"></script>
    <script src="{{ asset('plugins/jquery-validate/additional-methods.min.js') }}"></script>
    <script src="{{ asset('plugins/jquery-validate/messages_es.min.js') }}"></script>
	<script src="{{ asset('color/assets/plugins/chosen/chosen.jquery.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/bootstrap-daterangepicker/moment.js')}}"></script>
	<script src="{{asset('color/assets/plugins/bootstrap-daterangepicker/daterangepicker.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/chart-js/Chart.min.js')}}"></script>
	<script src="{{asset('plugins/dp/dobpicker.js')}}"></script>
	<script src="{{asset('color/assets/plugins/jstree/dist/jstree.min.js')}}"></script>
	
	<script src="{{ asset('color/assets/plugins/datatables.net/jquery.dataTables.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/dataT/dataTables.bootstrap4.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/DataTables/extensions/Buttons/js/dataTables.buttons.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/dataTables.buttons.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.bootstrap.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.flash.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/jszip.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/pdfmake.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/vfs_fonts.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.html5.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.print.min.js')}}"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>
	
	<!-- ================== END PAGE LEVEL JS ================== -->
	
	<script>
			@if(Auth::user()->id_usuario!=4)
	    (function() {

		    const idleDurationSecs = 600;    // X number of seconds
    		const redirectUrl = 'logout';  // Redirect idle users to this URL
    		let idleTimeout; // variable to hold the timeout, do not modify
    
    		const resetIdleTimeout = function() {
    
    			// Clears the existing timeout
    			if(idleTimeout) clearTimeout(idleTimeout);
    			//
    			// Set a new idle timeout to load the redirectUrl after idleDurationSecs
    			idleTimeout = setTimeout(() => {$(".loader2").show(); location.href = redirectUrl}, idleDurationSecs * 1000);
    		};
    
    		// Init on page load
    		resetIdleTimeout();
    
    		// Reset the idle timeout on any of the events listed below
    		['click', 'touchstart', 'mousemove'].forEach(evt => 
    			document.addEventListener(evt, resetIdleTimeout, false)
    		);

		})();
	@endif
		 $.ajaxSetup({

headers: {

	'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

}

});
	$("#cambiarPassword").validate({
		ignore: ":not(.chosen-select):checkbox",
		submitHandler: function(form) {
			$.ajax({
				url: "{{ url('usuarios/cambiar-password') }}",
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				type: 'post',
				data: $("#cambiarPassword").serialize(),
				success: function(result){
					$.gritter.add({title:"Operación realizada con éxito",text:"La contraseña fue actualizada con éxito"});
					$('#modal-message').modal('hide');
					$('#modal-message').find('input').val('');
				}
			});
			return false;
		},
		rules: {
			passwordNueva: {
				required: true,
				minlength: 6,
			},
			passwordNuevaConfirmar: {
				equalTo: "#passwordNueva"
			},
		},
		highlight: function (element, errorClass) {
		$(element).parent().addClass('has-feedback has-error');
		$(element).parent().removeClass('has-feedback has-success');
		},
		unhighlight: function (element, errorClass) {
		$(element).parent().removeClass('has-feedback has-error');
		$(element).parent().addClass('has-feedback has-success');
		},
		errorPlacement: function(error, element) {
			if(element.hasClass("no-label")){
			} else if(element.parents('.input-group').length > 0) {
				error.insertAfter(element.parents('.input-group'));
			} else if(element.parents('.form-group').find('.chosen-container').length > 0){
			} else if(element.parents('.radio').find('.chosen-container').length > 0){
				error.insertAfter(element.parents('.radio').find('.chosen-container'));
			} else {
				error.insertAfter(element);
			}
		}
	});
		$(document).ready(function() {
			App.init();
			Dashboard.init();
		});
		$(window).on('load', function(){
			$(".loader").fadeOut(1000);
			$("#contenedor").fadeIn(2000);
		});
		
	</script>
	<script>
		$('#valor_p').keypress(function (e) {
			if (String.fromCharCode(e.keyCode).match(/[^0-9]/g)){
				return false;
			}else if($(this).val().length > 9){
				return false;
			}
		});
		$('#valor_p').keyup(function () {
			calcularValorTarifaP();
		});

		tarifas = [
		@foreach(DB::table('tarifas')->orderBy('valor_inicial','asc')->get() as $tarifas)
			{
				inicio: {{$tarifas->valor_inicial}},
				fin: {{$tarifas->valor_final}},
				costo: {{blank($tarifas->costo) ? 0 : $tarifas->costo}},
				porcentaje: {{blank($tarifas->porcentaje) ? 0 : $tarifas->porcentaje}}
			},
		@endforeach
		];
		$("#incluirFleteP").change(function(){
		
			calcularValorTarifaP();
		
		});

		function calcularValorTarifaP()
		{
			var valor=$("#valor_p").val().replace(/,/gi, '');
			$("#valor_giro").val(valor);
			var valor_recibido=0;
			if(valor!=''){
				$('#et-g').val(2);
				var entre = false;
				for(var i=0; i<tarifas.length; i++){
					if(!$("#incluirFleteP").prop("checked")){
						
						$("#h1-valor-p").text(numeral(valor).format('0,0'));
						if(Number(valor)>=Number(tarifas[i].inicio) && Number(tarifas[i].fin)>=Number(valor)){
							entre = true;
							var data= tarifas[i];
							console.log(tarifas[i]);
							$('#et-g').val(1);
							var valor_total = Number(valor);
							if(data.porcentaje>0){
								valor_porcentaje = (Number(valor_total)*Number(tarifas[i].porcentaje))/100;
							}else{
								valor_porcentaje = 0;
							}
							var tarifa = Number(tarifas[i].costo)+Number(valor_porcentaje); 
							tarifa_global = tarifa;
							$('#valor_tarifa-p').val(tarifa);
							$("#h1-tarifa-p").text(numeral(tarifa).format('0,0'));
							$("#h1-total-p").text(numeral(valor_total+valor_porcentaje+tarifas[i].costo).format('0,0'));
							return true;
						}else{
							$("#h1-tarifa-p").text('');
							$("#h1-total-p").text('');
						}
					}else{
						$('#et-g').val(1);
						var valor_total = Number(valor);
						if(tarifas[i].porcentaje>0){
							valor_porcentaje_inicio = (Number(tarifas[i].inicio)*Number(tarifas[i].porcentaje))/100;
							valor_porcentaje_final = (Number(tarifas[i].fin)*Number(tarifas[i].porcentaje))/100;
						}else{
							valor_porcentaje_inicio = 0;
							valor_porcentaje_final = 0;
						}
						if(Number(valor)>=Number(tarifas[i].inicio+valor_porcentaje_inicio) && Number(tarifas[i].fin+valor_porcentaje_final)>=Number(valor)){
							console.log(tarifas[i]);
							entre = true;
							valorTemp = valor - tarifas[i].costo;
							var porcentaje = '1.0'+(tarifas[i].porcentaje*10);
							console.log(porcentaje);
							valorTemp = valorTemp / (porcentaje);
							valorTemp = valor - tarifas[i].costo - valorTemp;
							var tarifa = tarifas[i].costo + valorTemp;
							tarifa_global = tarifa;
							$("#h1-valor-p").text(numeral(valor-tarifa).format('0,0'));
							var valorN = Number(valor)-Number(tarifa); 
							//console.log(valorN+'-'+valor+'-'+tarifa); 
							$("#valor_giro").val((valorN));  
							$('#valor_tarifa').val(tarifa);
							$("#h1-tarifa-p").text(numeral(tarifa).format('0,0'));
							$("#h1-total-p").text(numeral(valor_total).format('0,0'));
							console.log(tarifa);
						}else{
							console.log('otra');
						}
						
					}
					
				}
				if(!entre){
					tarifa_global = 0;
					$("#h1-tarifa-p").text("-");
					$("#h1-total-p").text("-");
				}
			}else{
				$("#h1-recibido-p").text('');
				$("#h1-cambio-p").text('');
			}
		}
		
	</script>
	@yield('script')
</body>

<!-- Mirrored from seantheme.com/color-admin-v4.2/admin/html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 Jan 2019 18:53:31 GMT -->
</html>
