        <head>



            <!--STYLESHEET-->
            <!--=================================================-->

            <!--Open Sans Font [ OPTIONAL ]-->
            <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>


            <!--Bootstrap Stylesheet [ REQUIRED ]-->
            
            <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">


            <!--Nifty Stylesheet [ REQUIRED ]-->
            <link href="{{asset('css/nifty.min.css')}}" rel="stylesheet">


            <!--Nifty Premium Icon [ DEMONSTRATION ]-->
            <link href="{{asset('css/demo/nifty-demo-icons.min.css')}}" rel="stylesheet">


            <!--=================================================-->





            <!--Demo [ DEMONSTRATION ]-->
            <link href="{{asset('css/demo/nifty-demo.min.css')}}" rel="stylesheet">
            <link href="{{asset('plugins/themify-icons/themify-icons.min.css')}}" rel="stylesheet">
            <link href="{{asset('plugins/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">
            <!--Summernote [ OPTIONAL ]-->
            <link href="{{asset('plugins/summernote/summernote.min.css')}}" rel="stylesheet">
            <link href="{{ asset('plugins/fancybox/jquery.fancybox.min.css') }}" rel="stylesheet">
            <!--Chosen [ OPTIONAL ]-->
            <link href="{{ asset('plugins/chosen/chosen.min.css') }}" rel="stylesheet">
            <link href="{{ asset('plugins/chosen/chosenIcon.css') }}" rel="stylesheet">
            <!--Switchery [ OPTIONAL ]-->
            <link href="{{ asset('plugins/switchery/switchery.min.css') }}" rel="stylesheet">
            @yield('style')  

        </head>

        @yield('content')
        
        
        <!--JAVASCRIPT-->
        <!--=================================================-->
    
        <!--jQuery [ REQUIRED ]-->
        <script src="{{asset('js/jquery.min.js')}}"></script>

        
        <!-- jQuery validate JavaScript -->
        <script src="{{ asset('plugins/jquery-validate/jquery-validate.js') }}"></script>
        <script src="{{ asset('plugins/jquery-validate/additional-methods.min.js') }}"></script>
        <script src="{{ asset('plugins/jquery-validate/messages_es.min.js') }}"></script>
    
        <!--BootstrapJS [ RECOMMENDED ]-->
        <script src="{{asset('js/bootstrap.min.js')}}"></script>
    
    
        <!--NiftyJS [ RECOMMENDED ]-->
        <script src="{{asset('js/nifty.min.js')}}"></script>
    
    
    
    
        <!--=================================================-->
        
        <!--Demo script [ DEMONSTRATION ]-->
        <script src="{{asset('js/demo/nifty-demo.min.js')}}"></script>
    
        
        <!--Flot Chart [ OPTIONAL ]-->
        <script src="{{asset('plugins/flot-charts/jquery.flot.min.js')}}"></script>
        <script src="{{asset('plugins/flot-charts/jquery.flot.resize.min.js')}}"></script>
        <script src="{{asset('plugins/flot-charts/jquery.flot.tooltip.min.js')}}"></script>
        <!--Summernote [ OPTIONAL ]-->
        <script src="{{asset('plugins/summernote/summernote.min.js')}}"></script>
    
    
        <!--Sparkline [ OPTIONAL ]-->
        <script src="{{asset('plugins/sparkline/jquery.sparkline.min.js')}}"></script>
        <script src="{{ asset('plugins/fancybox/jquery.fancybox.min.js') }}"></script>
        <!--Chosen [ OPTIONAL ]-->
        <script src="{{ asset('plugins/chosen/chosen.jquery.min.js')}}"></script>
        <script src="{{ asset('plugins/chosen/chosenIcon.jquery.js')}}"></script>
        <!--Switchery [ OPTIONAL ]-->
        <script src="{{ asset('plugins/switchery/switchery.min.js')}}"></script>
        <script src="{{ asset('plugins/framework/framework.js') }}"></script>
        <script src="{{ asset('plugins/framework/plugins.js') }}"></script>
        <script src="{{ asset('plugins/bootbox/bootbox.min.js') }}"></script>

        
        @yield('script')
    
        <!--Specify page [ SAMPLE ]-->
        
    
  