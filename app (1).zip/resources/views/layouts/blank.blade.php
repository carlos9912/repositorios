<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('img/favicon.png') }}">

    <title>Giros - AFAInversiones</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
	
	<!-- ================== BEGIN BASE CSS STYLE ================== -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/jquery-ui/jquery-ui.min.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/bootstrap/4.1.3/css/bootstrap.min.css')}}" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link href="{{asset('color/assets/plugins/animate/animate.min.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/css/default/style.min.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/css/default/style-responsive.min.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/css/default/theme/default.css')}}" rel="stylesheet" id="theme" />
	<link href="color/assets/plugins/DataTables/media/css/dataTables.bootstrap.min.css" rel="stylesheet" />
	<link href="color/assets/plugins/DataTables/extensions/Responsive/css/responsive.bootstrap.min.css" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/DataTables/extensions/Buttons/css/buttons.bootstrap.min.css')}}" rel="stylesheet" id="theme" />
	
	<link href="color/assets/plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet" />
	<link href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css" rel="stylesheet"/>
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="{{asset('color/assets/plugins/jquery-jvectormap/jquery-jvectormap.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.css')}}" rel="stylesheet" />
	
	<link href="{{asset('color/assets/plugins/gritter/css/jquery.gritter.css')}}" rel="stylesheet" />
	<link href="color/assets/plugins/chosen/chosen.min.css" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="color/assets/plugins/pace/pace.min.js"></script>
	<!-- ================== END BASE JS ================== -->


</head>
<body class="pace-top">
	<!-- begin #page-loader -->
	<div id="page-loader" class="fade show"><span class="spinner"></span></div>
	<!-- end #page-loader -->
	
	<!-- begin #page-container -->
	<div id="page-container">
		
		
		@yield('content')
	</div>
	<!-- end page container -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="{{ asset('color/assets/plugins/jquery/jquery-3.3.1.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/jquery-ui/jquery-ui.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/bootstrap/4.1.3/js/bootstrap.bundle.min.js')}}"></script>
	<!--[if lt IE 9]>
		<script src="color/assets/crossbrowserjs/html5shiv.js"></script>
		<script src="color/assets/crossbrowserjs/respond.min.js"></script>
		<script src="color/assets/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	<script src="{{ asset('color/assets/plugins/slimscroll/jquery.slimscroll.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/js-cookie/js.cookie.js')}}"></script>
	<script src="{{ asset('color/assets/js/theme/default.min.js')}}"></script>
	<script src="{{ asset('color/assets/js/apps.min.js')}}"></script>
	<!-- ================== END BASE JS ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="{{ asset('color/assets/plugins/masked-input/masked-input.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/gritter/js/jquery.gritter.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.time.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.resize.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.pie.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/sparkline/jquery.sparkline.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/jquery-jvectormap/jquery-jvectormap.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/jquery-jvectormap/jquery-jvectormap-world-mill-en.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')}}"></script>
	<script src="{{ asset('color/assets/js/demo/dashboard.min.js')}}"></script>

	<!--Sparkline [ OPTIONAL ]-->
	<script src="{{ asset('plugins/sparkline/jquery.sparkline.min.js')}}"></script>
	<script src="{{ asset('plugins/fancybox/jquery.fancybox.min.js') }}"></script>
	<script src="{{ asset('plugins/bootbox/bootbox.min.js') }}"></script>

	<!--DataTables [ OPTIONAL ]-->
	<script src="{{ asset('color/assets/plugins/DataTables/media/js/jquery.dataTables.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/DataTables/media/js/dataTables.bootstrap.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/DataTables/extensions/Responsive/js/dataTables.responsive.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/select2/dist/js/select2.min.js')}}"></script>
	<script src="{{ asset('plugins/framework/framework.js') }}"></script>

	
    <!-- jQuery validate JavaScript -->
    <script src="{{ asset('plugins/jquery-validate/jquery-validate.js') }}"></script>
    <script src="{{ asset('plugins/jquery-validate/additional-methods.min.js') }}"></script>
    <script src="{{ asset('plugins/jquery-validate/messages_es.min.js') }}"></script>
	<script src="{{ asset('color/assets/plugins/chosen/chosen.jquery.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/bootstrap-daterangepicker/moment.js')}}"></script>
	<script src="{{asset('color/assets/plugins/bootstrap-daterangepicker/daterangepicker.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/chart-js/Chart.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/DataTables/extensions/Buttons/js/dataTables.buttons.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/dataTables.buttons.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.bootstrap.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.flash.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/jszip.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/pdfmake.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/vfs_fonts.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.html5.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.print.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Responsive/js/dataTables.responsive.min.js')}}"></script>
	
	<!-- ================== END PAGE LEVEL JS ================== -->
	<script>
	$(document).ready(function() {
			App.init();
			Dashboard.init();
		});
		$(window).on('load', function(){
			$(".loader").fadeOut(1000);
			$("#contenedor").fadeIn(2000);
		});
	
	</script>
	@yield('script')
</body>

<!-- Mirrored from seantheme.com/color-admin-v4.2/admin/html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 Jan 2019 18:53:31 GMT -->
</html>
