
@component('mail::layout')
    {{-- Header --}}
    @slot('header')
        @component('mail::header', ['url' => config('app.url')])
            Nueva notificación
        @endcomponent
    @endslot
{{-- Body --}}
   {{ Html::image(asset('img/logo-conaced_mail.png'), 'homepage', ['class' => 'dark-logo']) }}
   <br>
   {{ $informacion }}
   <br>
    <a class="  btn btn-primary  " href="{{config('app.url')}}/notificaciones">Abrir Notificaciones</a>
{{-- Footer --}}
    @slot('footer')
        @component('mail::footer')
            © {{ date('Y') }} {{ config('app.name') }}.
        @endcomponent
    @endslot
@endcomponent