@php
	use App\Models\Sucursal;
	use App\Models\Empleado;
	if(!blank(Auth::user()->codempleado)){
		$empleado = Empleado::find(Auth::user()->codempleado);
	}

@endphp
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<!-- Mirrored from seantheme.com/admetro/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Feb 2020 14:23:42 GMT -->
<head>
	<meta charset="utf-8" />
	<title>::Afainversiones - La oportunidad de crecer juntos::</title>
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
	
	<!-- ================== BEGIN BASE CSS STYLE ================== -->
	<link href="{{asset('new/assets/css/app.min.css')}}" rel="stylesheet" />
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN BASE CSS STYLE ================== -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/jquery-ui/jquery-ui.min.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/bootstrap/4.1.3/css/bootstrap.min.css')}}" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link href="{{asset('color/assets/plugins/animate/animate.min.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/css/default/style.min.css')}}" rel="stylesheet" />	
	<link href="{{asset('color/assets/css/default/style-responsive.min.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/css/default/theme/default.css')}}" rel="stylesheet" id="theme" />
	<link href="{{asset('color/assets/plugins/dataT/dataTables.bootstrap4.min.css')}}" rel="stylesheet" />
	
	<link href="{{asset('color/assets/plugins/bootstrap-daterangepicker/daterangepicker.css')}}" rel="stylesheet" />
	<link href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css" rel="stylesheet"/>
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="{{asset('color/assets/plugins/jquery-jvectormap/jquery-jvectormap.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.css')}}" rel="stylesheet" />
	
	<link href="{{asset('color/assets/plugins/gritter/css/jquery.gritter.css')}}" rel="stylesheet" />
	<link href="{{asset('color/assets/plugins/chosen/chosen.min.css')}}" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="{{asset('color/assets/plugins/pace/pace.min.js')}}"></script>
	<link href="{{asset('color/assets/plugins/jstree/dist/themes/default/style.min.css')}}" rel="stylesheet" />
	<!-- ================== END BASE JS ================== -->
	<style>
	    #content{
	         text-transform: uppercase;
	    }
		legend {
			font-size: 1rem;
			font-weight: 700;
		}
    	.dt-button{
			display: inline-block;
			margin-bottom: 0;
			font-weight: 400;
			text-align: center;
			white-space: nowrap;
			vertical-align: middle;
			-ms-touch-action: manipulation;
			touch-action: manipulation;
			cursor: pointer;
			background-image: none;
			border: 1px solid transparent;
			padding: 6px 12px;
			font-size: 12px;
			line-height: 1.42857143;
			border-radius: 4px;
			-webkit-user-select: none;
			-moz-user-select: none;
			-ms-user-select: none;
			user-select: none;
			color: #fff;
			background: #348fe2;
			border-color: #348fe2;
    	}
		.loader {
			position: absolute;
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			z-index: 99;
			background: 50% 50% no-repeat rgb(249,249,249);
		}
		.loader-container {
			height: 200px;
			
			top:0;
			bottom: 0;
			right: 0;

			margin: 270px;
			text-align: center;
		}
		.loader2 {
			position: absolute;
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			z-index: 9999999;
			background: 50% 50% no-repeat rgb(249,249,249,0.4);
		}
		.loader-container2 {
			height: 200px;
			
			top:0;
			bottom: 0;
			right: 0;

			margin: 270px;
			text-align: center;
		}
		.glyphicon-refresh-animate {
			-animation: spin .7s infinite linear;
			-webkit-animation: spin2 .7s infinite linear;
		}

		@-webkit-keyframes spin2 {
			from { -webkit-transform: rotate(0deg);}
			to { -webkit-transform: rotate(360deg);}
		}

		@keyframes spin {
			from { transform: scale(1) rotate(0deg);}
			to { transform: scale(1) rotate(360deg);}
		}
	</style>
</head>
<body>
	<!-- BEGIN #app -->
	<div id="app" class="app app-header-fixed app-sidebar-fixed">
		<div id="loader" class='loader'>
			<div class='loader-container'>
				<img class="img-responsive" src="{{ asset('img/cargando.gif') }}" style="margin: 0 auto;">
			</div>
		</div>
		<div id="loader2" class='loader2' style="display:none;">
			<div class='loader-container2'>
				<img class="img-responsive" src="{{ asset('img/cargando.gif') }}" style="margin: 0 auto;">
			</div>	
		</div>
		<!-- BEGIN #header -->
		<header id="header" class="app-header mt-0">
			<!-- BEGIN navbar-toggle-minify -->
			<button type="button" class="navbar-toggle navbar-toggle-minify" data-click="sidebar-minify">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<!-- END navbar-toggle-minify -->
			<!-- BEGIN navbar-header -->
			<div class="navbar-header">
				<a href="index.html" class="navbar-brand">
					Afainversiones
				</a>
				<button type="button" class="navbar-toggle" data-click="sidebar-toggled">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<!-- END navbar-header -->
			<!-- BEGIN navbar-nav -->
			<ul class="navbar-nav navbar-right">
				
				<li class="nav-item dropdown">
					
					<div class="dropdown-menu dropdown-menu-right">
					<a href="#" class="dropdown-item" data-toggle="modal" data-target="#modal-message"> 
								<i class="demo-pli-male icon-lg icon-fw"></i> Cambiar Password
						</a>
						<a href="{{route('logout')}}" class="dropdown-item">
								<i class="demo-pli-unlock icon-lg icon-fw"></i> Salir
						</a>
					</div>
				</li>
			</ul>
			<!-- END navbar-nav -->
			<!-- BEGIN navbar-search -->
			<div class="navbar-search">
				<form action="#" method="POST" name="navbar_search_form">
					<div class="form-group">
						<div class="icon"><i class="fa fa-search"></i></div>
						<input type="text" class="form-control" id="header-search" placeholder="Search admetro..." />
						<div class="icon">
							<a href="#" data-dismiss="search-bar" class="right-icon"><i class="fa fa-times"></i></a>
						</div>
					</div>
				</form>
			</div>
			<!-- END navbar-search -->
		</header>
		<!-- END #header -->
		
		<!-- BEGIN #sidebar -->
		<sidebar id="sidebar" class="app-sidebar">
			<!-- BEGIN scrollbar -->
			<div data-scrollbar="true" data-height="100%">
				<!-- BEGIN nav -->
				<ul class="nav">
					<li class="nav-profile">
						<div class="profile-img">
							<img src="{{asset('color/assets/img/user/user-13.jpg')}}" />
						</div>
						<div class="profile-info">
							@if(!blank(Auth::user()->codempleado))
								<h4>{{strtoupper($empleado->nombreCompleto())}}</h4>
								<p>Cajero</p>
							@else
								<h4>{{Auth::user()->nombres.' '.Auth::user()->apellidos}}</h4>
								<p>Administrador</p>
							@endif
						</div>
					</li>
					<li class="has-sub">
						<a href="#">
							<span class="nav-icon"><i class="fa fa-user bg-gradient-red text-white"></i> </span>
							<span class="nav-text">Opciones Usuario</span>
							<span class="nav-caret"><b class="caret"></b></span>
						</a>
						<ul class="nav-submenu">
							<li><a href="#" data-toggle="modal" data-target="#modal-message"> Cambiar Password</a></li>
							<li><a href="{{route('logout')}}">Salir</a></li>
						</ul>
					</li>
					<li class="nav-divider"></li>
					<li class="nav-header">Menú Principal</li>
					<li class="active">
						<a href="{{url('/')}}">
							<span class="nav-icon"><i class="fa fa-home bg-gradient-blue text-white"></i></span>
							<span class="nav-text">Inicio</span>
						</a>
					</li>
				
					@if(!blank(\Auth::user()->codempleado)&&\Auth::user()->perfil!=2)
						
						<li class="">
							<a href="{{url('transacciones')}}">
								<span class="nav-icon"><i class="fa fa-qrcode bg-gradient-orange icon text-white"></i></span>
								<span class="nav-text">Transacciones</span>
							</a>
						</li>
						@php
							$sucursal = Sucursal::find(session('sucursal')->codsucursal);
						@endphp
						
						<li>
							<a href="{{route('sucursal.estado-cuenta',[$sucursal->codsucursal])}}">
								<span class="nav-icon"><i class="fa fa-chart-bar bg-gradient-purple text-white"></i></span>
								<span class="nav-text">Estado de Cuenta</span>
							</a>
						</li>
						<li class="nav-header">Ayuda</li>
						<li>
							<a href="{{url('sucursal-consultar')}}">
								<span class="nav-icon"><i class="fa fa-map-marker-alt bg-gradient-blue text-white"></i></span>
								<span class="nav-text">Puntos Giros AFA</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="#">
								<span class="nav-icon"><i class="fa fa-cog bg-gradient-red text-white"></i> </span>
								<span class="nav-text">Soporte</span>
								<span class="nav-caret"><b class="caret"></b></span>
							</a>
							<ul class="nav-submenu">
								<li><a <a target="_blank" href="https://api.whatsapp.com/send?phone=573205624402">Whatsapp</a></li>
								<li><a <a target="_blank" href="https://www.facebook.com/GIROS-AFA-910681189277027/">Facebook</a></li>
							</ul>
						</li>
					@elseif(\Auth::user()->perfil==2)
						<li class="has-sub">
							<a href="#">
								<span class="nav-icon"><i class="fa fa-envelope"></i> </span>
								<span class="nav-text">Operaciones <span class="nav-label">20+</span></span>
								<span class="nav-caret"><b class="caret"></b></span>
							</a>
							<ul class="nav-submenu">
								<li><a href="{{url('pagos')}}">Pagos</a></li>
								<li><a href="{{url('consignaciones-giros')}}">Consignaciones</a></li>
								<li><a href="{{url('otros')}}">Otros</a></li>
							</ul>
						</li>
					@else
						<li class="has-sub">
							<a href="#">
								<span class="nav-icon"><i class="fa fa-store-alt bg-gradient-blue text-white icon"></i> </span>
								<span class="nav-text">Sucursales <span class="nav-label">20+</span></span>
								<span class="nav-caret"><b class="caret"></b></span>
							</a>
							<ul class="nav-submenu">
								<li><a href="{{url('sucursal')}}">Sucursales</a></li>
								<li><a href="{{url('sucursal-recargas')}}">Sucursales Recargas</a></li>
								<li><a href="{{url('consignaciones')}}">Compensaciones</a></li>
							</ul>
						</li>
						<li>
							<a href="{{url('clientes')}}">
								<span class="nav-icon"><i class="fa fa-users bg-gradient-indigo text-white icon"></i></span>
								<span class="nav-text">Clientes</span>
							</a>
						</li>
						<li>
							<a href="{{url('empleados')}}">
								<span class="nav-icon"><i class="fa fa-users bg-gradient-indigo text-white icon"></i></span>
								<span class="nav-text">Empleados</span>
							</a>
						</li>
						<li>
							<a href="{{url('convenios')}}">
								<span class="nav-icon"><i class="fa fa-file-alt bg-gradient-blue text-white"></i></span>
								<span class="nav-text">Convenios</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="#">
								<span class="nav-icon"><i class="fa fa-credit-card bg-gradient-green text-white icon"></i> </span>
								<span class="nav-text">Operaciones <span class="nav-label">20+</span></span>
								<span class="nav-caret"><b class="caret"></b></span>
							</a>
							<ul class="nav-submenu">
								<li><a href="{{url('pagos')}}">Pagos</a></li>
								<li><a href="{{url('consignaciones-giros')}}">Consignaciones</a></li>
								<li><a href="{{url('otros')}}">Otros</a></li>
							</ul>
						</li>
						<li>
							<a href="{{url('tarifas')}}">
								<span class="nav-icon"><i class="fa fa-dollar-sign bg-gradient-green text-white icon"></i></span>
								<span class="nav-text">Tarifas</span>
							</a>
						</li>
						<li class="has-sub">
							<a href="#">
								<span class="nav-icon"><i class="fa fa-chart-bar bg-gradient-purple text-white"></i> </span>
								<span class="nav-text">Reportes <span class="nav-label">20+</span></span>
								<span class="nav-caret"><b class="caret"></b></span>
							</a>
							<ul class="nav-submenu">
								<li><a href="{{url('reportes')}}">Giros</a></li>
								<li><a href="{{url('reportes-estadisticos')}}">Estadisticos</a></li>
								<li><a href="{{url('reportes-recargas')}}">Recargas</a></li>
								<li><a href="{{url('reportes-detalle')}}">Detallado Cajas</a></li>
								<li><a href="{{url('reportes-total')}}">General</a></li>
							</ul>
						</li>
						<li class="has-sub">
							<a href="#">
								<span class="nav-icon"><i class="fa fa-cog bg-gradient-primary "></i> </span>
								<span class="nav-text">Soporte <span class="nav-label">20+</span></span>
								<span class="nav-caret"><b class="caret"></b></span>
							</a>
							<ul class="nav-submenu">
								<li><a <a target="_blank" href="https://api.whatsapp.com/send?phone=573205624402">Whatsapp</a></li>
								<li><a <a target="_blank" href="https://www.facebook.com/GIROS-AFA-910681189277027/">Facebook</a></li>
							</ul>
						</li>
					@endif
					<li class="active">
						<a href="#" onclick='$("#modal-calcular").modal("show");'>
							<span class="nav-icon"><i class="fa fa-dollar-sign bg-gradient-green text-white"></i></span>
							<span class="nav-text">Calcular Tarifa Giro</span>
						</a>
					</li>
					
				</ul>
				<!-- END nav -->
			</div>
			<!-- END scrollbar -->
		</sidebar>
		<!-- END #sidebar -->
		
		<!-- BEGIN #content -->
		<div id="content" class="app-content">
			
			@yield('content')
		</div>
		<div class="modal modal-message fade" id="modal-message" aria-hidden="true" style="display: none;">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Cambiar Constraseña</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>
					<div class="modal-body">
					{{Form::open(['route' => 'sucursal.vincular-empleado', 'class' => 'validation-wizard wizard-circle', 'id' => 'cambiarPassword']) }} 
						<p>Introduce tu nueva contraseña</p>
						<input type="password" class="form-control" name="passwordNueva" id="passwordNueva" autocomplete="off">
						<input type="password" class="form-control" name="passwordNuevaConfirmar" autocomplete="off">
						<button class="btn btn-primary mt-4" type="submit">Cambiar Contraseña</button>
					{{Form::close()}}
					</div>
					<div class="modal-footer">
						<a href="javascript:;" class="btn btn-white" data-dismiss="modal">Cerrar</a>
					</div>
				</div>
			</div>
		</div>
		<div class="modal modal-message fade" id="modal-calcular" aria-hidden="true" style="display: none;">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body" style="width: 40%;">
						<div class="panel panel-inverse">
							<div class="panel-heading">
								Calcular valor giro
							</div>
							<div class="panel-body" >
								<div class="form-group row">
									<label class="col-form-label col-md-3">Valor Giro</label>
									<div class="col-md-9">
										<div class="input-group m-b-10">
											{!! Form::text('valor_p', null, ['class' => 'nombre-menu form-control numeric' . ($errors->has('nit') ? ' is-invalid' : ''), 'autocomplete' => 'off','id'=>'valor_p' ]) !!}
											<div class="input-group-prepend">
												<span class="input-group-text pt-0" style="text-transform: none !important; background-color: #c2ddf7; color: #1a4772 !important;">
													<div class="checkbox checkbox-css">
														<input type="checkbox" id="incluirFleteP" value="">
														<label for="incluirFleteP" style="color: #1a4772 !important;"><b>¿Flete incluido?<b></label>
													</div>
												</span>
											</div>
										</div>
									</div>
								</div>
								
								<div class="form-group row">
									<div class="col-md-12" id="resumen-giro">
										<hr>
										<div class="note note-primary m-b-15">
											<div class="note-icon"><i class="fa fa-dollar-sign"></i></div>
											<div class="note-content text-right">
												<div class="row">
													<div class="col-sm-7">
														<h4><b>Valor Enviado</b></h4>
													</div>
													<div class="col-sm-5">
														<h4><span id="h1-valor-p">$ 0<span></h4>
													</div>
												</div>
												<div class="row">
													<div class="col-sm-7">
														<h4><b>Tarifa</b></h4>
													</div>
													<div class="col-sm-5">
														<h4><span id="h1-tarifa-p">-<span></h4>
													</div>
												</div>
												<hr class="my-1 mb-2">
												<div class="row">
													<div class="col-sm-7">
														<h4><b>Total</b></h4>
													</div>
													<div class="col-sm-5">
														<h2 class="font-weight-bold"><span id="h1-total-p">-<span></h2>
													</div>
												</div>
												
											</div>
										</div>
											{{Form::hidden('et-g',2,['id'=>'et-g'])}}
									</div>
								</div>
								<hr>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<a href="javascript:;" class="btn btn-white" data-dismiss="modal">Cerrar</a>
					</div>
				</div>
			</div>
		</div>
		<!-- END #content -->
		
		<!-- BEGIN btn-scroll-top -->
		<a href="#" data-click="scroll-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
		<!-- END btn-scroll-top -->
	</div>
	<!-- END #app -->
	
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="{{asset('new/assets/js/app.min.js')}}"></script>
	<!-- ================== END BASE JS ================== -->
	<script src="{{ asset('color/assets/plugins/jquery/jquery-3.3.1.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/jquery-ui/jquery-ui.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/bootstrap/4.1.3/js/bootstrap.bundle.min.js')}}"></script>

	<script src="{{ asset('color/assets/plugins/slimscroll/jquery.slimscroll.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/js-cookie/js.cookie.js')}}"></script>
	
	
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="{{ asset('color/assets/plugins/masked-input/masked-input.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/gritter/js/jquery.gritter.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.time.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.resize.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/flot/jquery.flot.pie.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/sparkline/jquery.sparkline.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/jquery-jvectormap/jquery-jvectormap.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/jquery-jvectormap/jquery-jvectormap-world-mill-en.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')}}"></script>
	
	<!--Sparkline [ OPTIONAL ]-->
	<script src="{{ asset('plugins/sparkline/jquery.sparkline.min.js')}}"></script>
	<script src="{{ asset('plugins/fancybox/jquery.fancybox.min.js') }}"></script>
	<script src="{{ asset('plugins/bootbox/bootbox.min.js') }}"></script>

	<!--DataTables [ OPTIONAL ]-->
	<script src="{{ asset('color/assets/plugins/select2/dist/js/select2.min.js')}}"></script>
	<script src="{{ asset('plugins/framework/framework.js') }}"></script>

	
    <!-- jQuery validate JavaScript -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <script src="{{ asset('plugins/jquery-validate/additional-methods.min.js') }}"></script>
    <script src="{{ asset('plugins/jquery-validate/messages_es.min.js') }}"></script>
	<script src="{{ asset('color/assets/plugins/chosen/chosen.jquery.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/bootstrap-daterangepicker/moment.js')}}"></script>
	<script src="{{asset('color/assets/plugins/bootstrap-daterangepicker/daterangepicker.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/chart-js/Chart.min.js')}}"></script>
	<script src="{{asset('plugins/dp/dobpicker.js')}}"></script>
	<script src="{{asset('color/assets/plugins/jstree/dist/jstree.min.js')}}"></script>
	
	<script src="{{ asset('color/assets/plugins/datatables.net/jquery.dataTables.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/dataT/dataTables.bootstrap4.min.js')}}"></script>
	<script src="{{ asset('color/assets/plugins/DataTables/extensions/Buttons/js/dataTables.buttons.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/dataTables.buttons.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.bootstrap.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.flash.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/jszip.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/pdfmake.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/vfs_fonts.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.html5.min.js')}}"></script>
	<script src="{{asset('color/assets/plugins/DataTables/extensions/Buttons/js/buttons.print.min.js')}}"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>
	<script>
		@if(Auth::user()->id_usuario!=4)
			(function() {

				const idleDurationSecs = 600;    // X number of seconds
				const redirectUrl = 'logout';  // Redirect idle users to this URL
				let idleTimeout; // variable to hold the timeout, do not modify
		
				const resetIdleTimeout = function() {
		
					// Clears the existing timeout
					if(idleTimeout) clearTimeout(idleTimeout);
					//
					// Set a new idle timeout to load the redirectUrl after idleDurationSecs
					idleTimeout = setTimeout(() => {$(".loader2").show(); location.href = redirectUrl}, idleDurationSecs * 1000);
				};
		
				// Init on page load
				resetIdleTimeout();
		
				// Reset the idle timeout on any of the events listed below
				['click', 'touchstart', 'mousemove'].forEach(evt => 
					document.addEventListener(evt, resetIdleTimeout, false)
				);

			})();
		@endif
		$(function(){
			$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		})
		 
		});	
		$("#cambiarPassword").validate({
			ignore: ":not(.chosen-select):checkbox",
			submitHandler: function(form) {
				$.ajax({
					url: "{{ url('usuarios/cambiar-password') }}",
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					type: 'post',
					data: $("#cambiarPassword").serialize(),
					success: function(result){
						$.gritter.add({title:"Operación realizada con éxito",text:"La contraseña fue actualizada con éxito"});
						$('#modal-message').modal('hide');
						$('#modal-message').find('input').val('');
					}
				});
				return false;
			},
			rules: {
				passwordNueva: {
					required: true,
					minlength: 6,
				},
				passwordNuevaConfirmar: {
					equalTo: "#passwordNueva"
				},
			},
			highlight: function (element, errorClass) {
			$(element).parent().addClass('has-feedback has-error');
			$(element).parent().removeClass('has-feedback has-success');
			},
			unhighlight: function (element, errorClass) {
			$(element).parent().removeClass('has-feedback has-error');
			$(element).parent().addClass('has-feedback has-success');
			},
			errorPlacement: function(error, element) {
				if(element.hasClass("no-label")){
				} else if(element.parents('.input-group').length > 0) {
					error.insertAfter(element.parents('.input-group'));
				} else if(element.parents('.form-group').find('.chosen-container').length > 0){
				} else if(element.parents('.radio').find('.chosen-container').length > 0){
					error.insertAfter(element.parents('.radio').find('.chosen-container'));
				} else {
					error.insertAfter(element);
				}
			}
		});
		$(document).ready(function() {
			
		});
		$(window).on('load', function(){
			$(".loader").fadeOut(1000);
			$("#contenedor").fadeIn(2000);
		});
		
	</script>
	<script>
		$('#valor_p').keypress(function (e) {
			if (String.fromCharCode(e.keyCode).match(/[^0-9]/g)){
				return false;
			}else if($(this).val().length > 9){
				return false;
			}
		});
		$('#valor_p').keyup(function () {
			calcularValorTarifaP();
		});

		tarifas = [
		@foreach(DB::table('tarifas')->orderBy('valor_inicial','asc')->get() as $tarifas)
			{
				inicio: {{$tarifas->valor_inicial}},
				fin: {{$tarifas->valor_final}},
				costo: {{blank($tarifas->costo) ? 0 : $tarifas->costo}},
				porcentaje: {{blank($tarifas->porcentaje) ? 0 : $tarifas->porcentaje}}
			},
		@endforeach
		];
		$("#incluirFleteP").change(function(){
		
			calcularValorTarifaP();
		
		});

		function calcularValorTarifaP()
		{
			var valor=$("#valor_p").val().replace(/,/gi, '');
			$("#valor_giro").val(valor);
			var valor_recibido=0;
			if(valor!=''){
				$('#et-g').val(2);
				var entre = false;
				for(var i=0; i<tarifas.length; i++){
					if(!$("#incluirFleteP").prop("checked")){
						
						$("#h1-valor-p").text(numeral(valor).format('0,0'));
						if(Number(valor)>=Number(tarifas[i].inicio) && Number(tarifas[i].fin)>=Number(valor)){
							entre = true;
							var data= tarifas[i];
							console.log(tarifas[i]);
							$('#et-g').val(1);
							var valor_total = Number(valor);
							if(data.porcentaje>0){
								valor_porcentaje = (Number(valor_total)*Number(tarifas[i].porcentaje))/100;
							}else{
								valor_porcentaje = 0;
							}
							var tarifa = Number(tarifas[i].costo)+Number(valor_porcentaje); 
							tarifa_global = tarifa;
							$('#valor_tarifa-p').val(tarifa);
							$("#h1-tarifa-p").text(numeral(tarifa).format('0,0'));
							$("#h1-total-p").text(numeral(valor_total+valor_porcentaje+tarifas[i].costo).format('0,0'));
							return true;
						}else{
							$("#h1-tarifa-p").text('');
							$("#h1-total-p").text('');
						}
					}else{
						$('#et-g').val(1);
						var valor_total = Number(valor);
						if(tarifas[i].porcentaje>0){
							valor_porcentaje_inicio = (Number(tarifas[i].inicio)*Number(tarifas[i].porcentaje))/100;
							valor_porcentaje_final = (Number(tarifas[i].fin)*Number(tarifas[i].porcentaje))/100;
						}else{
							valor_porcentaje_inicio = 0;
							valor_porcentaje_final = 0;
						}
						if(Number(valor)>=Number(tarifas[i].inicio+valor_porcentaje_inicio) && Number(tarifas[i].fin+valor_porcentaje_final)>=Number(valor)){
							console.log(tarifas[i]);
							entre = true;
							valorTemp = valor - tarifas[i].costo;
							var porcentaje = '1.0'+(tarifas[i].porcentaje*10);
							console.log(porcentaje);
							valorTemp = valorTemp / (porcentaje);
							valorTemp = valor - tarifas[i].costo - valorTemp;
							var tarifa = tarifas[i].costo + valorTemp;
							tarifa_global = tarifa;
							$("#h1-valor-p").text(numeral(valor-tarifa).format('0,0'));
							var valorN = Number(valor)-Number(tarifa); 
							//console.log(valorN+'-'+valor+'-'+tarifa); 
							$("#valor_giro").val((valorN));  
							$('#valor_tarifa').val(tarifa);
							$("#h1-tarifa-p").text(numeral(tarifa).format('0,0'));
							$("#h1-total-p").text(numeral(valor_total).format('0,0'));
							console.log(tarifa);
						}else{
							console.log('otra');
						}
						
					}
					
				}
				if(!entre){
					tarifa_global = 0;
					$("#h1-tarifa-p").text("-");
					$("#h1-total-p").text("-");
				}
			}else{
				$("#h1-recibido-p").text('');
				$("#h1-cambio-p").text('');
			}
		}
		
	</script>
	@yield('script')
</body>

<!-- Mirrored from seantheme.com/admetro/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Feb 2020 14:24:00 GMT -->
</html>