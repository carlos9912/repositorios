

<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('img/favicon.png') }}">

    <title>@yield('title') - {{ config('app.name') }}</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">


    <!--STYLESHEET-->
    <!--=================================================-->

    <!--Open Sans Font [ OPTIONAL ]-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>


    <!--Bootstrap Stylesheet [ REQUIRED ]-->
    
    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">


    <!--Nifty Stylesheet [ REQUIRED ]-->
    <link href="{{asset('css/nifty.min.css')}}" rel="stylesheet">

    <!-- toast CSS -->
    <link href="{{ asset('plugins/toast-master/jquery.toast.css') }}" rel="stylesheet">


    <!--Nifty Premium Icon [ DEMONSTRATION ]-->
    <link href="{{asset('css/demo/nifty-demo-icons.min.css')}}" rel="stylesheet">    
    
    <!--Nestable List [ OPTIONAL ]-->
    <link href="{{asset('plugins/nestable-list/nestable-list.min.css')}}" rel="stylesheet">
    <link href="{{asset('plugins/bootstrap-datepicker/bootstrap-datepicker.min.js')}}" rel="stylesheet">
    

    <!--=================================================-->





    <!--Demo [ DEMONSTRATION ]-->
    <link href="{{asset('css/demo/nifty-demo.min.css')}}" rel="stylesheet">
    <link href="{{asset('plugins/themify-icons/themify-icons.min.css')}}" rel="stylesheet">
    <link href="{{asset('plugins/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">
    <!--Summernote [ OPTIONAL ]-->
    <link href="{{asset('plugins/summernote/summernote.min.css')}}" rel="stylesheet">
    <link href="{{ asset('plugins/fancybox/jquery.fancybox.min.css') }}" rel="stylesheet">
    <!--DataTables [ OPTIONAL ]-->
    <link href="{{ asset('plugins/datatables/media/css/dataTables.bootstrap.css') }}" rel="stylesheet">
	<!-- <link href="{{ asset('plugins/datatables/extensions/Responsive/css/responsive.dataTables.min.css') }}" rel="stylesheet"> -->
    <!--Chosen [ OPTIONAL ]-->
    <link href="{{ asset('plugins/chosen/chosen.min.css') }}" rel="stylesheet">
    <link href="{{ asset('plugins/chosen/chosenIcon.css') }}" rel="stylesheet">
    <!--Switchery [ OPTIONAL ]-->
    <link href="{{ asset('plugins/switchery/switchery.min.css') }}" rel="stylesheet">
    <!-- Calendar CSS -->
    <link href="{{ asset('plugins/bootstrap-datepicker/bootstrap-datepicker.min.css') }}" rel="stylesheet">
    <style>
        .loader {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            z-index: 99;
            background: 50% 50% no-repeat rgb(249,249,249);
        }
        .loader-container {
            height: 200px;
            
            top:0;
            bottom: 0;
            right: 0;

            margin: 270px;
            text-align: center;
        }
        .glyphicon-refresh-animate {
            -animation: spin .7s infinite linear;
            -webkit-animation: spin2 .7s infinite linear;
        }

        @-webkit-keyframes spin2 {
            from { -webkit-transform: rotate(0deg);}
            to { -webkit-transform: rotate(360deg);}
        }

        @keyframes spin {
            from { transform: scale(1) rotate(0deg);}
            to { transform: scale(1) rotate(360deg);}
        }
    </style>
    @yield('style') 


            
    <!--=================================================

    REQUIRED
    You must include this in your project.


    RECOMMENDED
    This category must be included but you may modify which plugins or components which should be included in your project.


    OPTIONAL
    Optional plugins. You may choose whether to include it in your project or not.


    DEMONSTRATION
    This is to be removed, used for demonstration purposes only. This category must not be included in your project.


    SAMPLE
    Some script samples which explain how to initialize plugins or components. This category should not be included in your project.


    Detailed information and more samples can be found in the document.

    =================================================-->
        
</head>

<!--TIPS-->
<!--You may remove all ID or Class names which contain "demo-", they are only used for demonstration. -->
<body>
    <div id="container" class="effect aside-float aside-bright mainnav-lg" style="background-color: #f5f5f5;">
        
        <!--NAVBAR-->
        <!--===================================================-->
        <header id="navbar">
            <div id="navbar-container" class="boxed">

                <!--Brand logo & name-->
                <!--================================-->
                <div class="navbar-header">
                    <a href="{{ url('/home') }}" class="navbar-brand">
                        <img src="img/logo.png" alt="Nifty Logo" class="brand-icon">
                        <div class="brand-title">
                            <span class="brand-text">{{ config('app.name') }}</span>
                        </div>
                    </a>
                </div>
                <!--================================-->
                <!--End brand logo & name-->


                <!--Navbar Dropdown-->
                <!--================================-->
                <div class="navbar-content">
                    <ul class="nav navbar-top-links">

                        <!--Navigation toogle button-->
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                        <li class="tgl-menu-btn">
                            <a class="mainnav-toggle" href="#">
                                <i class="demo-pli-list-view"></i>
                            </a>
                        </li>
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                        <!--End Navigation toogle button-->



                        <!--Search-->
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                        <li>
                            <div class="custom-search-form">
                                
                            </div>
                        </li>
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                        <!--End Search-->

                    </ul>
                    <ul class="nav navbar-top-links">

                    </ul>
                </div>
                <!--================================-->
                <!--End Navbar Dropdown-->

            </div>
        </header>
        <!--===================================================-->
        <!--END NAVBAR-->

        <div class="boxed">

            <!--CONTENT CONTAINER-->
            <!--===================================================-->
            <div id="content-container" style="background-color: #f5f5f5;">
                

                
                <!--Page content-->
                <!--===================================================-->
                <div id="page-content">
                
                    @yield('content')
					
					
					    
                </div>
                <!--===================================================-->
                <!--End page content-->

            </div>
            <!--===================================================-->
            <!--END CONTENT CONTAINER-->


            
            <!--ASIDE-->
            <!--===================================================-->
            <aside id="aside-container">
                <div id="aside">
                    <div class="nano">
                        <div class="nano-content">
                            
                            <!--Nav tabs-->
                            <!--================================-->
                            <ul class="nav nav-tabs nav-justified">
                                <li class="active">
                                    <a href="#demo-asd-tab-1" data-toggle="tab">
                                        <i class="demo-pli-speech-bubble-7 icon-lg"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#demo-asd-tab-2" data-toggle="tab">
                                        <i class="demo-pli-information icon-lg icon-fw"></i> Report
                                    </a>
                                </li>
                                <li>
                                    <a href="#demo-asd-tab-3" data-toggle="tab">
                                        <i class="demo-pli-wrench icon-lg icon-fw"></i> Settings
                                    </a>
                                </li>
                            </ul>
                            <!--================================-->
                            <!--End nav tabs-->



                            <!-- Tabs Content -->
                            <!--================================-->
                            <div class="tab-content">

                                <!--First tab (Contact list)-->
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <div class="tab-pane fade in active" id="demo-asd-tab-1">
                                    <p class="pad-all text-main text-sm text-uppercase text-bold">
                                        <span class="pull-right badge badge-warning">3</span> Family
                                    </p>

                                    <!--Family-->
                                    <div class="list-group bg-trans">
							            <a href="#" class="list-group-item">
							                <div class="media-left pos-rel">
							                    <img class="img-circle img-xs" src="img/profile-photos/2.png" alt="Profile Picture">
												<i class="badge badge-success badge-stat badge-icon pull-left"></i>
							                </div>
							                <div class="media-body">
							                    <p class="mar-no text-main">Stephen Tran</p>
							                    <small class="text-muteds">Availabe</small>
							                </div>
							            </a>
							            <a href="#" class="list-group-item">
							                <div class="media-left pos-rel">
							                    <img class="img-circle img-xs" src="img/profile-photos/7.png" alt="Profile Picture">
							                </div>
							                <div class="media-body">
							                    <p class="mar-no text-main">Brittany Meyer</p>
							                    <small class="text-muteds">I think so</small>
							                </div>
							            </a>
							            <a href="#" class="list-group-item">
							                <div class="media-left pos-rel">
							                    <img class="img-circle img-xs" src="img/profile-photos/1.png" alt="Profile Picture">
												<i class="badge badge-info badge-stat badge-icon pull-left"></i>
							                </div>
							                <div class="media-body">
							                    <p class="mar-no text-main">Jack George</p>
							                    <small class="text-muteds">Last Seen 2 hours ago</small>
							                </div>
							            </a>
							            <a href="#" class="list-group-item">
							                <div class="media-left pos-rel">
							                    <img class="img-circle img-xs" src="img/profile-photos/4.png" alt="Profile Picture">
							                </div>
							                <div class="media-body">
							                    <p class="mar-no text-main">Donald Brown</p>
							                    <small class="text-muteds">Lorem ipsum dolor sit amet.</small>
							                </div>
							            </a>
							            <a href="#" class="list-group-item">
							                <div class="media-left pos-rel">
							                    <img class="img-circle img-xs" src="img/profile-photos/8.png" alt="Profile Picture">
												<i class="badge badge-warning badge-stat badge-icon pull-left"></i>
							                </div>
							                <div class="media-body">
							                    <p class="mar-no text-main">Betty Murphy</p>
							                    <small class="text-muteds">Idle</small>
							                </div>
							            </a>
							            <a href="#" class="list-group-item">
							                <div class="media-left pos-rel">
							                    <img class="img-circle img-xs" src="img/profile-photos/9.png" alt="Profile Picture">
												<i class="badge badge-danger badge-stat badge-icon pull-left"></i>
							                </div>
							                <div class="media-body">
							                    <p class="mar-no text-main">Samantha Reid</p>
							                    <small class="text-muteds">Offline</small>
							                </div>
							            </a>
                                    </div>

                                    <hr>
                                    <p class="pad-all text-main text-sm text-uppercase text-bold">
                                        <span class="pull-right badge badge-success">Offline</span> Friends
                                    </p>

                                    <!--Works-->
                                    <div class="list-group bg-trans">
                                        <a href="#" class="list-group-item">
                                            <span class="badge badge-purple badge-icon badge-fw pull-left"></span> Joey K. Greyson
                                        </a>
                                        <a href="#" class="list-group-item">
                                            <span class="badge badge-info badge-icon badge-fw pull-left"></span> Andrea Branden
                                        </a>
                                        <a href="#" class="list-group-item">
                                            <span class="badge badge-success badge-icon badge-fw pull-left"></span> Johny Juan
                                        </a>
                                        <a href="#" class="list-group-item">
                                            <span class="badge badge-danger badge-icon badge-fw pull-left"></span> Susan Sun
                                        </a>
                                    </div>


                                    <hr>
                                    <p class="pad-all text-main text-sm text-uppercase text-bold">News</p>

                                    <div class="pad-hor">
                                        <p>Lorem ipsum dolor sit amet, consectetuer
                                            <a data-title="45%" class="add-tooltip text-semibold text-main" href="#">adipiscing elit</a>, sed diam nonummy nibh. Lorem ipsum dolor sit amet.
                                        </p>
                                        <small><em>Last Update : Des 12, 2014</em></small>
                                    </div>


                                </div>
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <!--End first tab (Contact list)-->


                                <!--Second tab (Custom layout)-->
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <div class="tab-pane fade" id="demo-asd-tab-2">

                                    <!--Monthly billing-->
                                    <div class="pad-all">
                                        <p class="pad-ver text-main text-sm text-uppercase text-bold">Billing &amp; reports</p>
                                        <p>Get <strong class="text-main">$5.00</strong> off your next bill by making sure your full payment reaches us before August 5, 2018.</p>
                                    </div>
                                    <hr class="new-section-xs">
                                    <div class="pad-all">
                                        <span class="pad-ver text-main text-sm text-uppercase text-bold">Amount Due On</span>
                                        <p class="text-sm">August 17, 2018</p>
                                        <p class="text-2x text-thin text-main">$83.09</p>
                                        <button class="btn btn-block btn-success mar-top">Pay Now</button>
                                    </div>


                                    <hr>

                                    <p class="pad-all text-main text-sm text-uppercase text-bold">Additional Actions</p>

                                    <!--Simple Menu-->
                                    <div class="list-group bg-trans">
                                        <a href="#" class="list-group-item"><i class="demo-pli-information icon-lg icon-fw"></i> Service Information</a>
                                        <a href="#" class="list-group-item"><i class="demo-pli-mine icon-lg icon-fw"></i> Usage Profile</a>
                                        <a href="#" class="list-group-item"><span class="label label-info pull-right">New</span><i class="demo-pli-credit-card-2 icon-lg icon-fw"></i> Payment Options</a>
                                        <a href="#" class="list-group-item"><i class="demo-pli-support icon-lg icon-fw"></i> Message Center</a>
                                    </div>


                                    <hr>

                                    <div class="text-center">
                                        <div><i class="demo-pli-old-telephone icon-3x"></i></div>
                                        Questions?
                                        <p class="text-lg text-semibold text-main"> (415) 234-53454 </p>
                                        <small><em>We are here 24/7</em></small>
                                    </div>
                                </div>
                                <!--End second tab (Custom layout)-->
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


                                <!--Third tab (Settings)-->
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <div class="tab-pane fade" id="demo-asd-tab-3">
                                    <ul class="list-group bg-trans">
                                        <li class="pad-top list-header">
                                            <p class="text-main text-sm text-uppercase text-bold mar-no">Account Settings</p>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="pull-right">
                                                <input class="toggle-switch" id="demo-switch-1" type="checkbox" checked>
                                                <label for="demo-switch-1"></label>
                                            </div>
                                            <p class="mar-no text-main">Show my personal status</p>
                                            <small class="text-muted">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</small>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="pull-right">
                                                <input class="toggle-switch" id="demo-switch-2" type="checkbox" checked>
                                                <label for="demo-switch-2"></label>
                                            </div>
                                            <p class="mar-no text-main">Show offline contact</p>
                                            <small class="text-muted">Aenean commodo ligula eget dolor. Aenean massa.</small>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="pull-right">
                                                <input class="toggle-switch" id="demo-switch-3" type="checkbox">
                                                <label for="demo-switch-3"></label>
                                            </div>
                                            <p class="mar-no text-main">Invisible mode </p>
                                            <small class="text-muted">Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </small>
                                        </li>
                                    </ul>


                                    <hr>

                                    <ul class="list-group pad-btm bg-trans">
                                        <li class="list-header"><p class="text-main text-sm text-uppercase text-bold mar-no">Public Settings</p></li>
                                        <li class="list-group-item">
                                            <div class="pull-right">
                                                <input class="toggle-switch" id="demo-switch-4" type="checkbox" checked>
                                                <label for="demo-switch-4"></label>
                                            </div>
                                            Online status
                                        </li>
                                        <li class="list-group-item">
                                            <div class="pull-right">
                                                <input class="toggle-switch" id="demo-switch-5" type="checkbox" checked>
                                                <label for="demo-switch-5"></label>
                                            </div>
                                            Show offline contact
                                        </li>
                                        <li class="list-group-item">
                                            <div class="pull-right">
                                                <input class="toggle-switch" id="demo-switch-6" type="checkbox" checked>
                                                <label for="demo-switch-6"></label>
                                            </div>
                                            Show my device icon
                                        </li>
                                    </ul>



                                    <hr>

                                    <p class="pad-hor text-main text-sm text-uppercase text-bold mar-no">Task Progress</p>
                                    <div class="pad-all">
                                        <p class="text-main">Upgrade Progress</p>
                                        <div class="progress progress-sm">
                                            <div class="progress-bar progress-bar-success" style="width: 15%;"><span class="sr-only">15%</span></div>
                                        </div>
                                        <small>15% Completed</small>
                                    </div>
                                    <div class="pad-hor">
                                        <p class="text-main">Database</p>
                                        <div class="progress progress-sm">
                                            <div class="progress-bar progress-bar-danger" style="width: 75%;"><span class="sr-only">75%</span></div>
                                        </div>
                                        <small>17/23 Database</small>
                                    </div>

                                </div>
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <!--Third tab (Settings)-->

                            </div>
                        </div>
                    </div>
                </div>
            </aside>
            <!--===================================================-->
            <!--END ASIDE-->

            
            <!--MAIN NAVIGATION-->
            <!--===================================================-->
            <nav id="mainnav-container">
                <div id="mainnav">


                    <!--OPTIONAL : ADD YOUR LOGO TO THE NAVIGATION-->
                    <!--It will only appear on small screen devices.-->
                    <!--================================
                    <div class="mainnav-brand">
                        <a href="index.html" class="brand">
                            <img src="img/logo.png" alt="Nifty Logo" class="brand-icon">
                            <span class="brand-text">Nifty</span>
                        </a>
                        <a href="#" class="mainnav-toggle"><i class="pci-cross pci-circle icon-lg"></i></a>
                    </div>
                    -->



                    <!--Menu-->
                    <!--================================-->
                    <div id="mainnav-menu-wrap">
                            <div class="nano">
                                <div class="nano-content">
    
                                    <!--Profile Widget-->
                                    <!--================================-->
                                    <div id="mainnav-profile" class="mainnav-profile">
                                        <div class="profile-wrap text-center">
                                            <div class="pad-btm">
                                                <img class="img-circle img-md" src="{{asset("img/profile-photos/1.png")}}" alt="Profile Picture">
                                            </div>
                                            <a href="#profile-nav" class="box-block" data-toggle="collapse" aria-expanded="false">
                                                <span class="pull-right dropdown-toggle">
                                                    <i class="dropdown-caret"></i>
                                                </span>
                                                <p class="mnp-name">{{Auth::user()->nombres.' '.Auth::user()->apellidos}}</p>
                                                <span class="mnp-desc">{{\App\Enums\ETipoDocumento::result(Auth::user()->tipo_identificacion)->getDescription().' - '.Auth::user()->numero_identificacion}}</span>
                                            </a>
                                        </div>
                                        <div class="pad-top btn-groups text-center">
                                            <a href="#" class="btn btn-icon ti ti-mobile add-tooltip" data-original-title="{{\Auth::user()->telefono}}" data-container="body"></a>
                                            <a href="#" class="btn btn-icon ti ti-home add-tooltip" data-original-title="{{\Auth::user()->direccion}}" data-container="body"></a>
                                            <a href="#" class="btn btn-icon ti ti-email add-tooltip" data-original-title="{{\Auth::user()->correo}}" data-container="body"></a>
                                            <a href="#" class="btn btn-icon ti ti-user add-tooltip" data-original-title="{{\Auth::user()->username}}" data-container="body"></a>
                                            <a href="#" class="btn btn-icon ti ti-money add-tooltip" data-original-title="{{\Auth::user()->cupo}}" data-container="body"></a>
                                        </div>
                                        <div id="profile-nav" class="collapse list-group bg-trans">
                                            <a href="#" class="list-group-item" data-toggle="modal" data-target="#modalPassword">
                                                <i class="demo-pli-male icon-lg icon-fw"></i> Cambiar Password
                                            </a>
                                            <a href="{{route('logout')}}" class="list-group-item">
                                                <i class="demo-pli-unlock icon-lg icon-fw"></i> Salir
                                            </a>
                                        </div>
                                    </div>
    
    
                                    <!--Shortcut buttons-->
                                    <!--================================-->
                                    <div id="mainnav-shortcut" class="hidden">
                                        <ul class="list-unstyled shortcut-wrap">
                                            <li class="col-xs-3" data-content="My Profile">
                                                <a class="shortcut-grid" href="#">
                                                    <div class="icon-wrap icon-wrap-sm icon-circle bg-mint">
                                                    <i class="demo-pli-male"></i>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="col-xs-3" data-content="Messages">
                                                <a class="shortcut-grid" href="#">
                                                    <div class="icon-wrap icon-wrap-sm icon-circle bg-warning">
                                                    <i class="demo-pli-speech-bubble-3"></i>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="col-xs-3" data-content="Activity">
                                                <a class="shortcut-grid" href="#">
                                                    <div class="icon-wrap icon-wrap-sm icon-circle bg-success">
                                                    <i class="demo-pli-thunder"></i>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="col-xs-3" data-content="Lock Screen">
                                                <a class="shortcut-grid" href="{{route('logout')}}">
                                                    <div class="icon-wrap icon-wrap-sm icon-circle bg-purple">
                                                    <i class="demo-pli-lock-2"></i>
                                                    </div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <!--================================-->
                                    <!--End shortcut buttons-->
    
    
                                    <ul id="mainnav-menu" class="list-group">
                            
                                        <!--Category name-->
                                        <li class="list-header"></li>
                                        @if(\Auth::user()->email==1)
                                            <li>
                                                <a href="#">
                                                    <i class="ti ti-shopping-cart"></i>
                                                    <span class="menu-title">Ventas</span>
                                                    <i class="arrow"></i>
                                                </a>
                                
                                                <!--Submenu-->
                                                <ul class="collapse">
                                                    <li><a href="{{ url('ventas') }}">Registrar Ventas</a></li>
                                                </ul>
                                            </li> 
                                            <li>
                                                <a href="#">
                                                    <i class="ti ti-user"></i>
                                                    <span class="menu-title">Cuenta</span>
                                                    <i class="arrow"></i>
                                                </a>
                                
                                                <!--Submenu-->
                                                <ul class="collapse">
                                                    <li><a href="{{ route('clientes.index') }}">Estado de cuenta</a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="ti ti-bar-chart"></i>
                                                    <span class="menu-title">Reportes</span>
                                                    <i class="arrow"></i>
                                                </a>
                                
                                                <!--Submenu-->
                                                <ul class="collapse">
                                                    <li><a href="{{ url('reportes') }}">Visualizar Reportes</a></li>
                                                </ul>
                                            </li>
                                        @else
                                            <li>
                                                <a href="#">
                                                    <i class="ti ti-shopping-cart"></i>
                                                    <span class="menu-title">Ventas</span>
                                                    <i class="arrow"></i>
                                                </a>
                                
                                                <!--Submenu-->
                                                <ul class="collapse">
                                                    <li><a href="{{ url('ventas') }}">Registrar Ventas</a></li>
                                                </ul>
                                            </li>
                                            <!--Menu list item-->
                                            <li>
                                                <a href="#">
                                                    <i class="ti ti-layout"></i>
                                                    <span class="menu-title">Productos</span>
                                                    <i class="arrow"></i>
                                                </a>
                                
                                                <!--Submenu-->
                                                <ul class="collapse">
                                                    <li><a href="{{ route('productos.index') }}">Administrar Productos</a></li>
                                                </ul>
                                            </li>   
                                            <li>
                                                <a href="#">
                                                    <i class="ti ti-user"></i>
                                                    <span class="menu-title">Clientes</span>
                                                    <i class="arrow"></i>
                                                </a>
                                
                                                <!--Submenu-->
                                                <ul class="collapse">
                                                    <li><a href="{{ route('clientes.index') }}">Administrar Clientes</a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="ti ti-bar-chart"></i>
                                                    <span class="menu-title">Reportes</span>
                                                    <i class="arrow"></i>
                                                </a>
                                
                                                <!--Submenu-->
                                                <ul class="collapse">
                                                    <li><a href="{{ url('reportes') }}">Visualizar Reportes</a></li>
                                                </ul>
                                                <!--Submenu-->
                                                <ul class="collapse">
                                                    <li><a href="{{ url('consignaciones') }}">Detalle Consignaciones</a></li>
                                                </ul>
                                            </li>
                                        @endif
                                    </ul>
    
                                </div>
                            </div>
                        </div>
                    <!--================================-->
                    <!--End menu-->

                </div>
            </nav>
            <!--===================================================-->
            <!--END MAIN NAVIGATION-->

        </div>

        

        <!-- FOOTER -->
        <!--===================================================-->
        <footer id="footer">

            <!-- Visible when footer positions are fixed -->
            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
            <div class="show-fixed pad-rgt pull-right">
                You have <a href="#" class="text-main"><span class="badge badge-danger">3</span> pending action.</a>
            </div>



            <!-- Visible when footer positions are static -->
            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
            <div class="hide-fixed pull-right pad-rgt">
                14GB of <strong>512GB</strong> Free.
            </div>



            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
            <!-- Remove the class "show-fixed" and "hide-fixed" to make the content always appears. -->
            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

            <p class="pad-lft">&#0169; 2018 Your Company</p>



        </footer>
        <!--===================================================-->
        <!-- END FOOTER -->


        <!-- SCROLL PAGE BUTTON -->
        <!--===================================================-->
        <button class="scroll-top btn">
            <i class="pci-chevron chevron-up"></i>
        </button>
        <!--===================================================-->
    </div>
    <!--===================================================-->
    <!-- END OF CONTAINER -->

    <!--JAVASCRIPT-->
    <!--=================================================-->

    <!--jQuery [ REQUIRED ]-->
    <script src="{{asset('js/jquery.min.js')}}"></script>

    
    <!-- jQuery validate JavaScript -->
    <script src="{{ asset('plugins/jquery-validate/jquery-validate.js') }}"></script>
    <script src="{{ asset('plugins/jquery-validate/additional-methods.min.js') }}"></script>
    <script src="{{ asset('plugins/jquery-validate/messages_es.min.js') }}"></script>

    <!--BootstrapJS [ RECOMMENDED ]-->
    <script src="{{asset('js/bootstrap.min.js')}}"></script>


    <!--NiftyJS [ RECOMMENDED ]-->
    <script src="{{asset('js/nifty.min.js')}}"></script>




    <!--=================================================-->
    
    <!--Demo script [ DEMONSTRATION ]-->
    <script src="{{asset('js/demo/nifty-demo.min.js')}}"></script>

    
    <!--Flot Chart [ OPTIONAL ]-->
    <script src="{{asset('plugins/flot-charts/jquery.flot.min.js')}}"></script>
    <script src="{{asset('plugins/flot-charts/jquery.flot.resize.min.js')}}"></script>
    <script src="{{asset('plugins/flot-charts/jquery.flot.tooltip.min.js')}}"></script>
    <!--Summernote [ OPTIONAL ]-->
    <script src="{{asset('plugins/summernote/summernote.min.js')}}"></script>

    <!-- Toast plugins -->
    <script src="{{ asset('plugins/toast-master/jquery.toast.js') }}"></script>


    <!--Sparkline [ OPTIONAL ]-->
    <script src="{{ asset('plugins/sparkline/jquery.sparkline.min.js')}}"></script>
    <script src="{{ asset('plugins/fancybox/jquery.fancybox.min.js') }}"></script>
    <script src="{{ asset('plugins/bootbox/bootbox.min.js') }}"></script>

    <!--DataTables [ OPTIONAL ]-->
    <script src="{{ asset('plugins/datatables/media/js/jquery.dataTables.js') }}"></script>
    <script src="{{ asset('plugins/datatables/media/js/dataTables.bootstrap.js') }}"></script>
    <!-- <script src="{{ asset('plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js') }}"></script> -->
    <!--Chosen [ OPTIONAL ]-->
    <script src="{{ asset('plugins/chosen/chosen.jquery.min.js')}}"></script>
    <script src="{{ asset('plugins/chosen/chosenIcon.jquery.js')}}"></script>
    <!--Switchery [ OPTIONAL ]-->
    <script src="{{ asset('plugins/switchery/switchery.min.js')}}"></script>
    <script src="{{ asset('plugins/framework/framework.js') }}"></script>
    <script src="{{ asset('plugins/framework/plugins.js') }}"></script>

    <script src="{{ asset('plugins/moment/moment.js') }}"></script>
    <script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>
    <script src="{{ asset('plugins/bootstrap-datepicker/bootstrap-datepicker.min.js') }}"></script>
    
    
    <!--Nestable List [ OPTIONAL ]-->
    <script src="{{ asset('plugins/nestable-list/jquery.nestable.js') }}"></script>
    
    <script>
        $(window).on('load', function(){
            $(".loader").fadeOut(1000);
            $("#contenedor").fadeIn(2000);
        });
        $(function(){
            $("#frmChangePassword").validate({
                errorClass: "text-danger form-error-label",
                successClass: "text-success", 
                errorElement : "small",
                highlight: function (element, errorClass) {
                    $(element).addClass('is-invalid');
                    $(element).removeClass(errorClass)
                },
                unhighlight: function (element, errorClass) {
                    $(element).removeClass('is-invalid');
                    $(element).removeClass(errorClass)
                },
                submitHandler: function(form) {
                    if(validarPassword($("#password").val())){
                        form.submit();
                    }
                },
                rules: {
                    password: {required: true, minlength: 8},
                    passwordConfirm: {
                        equalTo: "#passwordFirst"
                    }
                },
                errorPlacement: function(error, element) {
                    if(element.parents('.i-checks').length > 0) {
                        error.insertAfter(element.parents('.i-checks'));
                    }else if(element.parents('.input-group').length > 0) {
                        error.insertAfter(element.parents('.input-group'));
                    } else {
                        error.insertAfter(element);
                    }
                }
            });
    });
    
    function validarPassword(pswd){
        if (pswd.match(/[A-z]/) && pswd.match(/\d/) && pswd.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) {
            return true;
        }else{
            frameworkApp.setAlert('{{ trans("auth.password_debil") }}');
            return false;
        }
        
    }
    </script>
    @yield('script')
    <!--Specify page [ SAMPLE ]-->


    

</body>
</html>
