<!DOCTYPE html>
<html lang="en">
  <meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
  <head>
    <!-- SITE TITTLE -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title') - {{ config('app.name') }}</title>

    <!-- PLUGINS CSS STYLE -->
    <link rel="stylesheet" type="text/css" href="{{asset('plantilla/plugins/jquery-ui/jquery-ui.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('plantilla/plugins/bootstrap/css/bootstrap.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('plantilla/plugins/font-awesome/css/font-awesome.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('plantilla/plugins/rs-plugin/css/settings.css')}}" media="screen">
    <link rel="stylesheet" type="text/css" href="{{asset('plantilla/plugins/selectbox/select_option1.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('plantilla/plugins/owl-carousel/owl.carousel.css')}}" media="screen">
    <link rel="stylesheet" type="text/css" href="{{asset('plantilla/plugins/isotope/jquery.fancybox.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('plantilla/plugins/isotope/isotope.css')}}">

    <!-- GOOGLE FONT -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Dosis:400,300,600,700' rel='stylesheet' type='text/css'>

    <!-- CUSTOM CSS -->
    <link href="{{asset('plantilla/css/style.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('plantilla/css/default.css')}}" id="option_color">

    <!-- Icons -->
    <link rel="shortcut icon" href="{{asset('plantilla/img/favicon.png')}}">
    @yield('style')
    <!--[if lt IE 9]>
      <script src="{{asset('plantilla/js/html5shiv.min.js')}}"></script>
      <script src="{{asset('plantilla/js/respond.min.js')}}"></script>
    <![endif]-->
  </head>
  <body class="body-wrapper">
    <div class="main-wrapper">
      <!-- HEADER -->
      <header id="pageTop" class="header-wrapper">
        <!-- COLOR BAR -->
        <div class="container-fluid color-bar top-fixed clearfix">
          <div class="row">
            <div class="col-sm-1 col-xs-2 bg-color-1">fix bar</div>
            <div class="col-sm-1 col-xs-2 bg-color-2">fix bar</div>
            <div class="col-sm-1 col-xs-2 bg-color-3">fix bar</div>
            <div class="col-sm-1 col-xs-2 bg-color-4">fix bar</div>
            <div class="col-sm-1 col-xs-2 bg-color-5">fix bar</div>
            <div class="col-sm-1 col-xs-2 bg-color-6">fix bar</div>
            <div class="col-sm-1 bg-color-1 hidden-xs">fix bar</div>
            <div class="col-sm-1 bg-color-2 hidden-xs">fix bar</div>
            <div class="col-sm-1 bg-color-3 hidden-xs">fix bar</div>
            <div class="col-sm-1 bg-color-4 hidden-xs">fix bar</div>
            <div class="col-sm-1 bg-color-5 hidden-xs">fix bar</div>
            <div class="col-sm-1 bg-color-6 hidden-xs">fix bar</div>
          </div>
        </div>
        <!-- TOP INFO BAR -->
        <div class="top-info-bar bg-color-7">
          <div class="container">
            <div class="row">
              <div class="col-sm-7 hidden-xs">
                <ul class="list-inline topList">
                  @yield('informacion')
                </ul>
              </div>
              <div class="col-sm-5 text-right">
                  <a type="button" target="_blank" href="http://colpuyana.com" class="btn btn-success btn-xs btn-pill"><i class="fa fa-desktop"></i><span>Ingreso Plataforma</span></a>
              </div>
            </div>
          </div>
        </div>
        <!-- NAVBAR -->
        <nav id="menuBar" class="navbar navbar-default lightHeader" role="navigation">
          <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="{{ route('paginas.navegar', ["menu" => 1, "nombre" => 'principal']) }}"><img src="{{asset('img/logo-school.png')}}" alt="Kidz School"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
              <ul class="nav navbar-nav navbar-right">
                @yield('navbar')
              </ul>
            </div>

          </div>
        </nav>
      </header>
      @yield('galeria')
      
      <!-- PAGE TITLE SECTION-->      
      @yield('breadcum')
      <!-- MAIN SECTION -->
      <section class="full-width clearfix courseSingleSection" style="padding-top: 10px; padding-bottom: 40px;">
        <div class="container">
            @yield('contenido')
        </div>
      </section>
  <!-- FOOTER -->
  <footer>
    <!-- COLOR BAR -->
    <div class="container-fluid color-bar clearfix">
      <div class="row">
        <div class="col-sm-1 col-xs-2 bg-color-1">fix bar</div>
        <div class="col-sm-1 col-xs-2 bg-color-2">fix bar</div>
        <div class="col-sm-1 col-xs-2 bg-color-3">fix bar</div>
        <div class="col-sm-1 col-xs-2 bg-color-4">fix bar</div>
        <div class="col-sm-1 col-xs-2 bg-color-5">fix bar</div>
        <div class="col-sm-1 col-xs-2 bg-color-6">fix bar</div>
        <div class="col-sm-1 bg-color-1 hidden-xs">fix bar</div>
        <div class="col-sm-1 bg-color-2 hidden-xs">fix bar</div>
        <div class="col-sm-1 bg-color-3 hidden-xs">fix bar</div>
        <div class="col-sm-1 bg-color-4 hidden-xs">fix bar</div>
        <div class="col-sm-1 bg-color-5 hidden-xs">fix bar</div>
        <div class="col-sm-1 bg-color-6 hidden-xs">fix bar</div>
      </div>
    </div>
    <!-- FOOTER INFO AREA -->
    <div class="footerInfoArea full-width clearfix" style="background-image: url({{asset('plantilla/img/footer/footer-bg-1.png')}});">
      <div class="container">
        @yield('footer')
      </div>
    </div>
  </footer>
  </div>

  <div class="scrolling">
  <a href="#pageTop" class="backToTop hidden-xs" id="backToTop"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
  </div>

  <script src="{{asset('plantilla/js/jquery.min.js')}}"></script>
  <script src="{{asset('plantilla/plugins/jquery-ui/jquery-ui.js')}}"></script>
  <script src="{{asset('plantilla/plugins/bootstrap/js/bootstrap.min.js')}}"></script>
  <script src="{{asset('plantilla/plugins/rs-plugin/js/jquery.themepunch.tools.min.js')}}"></script>
  <script src="{{asset('plantilla/plugins/rs-plugin/js/jquery.themepunch.revolution.min.js')}}"></script>
  <script src="{{asset('plantilla/plugins/selectbox/jquery.selectbox-0.1.3.min.js')}}"></script>
  <script src="{{asset('plantilla/plugins/owl-carousel/owl.carousel.js')}}"></script>
  <script src="{{asset('plantilla/js/waypoints.min.js')}}"></script>
  <script src="{{asset('plantilla/plugins/counter-up/jquery.counterup.min.js')}}"></script>
  <script src="{{asset('plantilla/plugins/isotope/isotope.min.js')}}"></script>
  <script src="{{asset('plantilla/plugins/isotope/jquery.fancybox.pack.js')}}"></script>
  <script src="{{asset('plantilla/plugins/isotope/isotope-triger.js')}}"></script>
  <script src="{{asset('plantilla/plugins/countdown/jquery.syotimer.js')}}"></script>
  <script src="{{asset('plantilla/plugins/velocity/velocity.min.js')}}"></script>
  <script src="{{asset('plantilla/plugins/smoothscroll/SmoothScroll.js')}}"></script>
  <script src="{{asset('plantilla/js/custom.js')}}"></script>
  @yield('scripts')
  </body>
</html>

