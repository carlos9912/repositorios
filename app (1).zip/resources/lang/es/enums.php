<?php
return [
    /*
 * |--------------------------------------------------------------------------
 * | Authentication Language Lines
 * |--------------------------------------------------------------------------
 * |
 * | The following language lines are used during authentication for various
 * | messages that we need to display to the user. You are free to modify
 * | these language lines according to your application's requirements.
 * |
 */
    'horizontal_internal_location' => 'Horizontal interna',
    'horizontal_location' => 'Horizontal',
    'vertical_location' => 'Vertical',
    /*
     * |---------------------------------
     * | ETarget
     * |---------------------------------
     */
    'framename_target' => '_framename',
    'parent_target' => '_parent',
    'blank_target' => 'Página en blanco',
    'self_target' => 'Misma página',
    'top_target' => '_top',
    /*
     * |---------------------------------
     * | ETransicion
     * |---------------------------------
     */
    'desvanecer' => 'Desvanecer',
    'deslizar_up' => 'Deslizar arriba',
    'deslizar_down' => 'Deslizar abajo',
    'deslizar_right' => 'Deslizar derecha',
    'deslizar_left' => 'Deslizar izquierda',
    'cuadros' => 'Cuadros',
    'rayas' => 'Rayas horizontales',
    

    /*
     * |---------------------------------
     * | EEstadoPagina
     * |---------------------------------
     */
    'guardada' => 'Guardada',
    'publicada' => 'Publicada',
    'suspendida' => 'Suspendida',
    'archivada' => 'Archivada',

    /*
     * |---------------------------------
     * | EIcono
     * |---------------------------------
     */
    'icono' => 'Icono',
    'imagen' => 'Imagen',
    /*
     * |---------------------------------
     * | EGender
     * |---------------------------------
     */
    'masculino' => 'Masculino',
    'femenino' => 'Femenino',
    /*
     * |---------------------------------
     * | ESiNo
     * |---------------------------------
     */
    'yes' => 'Si',
    'no' => 'No',
    /*
     * |---------------------------------
     * | EOrientacion
     * |---------------------------------
     */
    'religiosa' => 'Religiosa',
    'diocesis' => 'Diócesis',
    'laico' => 'Laico',
    /*
     * |---------------------------------
     * | EEstadoCuenta
     * |---------------------------------
     */
    'procesado' => 'Aceptado',
    'pendiente' => 'En proceso',
    'rechazado' => 'Rechazado',
    /*
     * |---------------------------------
     * | ETipoPlan
     * |---------------------------------
     */
    'day' => 'Día',
    'weekly' => 'Semanal',
    'monthly' => 'Mensual',
    'bimonthly' => 'Bimestral',
    'trimester' => 'Trimestral',
    'quarterly' => 'Cuatrimestral',
    'biyearly' => 'Semestral',
    'yearly' => 'Anual',
    
    /*
     * |---------------------------------
     * | ETipoPlan
     * |---------------------------------
     */
    'departamento' => 'Departamento',
    'provincia' => 'Provincia',
    'municipio' => 'municipio',
    'region' => 'Región',
    'pais' => 'País',
    /*
     * |---------------------------------
     * | EAcceso
     * |---------------------------------
     */
    'acceso_total' => 'Acceso total',
    'sin_acceso' => 'Sin acceso',
    
    /*
     * |---------------------------------
     * | ECargoFederacion
     * |---------------------------------
     */
    'presidente' => 'Presidente',
    'asistente' => 'Asistente',
    /*
     * |---------------------------------
     * | ECargoColegio
     * |---------------------------------
     */
    'rector' => 'Rector',
    'secretaria' => 'Secretaria',
    'coordinador' => 'Coordinador',
    /*
     * |---------------------------------
     * | ENivelPruebaSaber
     * |---------------------------------
     */
    'no_aplica' => 'No aplica',
    'nivel_a_mas' => 'A+',
    'nivel_a' => 'A',
    'nivel_b' => 'B',
    'nivel_c' => 'C',
    'nivel_d' => 'D',
    /*
     * |---------------------------------
     * | ECargoComunidad
     * |---------------------------------
     */
    'superior' => 'Superior',
    'coordinador' => 'Coordinador',
    /*
     * |---------------------------------
     * | ECargoConaced
     * |---------------------------------
     */
    'presidente' => 'Presidente nacional',
    'directora_administrativa' => 'Directora administrativa',
    'directora_formacion' => 'Directora formación',
    'directora_pastoral' => 'Directora pastoral',
    'asistente_presidencial' => 'Asistente presidencial',
    'comunicaciones_mercadeo' => 'Comunicaciones y mercadeo',
    /*
     * |---------------------------------
     * | ERegimen
     * |---------------------------------
     */
    'libertad_regulada' => 'Libertad regulada',
    'libertad_vigilada' => 'Libertad vigilada',
    'regimen_controlada' => 'Régimen controlado',
    /*
     * |---------------------------------
     * | EEstadoVinculacion
     * |---------------------------------
     */
    'autorizado' => 'Sin actualizar',
    'en_proceso' => 'En proceso',
    'finalizado' => 'Finalizado',
    /*
     * |---------------------------------
     * | ETipoDocumento
     * |---------------------------------
     */
    'cedula_ciudadania' => 'CC',
    'cedula_extranjeria' => 'CE',
    /*
     * |---------------------------------
     * | EOrigen
     * |---------------------------------
     */
    'transferencia' => 'Transferencia',
    'consignacion' => 'Consignación',
    'efectivo' => 'Efectivo',
    'cheque' => 'Cheque',
    /*
     * |---------------------------------
     * | ETipoMovimiento
     * |---------------------------------
     */
    'saldo_cargado' => 'Registro inicial del colegio ',
    'descuento_aplicado' => 'Descuento',
    'condonacion' => 'Condonación',
    'pago_parcial' => 'Parcial',
    'pago_total' => 'Total',
    /*
     * |---------------------------------
     * | EFuncionamiento
     * |---------------------------------
     */
    'basica_secundaria' => 'Básica secundaria',
    'basica_primaria' => 'Básica primaria',
    'vocacional' => 'Media vocacional',
    'preescolar' => 'Preescolar',
    /*
     * |---------------------------------
     * | EEstadoAfiliacion
     * |---------------------------------
     */
    'en_solicitud' => 'En solicitud',
    'rechazado' => 'Rechazado',
    'aprobado' => 'Aprobado',
    /*
     * |---------------------------------
     * | ETipoArchivo
     * |---------------------------------
     */
    'resolucion' => 'Resolución de costos educativos del año actual',
    'acta_consejo_est' => 'Acta consejo estudiantil',
    'logo' => 'Logo del colegio',
    'soporte' => 'Soporte',
    'pei' => 'PEI',
    'rut' => 'RUT',
    /*
     * |---------------------------------
     * | ECaracter
     * |---------------------------------
     */
    'privado' => 'Privado',
    'oficial' => 'Oficial',
    'contratacion_estado' => 'Contratación con el estado',
    /*
     * |---------------------------------
     * | EPoblacionEstudiantil
     * |---------------------------------
     */
    'masculina' => 'Masculina',
    'femenina' => 'Femenina',
    'mixta' => 'Mixta',
    /*
     * |---------------------------------
     * | EJornada
     * |---------------------------------
     */
    'manana' => 'Mañana',
    'tarde' => 'Tarde',
    'noche' => 'Noche',
    'unica' => 'Única', 
    /*
     * |---------------------------------
     * | ECalendario
     * |---------------------------------
     */
    'calendario_a' => 'A',
    'calendario_b' => 'B', 
    /*
     * |---------------------------------
     * | EEspecialidad
     * |---------------------------------
     */
    'academica' => 'Académica',
    'tecnica' => 'Técnica',
    'comercial' => 'Comercial',
    'otra' => 'Otra',
    /*
     * |---------------------------------
     * | ENivelFormativo
     * |---------------------------------
     */
    'bachiller_pedagogico' => 'Bachiller pedagógico',
    'especialista' => 'Especialista',
    'licenciado' => 'Licenciado',
    'magister' => 'Magister',
    'doctor' => 'Doctor',
    'otro' => 'otro',
    /*
     * |---------------------------------
     * | ESistemaGestionCalidad
     * |---------------------------------
     */
    'no_certificado' => 'No certificado',
    'certificado' => 'Certificado',
    'en_proceso' => 'En proceso',
    /*
     * |---------------------------------
     * | ENavegador
     * |---------------------------------
     */
    'internet_explorer' => 'IE',
    'firefox' => 'Firefox',
    'chrome' => 'Chrome',
    'safari' => 'Safari',
    'edge' => 'Edge',
    /*
     * |---------------------------------
     * | EPerfiles
     * |---------------------------------
     */
    'federacion' => 'Federación',
    'comunidad' => 'Comunidad',
    'conaced' => 'Conaced',
    'colegio' => 'Colegio',
    //--------------------------------------------//
    'solicitado' => 'En solicitud',
    'rechazado' => 'Rechazado',
    'aceptado' => 'Aceptado',

    'afiliacion' => 'Afiliación',
    'retencion' => 'Retención',
    'servicio' => 'Servicio',
    'evento' => 'Evento',
    'pago' => 'Pago',

    'sin_evaluacion' => 'Sin evaluación',
    'exitosa' => 'Exitosa',
    'fallida' => 'Fallida',
];

