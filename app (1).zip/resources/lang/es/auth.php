<?php
return [
    /*
     * |--------------------------------------------------------------------------
     * | Authentication Language Lines
     * |--------------------------------------------------------------------------
     * |
     * | The following language lines are used during authentication for various
     * | messages that we need to display to the user. You are free to modify
     * | these language lines according to your application's requirements.
     * |
     */
    'username_without_components' => 'El usuario :username, no tiene componentes asignados para acceder a la aplicación, contacte con el administrador',
    'throttle' => 'Demasiados intentos de acceso. Intente nuevamente en :seconds segundos.',
    'username_instructions' => '¡Ingrese su nombre de usuario y se le enviarán las instrucciones!',
    'failed' => 'Estas credenciales no coinciden con nuestros registros.',
    'reset_password' => 'Restablecer la contraseña',
    'recover' => 'Recuperar contraseña',
    
    'username_obligatorio' => 'El campo usuario es obligatorio',
    'recordar_password' => '¿Se te olvidó tu contraseña?',
    'iniciar_sesion' => 'Iniciar sesión',
    'recuerdame' => 'Recuérdame',
    'password' => 'Contraseña',
    'username' => 'Usuario',

    'cambiar_password_tutorial'=>'Debido a que es su primer ingreso a la plataforma, es importante que realice el cambio de la contraseña',
    'password_debil'=>'La contraseña debe contener al menos una letra, un número y un carácter especial',
    'cambiar_password_tittle'=>'Cambiar contraseña',
    'conf_nueva_password'=>'Confirmar contraseña',
    'nueva_password'=>'Nueva contraseña',
    //--------------------------------------------//
];