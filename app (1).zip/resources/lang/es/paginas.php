<?php
return [
   /*
 * |--------------------------------------------------------------------------
 * | Langs utilizados en los textos relacionados con menus
 * |--------------------------------------------------------------------------
*/


//PLACEHOLDERS
'placeholder_pagina_seleccione' => 'Seleccione menú',
'placeholder_pagina_seleccione_padre' => 'Seleccione menú padre',
'placeholder_pagina_seleccione_target' => 'Seleccione target',
'placeholder_pagina_seleccione_icono' => 'Seleccione icono',


//FORMULARIOS

'pagina_menu' => 'Menú',
'pagina_nombre' => 'Nombre',
'pagina_principal' => '¿Principal?',
'pagina_publicada' => '¿Publicada?',
'pagina_url' => 'Url',
'pagina_target' => 'Target',
'pagina_activo' => '¿Activo?',
'pagina_estado' => 'Estado',
'pagina_acciones' => 'Acciones',
'pagina_color' => 'Color',
'pagina_icono' => 'Icono',
'pagina_recurso' => 'Recurso',
'pagina_titulo' => 'Titulo',
'pagina_previsualizar' => 'Previsualizar',
'pagina_fecha_creacion'=>'Fecha creación',
'pagina_fecha_modificacion'=>'Fecha modificación',
'pagina_ultima_modificacion'=>'Ultima modificación',

//TITULOS
'pagina_title_guardadar_pagina'=>'Guardar Pagina',
'pagina_title_crear_menu'=>'Crear Menú',
'pagina_title_editar_pagina' => 'Editar página',
'pagina_title_administrar_pagina' => 'Administrar página',
'pagina_title_sin_modificacion'=>'Sin modificaciones',
'pagina_title_nombre_pagina'=>'Nombre página',

//TUTORIALES
'pagina_tutorial_iconos_seleccionar'=>'Si desea puede seleccionar directamente el icono desde aquí, solo hay que dar doble click',

//ALERTAS
'paginas_confirmacion_eliminar' => 'Esta seguro que desea eliminar la pagina?',
'paginas_eliminacion_exitosa' => 'Pagina eliminada con éxito!',
'paginas_visualizar_error' => '¡Debe guardar la página primero para poder visualizarla!',
'paginas_guardar_exito' => '¡La página se ha guardado con éxito!',

//BOTONES
'pagina_crear' => 'Crear página',

//TOOLTIP
'pagina_tooltip_editar_contenido' => 'Editar contenido',
'pagina_tooltip_editar_informacion' => 'Editar información',
'pagina_tooltip_eliminar' => 'Eliminar página',
'pagina_tooltip_ver_pagina' => 'Previsualizar página',


];

