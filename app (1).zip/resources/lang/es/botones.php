<?php
return [
    /*
 * |--------------------------------------------------------------------------
 * | Authentication Language Lines
 * |--------------------------------------------------------------------------
 * |
 * | The following language lines are used during authentication for various
 * | messages that we need to display to the user. You are free to modify
 * | these language lines according to your application's requirements.
 * |
 */
    'visualizar' => 'Visualizar',
    'solicitar' => 'Solicitar',
    'cancelar' => 'Cancelar',
    'eliminar' => 'Eliminar',
    'validar' => 'Validar',
    'limpiar' => 'Limpiar',
    'guardar' => 'Guardar',
    'cerrar' => 'Cerrar',
    'editar' => 'Editar',
    'buscar' => 'Buscar',
    'atras' => 'Atrás',
    'cambiar' => 'Cambiar',
    'cortar' => 'Cortar',
    'finalizar_galeria' => 'Incrustar galería',

    'title_intro' => 'Clic para visualizar las instrucciones',
    'descargar' => 'Descargar',
    'eestado_cuenta' => 'Estado de cuenta',
    'finalizar' => 'Finalizar',
    'siguiente' => 'Siguiente',
    'password' => 'Contraseña',
    'registrar' => 'Registrar',
    'anterior' => 'Anterior',
    'rechazar' => 'Rechazar',
    'aprobar' => 'Aprobar',
    'generar' => 'Generar',
    'subir_archivo' => 'Subir Archivo',
    'guardar_rapido' => 'Guardado rápido',
    'subir' => 'Subir',
    'subir_imagen' => 'Subir Imagen',
    'seguir_editando' => 'Seguir editando',
    'aceptar' => 'Aceptar'
    //--------------------------------------------//
];

