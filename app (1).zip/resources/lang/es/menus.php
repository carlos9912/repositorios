<?php
return [
   /*
 * |--------------------------------------------------------------------------
 * | Langs utilizados en los textos relacionados con menus
 * |--------------------------------------------------------------------------
*/


//PLACEHOLDERS
'placeholder_menu_seleccione' => 'Seleccione menú',
'placeholder_menu_seleccione_padre' => 'Seleccione menú padre',
'placeholder_menu_seleccione_target' => 'Seleccione donde mostrar',
'placeholder_menu_seleccione_icono' => 'Seleccione icono',


//FORMULARIOS

'menu' => 'Menú',
'menu_plural' => 'Menús',
'menu_nombre' => 'Nombre menú',
'menu_padre' => 'Menú padre',
'menu_url' => 'Url',
'menu_target' => 'Mostrar en',
'menu_activo' => '¿Activo?',
'menu_estado' => 'Estado',
'menu_acciones' => 'Acciones',
'menu_color' => 'Color',
'menu_icono' => 'Icono',
'menu_recurso' => 'Recurso',
'menu_previsualizar' => 'Previsualizar',

//TITULOS
'menu_title_listado_iconos'=>'Listado de iconos',
'menu_title_crear_menu'=>'Crear Menú',
'menu_title_crear_menu'=>'Crear Menú',

//TUTORIALES
'menu_tutorial_iconos_seleccionar'=>'Si desea puede seleccionar directamente el icono desde aquí, solo hay que dar doble click',

//ALERTAS
'menus_crear_exito' => '¡Menú creado con éxito!',
'menus_ordenado_fallo' => 'El ordenamiento del menú fallo, por favor verifique',
'menus_ordenado_exito' => '¡El ordenamiento del menú se realizó con exito!',

//TOOLTIP
'menus_tooltip_editar_menu' => 'Editar menú',
'menus_tooltip_ordenar_menu' => 'Ordenar',

];

