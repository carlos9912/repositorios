<?php
return [

    //Botones
    'wysiwyg_editor_tamaño_texto' => 'Tamaño del texto',
    'wysiwyg_editor_tipo_fuente' => 'Tipo fuente',
    'wysiwyg_editor_undo' => 'Rehace la última acción',
    'wysiwyg_editor_redo' => 'Deshace la última acción',
    'wysiwyg_editor_eliminar' => 'Elimina el texto seleccionado',
    'wysiwyg_editor_tamaño' => 'Modifica el tamaño del texto seleccionado',
    'wysiwyg_editor_fuente' => 'Modifica la fuente del texto seleccionado',
    'wysiwyg_editor_linea' => 'Aplica el formato de SUBRAYADO al texto seleccionado',
    'wysiwyg_editor_negrita' => 'Aplica el formato de NEGRITA al texto seleccionado',
    'wysiwyg_editor_cursiva' => 'Aplica el formato de CURSIVA al texto seleccionado',
    'wysiwyg_editor_tachado' => 'Tacha algo dibujando una línea encima',
    'wysiwyg_editor_color' => 'Cambia el color del texto seleccionado',
    'wysiwyg_editor_izquierda' => 'Alinea el contenido con el margen izquierdo',
    'wysiwyg_editor_centro' => 'Centra el contenido en el contenedor',
    'wysiwyg_editor_derecha' => 'Alinea el contenido con el margen derecho',
    'wysiwyg_editor_justificado' => 'Alinea el contenido de forma homogenea',
    'wysiwyg_editor_link' => 'Inserta un hipervínculo en el texto seleccionado',
    'wysiwyg_borde_inferior' => 'Inserta un borde en la posición inferior',
    'wysiwyg_borde_izquierda' => 'Inserta un borde en la posición izquierda',
    'wysiwyg_borde_derecha' => 'Inserta un borde en la posición derecha',
    'wysiwyg_borde_arriba' => 'Inserta un borde en la posición arriba',
    'wysiwyg_borde_horizontal' => 'Inserta un borde en el lado derecho e izquierdo',
    'wysiwyg_borde_vertical' => 'Inserta un borde en el lado superior e inferior',
    'wysiwyg_borde_total' => 'Inserta un borde en la todo el contenedor',
    'wysiwyg_sin_borde' => 'Elimina los bordes de un contenedor',
/*
 * |--------------------------------------------------------------------------
 * | Langs utilizados en la paleta de opciones del editor
 * |--------------------------------------------------------------------------
*/
    //Tools

    
    'tools_editor' => 'Editor',

    //Alineacion
    'tools_alineacion' => 'Alineación',
    'tools_alineacion_izquierda' => 'Izquierda',
    'tools_alineacion_derecha' => 'Derecha',
    'tools_alineacion_centro' => 'Centro',
    'tools_alineacion_justificada' => 'Justificada',

    //Color
    'tools_color' => 'Color',
    'tools_color_total' => 'Color Total',
    'tools_color_parcial' => 'Color Parcial',
    'tools_color_negro' => 'Negro',
    'tools_color_verde' => 'Verde',
    'tools_color_azul' => 'Azul',
    'tools_color_amarillo' => 'Amarillo',
    'tools_color_purpura' => 'Purpura',
    'tools_color_rosado' => 'Rosado',

    //Aumentar
    'tools_aumentar' => 'Aumentar',

    //Borde
    'tools_borde' => 'Borde',

    //Borde
    'tools_centrada' => 'Centrada',
    
    //Interlineado
    'tools_interlineado' => 'Interlineado',

    //Borde
    'tools_estilos' => 'Estilos',
    'tools_estilos_bordes_redondeado' => 'Bordes redondeados',
    'tools_estilos_circulo' => 'Imagen circular',
    'tools_estilos_bordes_exterior' => 'Bordes exterior',

    //Diseño
    'disenio_title' => 'Diseño',
    'disenio_columna_12' => '1 Columna de 12',
    'disenio_columna_12_instruccion' => 'Inserta una columna que ocupará todo el espacio del contenedor padre<br>En ella se podrán arrastrar textos y componentes',
    'disenio_columna_6' => '2 Columnas de 6',
    'disenio_columna_6_instruccion' => 'Inserta dos columnas que ocuparán todo el espacio del contenedor padre<br>En ella se podrán arrastrar textos y componentes',
    'disenio_columna_4' => '3 Columnas de 4',
    'disenio_columna_4_instruccion' => 'Inserta tres columnas que ocuparán todo el espacio del contenedor padre<br>En ella se podrán arrastrar textos y componentes',
    'disenio_columna_3' => '4 Columnas de 3',
    'disenio_columna_3_instruccion' => 'Inserta cuatro columnas que ocuparán todo el espacio del contenedor padre<br>En ella se podrán arrastrar textos y componentes',
    'disenio_columna_8_4' => '2 Columnas de 4-8',
    'disenio_columna_8_4_instruccion' => 'Inserta dos columnas que ocuparán todo el espacio del contenedor padre<br>En ella se podrán arrastrar textos y componentes',

    //Textos
    'textos_title' => 'Textos',

    //Titulo
    'textos_titulo' => 'Título',
    'textos_titulo_instruccion' => 'Inserta un título en un contenedor',
    'textos_titulo_contenido' => 'Titulo de tu publicación',

    //Divisor
    'textos_divisor' => 'Divisor',
    'textos_divisor_instruccion' => 'Inserta una línea que servirá como divisor entre un elemento y otro',
    'textos_divisor_bordes' => 'Bordes',
    'textos_divisor_con_bordes' => 'Con bordes',
    'textos_divisor_sin_bordes' => 'Sin bordes',
    'textos_divisor_delgado' => 'Delgado',
    'textos_divisor_normal' => 'Normal',
    'textos_divisor_ancho' => 'Ancho',

    //Parrafo
    'textos_parrafo' => 'Parrafo',
    'textos_parrafo_instruccion' => 'Inserta un párrafo en un contenedor',
    'textos_parrafo_contenido' => 'Lorem ipsum dolor sit amet, <strong>consectetur adipiscing elit</strong>. Aliquam eget sapien sapien. Curabitur in metus urna. In hac habitasse platea dictumst. Phasellus eu sem sapien, sed vestibulum velit. Nam purus nibh, lacinia non faucibus et, pharetra in dolor. Sed iaculis posuere diam ut cursus. <em>Morbi commodo sodales nisi id sodales. Proin consectetur, nisi id commodo imperdiet, metus nunc consequat lectus, id bibendum diam velit et dui.</em> Proin massa magna, vulputate nec bibendum nec, posuere nec lacus. <small>Aliquam mi erat, aliquam vel luctus eu, pharetra quis elit. Nulla euismod ultrices massa, et feugiat ipsum consequat eu. </small>',
    
    //Lista
    'textos_lista' => 'Lista',
    'textos_lista_instruccion' => 'Inserta una lista en un contenedor',

    //Lista Ordenada
    'textos_lista_ordenada' => 'Lista Ordenada',
    'textos_lista_ordenada_instruccion' => 'Inserta una lista ordenada por numeros que van de forma ascendente',
    
    //Descripcion
    'textos_descripcion' => 'Descripción',
    'textos_descripcion_instruccion' => 'Inserta una descripción en un contenedor',
    
    //Cita
    'textos_cita' => 'Cita',
    'textos_cita_instruccion' => 'Inserta una cita de un texto en un contenedor',


    //Componentes
    'componentes_title' => 'Componentes',

    //Tabla
    'componentes_tabla' => 'Tabla',
    'componentes_tabla_instruccion' => 'Inserta una tabla en un contenedor, esta tabla puede ser re-diseñada con la cantidad de columnas y filas necesarías',
    'componentes_tabla_rayas' => 'Rayas',
    'componentes_tabla_bordes' => 'Bordes',
    'componentes_tabla_seleccion' => 'Selección',
    'componentes_tabla_pequeña' => 'Pequeña',

    //Encabezado
    'componentes_encabezado' => 'Encabezado',
    'componentes_encabezado_instruccion' => 'Inserta un encabezado que contiene título y subtitulo en un contenedor',
    
    //Alerta
    'componentes_alerta' => 'Alerta',
    'componentes_alerta_instruccion' => 'Inserta una alerta en un contenedor',

    
    //Panel
    'componentes_panel' => 'Panel',
    'componentes_panel_instruccion' => 'Inserta un panel el cual es un contenedor, se podrán arrastrar elementos a él',

    //Panel Pestaña
    'componentes_panel_pestaña' => 'Panel con pestaña',
    'componentes_panel_pestaña_instruccion' => 'Inserta un panel que tiene dos secciones diferentes en un contenedor',
    
    //Tabla precio
    'componentes_tabla_precio' => 'Tabla de precio',
    'componentes_tabla_precio_instruccion' => 'Inserta una tabla de precios con tres opciones en un contenedor',
    
    //PDF
    'componentes_pdf' => 'PDF',
    'componentes_pdf_instruccion' => 'Inserta un PDF cuyo contenido podrá ser cambiado en el administrador de archivos',
    
    //Video
    'componentes_video' => 'Video',
    'componentes_video_instruccion' => 'Inserta un video cuyo contenido podrá ser cambiado por el que se desee',
    
    //Imagen
    'componentes_imagen' => 'Imagen',
    'componentes_imagen_instruccion' => 'Inserta una imagen que podrá ser cambiado en el administrador de archivos',

    
    //Imagen Link
    'componentes_imagen_link' => 'Imagen Link',
    'componentes_imagen_instruccion' => 'Inserta una imagen que podrá ser cambiado en el administrador de archivos',

    //Imagen Texto
    'componentes_imagen_texto' => 'Imagen con texto',
    'componentes_imagen_texto_instruccion' => 'Inserta una imagen que podrá ser cambiado en el administrador de archivos con un texto descriptivo',

    //Galeria
    'componentes_galeria' => 'Galería',
    'componentes_galeria_instruccion' => 'Inserta una galería en la cual se podrá agregar cualquier cantidad de imágenes',
];

