<?php
return [
    /*
 * |--------------------------------------------------------------------------
 * | Authentication Language Lines
 * |--------------------------------------------------------------------------
 * |
 * | The following language lines are used during authentication for various
 * | messages that we need to display to the user. You are free to modify
 * | these language lines according to your application's requirements.
 * |
 */
    'imagen_subir_editar' => 'Subir y editar imagen',
    'imagen_terminada' => 'Imagen terminada',
    'imagen_ancho' => 'Ancho',
    'imagen_alto' => 'Alto',
    'imagen_pixeles' => 'Pixeles',
    'imagen_dimension' => 'Las dimensiones de la imagen son alto: :ancho x ancho: :alto',
    'imagen_confirmacion_abrir' => 'Desea abrir el link de la imagen?',
    'imagen_url_ingresar' => 'Ingrese el url para enlazarlo con la imagen',
    'imagen_url_ingresar_error' => 'No se ingresó una ruta correcta',
    'imagen_subir_exito' => 'Imagen subida con éxito',
    'imagen_subir_editar_exito' => 'Imagen subida y editada con éxito',
    'imagen_subir_tutorial' => '<strong>Indicaciones!</strong>
                                <br>- Los archivos pueden ser <strong>JPG, PNG, GIF</strong>
                                <br>- Las imágenes serán subidas tal cual como se seleccione
                                <br>- El tamaño máximo permitido es de <strong>8 MB</strong>',
    'pdf_subir' => 'Subir PDF',
    'pdf_subir_tutorial' => '<strong>Indicaciones!</strong>
                                <br>- Solo se permiten archivos <strong>PDF</strong>
                                <br>- Las imágenes serán subidas tal cual como se seleccione
                                <br>- El tamaño máximo permitido es de <strong>8 MB</strong>',
    'pdf_subir_exito' => 'Pdf subido con éxito',
    'cambiar_video_title' => 'Cambiar video',

    'imagen_galeria_preview' => 'Previsualización de la galería generada',
    'imagen_galeria_seleccionada' => 'Imágenes seleccionadas',
    'imagen_galeria_seleccionar_archivos' => 'Seleccionar desde archivos guardados',
    'error_seleccione_imagenes_galeria' => 'No se han seleccionado imagenes para generar la galería',
    'error_seleccione_imagen' => 'Debe seleccionar una imagen desde el editor para poder cargar la imagen',
    'error_seleccione_pdf' => 'Debe seleccionar un pdf desde el editor para poder cargar el pdf',
    'error_seleccione_boton' => 'Debe seleccionar un botón desde el editor para asignarle el recurso',
    'error_crear_tablas' => 'Debe ingresar un valor mayor que 1 en filas y columnas',
    'error_crear_video' => 'Debe ingresar un video',
    
    'galeria' => 'Galería',
    'cancelar' => 'Cancelar',
    'eliminar' => 'Eliminar',
    'validar' => 'Validar',
    'limpiar' => 'Limpiar',
    'guardar' => 'Guardar',
    'cerrar' => 'Cerrar',
    'editar' => 'Editar',
    'buscar' => 'Buscar',
    'atras' => 'Atrás',

    'title_intro' => 'Clic para visualizar las instrucciones',
    'diligenciar_ahora' => 'Diligenciar ahora',
    'eestado_cuenta' => 'Estado de cuenta',
    'finalizar' => 'Finalizar',
    'siguiente' => 'Siguiente',
    'password' => 'Contraseña',
    'registrar' => 'Registrar',
    'anterior' => 'Anterior',
    'rechazar' => 'Rechazar',
    'aprobar' => 'Aprobar',
    'aceptar' => 'Aceptar'
    //--------------------------------------------//
];

