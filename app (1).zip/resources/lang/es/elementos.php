<?php
return [
    /*
 * |--------------------------------------------------------------------------
 * | Authentication Language Lines
 * |--------------------------------------------------------------------------
 * |
 * | The following language lines are used during authentication for various
 * | messages that we need to display to the user. You are free to modify
 * | these language lines according to your application's requirements.
 * |
 */
    'cambiar_video_instruccion' => 'Pega todo el texto copiado de la página que contiene el video',
    'cambiar_video_title' => 'Cambiar video',



    'seleccionar_fondo' => 'Selecciona un fondo',
    
    'galeria' => 'Galería',
    'cancelar' => 'Cancelar',
    'eliminar' => 'Eliminar',
    'validar' => 'Validar',
    'limpiar' => 'Limpiar',
    'guardar' => 'Guardar',
    'cerrar' => 'Cerrar',
    'editar' => 'Editar',
    'buscar' => 'Buscar',
    'atras' => 'Atrás',

    'title_intro' => 'Clic para visualizar las instrucciones',
    'diligenciar_ahora' => 'Diligenciar ahora',
    'eestado_cuenta' => 'Estado de cuenta',
    'finalizar' => 'Finalizar',
    'siguiente' => 'Siguiente',
    'password' => 'Contraseña',
    'registrar' => 'Registrar',
    'anterior' => 'Anterior',
    'rechazar' => 'Rechazar',
    'aprobar' => 'Aprobar',
    'aceptar' => 'Aceptar'
    //--------------------------------------------//
];

