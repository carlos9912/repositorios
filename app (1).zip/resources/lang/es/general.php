<?php


return [


/*


 * |--------------------------------------------------------------------------


 * | TITULOS DE NOTIFICACIONES


 * |--------------------------------------------------------------------------


 */





    //NAVBAR


    'navbar_pagina_title' => 'Paginas',


    'navbar_menu_title' => 'Menús',


    'navbar_configuracion_title' => 'Configuración',


    'navbar_galeria_title' => 'Galería',


    'navbar_sitio_title' => 'Sitio',


    'resetear_clave' => 'Contraseña reseteada con éxito! <br><br>Usuario: <b>:nombre</b> <br>Contraseña: <b>:pass</b>',


    





    //Titulos


    'title_crear_pagina' => 'Crear nueva página',


    'title_administrar_archivos' => 'Administrar archivos',


    'title_guardado_exito' => 'Guardado con éxito',


    'title_guardado_exito_descripcion' => 'La página se ha guardado con éxito',





    //Dashboard


 


    //Crear


    'crear_pagina_title' => 'Crear nueva página',


    'crear_pagina_detalle' => 'Crea una nueva página en el sitio',


    'crear_pagina_btn' => 'Crear página',





    //Editar


    'editar_pagina_title' => 'Editar una página',


    'editar_pagina_detalle' => 'Se puede editar una página existente',


    'editar_pagina_btn' => 'Editar página',


    


    //Administrar


    'administrar_pagina_title' => 'Administrar paginas',


    'administrar_pagina_detalle' => 'Administrar las paginas existentes',


    'administrar_pagina_btn' => 'Administrar paginas',


    


    //Visualizar


    'ver_sitio_title' => 'Ver Sitio',


    'ver_sitio_detalle' => 'Visualiza el sitio creado',


    'ver_sitio_btn' => 'Ver sitio',





    //Menus


    'administrar_menu_title' => 'Administrar menús',


    'administrar_menu_detalle' => 'Administrar los menús de las paginas',


    'administrar_menu_btn' => 'Administrar menús',





    //Galeria


    'galeria_title' => 'Administrar Galería Principal',


    'galeria_detalle' => 'Administrar la galería de la página principal',


    'galeria_btn' => 'Administrar galería',





    


    //Configuracion Principal


    'configuracion_principal_title' => 'Configuraciones Principales',


    'configuracion_principal_detalle' => 'Administrar las configuraciones principales',


    'configuracion_principal_btn' => 'Ir a configuraciones',





    


    //Footer


    'footer_principal_title' => 'Footer',


    'footer_principal_detalle' => 'Administrar el footer del sitio',


    'footer_principal_btn' => 'Editar footer',





    'copyright' => '© Bayron Tarazona - 2019',


    'atencion' => 'Atención',


    'inicio_sesion_title' => 'Editor de contenido',


    'inicio_sesion_subtitle' => 'Ingresa la información para iniciar sesión',


    'inicio_sesion_btn' => 'Ingresar',


    'size_failed' => 'El peso del archivo no puede exceder 8 MB',


    'extension_failed' => 'La extensión del archivo no es la correcta (:ext)',


    'format_datetime' => 'd-m-y, h:i a',


    'format_date' => 'd-m-y',


    'format_time' => 'H:i a',





    


];





